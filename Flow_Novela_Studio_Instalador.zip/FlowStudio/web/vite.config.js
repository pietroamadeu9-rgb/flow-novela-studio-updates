import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from 'tailwindcss';
import autoprefixer from 'autoprefixer';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  root: dir,
  plugins: [react()],
  css: {
    postcss: {
      plugins: [
        tailwindcss({
          content: [path.join(dir, 'index.html'), path.join(dir, 'src/**/*.{js,jsx}')],
          theme: {
            extend: {
              fontFamily: { sans: ['Inter', 'Segoe UI', 'system-ui', 'sans-serif'] },
              colors: {
                studio: {
                  950: '#0B0D12', 900: '#12151E', 850: '#161A24', 800: '#1B202C',
                  700: '#232938', 600: '#2E364A', 500: '#46506B',
                },
              },
            },
          },
        }),
        autoprefixer(),
      ],
    },
  },
  build: { outDir: path.join(dir, 'dist'), emptyOutDir: true, chunkSizeWarningLimit: 1500 },
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    proxy: {
      '/api': 'http://127.0.0.1:3456',
      '/media': 'http://127.0.0.1:3456',
      '/ws': { target: 'ws://127.0.0.1:3456', ws: true },
    },
  },
});
