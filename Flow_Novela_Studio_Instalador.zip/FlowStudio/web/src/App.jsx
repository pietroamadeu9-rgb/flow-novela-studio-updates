import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Clapperboard, Plus, Play, Pause, Plug, PlugZap, ScanSearch, Server, ChevronDown, ChevronUp, Activity, Settings2, Volume2, VolumeX, Scissors, Bot, AlertTriangle, Gauge, RotateCcw, RefreshCw, CheckCircle2, Smartphone, Copy, Lock, Wifi,
} from 'lucide-react';

/** Dois tons suaves (sucesso) ou um tom grave (erro) via Web Audio. */
function tocarAlerta(tipo) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const notas = tipo === 'erro' ? [[330, 0], [247, 0.22]] : [[659, 0], [880, 0.18]];
    for (const [freq, atraso] of notas) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = freq;
      const t = ctx.currentTime + atraso;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.18, t + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + 0.5);
    }
    setTimeout(() => ctx.close(), 1500);
  } catch {}
}
import { api, fab, useStudio, progressoNovela } from './api.js';
import { Modal, Toasts, Vazio } from './components/ui.jsx';
import NovelaView from './components/NovelaView.jsx';
import SeletoresQualidade from './components/SeletoresQualidade.jsx';
import FabricaClaude from './components/FabricaClaude.jsx';
import ListaNovelas from './components/ListaNovelas.jsx';

const ROTULO_ETAPA_COTA = {
  roteiro: 'Roteiro',
  prompts: 'Prompts',
  sementes: 'Sementes',
  automatico: 'Automático',
  serie: 'Nova Parte',
  parte: 'Nova Parte',
  regerar: 'Reescrita',
  ficha: 'Ficha viral',
  reparo_validador: 'Auto-reparo',
  reparo_bloqueio: 'Suavizar Flow',
};

export default function App() {
  const studio = useStudio();
  const { novelas, extensao, fila, domMap, claudeCli, tunel, servidorOnline, logs } = studio;
  const [selecionada, setSelecionada] = useState(() => new URLSearchParams(location.search).get('novela') || localStorage.getItem('fns.novela') || null);
  const [aba, setAba] = useState(() => new URLSearchParams(location.search).get('aba') || localStorage.getItem('fns.aba') || 'estudio'); // 'estudio' | 'fabrica'
  const mudarAba = (a) => { setAba(a); localStorage.setItem('fns.aba', a); };
  const [modalNova, setModalNova] = useState(false);
  const [nomeNova, setNomeNova] = useState('');
  const [toasts, setToasts] = useState([]);
  const [logAberto, setLogAberto] = useState(false);
  const [modalPadroes, setModalPadroes] = useState(() => new URLSearchParams(location.search).get('padroes') === '1');
  const [aplicarPendentesPadroes, setAplicarPendentesPadroes] = useState(true);
  const [mudo, setMudo] = useState(() => localStorage.getItem('fns.mudo') === '1');
  const [capcut, setCapcut] = useState(null);
  const [caminhoCapcut, setCaminhoCapcut] = useState('');
  const [cota, setCota] = useState(null);
  const [popoverCota, setPopoverCota] = useState(() => new URLSearchParams(location.search).get('popoverCota') === '1');
  const [pctCalibracao, setPctCalibracao] = useState('2.7');
  const [pct5hRealInput, setPct5hRealInput] = useState('');
  const [modalCelular, setModalCelular] = useState(false);
  const [infoRede, setInfoRede] = useState(null);
  const [abaQrRede, setAbaQrRede] = useState('tunel');
  const [operandoTunel, setOperandoTunel] = useState(false);
  const [trocandoPin, setTrocandoPin] = useState(false);
  const [gavetaMobileAberta, setGavetaMobileAberta] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [wakeLockAtivo, setWakeLockAtivo] = useState(false);
  const [infoUpdate, setInfoUpdate] = useState(null);
  const [atualizandoApp, setAtualizandoApp] = useState(false);
  const rodavaAntes = useRef(false);
  const wakeLockRef = useRef(null);

  // Screen Wake Lock API: evita que o navegador/celular suspenda a aba enquanto a fila estiver rodando
  useEffect(() => {
    let cancelado = false;
    const requisitarWakeLock = async () => {
      if (!fila.rodando || !navigator.wakeLock?.request) {
        if (wakeLockRef.current) {
          try { await wakeLockRef.current.release(); } catch {}
          wakeLockRef.current = null;
        }
        if (!cancelado) setWakeLockAtivo(false);
        return;
      }
      try {
        if (!wakeLockRef.current) {
          const sentinel = await navigator.wakeLock.request('screen');
          sentinel.addEventListener?.('release', () => {
            if (wakeLockRef.current === sentinel) wakeLockRef.current = null;
            if (!cancelado) setWakeLockAtivo(false);
          });
          wakeLockRef.current = sentinel;
        }
        if (!cancelado) setWakeLockAtivo(true);
      } catch {
        if (!cancelado) setWakeLockAtivo( Boolean(fila.wakeLockAtivo) );
      }
    };
    requisitarWakeLock();
    const aoMudarVisibilidade = () => {
      if (document.visibilityState === 'visible' && fila.rodando) requisitarWakeLock();
    };
    document.addEventListener('visibilitychange', aoMudarVisibilidade);
    return () => {
      cancelado = true;
      document.removeEventListener('visibilitychange', aoMudarVisibilidade);
    };
  }, [fila.rodando, fila.wakeLockAtivo]);

  const recarregarInfoRede = useCallback(() => {
    api.rede().then((r) => {
      setInfoRede(r);
      if (r?.tunel) studio.setTunel?.(r.tunel);
      setAbaQrRede((atual) => (r?.tunel?.url ? 'tunel' : atual === 'tunel' && !r?.tunel?.url ? 'wifi' : atual));
    }).catch(() => {});
  }, [studio]);

  const abrirModalCelular = () => {
    setModalCelular(true);
    recarregarInfoRede();
  };

  const recarregarCota = useCallback(() => {
    fab.cota().then((d) => {
      setCota(d);
      if (d?.calibracao?.pctPorHistoriaPadrao) setPctCalibracao(String(d.calibracao.pctPorHistoriaPadrao));
      if (typeof d?.janela5h?.percentual === 'number') setPct5hRealInput(String(d.janela5h.percentual));
    }).catch(() => {});
  }, []);

  useEffect(() => {
    recarregarCota();
    const t = setInterval(recarregarCota, 12000);
    return () => clearInterval(t);
  }, [recarregarCota]);

  // Verifica silenciosamente ao abrir o app se há versão nova publicada no GitHub
  useEffect(() => {
    api.updateVerificar().then((st) => {
      if (st) setInfoUpdate(st);
    }).catch(() => {});
  }, []);

  const acionarAutoUpdate = async () => {
    if (atualizandoApp) return;
    setAtualizandoApp(true);
    try {
      const check = await api.updateVerificar();
      setInfoUpdate(check);
      if (!check?.configurado) {
        toast(check?.motivo || 'Repositório GitHub ainda não configurado neste PC.', 'info');
        return;
      }
      if (check?.erro) {
        toast(`Não foi possível consultar o GitHub: ${check.erro}`, 'erro');
        return;
      }
      if (!check?.atualizacaoDisponivel) {
        toast(`✅ Você já está na versão mais recente (v${check.versaoLocal}).`, 'ok');
        return;
      }
      toast(`⬇️ Baixando atualização v${check.versaoRemota} do GitHub...`, 'info');
      const res = await api.updateAplicar({
        zipUrl: check.zipUrl,
        versaoAlvo: check.versaoRemota,
      });
      toast(
        `✅ Atualizado para v${res?.versaoNova || check.versaoRemota}${res?.extensaoMudou ? ' (extensão Chrome recarregada)' : ''}! Recarregando painel...`,
        'ok'
      );
      setTimeout(() => {
        window.location.reload();
      }, 1800);
    } catch (e) {
      toast(e.message || 'Falha ao atualizar.', 'erro');
    } finally {
      setAtualizandoApp(false);
    }
  };

  // alerta sonoro suave quando a fila termina ou para por erro
  useEffect(() => {
    if (rodavaAntes.current && !fila.rodando && !mudo) {
      const recente = logs.slice(-6).some((l) => l.nivel === 'erro' && Date.now() - new Date(l.t).getTime() < 60000);
      tocarAlerta(recente ? 'erro' : 'ok');
    }
    rodavaAntes.current = fila.rodando;
  }, [fila.rodando]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!modalPadroes) return;
    api.statusCapcut().then((s) => { setCapcut(s); setCaminhoCapcut(studio.config.capcutDraftsPath || s.pasta || ''); }).catch(() => {});
  }, [modalPadroes]); // eslint-disable-line react-hooks/exhaustive-deps

  const toast = useCallback((msg, tipo = 'info') => {
    const id = Math.random();
    setToasts((t) => [...t, { id, msg, tipo }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), tipo === 'erro' ? 7000 : 3500);
  }, []);

  const executar = useCallback(async (fn, ok) => {
    try { const r = await fn(); if (ok) toast(ok, 'ok'); return r; }
    catch (e) { toast(e.message, 'erro'); return null; }
  }, [toast]);

  useEffect(() => {
    if (selecionada) localStorage.setItem('fns.novela', selecionada);
    if (novelas.length && !novelas.find((n) => n.id === selecionada)) {
      const ativaRecente = [...novelas].reverse().find((n) => Array.isArray(n.itens) && n.itens.length > 0);
      setSelecionada((ativaRecente || novelas[novelas.length - 1]).id);
    }
  }, [novelas, selecionada]);

  const novela = novelas.find((n) => n.id === selecionada) || null;

  const statusCurtoFila = useMemo(() => {
    if (fila.rodando) {
      if (fila.pausaSolicitada) {
        return { rotulo: 'Pausando após item atual...', cor: 'text-amber-200 border-amber-500/40 bg-amber-500/15' };
      }
      if (fila.modoIsolado) {
        return { rotulo: `Regenerando ${fila.itemAtual ? `{${fila.itemAtual}}` : 'cena'} (Fila pausada)`, cor: 'text-fuchsia-200 border-fuchsia-500/40 bg-fuchsia-500/15' };
      }
      const nAtiva = novelas.find((n) => n.id === fila.novelaAtual) || novela;
      if (nAtiva) {
        const p = progressoNovela(nAtiva);
        const refCount = p.videos.total ? `${p.videos.feito}/${p.videos.total}` : `${p.todos.feito}/${p.todos.total}`;
        return { rotulo: `Rodando ${refCount}`, cor: 'text-amber-300 border-amber-500/30 bg-amber-500/10' };
      }
      return { rotulo: 'Rodando', cor: 'text-amber-300 border-amber-500/30 bg-amber-500/10' };
    }
    if (fila.pausado) {
      const nPausada = novelas.find((n) => n.id === (fila.novelaPausadaId || fila.fila?.[0]));
      return {
        rotulo: nPausada ? `Pausado · ${nPausada.nome}` : 'Fila Pausada',
        cor: 'text-amber-200 border-amber-500/40 bg-amber-500/15',
      };
    }
    const comItens = novelas.filter((n) => Array.isArray(n.itens) && n.itens.length > 0);
    if (comItens.length > 0 && comItens.every((n) => n.concluidaManualmente || n.itens.every((i) => i.status === 'concluido'))) {
      return { rotulo: 'Concluído', cor: 'text-emerald-300 border-emerald-500/25 bg-emerald-500/10' };
    }
    return { rotulo: 'Pronto', cor: 'text-zinc-400 border-white/[0.07] bg-studio-850/70' };
  }, [fila.rodando, fila.pausado, fila.pausaSolicitada, fila.modoIsolado, fila.itemAtual, fila.novelaAtual, fila.novelaPausadaId, fila.fila, novelas, novela]);

  const criar = async () => {
    const n = await executar(() => api.criarNovela(nomeNova), 'Novela criada!');
    if (n) { studio.upsert(n); setSelecionada(n.id); setModalNova(false); setNomeNova(''); }
  };

  const salvarPadroes = async (patch, msg = 'Padrões salvos', opcoes = {}) => {
    const c = await executar(
      () => api.atualizarConfig({ ...(studio.config.padroes || {}), ...patch }, { aplicarNasPendentes: aplicarPendentesPadroes, ...opcoes }),
      msg,
    );
    if (c) studio.setConfig(c);
  };

  const pct5h = cota?.janela5h?.percentual ?? 0;
  const pctSem = cota?.semana7d?.percentual ?? 0;

  // SEGURANCA BLINDADA: Visitantes externos (ex.: https://*.trycloudflare.com) sem PIN autenticado so veem a tela de bloqueio!
  if (studio.pinBloqueado) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-studio-950 p-4 text-zinc-200">
        <div className="card w-full max-w-sm space-y-4 border border-white/[0.1] bg-studio-900 p-6 shadow-2xl">
          <div className="flex flex-col items-center gap-2 text-center">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-lg shadow-fuchsia-950/50">
              <Lock size={20} className="text-white" />
            </div>
            <h1 className="text-base font-bold text-white">Flow Novela Studio</h1>
            <p className="text-xs text-zinc-400">
              Acesso remoto protegido por PIN. Digite o PIN exibido no modal <b className="text-zinc-200">📱 Celular</b> na tela do seu PC.
            </p>
          </div>
          <input
            type="password"
            inputMode="numeric"
            autoFocus
            placeholder="PIN de 6 dígitos"
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && pinInput.trim()) {
                executar(() => studio.autenticarPin(pinInput.trim()), '🔓 Acesso liberado!');
              }
            }}
            className="input py-2.5 text-center font-mono text-lg tracking-widest text-white"
          />
          <button
            type="button"
            className="btn-primary w-full justify-center py-2.5 text-sm"
            disabled={!pinInput.trim()}
            onClick={() => executar(() => studio.autenticarPin(pinInput.trim()), '🔓 Acesso liberado!')}
          >
            <Lock size={15} /> Desbloquear Estúdio
          </button>
          <p className="text-center text-[11px] text-zinc-500">
            O PIN ficará salvo no navegador do seu iPhone para não precisar redigitar.
          </p>
        </div>
        <Toasts toasts={toasts} />
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col bg-studio-950">
      {/* ======== HEADER GLOBAL CLEAN ======== */}
      <header className="flex h-12 shrink-0 items-center justify-between gap-3 border-b border-white/[0.07] bg-studio-900/90 px-4 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-sm shadow-fuchsia-950/50">
              <Clapperboard size={15} className="text-white" />
            </div>
            <span className="text-sm font-semibold tracking-tight text-white">Flow Novela Studio</span>
          </div>

          {/* Pill compacto de status da fila */}
          <div
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium ${statusCurtoFila.cor}`}
            title={fila.mensagem || statusCurtoFila.rotulo}
          >
            {fila.rodando ? <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-amber-400" /> : <Activity size={11} />}
            <span>{statusCurtoFila.rotulo}</span>
            {fila.tentativaAtual > 0 && (
              <span className="ml-1 rounded bg-amber-500/20 px-1 text-[10px] font-semibold text-amber-200">
                {fila.tentativaAtual}/3
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Pill unico Claude + Cota com Popover */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                const abrir = !popoverCota;
                setPopoverCota(abrir);
                if (abrir) {
                  recarregarCota();
                  api.statusClaude().then((c) => studio.setClaudeCli(c)).catch(() => {});
                }
              }}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-medium transition ${
                claudeCli?.disponivel
                  ? 'border-white/[0.08] bg-studio-850 text-zinc-200 hover:border-violet-500/40 hover:bg-studio-800'
                  : 'border-white/[0.06] bg-studio-850/60 text-zinc-400 hover:text-zinc-200'
              }`}
              title={
                claudeCli?.disponivel
                  ? `Claude Code CLI (${claudeCli.versao}) · Clique para abrir o painel de cotas (5h / Semana)`
                  : 'Claude CLI em modo fallback local · Clique para ver painel de cotas'
              }
            >
              <Bot size={13} className={claudeCli?.disponivel ? 'text-fuchsia-400' : 'text-zinc-500'} />
              <span>Opus + Sonnet</span>
              <span className="text-zinc-600">·</span>
              <Gauge size={12} className={pct5h >= 80 ? 'text-red-400' : pct5h >= 50 ? 'text-amber-300' : 'text-emerald-400'} />
              <span>5h: <b className="text-white">{pct5h}%</b></span>
              <span className="text-zinc-600">·</span>
              <span>Sem: <b className="text-zinc-300">{pctSem}%</b></span>
            </button>

            {popoverCota && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setPopoverCota(false)} />
                <div className="absolute right-0 top-full z-50 mt-1.5 w-96 max-w-[calc(100vw-1.5rem)] rounded-xl border border-white/[0.1] bg-studio-900 p-3.5 text-xs shadow-2xl">
                  <div className="mb-3 flex items-center justify-between border-b border-white/[0.07] pb-2">
                    <div className="flex items-center gap-1.5 font-semibold text-white">
                      <Bot size={14} className="text-fuchsia-400" />
                      <span>Painel de Cota Claude (Opus + Sonnet)</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={`rounded px-1.5 py-0.5 text-[10px] ${claudeCli?.disponivel ? 'bg-emerald-500/15 text-emerald-300' : 'bg-zinc-700 text-zinc-400'}`}>
                        {claudeCli?.disponivel ? 'CLI Ativo' : 'Fallback'}
                      </span>
                      <button type="button" className="rounded p-1 text-zinc-400 hover:bg-studio-800 hover:text-white" title="Atualizar" onClick={recarregarCota}>
                        <RefreshCw size={12} />
                      </button>
                    </div>
                  </div>

                  {/* Janela de 5 Horas */}
                  <div className="mb-3 rounded-lg border border-white/[0.06] bg-studio-950/80 p-2.5">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="font-medium text-zinc-200">Janela Móvel de 5 horas</span>
                      <span className={`font-bold ${pct5h >= 80 ? 'text-red-400' : pct5h >= 50 ? 'text-amber-300' : 'text-emerald-400'}`}>{pct5h}%</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-studio-800">
                      <div
                        className={`h-full rounded-full transition-all ${pct5h >= 80 ? 'bg-red-500' : pct5h >= 50 ? 'bg-amber-400' : 'bg-emerald-500'}`}
                        style={{ width: `${Math.min(100, pct5h)}%` }}
                      />
                    </div>
                    <div className="mt-1.5 flex items-center justify-between text-[11px] text-zinc-500">
                      <span>
                        {cota?.janela5h?.chamadas || 0} chamada(s) · ~{(cota?.janela5h?.tokensEstimados || 0).toLocaleString('pt-BR')} tok
                        {cota?.janela5h?.custoUsd > 0 ? ` · $${Number(cota.janela5h.custoUsd).toFixed(2)}` : ''}
                      </span>
                      <span>
                        {cota?.janela5h?.liberaTotalEm
                          ? `Libera às ${new Date(cota.janela5h.liberaTotalEm).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`
                          : 'Janela livre'}
                      </span>
                    </div>
                  </div>

                  {/* Consumo por modelo (Opus pesa mais que Sonnet) */}
                  {cota?.janela5h?.porModelo && Object.keys(cota.janela5h.porModelo).length > 0 && (
                    <div className="mb-3 rounded-lg border border-white/[0.06] bg-studio-950/80 p-2.5">
                      <div className="mb-1.5 flex items-center justify-between">
                        <span className="font-medium text-zinc-200">Por modelo (janela de 5h)</span>
                        <span className="text-[10px] text-zinc-500">peso: Sonnet {cota?.pesosModelo?.sonnet ?? 1}x · Opus {cota?.pesosModelo?.opus ?? 5}x</span>
                      </div>
                      <div className="space-y-1">
                        {Object.entries(cota.janela5h.porModelo).map(([m, v]) => (
                          <div key={m} className="flex items-center justify-between text-[11px] text-zinc-400">
                            <span className={`font-medium ${m === 'opus' ? 'text-amber-300' : 'text-sky-300'}`}>{m === 'opus' ? 'Opus' : 'Sonnet'}</span>
                            <span>{v.chamadas || 0} chamada(s) · ~{(v.tokensPonderados || 0).toLocaleString('pt-BR')} tok</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Semana (7 dias) com meta de 60% */}
                  <div className="mb-3 rounded-lg border border-white/[0.06] bg-studio-950/80 p-2.5">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="font-medium text-zinc-200">Semana (7 dias) <span className="text-[10px] font-normal text-zinc-500">· meta 60%</span></span>
                      <span className="font-bold text-violet-300">{pctSem}%</span>
                    </div>
                    <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-studio-800">
                      <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all" style={{ width: `${Math.min(100, pctSem)}%` }} />
                      <div className="absolute inset-y-0 left-[60%] w-0.5 bg-white/40" title="Meta visual de 60%" />
                    </div>
                    <div className="mt-1.5 flex items-center justify-between text-[11px] text-zinc-500">
                      <span>{cota?.semana7d?.historias || 0} história(s) na semana</span>
                      <span>Hoje (24h): {cota?.hoje24h?.chamadas || 0} cham. (~{cota?.hoje24h?.percentual5hEquiv || 0}%)</span>
                    </div>
                  </div>

                  {/* Historico das ultimas 8 chamadas */}
                  <div className="mb-3">
                    <div className="label mb-1.5">Últimas chamadas ({cota?.ultimasChamadas?.length || 0})</div>
                    {(!cota?.ultimasChamadas || cota.ultimasChamadas.length === 0) ? (
                      <div className="rounded-lg border border-white/[0.05] bg-studio-950/50 py-3 text-center text-[11px] text-zinc-500">
                        Nenhuma chamada registrada ainda nesta janela.
                      </div>
                    ) : (
                      <div className="max-h-40 space-y-1 overflow-y-auto pr-0.5">
                        {cota.ultimasChamadas.map((ch, idx) => (
                          <div key={idx} className="flex items-center justify-between gap-2 rounded-md border border-white/[0.05] bg-studio-950/70 px-2 py-1 text-[11px]">
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5">
                                <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${ch.ok ? 'bg-emerald-400' : 'bg-red-400'}`} />
                                <span className="font-medium text-zinc-200">{String(ch.tipo || '').endsWith('_ideacao') ? `${ROTULO_ETAPA_COTA[String(ch.tipo).replace(/_ideacao$/, '')] || 'Roteiro'} · escaleta` : (ROTULO_ETAPA_COTA[ch.tipo] || ch.tipo)}</span>
                                {ch.modeloRotulo && <span className={`rounded px-1 text-[9.5px] ${ch.modelo === 'opus' ? 'bg-amber-500/15 text-amber-300' : 'bg-sky-500/15 text-sky-300'}`} title={`Peso ${ch.pesoModelo || 1}x na cota`}>{ch.modeloRotulo}{ch.pesoModelo > 1 ? ` ${ch.pesoModelo}x` : ''}</span>}
                                <span className="truncate text-zinc-500">· {ch.novelaTitulo}</span>
                              </div>
                            </div>
                            <div className="shrink-0 text-right font-mono text-[10.5px] text-zinc-400">
                              <span>{Math.max(1, Math.round((ch.duracaoMs || 0) / 1000))}s</span>
                              <span className="ml-1.5 text-fuchsia-300">~{ch.percentual5h}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Zerar / Recalibrar */}
                  <div className="space-y-2 border-t border-white/[0.07] pt-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                        <span>% 5h real:</span>
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          max="100"
                          value={pct5hRealInput}
                          onChange={(e) => setPct5hRealInput(e.target.value)}
                          className="w-14 rounded border border-white/[0.1] bg-studio-950 px-1.5 py-0.5 text-center text-[11px] text-white"
                          title="Digite o percentual atual mostrado na sua conta Claude para sincronizar a barra de 5h"
                        />
                        <button
                          type="button"
                          className="btn-ghost px-2 py-0.5 text-[10.5px]"
                          onClick={() => executar(() => fab.calibrarCota({ percentual5hAtualReal: Number(pct5hRealInput) || 0 }), 'Percentual 5h sincronizado').then((d) => d && setCota(d))}
                        >
                          Sincronizar
                        </button>
                      </div>
                      <button
                        type="button"
                        className="btn-ghost px-2 py-0.5 text-[10.5px] text-zinc-400 hover:text-white"
                        title="Zera a contagem da janela atual de 5h"
                        onClick={() => executar(() => fab.calibrarCota({ zerarJanela5h: true }), 'Janela de 5h zerada').then((d) => d && setCota(d))}
                      >
                        <RotateCcw size={11} /> Zerar 5h
                      </button>
                    </div>
                    <div className="flex items-center justify-between gap-1.5 text-[11px] text-zinc-400">
                      <span>Peso padrão %/história (Sonnet):</span>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          step="0.1"
                          min="0.5"
                          max="25"
                          value={pctCalibracao}
                          onChange={(e) => setPctCalibracao(e.target.value)}
                          className="w-14 rounded border border-white/[0.1] bg-studio-950 px-1.5 py-0.5 text-center text-[11px] text-white"
                        />
                        <button
                          type="button"
                          className="btn-ghost px-2 py-0.5 text-[10.5px]"
                          onClick={() => executar(() => fab.calibrarCota({ pctPorHistoriaPadrao: Number(pctCalibracao) || 2.7 }), 'Calibração atualizada').then((d) => d && setCota(d))}
                        >
                          Calibrar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          <button
            className="btn-ghost px-2 py-1 text-xs"
            title={mudo ? 'Ativar alerta sonoro' : 'Silenciar alerta sonoro'}
            onClick={() => { const v = !mudo; setMudo(v); localStorage.setItem('fns.mudo', v ? '1' : '0'); if (!v) tocarAlerta('ok'); }}
          >
            {mudo ? <VolumeX size={13} /> : <Volume2 size={13} />}
          </button>

          <button
            className={`btn-ghost px-2.5 py-1 text-xs ${
              infoUpdate?.atualizacaoDisponivel
                ? 'border border-emerald-500/40 bg-emerald-500/15 text-emerald-200 hover:bg-emerald-500/25'
                : 'text-zinc-300 hover:text-white'
            }`}
            disabled={atualizandoApp}
            title={
              infoUpdate?.atualizacaoDisponivel
                ? `Nova versão v${infoUpdate.versaoRemota} disponível no GitHub! Clique para atualizar preservando suas novelas e configurações`
                : `Verificar atualizações no GitHub${infoUpdate?.versaoLocal ? ` (versão atual v${infoUpdate.versaoLocal})` : ''}`
            }
            onClick={acionarAutoUpdate}
          >
            <RefreshCw size={13} className={atualizandoApp ? 'animate-spin text-emerald-300' : ''} />
            <span className="hidden sm:inline">
              {atualizandoApp
                ? 'Atualizando...'
                : infoUpdate?.atualizacaoDisponivel
                  ? `🔄 Atualizar (v${infoUpdate.versaoRemota})`
                  : '🔄 Atualizar'}
            </span>
          </button>

          <button
            className="btn-ghost px-2.5 py-1 text-xs text-sky-300 hover:text-white"
            title="Abrir controle remoto no celular (Wi-Fi Local ou Tailscale + QR Code)"
            onClick={abrirModalCelular}
          >
            <Smartphone size={13} /> <span className="hidden sm:inline">📱 Celular</span>
          </button>

          <button className="btn-ghost px-2.5 py-1 text-xs" title="Padrões globais de qualidade e modelos" onClick={() => setModalPadroes(true)}>
            <Settings2 size={13} /> <span className="hidden sm:inline">Padrões</span>
          </button>

          {/* Pill compacto Mapa do Flow */}
          <span
            className={`hidden items-center gap-1 rounded-lg border px-2 py-1 text-[11px] lg:inline-flex ${
              domMap.existe ? 'border-sky-500/25 bg-sky-500/10 text-sky-300' : 'border-white/[0.06] bg-studio-850 text-zinc-500'
            }`}
            title={
              domMap.existe
                ? `Mapa do Flow: ${domMap.capturas} captura(s) · ${domMap.elementos} elementos · Atualizado em ${new Date(domMap.atualizadoEm).toLocaleString('pt-BR')}`
                : 'Use o botão "Mapear Botões do Google Flow" na extensão'
            }
          >
            <ScanSearch size={12} />
            <span>{domMap.existe ? 'Flow Mapeado' : 'Flow s/ Mapa'}</span>
          </span>

          {!servidorOnline && (
            <span className="inline-flex items-center gap-1 rounded-lg border border-red-500/40 bg-red-500/10 px-2 py-1 text-[11px] text-red-300">
              <Server size={12} /> Offline
            </span>
          )}

          {/* Pill compacto Extensao */}
          <span
            className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-[11px] font-medium ${
              extensao.conectada ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-300'
            }`}
            title={
              extensao.conectada
                ? `Extensão Conectada · Versão ${extensao.info?.versao || '?'}${extensao.info?.flowAberto ? ' · aba do Google Flow aberta' : ' · nenhuma aba do Flow aberta'}`
                : 'Aguardando Extensão Chrome — carregue a pasta extensao-chrome em chrome://extensions'
            }
          >
            {extensao.conectada ? <PlugZap size={12} /> : <Plug size={12} className="pulse-dot" />}
            <span>{extensao.conectada ? 'Extensão OK' : 'Extensão...'}</span>
          </span>
        </div>
      </header>

      {/* ======== BARRA SUPERIOR (Apenas Estúdio & Fila Flow — Fábrica Claude removida) ======== */}
      <nav className="flex shrink-0 items-center justify-between gap-2 border-b border-white/[0.07] bg-studio-900/60 px-4">
        <div className="flex items-center gap-2 border-b-2 border-fuchsia-500 px-3 py-2 text-xs font-medium text-white">
          🎬 Estúdio & Fila Flow
        </div>
        <div className="flex items-center gap-2 text-[11px] text-zinc-500">
          {(wakeLockAtivo || fila.wakeLockAtivo) && (
            <span className="rounded border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-300" title="Prevenção de suspensão ativa no navegador e no Windows">
              ⚡ Anti-Suspensão Ativo
            </span>
          )}
          <span className="hidden sm:inline">Parser 100% local · Fila global autônoma</span>
        </div>
      </nav>

      {/* Banner amigavel de creditos esgotados (Etapa 2) */}
      {(fila.motivoPausa === 'creditos_esgotados' || fila.alertaCreditos?.ativo) && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-500/40 bg-amber-500/15 px-5 py-2.5 text-xs text-amber-100">
          <div className="flex items-center gap-2.5">
            <AlertTriangle size={15} className="shrink-0 text-amber-300" />
            <span>
              <b className="text-amber-200">Créditos esgotados nesta conta!</b> Troque para outra conta na aba do Google Flow e clique em <b>Rodar/Continuar</b> — o estúdio criará um novo projeto na nova conta e continuará da cena exata onde parou
              {fila.alertaCreditos?.itemId ? ` ({${fila.alertaCreditos.itemId}})` : ''}.
            </span>
          </div>
          <button
            className="btn-primary py-1 text-xs"
            onClick={() => {
              const alvoId = fila.alertaCreditos?.novelaId || selecionada;
              if (alvoId) executar(() => api.rodarNovela(alvoId), 'Continuando na nova conta do Google Flow...');
              else executar(() => api.rodarFila(), 'Continuando fila na nova conta...');
            }}
          >
            <Play size={13} /> Rodar / Continuar na Nova Conta
          </button>
        </div>
      )}

      {/* ======== BARRA COMPACTA MOBILE (iPhone / Safari vertical) ======== */}
      <div className="flex flex-col gap-2 border-b border-white/[0.07] bg-studio-900/95 p-2.5 md:hidden">
        <div className="grid grid-cols-3 gap-1.5">
          <button className="btn-primary justify-center py-2 text-xs" onClick={() => setModalNova(true)}>
            <Plus size={14} /> Nova Novela
          </button>
          <button
            className="btn-success justify-center py-2 text-xs"
            disabled={fila.rodando}
            onClick={() =>
              fila.pausado
                ? executar(() => api.retomarFila(), 'Fila retomada exatamente de onde parou!')
                : executar(() => api.rodarFila(), 'Fila geral iniciada')
            }
          >
            <Play size={13} /> Rodar Fila
          </button>
          {fila.pausado && !fila.rodando ? (
            <button
              className="btn inline-flex items-center justify-center gap-1 rounded-lg border border-amber-500/50 bg-amber-500/20 py-2 text-xs font-semibold text-amber-200"
              onClick={() => executar(() => api.retomarFila(), 'Fila retomada exatamente do item onde parou!')}
            >
              <Play size={13} /> Retomar
            </button>
          ) : (
            <button
              className="btn-ghost justify-center py-2 text-xs"
              disabled={(!fila.rodando && !fila.fila?.length) || fila.pausaSolicitada}
              onClick={() => executar(() => api.pausar(), 'Pausa solicitada: aguardando apenas concluir o item atual no Flow...')}
            >
              <Pause size={13} /> {fila.pausaSolicitada ? 'Pausando...' : 'Pausar'}
            </button>
          )}
        </div>
        <button
          type="button"
          onClick={() => setGavetaMobileAberta((v) => !v)}
          className="flex w-full items-center justify-between rounded-lg border border-white/[0.08] bg-studio-850 px-3 py-2 text-xs text-zinc-200"
        >
          <span className="truncate font-medium">
            📂 {novela ? `${novela.nome} (${progressoNovela(novela).videos.feito}/${progressoNovela(novela).videos.total} vídeos)` : `Minhas Novelas (${novelas.length})`}
          </span>
          <span className="flex items-center gap-1 text-[11px] text-fuchsia-300">
            {gavetaMobileAberta ? 'Fechar lista' : `Trocar (${novelas.length})`}
            {gavetaMobileAberta ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </span>
        </button>
      </div>

      {/* Tela do Estúdio (Responsiva: empilha no celular e divide lado a lado no PC) */}
      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        {/* ======== MENU LATERAL ======== */}
        <aside className={`${gavetaMobileAberta ? 'flex max-h-[60vh]' : 'hidden'} w-full shrink-0 flex-col border-b border-white/[0.07] bg-studio-900/90 md:flex md:max-h-none md:w-64 md:border-b-0 md:border-r`}>
          <div className="hidden space-y-1.5 p-2.5 md:block">
            <button className="btn-primary w-full py-1.5 text-xs" onClick={() => setModalNova(true)}><Plus size={14} /> Nova Novela</button>
            <div className="grid grid-cols-[1.35fr_1fr] gap-1.5 [&>button]:whitespace-nowrap [&>button]:px-2">
              <button
                className="btn-success py-1.5 text-xs"
                disabled={fila.rodando}
                onClick={() =>
                  fila.pausado
                    ? executar(() => api.retomarFila(), 'Fila retomada exatamente de onde parou!')
                    : executar(() => api.rodarFila(), 'Fila geral iniciada')
                }
                title="Roda todas as novelas com itens pendentes, uma após a outra"
              >
                <Play size={13} /> Rodar Fila
              </button>
              {fila.pausado && !fila.rodando ? (
                <button
                  className="btn inline-flex items-center justify-center gap-1 rounded-lg border border-amber-500/50 bg-amber-500/20 py-1.5 text-xs font-semibold text-amber-200 transition hover:bg-amber-500/30"
                  onClick={() => executar(() => api.retomarFila(), 'Fila retomada exatamente do item onde parou!')}
                  title="Retoma a novela pausada exatamente do item onde parou"
                >
                  <Play size={13} /> Retomar
                </button>
              ) : (
                <button
                  className="btn-ghost py-1.5 text-xs"
                  disabled={(!fila.rodando && !fila.fila?.length) || fila.pausaSolicitada}
                  onClick={() => executar(() => api.pausar(), 'Pausa solicitada: aguardando apenas concluir o item atual no Flow...')}
                  title="Aguarda apenas o item em andamento concluir no Flow e congela a fila global (permitindo regenerar cenas isoladas de outros projetos)"
                >
                  <Pause size={13} /> {fila.pausaSolicitada ? 'Pausando...' : 'Pausar'}
                </button>
              )}
            </div>
          </div>

          <ListaNovelas
            novelas={novelas}
            fila={fila}
            selecionada={selecionada}
            onSelecionar={(id) => { setSelecionada(id); setGavetaMobileAberta(false); }}
            executar={executar}
          />

          {/* Log de atividade */}
          <div className="border-t border-white/[0.07]">
            <button className="flex w-full items-center justify-between px-3 py-1.5 text-[11px] text-zinc-500 hover:text-zinc-200" onClick={() => setLogAberto(!logAberto)}>
              <span className="flex items-center gap-1.5">
                <Activity size={12} /> Atividade
                {fila.tentativaAtual > 0 && (
                  <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-amber-300">
                    Tentativa {fila.tentativaAtual}/3
                  </span>
                )}
              </span>
              {logAberto ? <ChevronDown size={13} /> : <ChevronUp size={13} />}
            </button>
            {logAberto && (
              <div className="max-h-52 space-y-0.5 overflow-y-auto px-3 pb-2.5 font-mono text-[10px] leading-relaxed">
                {logs.slice().reverse().map((l, i) => (
                  <div
                    key={i}
                    className={
                      l.nivel === 'erro'
                        ? 'text-red-400'
                        : l.nivel === 'aviso'
                        ? 'text-amber-300'
                        : l.nivel === 'ok'
                        ? 'text-emerald-400'
                        : 'text-zinc-400'
                    }
                  >
                    <span className="text-zinc-600">{l.t.slice(11, 19)}</span> {l.msg}
                  </div>
                ))}
              </div>
            )}
          </div>
        </aside>

        {/* ======== AREA PRINCIPAL ======== */}
        <main className="min-w-0 flex-1 overflow-hidden">
          {novela ? (
            <NovelaView key={novela.id} novela={novela} studio={studio} executar={executar} toast={toast} />
          ) : (
            <div className="flex h-full items-center justify-center p-8">
              <Vazio icon={Clapperboard} titulo="Bem-vindo ao Flow Novela Studio" texto="Crie uma nova novela e cole seu roteiro (BLOCO 1, BLOCO 2 e BLOCO 3) para iniciar a fila no Google Flow.">
                <button className="btn-primary mt-2" onClick={() => setModalNova(true)}><Plus size={15} /> Nova Novela</button>
              </Vazio>
            </div>
          )}
        </main>
      </div>

      <Modal aberto={modalCelular} onFechar={() => setModalCelular(false)} titulo="📱 Controle Remoto pelo Celular (Sem VPN)" largura="max-w-lg">
        {(() => {
          const tunelAtual = tunel?.url ? tunel : (infoRede?.tunel || tunel || {});
          const tunelOnline = Boolean(tunelAtual?.online && tunelAtual?.url);
          const tunelCarregando = operandoTunel || tunelAtual?.estado === 'baixando' || tunelAtual?.estado === 'conectando';
          const itemWifi = infoRede?.ipsLocais?.[0] || null;
          const mostrarQrTunel = tunelOnline && (abaQrRede === 'tunel' || !itemWifi);
          const qrExibido = mostrarQrTunel ? tunelAtual.qrDataUrl : itemWifi?.qrDataUrl;
          const urlQrExibida = mostrarQrTunel ? tunelAtual.url : itemWifi?.url;

          return (
            <div className="space-y-3.5 text-xs text-zinc-300">
              {/* OPCAO PRINCIPAL: Tunel HTTPS Direto Cloudflare (Sem VPN) */}
              <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/[0.08] p-3.5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-200">
                      <span>🌍 Acesso de Qualquer Lugar (Sem VPN — Seguro p/ Redes Sociais)</span>
                    </div>
                    <p className="mt-0.5 text-[11px] text-zinc-400">
                      Túnel HTTPS oficial Cloudflare (<code>trycloudflare.com</code> + <code>wss://</code>). Não altera o IP do PC nem do iPhone.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={tunelCarregando}
                    onClick={async () => {
                      setOperandoTunel(true);
                      if (tunelOnline) {
                        const r = await executar(() => api.tunelParar(), '🛑 Túnel HTTPS desligado.');
                        if (r) studio.setTunel?.(r);
                      } else {
                        const r = await executar(() => api.tunelIniciar(), '🌍 Túnel HTTPS ligado com sucesso!');
                        if (r) {
                          studio.setTunel?.(r);
                          setAbaQrRede('tunel');
                        }
                      }
                      setOperandoTunel(false);
                      recarregarInfoRede();
                    }}
                    className={`btn shrink-0 px-3 py-1.5 text-xs font-semibold ${
                      tunelOnline
                        ? 'border border-red-500/40 bg-red-500/15 text-red-200 hover:bg-red-500/25'
                        : 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm hover:from-emerald-500 hover:to-teal-500'
                    }`}
                  >
                    {tunelCarregando
                      ? (tunelAtual?.estado === 'baixando' ? '⬇️ Baixando cloudflared...' : '⏳ Abrindo túnel HTTPS...')
                      : tunelOnline
                        ? '🛑 Desligar Túnel'
                        : '⚡ Ligar Túnel HTTPS'}
                  </button>
                </div>

                {tunelAtual?.erro && (
                  <div className="mt-2 rounded-lg border border-red-500/40 bg-red-500/10 px-2.5 py-1.5 text-[11px] text-red-200">
                    ⚠️ {tunelAtual.erro}
                  </div>
                )}

                {tunelOnline && (
                  <div className="mt-3 space-y-2">
                    <div className="flex items-center gap-1.5">
                      <input readOnly value={tunelAtual.url} className="input flex-1 py-1.5 font-mono text-xs font-semibold text-emerald-200" />
                      <button
                        type="button"
                        className="btn-primary py-1.5 text-xs"
                        onClick={() => { navigator.clipboard.writeText(tunelAtual.url); toast('Link HTTPS copiado!', 'ok'); }}
                      >
                        <Copy size={12} /> Copiar
                      </button>
                      <button
                        type="button"
                        className="btn-ghost border border-emerald-500/35 bg-emerald-500/15 py-1.5 text-xs text-emerald-200 hover:bg-emerald-500/25"
                        title="Envia o link HTTPS + PIN direto para o seu WhatsApp"
                        onClick={() => executar(() => api.tunelEnviarWhatsapp(), '📲 Link HTTPS + PIN enviados ao seu WhatsApp!')}
                      >
                        📲 WhatsApp
                      </button>
                    </div>
                  </div>
                )}

                <label className="mt-2.5 flex cursor-pointer items-center gap-2 text-[11px] text-zinc-400">
                  <input
                    type="checkbox"
                    checked={Boolean(tunelAtual?.autoIniciar)}
                    onChange={async (e) => {
                      const r = await executar(() => api.tunelConfig({ autoIniciar: e.target.checked }), e.target.checked ? 'Túnel iniciará ligado com o Estúdio' : 'Início automático do túnel desativado');
                      if (r) studio.setTunel?.(r);
                    }}
                  />
                  <span>Iniciar túnel HTTPS automaticamente ao abrir o Flow Novela Studio</span>
                </label>
              </div>

              {/* PIN DE ACESSO (Visivel SOMENTE na tela local do PC - localhost!) */}
              {infoRede?.ehLocalPc && infoRede?.pinAtual ? (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-500/35 bg-amber-500/10 px-3.5 py-2.5">
                  <div>
                    <div className="flex items-center gap-1.5 font-semibold text-amber-200">
                      <Lock size={13} /> PIN de Acesso Externo (visível só neste PC)
                    </div>
                    <div className="text-[10.5px] text-zinc-400">
                      Obrigatório no link HTTPS · Proteção anti-força bruta ativa (bloqueia IP após 5 erros)
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="rounded-lg border border-amber-500/40 bg-studio-950 px-3 py-1 font-mono text-sm font-bold tracking-widest text-amber-200">
                      {infoRede.pinAtual}
                    </span>
                    <button
                      type="button"
                      className="btn-ghost px-2 py-1 text-[11px]"
                      title="Copiar PIN"
                      onClick={() => { navigator.clipboard.writeText(infoRede.pinAtual); toast('PIN copiado!', 'ok'); }}
                    >
                      <Copy size={12} />
                    </button>
                    <button
                      type="button"
                      disabled={trocandoPin}
                      className="btn-ghost px-2 py-1 text-[11px]"
                      title="Gerar um novo PIN aleatório de 6 dígitos"
                      onClick={async () => {
                        setTrocandoPin(true);
                        const r = await executar(() => api.trocarPin(), '🔒 Novo PIN de 6 dígitos gerado e salvo no .env!');
                        setTrocandoPin(false);
                        if (r?.pin) setInfoRede((ant) => (ant ? { ...ant, pinAtual: r.pin } : ant));
                      }}
                    >
                      <RefreshCw size={12} className={trocandoPin ? 'animate-spin' : ''} /> Trocar PIN
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2 rounded-lg border border-white/[0.07] bg-studio-950/80 px-3 py-2 text-[11px] text-zinc-400">
                  <Lock size={12} className="text-emerald-400" />
                  <span>Sessão remota autenticada via PIN criptografado (o PIN em texto só é exibido na tela local do PC).</span>
                </div>
              )}

              {/* QR Code (Túnel HTTPS ou Wi-Fi Local) */}
              {qrExibido && (
                <div className="flex flex-col items-center rounded-xl border border-white/[0.08] bg-studio-950 p-3.5 text-center">
                  {tunelOnline && itemWifi && (
                    <div className="mb-2.5 flex gap-1.5 rounded-lg border border-white/[0.08] bg-studio-900 p-1">
                      <button
                        type="button"
                        onClick={() => setAbaQrRede('tunel')}
                        className={`rounded-md px-2.5 py-1 text-[11px] font-medium ${mostrarQrTunel ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-white'}`}
                      >
                        🌍 QR Túnel HTTPS (Qualquer Lugar)
                      </button>
                      <button
                        type="button"
                        onClick={() => setAbaQrRede('wifi')}
                        className={`rounded-md px-2.5 py-1 text-[11px] font-medium ${!mostrarQrTunel ? 'bg-sky-600 text-white' : 'text-zinc-400 hover:text-white'}`}
                      >
                        🏠 QR Wi-Fi Local ({itemWifi.ip})
                      </button>
                    </div>
                  )}
                  <div className="rounded-xl bg-white p-2.5 shadow-lg">
                    <img src={qrExibido} alt="QR Code Celular" className="h-44 w-44" />
                  </div>
                  <div className="mt-2 break-all font-mono text-xs font-semibold text-white">{urlQrExibida}</div>
                  <div className="mt-0.5 text-[11px] text-zinc-400">
                    Aponte a câmera do iPhone para abrir no Safari · Para instalar na Tela de Início: <b>Compartilhar → Adicionar à Tela de Início</b>.
                  </div>
                </div>
              )}

              {/* OPCAO SECUNDARIA: Wi-Fi Local */}
              {infoRede?.ipsLocais?.length > 0 && (
                <div className="rounded-lg border border-white/[0.07] bg-studio-950/60 p-3">
                  <div className="mb-1.5 flex items-center justify-between text-[11px] text-zinc-400">
                    <span className="flex items-center gap-1.5 font-medium text-sky-300">
                      <Wifi size={12} /> Opção secundária: Wi-Fi Local (mesma rede de casa)
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {infoRede.ipsLocais.map((item) => (
                      <div key={item.ip} className="flex items-center gap-2">
                        <input readOnly value={item.url} className="input flex-1 py-1 font-mono text-[11px] text-zinc-300" />
                        <button
                          type="button"
                          className="btn-ghost border border-white/[0.08] py-1 text-[11px]"
                          onClick={() => { navigator.clipboard.writeText(item.url); toast('Link Wi-Fi Local copiado!', 'ok'); }}
                        >
                          <Copy size={11} /> Copiar
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end">
                <button type="button" className="btn-ghost py-1 text-xs" onClick={() => setModalCelular(false)}>
                  Fechar
                </button>
              </div>
            </div>
          );
        })()}
      </Modal>

      <Modal aberto={modalNova} onFechar={() => setModalNova(false)} titulo="Nova Novela">
        <div className="space-y-3">
          <div>
            <div className="label mb-1.5">Nome da novela</div>
            <input autoFocus className="input" placeholder="Ex.: Amor na Fazenda" value={nomeNova} onChange={(e) => setNomeNova(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && nomeNova.trim() && criar()} />
            <div className="mt-1.5 text-[11px] text-zinc-500">Será criada em <span className="font-mono text-zinc-400">Meus_Projetos_Flow\{nomeNova.trim() || '…'}</span></div>
          </div>
          <div className="flex justify-end gap-2">
            <button className="btn-ghost" onClick={() => setModalNova(false)}>Cancelar</button>
            <button className="btn-primary" disabled={!nomeNova.trim()} onClick={criar}><Plus size={14} /> Criar</button>
          </div>
        </div>
      </Modal>

      <Modal aberto={modalPadroes} onFechar={() => setModalPadroes(false)} titulo="Padrões globais do FlowStudio">
        <p className="mb-3 text-xs text-zinc-400">
          Fonte única de verdade para novelas novas e histórias importadas da Fábrica Claude (tanto no modo Automático quanto Com Aprovação).
        </p>
        <div className="mb-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
          <label className="block">
            <span className="label mb-1 block">Modelo de Imagem padrão</span>
            <select
              className="input py-1.5"
              value={studio.config.padroes?.modeloImagem || 'Nano Banana 2.1'}
              onChange={(e) => salvarPadroes({ modeloImagem: e.target.value })}
            >
              {[...new Set([...(studio.config.modelosImagem || ['Nano Banana 2.1', 'Nano Banana Pro']), studio.config.padroes?.modeloImagem].filter(Boolean))].map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label mb-1 block">Modelo de Vídeo padrão</span>
            <select
              className="input py-1.5"
              value={studio.config.padroes?.modeloVideo || 'Omni 1.1 Flash'}
              onChange={(e) => salvarPadroes({ modeloVideo: e.target.value })}
            >
              {[...new Set([...(studio.config.modelosVideo || ['Omni 1.2 Flash', 'Omni 1.1 Flash']), studio.config.padroes?.modeloVideo].filter(Boolean))].map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </label>
        </div>
        <SeletoresQualidade
          valores={studio.config.padroes}
          padroes={studio.config.padroes}
          onChange={(p) => salvarPadroes(p)}
        />
        <div className="mt-3 rounded-lg border border-white/[0.07] bg-studio-950/70 p-2.5">
          <label className="flex cursor-pointer items-center gap-2 text-xs text-zinc-300">
            <input
              type="checkbox"
              checked={aplicarPendentesPadroes}
              onChange={(e) => setAplicarPendentesPadroes(e.target.checked)}
            />
            <span>Aplicar automaticamente às novelas pendentes / em andamento</span>
          </label>
          <div className="mt-2 flex flex-wrap gap-2">
            <button
              type="button"
              className="btn-ghost py-1 text-[11px]"
              onClick={() => salvarPadroes({}, 'Padrões aplicados às novelas pendentes!', { aplicarNasPendentes: true })}
            >
              <CheckCircle2 size={12} /> Sincronizar Pendentes Agora
            </button>
            <button
              type="button"
              className="btn-ghost py-1 text-[11px]"
              onClick={() => salvarPadroes({}, 'Padrões aplicados a TODAS as novelas do Estúdio!', { aplicarEmTodas: true })}
            >
              Aplicar em Todas as Novelas
            </button>
          </div>
        </div>
        <div className="mt-4 border-t border-white/[0.07] pt-3.5">
          <div className="label mb-1.5 flex items-center gap-1.5"><Scissors size={12} /> Pasta de rascunhos do CapCut PC</div>
          {capcut && (
            <div className={`mb-2 rounded-lg border px-3 py-1.5 text-xs ${capcut.encontrada ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-300'}`}>
              {capcut.encontrada ? `✅ Detectada (${capcut.origem}) · ${capcut.projetos} projeto(s)` : '⚠️ Não encontrei a pasta do CapCut automaticamente.'}
            </div>
          )}
          <div className="flex gap-2">
            <input className="input font-mono text-[11px]" value={caminhoCapcut} onChange={(e) => setCaminhoCapcut(e.target.value)} placeholder="...\CapCut\User Data\Projects\com.lveditor.draft" />
            <button className="btn-ghost whitespace-nowrap text-xs" onClick={async () => {
              const c = await executar(() => api.salvarCaminhoCapcut(caminhoCapcut), 'Pasta do CapCut salva');
              if (c) { studio.setConfig(c); setCapcut(await api.statusCapcut()); }
            }}>Salvar</button>
          </div>
          <div className="mt-1 text-[10px] text-zinc-600">Deixe vazio e salve para voltar à detecção automática.</div>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <button
            className="btn-primary"
            onClick={async () => {
              await salvarPadroes({}, 'Padrões salvos e sincronizados!');
              setModalPadroes(false);
            }}
          >
            Salvar e Fechar
          </button>
        </div>
      </Modal>

      <Toasts toasts={toasts} />
    </div>
  );
}
