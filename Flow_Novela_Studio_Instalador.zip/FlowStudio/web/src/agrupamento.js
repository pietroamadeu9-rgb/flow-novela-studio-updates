// Organizacao visual das historias: "Parte Unica" x "Series" (agrupadas pelo titulo-base / serieSlug).
// Apenas front-end: nenhum dado salvo e alterado.

const RE_SUFIXO_PARTE = /\s*(?:[-–—:|]\s*)?\(?\s*(?:parte|part|pt\.?|ep(?:is[oó]dio)?\.?)\s*[_\s#-]*0*(\d{1,3})\s*\)?\s*(?:\(\d+\))?\s*$/i;
const RE_PARTE_SLUG = /(?:^|[_\s-])parte[_\s-]*0*(\d{1,3})(?:$|[_\s-])/i;

const normalizar = (s) =>
  String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

/** Separa "O Caderno de Fiado — Parte 2" em { titulo: "O Caderno de Fiado", parte: 2 }. */
export function separarTituloParte(nome) {
  const bruto = String(nome || '').trim();
  const m = bruto.match(RE_SUFIXO_PARTE);
  if (m) {
    const titulo = bruto.slice(0, m.index).replace(/[\s\-–—:|]+$/, '').trim();
    if (titulo) return { titulo, parte: Number(m[1]) };
  }
  const ms = bruto.match(RE_PARTE_SLUG);
  if (ms) return { titulo: bruto.replace(RE_PARTE_SLUG, ' ').replace(/[_-]+/g, ' ').trim() || bruto, parte: Number(ms[1]) };
  return { titulo: bruto, parte: null };
}

/** Indica se uma novela do Estudio e um rascunho vazio (0 itens / 0 videos). */
export function ehRascunhoVazio(n) {
  return !Array.isArray(n?.itens) || n.itens.length === 0;
}

/** Informacoes de serie de uma novela do Estudio. */
export function infoSerieNovela(n) {
  const { titulo, parte: parteNome } = separarTituloParte(n?.nome);
  const parte = Number(n?.numeroParte) || parteNome || null;
  const totalPartes = Number(n?.totalPartes) || 0;
  const ehUnicaExplicita =
    n?.formatoHistoria === 'unica' ||
    n?.formato === 'unica' ||
    (totalPartes === 1 && (parte || 1) === 1 && !parteNome && n?.serie !== true);
  const indicaSerie =
    !ehUnicaExplicita &&
    (totalPartes > 1 ||
      (parte != null && parte > 1) ||
      parteNome != null ||
      n?.formatoHistoria === 'serie' ||
      (n?.serie === true && totalPartes > 1));
  return {
    chave: n?.serieSlug ? `slug:${n.serieSlug}` : `titulo:${normalizar(titulo)}`,
    titulo: titulo || n?.nome || 'Sem título',
    parte,
    totalPartes,
    indicaSerie,
  };
}

/**
 * Agrupa a lista de novelas em { unicas: [novela], series: [{ chave, titulo, partes:[{novela, parte}], totalPartes }] }.
 * Um grupo vira Serie se qualquer parte indicar serie OU houver mais de uma novela com o mesmo titulo-base/serieSlug.
 */
export function agruparNovelas(novelas = []) {
  const grupos = new Map();
  for (const n of novelas) {
    const info = infoSerieNovela(n);
    if (!grupos.has(info.chave)) grupos.set(info.chave, { chave: info.chave, titulo: info.titulo, membros: [], indicaSerie: false, totalPartes: 0 });
    const g = grupos.get(info.chave);
    g.membros.push({ novela: n, parte: info.parte });
    g.indicaSerie = g.indicaSerie || info.indicaSerie;
    g.totalPartes = Math.max(g.totalPartes, info.totalPartes);
  }
  const unicas = [];
  const series = [];
  for (const g of grupos.values()) {
    if (!g.indicaSerie && g.membros.length === 1) {
      unicas.push(g.membros[0].novela);
      continue;
    }
    g.membros.sort((a, b) => (a.parte ?? 999) - (b.parte ?? 999) || String(a.novela.nome).localeCompare(String(b.novela.nome), 'pt-BR', { numeric: true }));
    series.push({ chave: g.chave, titulo: g.titulo, partes: g.membros, totalPartes: Math.max(g.totalPartes, g.membros.length) });
  }
  return { unicas, series };
}

/** Mesma separacao para os "Prontos para importar" da Fabrica Claude. */
export function agruparProntos(prontos = []) {
  const grupos = new Map();
  for (const p of prontos) {
    const chave = p.slug || normalizar(separarTituloParte(p.titulo).titulo);
    if (!grupos.has(chave)) grupos.set(chave, { chave, titulo: separarTituloParte(p.titulo).titulo || p.slug, partes: [], ehSerie: false, totalPartes: 0 });
    const g = grupos.get(chave);
    g.partes.push(p);
    const totalP = Number(p.totalPartes) || 1;
    const numP = Number(p.parte) || 1;
    const ehUnica = p.formato === 'unica' || p.formatoHistoria === 'unica' || (totalP === 1 && numP === 1 && p.tipoFinal !== 'aberto');
    const pEhSerie = !ehUnica && (totalP > 1 || numP > 1 || p.tipoFinal === 'aberto' || (Boolean(p.serie) && totalP > 1));
    g.ehSerie = g.ehSerie || pEhSerie;
    g.totalPartes = Math.max(g.totalPartes, totalP);
  }
  const unicas = [];
  const series = [];
  for (const g of grupos.values()) {
    if (!g.ehSerie && g.partes.length === 1) { unicas.push(g.partes[0]); continue; }
    g.partes.sort((a, b) => (a.parte || 0) - (b.parte || 0));
    series.push({ ...g, totalPartes: Math.max(g.totalPartes, g.partes.length) });
  }
  return { unicas, series };
}
