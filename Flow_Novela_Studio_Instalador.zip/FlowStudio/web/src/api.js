import { useEffect, useRef, useState, useCallback } from 'react';

export function obterPinSalvo() {
  try { return localStorage.getItem('fns.pin') || ''; } catch { return ''; }
}

export function salvarPinLocal(pin) {
  try {
    if (pin) localStorage.setItem('fns.pin', String(pin).trim());
    else localStorage.removeItem('fns.pin');
  } catch {}
}

async function req(method, url, body) {
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  const pin = obterPinSalvo();
  if (pin) headers['x-studio-pin'] = pin;
  const r = await fetch(url, {
    method,
    headers: Object.keys(headers).length ? headers : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await r.json().catch(() => ({}));
  if (r.status === 401 && data?.pinExigido) {
    window.dispatchEvent(new CustomEvent('fns:pin-exigido'));
  }
  if (!r.ok) {
    const err = new Error(data.erro || `Erro ${r.status}`);
    err.status = r.status;
    err.requerConfirmacao = !!data?.requerConfirmacao;
    err.midiasExistentes = data?.midiasExistentes || null;
    throw err;
  }
  return data;
}

export const api = {
  criarNovela: (nome) => req('POST', '/api/novelas', { nome }),
  atualizarNovela: (id, dados) => req('PATCH', `/api/novelas/${id}`, dados),
  marcarNovelasConcluidas: (ids, concluida = true) => req('POST', '/api/novelas/marcar-concluidas', { ids, concluida }),
  removerNovela: (id) => req('DELETE', `/api/novelas/${id}`),
  processarRoteiro: (id, texto, opcoes = {}) => req('POST', `/api/novelas/${id}/roteiro`, { texto, ...opcoes }),
  recuperarMidiasPasta: (id) => req('POST', `/api/novelas/${id}/recuperar-midias`),
  atualizarItem: (id, itemId, dados) => req('PATCH', `/api/novelas/${id}/itens/${encodeURIComponent(itemId)}`, dados),
  marcarItemFeitoManual: (id, itemId, feito = true) => req('PATCH', `/api/novelas/${id}/itens/${encodeURIComponent(itemId)}`, { acao: feito ? 'marcar_feito_manual' : 'desmarcar_feito_manual' }),
  restaurarPromptOriginal: (id, itemId) => req('PATCH', `/api/novelas/${id}/itens/${encodeURIComponent(itemId)}`, { acao: 'restaurar_original', restaurarPromptOriginal: true }),
  suavizarItemComImagem: (id, itemId, rodar = true) => req('PATCH', `/api/novelas/${id}/itens/${encodeURIComponent(itemId)}`, { acao: 'suavizar_com_imagem', rodar }),
  gerarItemPorDescricaoSemImagem: (id, itemId, rodar = true) => req('PATCH', `/api/novelas/${id}/itens/${encodeURIComponent(itemId)}`, { acao: 'descritivo_sem_imagem', rodar }),
  acaoLoteItensFalhos: (id, acao, rodar = true) => req('POST', `/api/novelas/${id}/itens-falhos/acao`, { acao, rodar }),
  regerar: (id, itemId, cascata = [], opcoes = {}) => req('POST', `/api/novelas/${id}/itens/${encodeURIComponent(itemId)}/regerar`, { cascata, ...opcoes }),
  enviarCapcut: (id) => req('POST', `/api/novelas/${id}/capcut`),
  statusCapcut: () => req('GET', '/api/capcut/status'),
  statusClaude: () => req('GET', '/api/claude/status'),
  salvarCaminhoCapcut: (capcutDraftsPath) => req('PATCH', '/api/config', { capcutDraftsPath }),
  rebaixar: (id, itemId) => req('POST', `/api/novelas/${id}/itens/${encodeURIComponent(itemId)}/rebaixar`),
  recapturarVideos: (id) => req('POST', `/api/novelas/${id}/recapturar-videos`),
  atualizarConfig: (padroes, opcoes = {}) => req('PATCH', '/api/config', { padroes, ...opcoes }),
  rodarNovela: (id) => req('POST', `/api/novelas/${id}/rodar`),
  rodarFila: (novelaIds) => req('POST', '/api/fila/rodar', { novelaIds }),
  retomarFila: () => req('POST', '/api/fila/retomar'),
  pausar: (opcoes = {}) => req('POST', '/api/fila/pausar', opcoes),
  abrirPasta: (id, sub) => req('POST', `/api/novelas/${id}/abrir-pasta`, { sub }),
  mapearFlow: (modo = 'novo') => req('POST', '/api/extensao/mapear', { modo }),
  rede: () => req('GET', '/api/rede'),
  authStatus: () => req('GET', '/api/auth/status'),
  verificarPin: (pin) => req('POST', '/api/auth/verificar', { pin }),
  trocarPin: (pin) => req('POST', '/api/auth/trocar-pin', pin ? { pin } : {}),
  tunelStatus: () => req('GET', '/api/tunel/status'),
  tunelIniciar: () => req('POST', '/api/tunel/iniciar'),
  tunelParar: () => req('POST', '/api/tunel/parar'),
  tunelConfig: (dados) => req('PATCH', '/api/tunel/config', dados),
  tunelEnviarWhatsapp: (numero) => req('POST', '/api/tunel/enviar-whatsapp', { numero }),
  health: () => req('GET', '/api/health'),
  updateStatus: () => req('GET', '/api/update/status'),
  updateVerificar: () => req('POST', '/api/update/verificar'),
  updateAplicar: (dados = {}) => req('POST', '/api/update/aplicar', dados),
};

/** ✨ Fábrica Claude / WhatsApp / Vigia do CapCut */
export const fab = {
  status: (forcar) => req('GET', `/api/fabrica/status${forcar ? '?forcar=1' : ''}`),
  abrirLogin: () => req('POST', '/api/fabrica/abrir-login-claude'),
  config: () => req('GET', '/api/fabrica/config'),
  salvarConfig: (c) => req('PATCH', '/api/fabrica/config', c),
  estadoCriador: () => req('GET', '/api/fabrica/estado-criador'),
  salvarEstadoCriador: (b) => req('PUT', '/api/fabrica/estado-criador', b || {}),
  prontos: () => req('GET', '/api/fabrica/prontos'),
  series: () => req('GET', '/api/fabrica/series'),
  importar: (slug, parte, iniciarFila = false) => req('POST', '/api/fabrica/importar', { slug, parte, iniciarFila }),
  sementes: (b) => req('POST', '/api/fabrica/sementes', b),
  roteiro: (b) => req('POST', '/api/fabrica/roteiro', b),
  prompts: (b) => req('POST', '/api/fabrica/prompts', b),
  automatico: (b) => req('POST', '/api/fabrica/automatico', b),
  gerarParte: (slug, b) => req('POST', `/api/fabrica/series/${encodeURIComponent(slug)}/gerar-parte`, b || {}),
  regerar: (b) => req('POST', '/api/fabrica/regerar', b),
  dialogos: (slug, parte) => req('GET', `/api/fabrica/dialogos?slug=${encodeURIComponent(slug)}&parte=${encodeURIComponent(parte || 1)}&_=${Date.now()}`),
  editarFala: (b) => req('PATCH', '/api/fabrica/dialogos', b),
  fichas: () => req('GET', `/api/fabrica/fichas?_=${Date.now()}`),
  criarFicha: (b) => req('POST', '/api/fabrica/fichas', b || {}),
  extrairFicha: (b) => req('POST', '/api/fabrica/fichas/extrair', b || {}),
  promoverFicha: (b) => req('POST', '/api/fabrica/fichas/promover', b || {}),
  atualizarFicha: (id, b) => req('PATCH', `/api/fabrica/fichas/${encodeURIComponent(id)}`, b || {}),
  excluirFicha: (id) => req('DELETE', `/api/fabrica/fichas/${encodeURIComponent(id)}`),
  cota: () => req('GET', `/api/fabrica/cota?_=${Date.now()}`),
  calibrarCota: (b) => req('POST', '/api/fabrica/cota/calibrar', b || {}),
  job: (id) => req('GET', `/api/fabrica/jobs/${id}`),
  jobs: () => req('GET', '/api/fabrica/jobs'),
  cancelarJob: (id) => req('POST', `/api/fabrica/jobs/${id}/cancelar`),
  agendamento: () => req('GET', '/api/fabrica/agendamento'),
  salvarAgendamento: (b) => req('POST', '/api/fabrica/agendamento', b),
  buscarAgora: () => req('POST', '/api/fabrica/agendamento/buscar'),
  sortearLegenda: (id) => req('POST', `/api/novelas/${id}/legenda/sortear`),
  gerarLegenda: (id, opcoes = {}) => req('POST', `/api/novelas/${id}/legenda/gerar`, opcoes),
  salvarLegenda: (id, texto) => req('PATCH', `/api/novelas/${id}/legenda`, { texto }),
  enviarLegenda: (id, numero, opcoes = {}) => req('POST', `/api/novelas/${id}/enviar-legenda`, { numero, ...opcoes }),
  zapStatus: () => req('GET', '/api/whatsapp/status'),
  zapConectar: () => req('POST', '/api/whatsapp/conectar'),
  zapDesconectar: () => req('POST', '/api/whatsapp/desconectar'),
  zapTeste: (numero) => req('POST', '/api/whatsapp/enviar-teste', { numero }),
  capcut: () => req('GET', '/api/capcut/config'),
  salvarCapcut: (c) => req('PATCH', '/api/capcut/config', c),
  escolherPasta: () => req('POST', '/api/capcut/escolher-pasta'),
  testarDisparoCapcut: (numero) => req('POST', '/api/capcut/testar-disparo', { numero }),
  gdriveStatus: () => req('GET', '/api/gdrive/status'),
  gdriveSalvarCreds: (b) => req('POST', '/api/gdrive/credenciais', b),
  gdriveConfig: (b) => req('PATCH', '/api/gdrive/config', b),
  gdriveConectar: (b) => req('POST', '/api/gdrive/conectar', b || {}),
  gdriveDesconectar: (apagarCredenciais = false) => req('POST', '/api/gdrive/desconectar', { apagarCredenciais }),
  gdriveSubirUltimo: (numero) => req('POST', '/api/gdrive/subir-ultimo', { numero }),
};

export function mediaUrl(novela, item) {
  if (!item?.arquivo) return null;
  const caminho = [novela.pasta, ...item.arquivo.split('/')].map(encodeURIComponent).join('/');
  return `/media/${caminho}?v=${encodeURIComponent(item.geradoEm || item.atualizadoEm || item.tamanhoBytes || '')}`;
}

/** Estado global ao vivo via WebSocket */
export function useStudio() {
  const [novelas, setNovelas] = useState([]);
  const [extensao, setExtensao] = useState({ conectada: false });
  const [fila, setFila] = useState({ rodando: false, fila: [], mensagem: 'Parado' });
  const [domMap, setDomMap] = useState({ existe: false, capturas: 0 });
  const [config, setConfig] = useState({ modelosImagem: [], modelosVideo: [] });
  const [claudeCli, setClaudeCli] = useState({ disponivel: false, versao: null });
  const [tunel, setTunel] = useState({ estado: 'parado', ativo: false, online: false, url: null, qrDataUrl: null, autoIniciar: false });
  const [logs, setLogs] = useState([]);
  const [servidorOnline, setServidorOnline] = useState(false);
  const [pinBloqueado, setPinBloqueado] = useState(false);
  const [cicloAuth, setCicloAuth] = useState(0);
  const wsRef = useRef(null);

  useEffect(() => {
    const onPin = () => setPinBloqueado(true);
    window.addEventListener('fns:pin-exigido', onPin);
    return () => window.removeEventListener('fns:pin-exigido', onPin);
  }, []);

  useEffect(() => {
    let vivo = true;
    let timer;
    const aplicarEstado = (m) => {
      if (!vivo || !m) return;
      setPinBloqueado(false);
      if (Array.isArray(m.novelas)) setNovelas(m.novelas);
      if (m.extensao) setExtensao(m.extensao);
      if (m.fila) setFila(m.fila);
      if (m.domMap) setDomMap(m.domMap);
      if (m.config) setConfig(m.config || {});
      if (m.claudeCli) setClaudeCli(m.claudeCli);
      if (m.tunel) setTunel(m.tunel);
      if (Array.isArray(m.logs)) setLogs(m.logs);
    };
    const conectar = () => {
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const pin = obterPinSalvo();
      const qs = pin ? `?pin=${encodeURIComponent(pin)}` : '';
      const ws = new WebSocket(`${proto}//${location.host}/ws${qs}`);
      wsRef.current = ws;
      ws.onopen = () => {
        setServidorOnline(true);
        ws.send(JSON.stringify({ type: 'hello', role: 'ui' }));
      };
      ws.onmessage = (ev) => {
        const m = JSON.parse(ev.data);
        switch (m.type) {
          case 'estado':
            aplicarEstado(m);
            break;
          case 'novela':
            setNovelas((prev) => {
              const i = prev.findIndex((n) => n.id === m.novela.id);
              if (i === -1) return [...prev, m.novela].sort((a, b) => a.ordem - b.ordem);
              const c = prev.slice(); c[i] = m.novela; return c;
            });
            break;
          case 'novela_removida': setNovelas((p) => p.filter((n) => n.id !== m.id)); break;
          case 'extensao': setExtensao(m.extensao); break;
          case 'fila': setFila(m.fila); break;
          case 'dom_map': setDomMap(m.domMap); break;
          case 'config': setConfig(m.config || {}); break;
          case 'tunel': setTunel(m.tunel || { estado: 'parado', ativo: false, online: false }); break;
          case 'log': setLogs((p) => [...p.slice(-299), m.entrada]); break;
        }
      };
      ws.onclose = (ev) => {
        if (ev?.code === 4401) {
          setPinBloqueado(true);
          return;
        }
        setServidorOnline(false);
        setExtensao({ conectada: false });
        if (vivo) timer = setTimeout(conectar, 1500);
      };
    };

    req('GET', '/api/auth/status')
      .then((auth) => {
        if (!vivo) return;
        setServidorOnline(true);
        if (auth?.pinExigido && !auth?.autenticado) {
          setPinBloqueado(true);
          return;
        }
        req('GET', '/api/estado').then((m) => {
          if (!vivo) return;
          aplicarEstado(m);
        }).catch(() => {});
        conectar();
      })
      .catch(() => {
        if (!vivo) return;
        conectar();
      });

    return () => { vivo = false; clearTimeout(timer); wsRef.current?.close(); };
  }, [cicloAuth]);

  const autenticarPin = useCallback(async (pinDigitado) => {
    const r = await api.verificarPin(pinDigitado);
    salvarPinLocal(r?.token || pinDigitado);
    setPinBloqueado(false);
    setCicloAuth((c) => c + 1);
  }, []);

  const upsert = useCallback((n) => {
    setNovelas((prev) => {
      const i = prev.findIndex((x) => x.id === n.id);
      if (i === -1) return [...prev, n];
      const c = prev.slice(); c[i] = n; return c;
    });
  }, []);

  return { novelas, extensao, fila, domMap, config, setConfig, claudeCli, setClaudeCli, tunel, setTunel, logs, servidorOnline, pinBloqueado, autenticarPin, upsert };
}

export const QUALIDADES = {
  qualidadeGeracaoVideo: {
    rotulo: 'Qualidade de Geração (Vídeo)',
    opcoes: [['360p', '360p (mais rápida)'], ['720p', '720p'], ['1080p', '1080p'], ['4k', '4K / 2160p (se o modelo oferecer)']],
  },
  qualidadeDownloadVideo: {
    rotulo: 'Qualidade de Download (Vídeo)',
    opcoes: [['original', 'Mesma da geração — sem upscale'], ['720p', '720p HD'], ['1080p', '1080p / 1K'], ['4k', '4K / 2160p (upscale)']],
  },
  qualidadeDownloadImagem: {
    rotulo: 'Qualidade de Download (Imagem)',
    opcoes: [['original', 'Original do Flow'], ['1k', '1K'], ['2k', '2K (alta qualidade)'], ['4k', '4K (upscale)']],
  },
};

export const ROTULOS_TIPO = {
  referencia_imagem: 'Referência',
  imagem_base: 'Imagem-base',
  video: 'Vídeo',
};

export const ROTULOS_SUBMODO = {
  texto_puro: 'Texto puro',
  ingredientes_imagem: 'Ingredientes',
  frame_inicial: 'Frame inicial',
  elementos_video: 'Elementos',
  texto_video: 'Texto → vídeo',
};

export function progressoNovela(n) {
  const itens = Array.isArray(n?.itens) ? n.itens : [];
  const vids = itens.filter((i) => i.tipo === 'video');
  const concl = (arr) => arr.filter((i) => i.status === 'concluido').length;
  return {
    videos: { feito: concl(vids), total: vids.length },
    todos: { feito: concl(itens), total: itens.length },
  };
}

export function statusNovela(n, fila = {}) {
  const itens = Array.isArray(n?.itens) ? n.itens : [];
  if (fila?.novelaAtual === n?.id && fila?.rodando) return { chave: 'rodando', rotulo: fila?.modoIsolado ? 'Regenerando' : 'Rodando' };
  if (n?.concluidaManualmente || n?.statusManual === 'concluida') return { chave: 'concluida', rotulo: '✅ Concluída', manual: true };
  if (fila?.motivoPausa === 'creditos_esgotados' && fila?.alertaCreditos?.novelaId === n?.id) return { chave: 'sem_creditos', rotulo: 'Trocar conta' };
  if (fila?.pausado && !fila?.rodando && fila?.novelaPausadaId === n?.id) return { chave: 'pausada', rotulo: 'Pausada' };
  if (fila?.fila?.includes(n?.id)) return { chave: 'na_fila', rotulo: 'Na fila' };
  if (!itens.length) return { chave: 'rascunho', rotulo: 'Rascunho' };
  if (!n?.validacao?.ok) return { chave: 'invalido', rotulo: 'Roteiro com erros' };
  if (itens.every((i) => i.status === 'concluido')) return { chave: 'concluida', rotulo: '✅ Concluída', manual: false };
  if (itens.some((i) => i.status === 'falha_revisar' || i.status === 'bloqueado_dependencia' || i.status === 'erro')) {
    return { chave: 'revisar', rotulo: 'Revisar itens' };
  }
  if (itens.some((i) => i.status === 'concluido')) return { chave: 'parcial', rotulo: 'Em andamento' };
  return { chave: 'pronta', rotulo: 'Pronta' };
}
