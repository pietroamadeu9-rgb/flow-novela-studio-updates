import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { erro: null, info: null };
  }
  static getDerivedStateFromError(erro) {
    return { erro };
  }
  componentDidCatch(erro, info) {
    console.error('[ErrorBoundary FlowStudio]', erro, info?.componentStack || '');
    this.setState({ info });
  }
  render() {
    if (this.state.erro) {
      return (
        <div className="flex h-full flex-col items-center justify-center bg-studio-950 p-6 text-zinc-200">
          <div className="w-full max-w-2xl rounded-xl border border-red-500/40 bg-studio-900 p-5 shadow-2xl">
            <h2 className="text-base font-bold text-red-300">Ocorreu um erro inesperado na interface</h2>
            <p className="mt-1 text-xs text-zinc-400">
              O ErrorBoundary interceptou a falha para evitar tela preta. Detalhes técnicos:
            </p>
            <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap rounded-lg border border-white/[0.08] bg-black/50 p-3 font-mono text-[11px] text-red-200">
              {String(this.state.erro?.stack || this.state.erro?.message || this.state.erro)}
              {this.state.info?.componentStack ? `\n${this.state.info.componentStack}` : ''}
            </pre>
            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                className="btn-primary"
                onClick={() => window.location.reload()}
              >
                Recarregar Interface
              </button>
              <button
                type="button"
                className="btn-ghost"
                onClick={() => {
                  try {
                    localStorage.removeItem('fns.fabrica.criadorEstado.v1');
                  } catch {}
                  this.setState({ erro: null, info: null });
                }}
              >
                Limpar Cache Local e Tentar Novamente
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
