import React, { useState } from 'react';
import { RotateCw, Pencil, Save, X, ImageOff, Loader2, AlertTriangle, VideoOff, FolderOpen, Clock, Link2, Download } from 'lucide-react';
import { api, mediaUrl, ROTULOS_SUBMODO } from '../api.js';
import { ItemStatus, Vazio } from './ui.jsx';
import { BotoesItem } from './AcoesItem.jsx';

const PASTA_TIPO = { referencia_imagem: '01_Referencias', imagem_base: '02_Imagens_Base', video: '03_Videos' };

function Placeholder({ item, video }) {
  const ehFalha = item.status === 'erro' || item.status === 'falha_revisar' || item.status === 'bloqueado_dependencia';
  const I = item.status === 'gerando' ? Loader2 : ehFalha ? AlertTriangle : video ? VideoOff : ImageOff;
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-[radial-gradient(ellipse_at_top,_#1e1b2e,_#0b0b10)] p-4 text-center">
      <I size={28} className={`${item.status === 'gerando' ? 'animate-spin text-amber-400' : ehFalha ? 'text-rose-400' : 'text-studio-500'}`} />
      <div className="text-[11px] text-zinc-500">
        {item.status === 'gerando'
          ? (item.progresso || 'Gerando no Google Flow...')
          : item.status === 'falha_revisar'
          ? 'Falhou após 3 tentativas (revisar)'
          : item.status === 'bloqueado_dependencia'
          ? 'Aguardando referência/imagem-base'
          : item.status === 'erro'
          ? 'Falhou'
          : item.status === 'na_fila'
          ? 'Na fila'
          : 'Ainda não gerado'}
      </div>
    </div>
  );
}

function EditorPrompt({ novela, item, executar }) {
  const [editando, setEditando] = useState(false);
  const [valor, setValor] = useState(item.prompt);
  if (!editando) {
    return (
      <div className="group relative">
        <p className="line-clamp-3 text-[11px] leading-snug text-zinc-400" title={item.prompt}>{item.prompt}</p>
        <button className="absolute -right-1 -top-1 rounded bg-studio-800 p-1 text-zinc-500 opacity-0 transition group-hover:opacity-100 hover:text-white"
          title="Editar prompt" onClick={() => { setValor(item.prompt); setEditando(true); }}><Pencil size={11} /></button>
      </div>
    );
  }
  return (
    <div className="space-y-1.5">
      <textarea className="input min-h-[110px] resize-y p-2 text-[11px] leading-snug" autoFocus value={valor} onChange={(e) => setValor(e.target.value)} />
      <div className="flex justify-end gap-1.5">
        <button className="btn-ghost px-2 py-1 text-[11px]" onClick={() => setEditando(false)}><X size={12} /></button>
        <button className="btn-primary px-2 py-1 text-[11px]" onClick={async () => {
          const r = await executar(() => api.atualizarItem(novela.id, item.id, { prompt: valor }), 'Prompt atualizado');
          if (r) setEditando(false);
        }}><Save size={12} /> Salvar</button>
      </div>
    </div>
  );
}

function Rodape({ novela, item, executar, extra, acoes }) {
  return (
    <div className="flex flex-1 flex-col gap-2 p-3">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate font-mono text-[13px] font-semibold text-white" title={item.arquivoNome}>{item.id}</div>
          <div className="text-[10px] text-zinc-600">{ROTULOS_SUBMODO[item.submodo]} · {item.proporcao}</div>
        </div>
        <ItemStatus status={item.status} />
      </div>
      {extra}
      <EditorPrompt novela={novela} item={item} executar={executar} />
      {(item.geradoPorDescricaoSemImagem || item.modoDescritivoSemImagem) ? (
        <div className="rounded border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[10px] font-semibold text-amber-200" title={`Prompt original: ${item.promptOriginalBackup || item.originalPrompt || ''}`}>
          {item.status === 'concluido' ? '📝 Gerado por descrição (sem imagem)' : '📝 Modo 100% Descritivo (sem imagem anexada)'}
        </div>
      ) : (item.originalPrompt || item.promptOriginalBackup) && (item.originalPrompt || item.promptOriginalBackup) !== item.prompt ? (
        <div className="rounded border border-violet-500/30 bg-violet-500/10 px-2 py-1 text-[10px] text-violet-300" title={`Prompt original: ${item.promptOriginalBackup || item.originalPrompt}`}>
          ✨ Auto-ajustado ({item.promptAutoAjustado === 'claude-cli' ? 'Claude CLI' : 'segurança local'})
        </div>
      ) : null}
      {item.erro && <div className="rounded bg-red-500/10 px-2 py-1 text-[10px] text-red-300">{item.erro}</div>}
      {item.arquivo && item.formatoReal && (
        <div className="text-[10px] text-zinc-600">
          {item.formatoReal.toUpperCase()} · {Math.round((item.tamanhoBytes || 0) / 1024)} KB{item.resolucaoDownload ? ` · ${item.resolucaoDownload}` : ''}
        </div>
      )}
      <div className="mt-auto space-y-1.5 pt-1">
        <BotoesItem item={item} novela={novela} acoes={acoes} />
        {novela.flowProjectUrl && (item.flowMidiaChave || item.nomeAtivoFlow) && (
          <button className="btn-ghost w-full py-1 text-[11px]" disabled={item.status === 'gerando'} title="Baixar de novo do Flow (sem gerar outra vez), com a qualidade de download atual"
            onClick={() => executar(() => api.rebaixar(novela.id, item.id), `Baixando {${item.id}} de novo...`)}>
            <Download size={12} /> Baixar de novo
          </button>
        )}
      </div>
    </div>
  );
}

function Cabecalho({ novela, tipo, itens, executar, titulo, descricao }) {
  const feitos = itens.filter((i) => i.status === 'concluido').length;
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-base font-semibold text-white">{titulo}</h2>
        <p className="text-xs text-zinc-500">{descricao} · {feitos}/{itens.length} gerados</p>
      </div>
      <button className="btn-ghost text-xs" onClick={() => executar(() => api.abrirPasta(novela.id, PASTA_TIPO[tipo]))}>
        <FolderOpen size={14} /> Abrir {PASTA_TIPO[tipo]}
      </button>
    </div>
  );
}

export function GaleriaImagens({ novela, tipo, executar, acoes }) {
  const itens = novela.itens.filter((i) => i.tipo === tipo);
  const porId = Object.fromEntries(novela.itens.map((i) => [i.id, i]));
  const ehRef = tipo === 'referencia_imagem';

  if (!itens.length) {
    return <Vazio icon={ImageOff} titulo={ehRef ? 'Nenhuma referência ainda' : 'Nenhuma imagem-base ainda'} texto="Processe o roteiro na aba “Roteiro & Fila” para preencher esta galeria." />;
  }
  return (
    <div>
      <Cabecalho novela={novela} tipo={tipo} itens={itens} executar={executar}
        titulo={ehRef ? 'Referências (Bloco 1)' : 'Imagens-Base (Bloco 2)'}
        descricao={ehRef ? 'Personagens e cenários gerados por texto puro' : 'Composições geradas com ingredientes de referência'} />
      <div className="grid grid-cols-[repeat(auto-fill,minmax(210px,1fr))] gap-4">
        {itens.map((it) => {
          const url = mediaUrl(novela, it);
          return (
            <div key={it.id} className={`card flex flex-col overflow-hidden transition hover:border-studio-500 ${it.status === 'gerando' ? 'ring-1 ring-amber-500/50' : ''}`}>
              <div className="relative aspect-[9/16] w-full overflow-hidden bg-black">
                {url ? (
                  <a href={url} target="_blank" rel="noreferrer"><img src={url} alt={it.id} loading="lazy" className="h-full w-full object-cover transition duration-300 hover:scale-[1.02]" /></a>
                ) : <Placeholder item={it} />}
                {url && it.status === 'gerando' && <div className="absolute inset-0 flex items-center justify-center bg-black/60"><Loader2 className="animate-spin text-amber-400" /></div>}
              </div>
              <Rodape novela={novela} item={it} executar={executar} acoes={acoes} extra={!ehRef && (
                <div>
                  <div className="mb-1 flex items-center gap-1 text-[10px] uppercase tracking-wider text-zinc-600"><Link2 size={10} /> Refs usadas (ordem)</div>
                  <div className="flex flex-wrap gap-1.5">
                    {it.refs.map((r, i) => {
                      const ri = porId[r];
                      const ru = ri && mediaUrl(novela, ri);
                      return (
                        <span key={r} className={`chip pr-2 ${it.refsFaltando?.includes(r) ? '!border-red-500/60 !text-red-300' : ''}`} title={ri ? ri.prompt : 'Referência não declarada'}>
                          {ru ? <img src={ru} className="h-5 w-3 rounded-sm object-cover" alt="" /> : <span className="text-zinc-600">{i + 1}.</span>}
                          {r}
                        </span>
                      );
                    })}
                  </div>
                </div>
              )} />
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function GaleriaVideos({ novela, executar, acoes }) {
  const itens = novela.itens.filter((i) => i.tipo === 'video');
  const porId = Object.fromEntries(novela.itens.map((i) => [i.id, i]));
  if (!itens.length) {
    return <Vazio icon={VideoOff} titulo="Nenhum vídeo ainda" texto="Processe o roteiro na aba “Roteiro & Fila” para preencher esta galeria." />;
  }
  return (
    <div>
      <Cabecalho novela={novela} tipo="video" itens={itens} executar={executar} titulo="Vídeos 9:16 (Bloco 3)" descricao={`Modelo ${novela.modeloVideo}`} />
      <div className="grid grid-cols-[repeat(auto-fill,minmax(230px,1fr))] gap-4">
        {itens.map((it) => {
          const url = mediaUrl(novela, it);
          return (
            <div key={it.id} className={`card flex flex-col overflow-hidden transition hover:border-studio-500 ${it.status === 'gerando' ? 'ring-1 ring-amber-500/50' : ''}`}>
              <div className="relative aspect-[9/16] w-full overflow-hidden bg-black">
                {url ? (
                  <video key={url} src={url} controls loop playsInline preload="metadata" className="h-full w-full object-cover" />
                ) : <Placeholder item={it} video />}
                <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-semibold text-white backdrop-blur"><Clock size={10} /> {it.duracao}s</span>
              </div>
              <Rodape novela={novela} item={it} executar={executar} acoes={acoes} extra={
                <div className="flex flex-wrap items-center gap-1.5">
                  {it.refs.map((r) => {
                    const ri = porId[r];
                    const ru = ri && mediaUrl(novela, ri);
                    return (
                      <span key={r} className={`chip pr-2 ${it.refsFaltando?.includes(r) ? '!border-red-500/60 !text-red-300' : ''}`}>
                        {ru && <img src={ru} className="h-5 w-3 rounded-sm object-cover" alt="" />}{r}
                      </span>
                    );
                  })}
                  <select className="ml-auto rounded border border-studio-700 bg-studio-950 px-1 py-0.5 text-[10px] text-zinc-400" value={it.duracao}
                    title="Duração" onChange={(e) => executar(() => api.atualizarItem(novela.id, it.id, { duracao: Number(e.target.value) }))}>
                    <option value={10}>10s</option><option value={15}>15s</option>
                  </select>
                </div>
              } />
            </div>
          );
        })}
      </div>
    </div>
  );
}
