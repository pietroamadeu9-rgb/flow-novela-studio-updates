import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Rocket, Library, Smartphone, AlarmClock, Download, CheckCircle2, Loader2, FolderOpen, QrCode, Send, Dice5, Bot, LogIn, Play, Square, Sparkles, FileText, RefreshCw, Link2, Settings2, Cloud, ExternalLink, Copy, Folder, ChevronDown, ChevronRight, Info, Target,
} from 'lucide-react';
import { fab, api } from '../api.js';
import { Toggle } from './ui.jsx';
import { AbasPartes } from './ListaNovelas.jsx';
import { agruparProntos } from '../agrupamento.js';
import FichasVirais from './FichasVirais.jsx';
import { ModalTipoFinal, ModalDialogos, SeletorTipoFinal, BadgeTipoFinal, ListaDialogosEditavel } from './FabricaModais.jsx';

/** Atualiza um valor chamando `fn` agora e a cada `ms` (enquanto a aba estiver aberta). */
function usePoll(fn, ms, deps = []) {
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState(null);
  const ref = useRef(fn); ref.current = fn;
  const recarregar = useCallback(async () => { try { setDados(await ref.current()); setErro(null); } catch (e) { setErro(e.message); } }, []);
  useEffect(() => {
    let vivo = true;
    const roda = async () => { try { const d = await ref.current(); if (vivo) { setDados(d); setErro(null); } } catch (e) { if (vivo) setErro(e.message); } };
    roda();
    const t = ms ? setInterval(roda, ms) : null;
    return () => { vivo = false; if (t) clearInterval(t); };
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  return [dados, erro, recarregar];
}

const SUBS = [
  { id: 'criador', rotulo: '🚀 Criador & Prontos', icon: Rocket },
  { id: 'series', rotulo: '📚 Minhas Séries', icon: Library },
  { id: 'capcut', rotulo: '📲 CapCut & WhatsApp', icon: Smartphone },
  { id: 'fichas', rotulo: '🎯 Fichas Virais', icon: Target },
  { id: 'agenda', rotulo: '⏰ Agendamento Viral', icon: AlarmClock },
];

function Caixa({ titulo, icon: I, children, direita }) {
  return (
    <section className="card p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">{I && <I size={15} className="text-fuchsia-400" />} {titulo}</div>
        {direita}
      </div>
      {children}
    </section>
  );
}

function Legenda({ texto }) {
  if (!texto) return <div className="text-xs text-zinc-600">Sem legenda.</div>;
  return <pre className="whitespace-pre-wrap rounded-lg border border-studio-700 bg-studio-950 p-3 font-sans text-xs leading-relaxed text-zinc-200">{texto}</pre>;
}

/**
 * Extrai o texto limpo da semente gerada pelo Claude na etapa `sementes` (Link Viral ou Sementes Anti-Clichê),
 * removendo logs técnicos do yt-dlp/whisper (`extrair_video.mjs`) e linhas `RESULTADO_JSON:`.
 */
export function extrairSementeLimpaFront(saida, transcricaoViral = '') {
  const bruto = String(saida || '').replace(/\r\n?/g, '\n');
  const limpo = bruto
    .replace(/^Tentando download[^\n]*\n?/gim, '')
    .replace(/^Transcrevendo as falas com whisper[^\n]*\n?/gim, '')
    .replace(/^⚡\s*Transcri[cç][aã]o[^\n]*cache local[^\n]*\n?/gim, '')
    .replace(/^#\s*Extra[cç][aã]o\s*[—–-][^\n]*\n?/gim, '')
    .replace(/^-\s*(?:Pasta|V[ií]deo|Dura[cç][aã]o|Transcri[cç][aã]o|Frames)\s*:[^\n]*\n?/gim, '')
    .replace(/^Pr[oó]ximo passo:\s*ler transcricao\.txt[^\n]*\n?/gim, '')
    .replace(/^RESULTADO_JSON:\s*\{[^\n]*\}\s*$/gim, '')
    .replace(/\n---\s*$/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  if (limpo) return limpo;
  return String(transcricaoViral || '').trim();
}

// ---------- Visualizador de tarefa do Claude ----------
function JobView({ jobId, aoTerminar, aoNaoEncontrar, rotuloSaida = 'O que o Claude fez' }) {
  const [job, erro, recarregar] = usePoll(() => (jobId ? fab.job(jobId) : Promise.resolve(null)), 1500, [jobId]);
  const [expirado, setExpirado] = useState(false);
  const avisou = useRef(false);
  const avisouSumiu = useRef(false);
  useEffect(() => { avisou.current = false; avisouSumiu.current = false; setExpirado(false); }, [jobId]);
  useEffect(() => { if (job && job.estado !== 'rodando' && !avisou.current) { avisou.current = true; aoTerminar?.(job); } }, [job]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (erro && !avisouSumiu.current) {
      avisouSumiu.current = true;
      aoNaoEncontrar?.(erro);
    }
  }, [erro]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!jobId || job || erro) return undefined;
    const t = setTimeout(() => {
      if (!avisouSumiu.current) {
        avisouSumiu.current = true;
        setExpirado(true);
        aoNaoEncontrar?.('Tarefa não encontrada após reinício do servidor.');
      }
    }, 3500);
    return () => clearTimeout(t);
  }, [jobId, job, erro]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!jobId || erro || expirado) return null;
  if (!job) return <div className="text-xs text-zinc-500">Carregando tarefa...</div>;
  const rodando = job.estado === 'rodando';
  return (
    <div className="mt-3 rounded-lg border border-studio-700 bg-studio-950 p-3">
      <div className="flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 font-semibold text-zinc-200">
          {rodando ? <Loader2 size={14} className="animate-spin text-amber-300" /> : job.estado === 'ok' ? <CheckCircle2 size={14} className="text-emerald-400" /> : <Square size={13} className="text-red-400" />}
          {job.titulo} <span className="font-normal text-zinc-500">· {job.etapa}</span>
        </div>
        {rodando && <button className="btn-ghost px-2 py-1 text-[11px]" onClick={async () => { await fab.cancelarJob(job.id); recarregar(); }}>Cancelar</button>}
      </div>
      {Array.isArray(job.etapas) && job.etapas.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-2 text-[11px]">
          {job.etapas.map((e) => (
            <span key={e.n} className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-1 ${e.estado === 'ok' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : e.estado === 'rodando' ? 'border-amber-500/40 bg-amber-500/10 text-amber-200' : e.estado === 'erro' ? 'border-red-500/30 bg-red-500/10 text-red-200' : 'border-studio-700 text-zinc-500'}`}>
              {e.estado === 'ok' ? <CheckCircle2 size={12} /> : e.estado === 'rodando' ? <Loader2 size={12} className="animate-spin" /> : <span className="inline-block h-2 w-2 rounded-full bg-zinc-600" />}
              Etapa {e.n}/{job.etapas.length}: {e.rotulo || e.nome}{e.modelo ? ` (${e.modelo === 'opus' ? 'Opus' : 'Sonnet'})` : ''}
            </span>
          ))}
        </div>
      )}
      {job.erro && <div className="mt-2 rounded border border-red-500/30 bg-red-500/10 px-2 py-1.5 text-xs text-red-200">{job.erro}</div>}
      {job.tipo === 'sementes' && job.estado === 'ok' && (
        <div className="mt-2 rounded border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1.5 text-xs text-emerald-200">
          ✅ Semente gerada e preenchida na caixa abaixo — revise/edite se quiser e clique em <b>🎬 Aprovar semente → escrever roteiro</b>.
        </div>
      )}
      {job.validacao && job.tipo !== 'sementes' && job.tipo !== 'ficha' && (
        <div className={`mt-2 rounded border px-2 py-1.5 text-xs ${job.validacao.ok ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-amber-500/30 bg-amber-500/10 text-amber-200'}`}>
          {job.validacao.ok
            ? ((job.tipo === 'roteiro' || job.validacao.apenasRoteiro)
                ? '✅ Roteiro validado (0 erros)'
                : '✅ Validador da Fábrica: APROVADO (roteiro, prompts e legenda)')
            : '⚠️ Validador reprovou ou falta arquivo:'}
          {!job.validacao.ok && <pre className="mt-1 whitespace-pre-wrap font-mono text-[10px]">{String(job.validacao.saida || '').slice(-1500)}</pre>}
        </div>
      )}
      {job.importacao && (
        <div className="mt-2 rounded border border-violet-500/30 bg-violet-500/10 px-2 py-1.5 text-xs text-violet-100">
          📥 Importada no Estúdio: <b>{job.importacao.nome}</b>
          {job.importacao.herdadas ? ` · ${job.importacao.herdadas} referência(s) herdada(s)` : ''}
          {job.importacao.filaIniciada ? ' · fila do Flow iniciada' : ''}
        </div>
      )}
      <details className="mt-2">
        <summary className="cursor-pointer text-[11px] uppercase tracking-wider text-zinc-500">{rotuloSaida}</summary>
        <pre className="mt-1 max-h-96 overflow-y-auto whitespace-pre-wrap rounded bg-black/40 p-2 font-mono text-[11px] leading-relaxed text-zinc-300">{job.saida || (rodando ? 'Aguardando resposta do Claude...' : '(sem texto)')}</pre>
      </details>
    </div>
  );
}

// ---------- Status do Claude (oculto por padrao quando tudo estiver 100% OK) ----------
function StatusFabrica({ executar, forcarAberto = false }) {
  const [st, erro, recarregar] = usePoll(() => fab.status(), 15000);
  if (erro) return <div className="card border-red-500/30 p-3 text-xs text-red-300">Não consegui ler a Fábrica: {erro}</div>;
  if (!st) return null;
  const c = st.claude || {};
  const tudoOk = Boolean(
    st.fabricaExiste &&
    c.disponivel &&
    c.logado !== false &&
    st.ferramentas?.ytdlp &&
    st.ferramentas?.ffmpeg &&
    st.ferramentas?.whisper
  );
  if (tudoOk && !forcarAberto) return null;
  return (
    <div className="card flex flex-wrap items-center gap-3 p-3 text-xs">
      <span className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 ${st.fabricaExiste ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-red-500/30 bg-red-500/10 text-red-300'}`}>
        <FolderOpen size={13} /> {st.fabricaExiste ? st.pasta : 'Pasta da Fábrica não encontrada'}
      </span>
      <span className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 ${c.disponivel ? 'border-violet-500/30 bg-violet-500/10 text-violet-200' : 'border-amber-500/30 bg-amber-500/10 text-amber-200'}`} title="Chamadas em segundo plano sempre usam o modelo Sonnet (nunca Opus)">
        <Bot size={13} /> {c.disponivel ? `Claude ${c.versao?.split(' ')[0]} · ${c.modeloBackground}` : 'Claude CLI não encontrado'}
      </span>
      {c.disponivel && (
        c.logado === false
          ? <button className="btn-primary px-2.5 py-1 text-xs" onClick={() => executar(() => fab.abrirLogin(), 'Terminal aberto — digite /login se pedir')}><LogIn size={13} /> Fazer login no Claude</button>
          : <span className={c.logado ? 'text-emerald-400' : 'text-zinc-500'}>{c.logado ? '✅ logado' : 'login: verificar'}</span>
      )}
      <span className="text-zinc-500">Ferramentas:</span>
      {[['yt-dlp', st.ferramentas?.ytdlp], ['ffmpeg', st.ferramentas?.ffmpeg], ['whisper', st.ferramentas?.whisper]].map(([n, ok]) => (
        <span key={n} className={ok ? 'text-emerald-400' : 'text-red-400'}>{ok ? '✓' : '✗'} {n}</span>
      ))}
      <button className="btn-ghost ml-auto px-2 py-1 text-[11px]" onClick={() => { fab.status(true).then(() => recarregar()); }}><RefreshCw size={12} /></button>
    </div>
  );
}

// ---------- Card de parte pronta / rascunho ----------
function CardPronto({ p, executar, toast, studio, irParaNovela, serie, destaque, recarregarProntos, modoOperacao = 'aprovacao', modeloRoteirista = 'sonnet', aoAbrirRevisaoRoteiro = null }) {
  const [iniciarFila, setIniciarFila] = useState(false);
  const [job, setJob] = useState(null);
  const [modal, setModal] = useState(null); // 'regerar' | 'proxima' | null
  const [dialogos, setDialogos] = useState(null);
  const novela = p.importada ? studio.novelas.find((n) => n.id === p.importada.novelaId) : null;
  const regerando = !!p.regerando; // o Claude esta reescrevendo ESTA parte agora (vem do servidor)
  const jobVisivel = job || p.regerando?.jobId || null;
  const proximaPronta = !!serie?.partes?.find((x) => x.parte === p.parte + 1 && x.status === 'pronta');
  const podeProxima = !regerando && !!serie && p.pronta && !p.rascunho && !proximaPronta
    && (p.parte < (serie.totalPartes || p.totalPartes || 1) || p.tipoFinal === 'aberto');
  const aguardandoPrompts = p.temRoteiro && (!p.temPrompts || !p.pronta);
  return (
    <div className={`card p-4 ${p.rascunho ? 'border-amber-500/40' : destaque ? 'border-fuchsia-500/50 bg-gradient-to-br from-violet-950/40 to-studio-900 shadow-lg shadow-fuchsia-950/30' : ''}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-base font-bold text-white">
            <Sparkles size={16} className="text-fuchsia-400" /> {p.titulo}
            {p.rascunho && <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-amber-200" title={p.motivoRascunho || ''}>Rascunho</span>}
            <BadgeTipoFinal tipo={p.tipoFinal} />
          </div>
          <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-zinc-500">
            <span>{p.numeroCenas || '?'} cenas de {p.tamanhoCenaSegundos || '?'}s</span>
            <span>{p.serie && (p.totalPartes > 1 || p.parte > 1) ? `Série · parte ${p.parte}/${p.totalPartes}` : 'História única'}</span>
            <span className={p.legendaValida ? 'text-emerald-400' : 'text-amber-300'}>{p.legendaValida ? '✓ legenda Facebook válida' : '⚠ legenda ausente/inválida'}</span>
            {p.rascunho && p.motivoRascunho && <span className="text-amber-300">⚠ {p.motivoRascunho}</span>}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {!p.importada ? (
            <>
              <label className="flex items-center gap-1.5 text-[11px] text-zinc-400"><input type="checkbox" checked={iniciarFila} onChange={(e) => setIniciarFila(e.target.checked)} /> já iniciar a fila</label>
              {aguardandoPrompts ? (
                <button
                  className="btn-primary"
                  disabled={regerando}
                  title={regerando ? 'Aguarde o Claude terminar' : 'Executa apenas a Etapa 2: gera prompts_flow.txt, continuidade_cenas.md, metadata_flow.json e legenda_facebook.txt a partir do roteiro_humano.md já pronto (sem reescrever o roteiro)'}
                  onClick={async () => {
                    const j = await executar(
                      () => fab.prompts({ slug: p.slug, parte: p.parte, ajustes: '', importar: true, iniciarFila, tipoFinal: p.tipoFinal || 'fechado' }),
                      `Gerando prompts do Flow para "${p.titulo}"...`,
                    );
                    if (j) setJob(j.id);
                  }}
                >
                  <Sparkles size={15} /> ⚡ Gerar Prompts pro Flow
                </button>
              ) : (
                <button className="btn-primary" disabled={!p.pronta || regerando} title={regerando ? 'Espere o Claude terminar de reescrever' : undefined} onClick={async () => {
                  const r = await executar(() => fab.importar(p.slug, p.parte, iniciarFila), 'Importada para o Estúdio!');
                  if (r) { if (r.heranca?.faltando?.length && p.parte > 1) toast(`${r.heranca.faltando.length} referência(s) ainda não existem na Parte anterior e serão geradas.`, 'info'); irParaNovela?.(r.novelaId); }
                }}><Download size={15} /> Importar pro Estúdio (1 clique)</button>
              )}
            </>
          ) : (
            <button className="btn-success" onClick={() => irParaNovela?.(p.importada.novelaId)}><CheckCircle2 size={15} /> Importada — abrir no Estúdio</button>
          )}
          {(p.temRoteiro || regerando) && (
            <button className="btn-ghost text-xs" disabled={regerando} title={regerando ? '⏳ O Claude está reescrevendo — espere terminar para ler os diálogos novos' : 'Mostra só as falas das cenas para aprovar a história rapidinho'} onClick={() => setDialogos({ slug: p.slug, parte: p.parte })}>
              👁️ Ler Só Diálogos
            </button>
          )}
          <button className="btn-ghost text-xs" disabled={regerando} title={regerando ? 'Já está sendo reescrita' : 'Reescreve esta parte com o Claude (a versão atual é movida para _versoes)'} onClick={() => setModal('regerar')}>
            🔄 Gerar Novamente
          </button>
          {podeProxima && (
            <button className="btn-ghost text-xs" title="Gera a próxima parte herdando catálogo e imagens de 01_Referencias" onClick={() => setModal('proxima')}>
              ➕ Gerar Parte {p.parte + 1}
            </button>
          )}
        </div>
      </div>
      <div className="mt-3 grid gap-3 md:grid-cols-[1fr_auto]">
        <div>
          <div className="label mb-1">Legenda do Facebook</div>
          <Legenda texto={p.legendaFacebook} />
        </div>
        {novela && (
          <div className="min-w-[180px] text-xs text-zinc-500">
            <div className="label mb-1">No Estúdio</div>
            {novela.itens.filter((i) => i.tipo === 'video' && i.status === 'concluido').length}/{novela.itens.filter((i) => i.tipo === 'video').length} vídeos prontos
            {novela.legendaEnviadaWhatsappEm && <div className="mt-1 text-emerald-400">📲 legenda enviada {new Date(novela.legendaEnviadaWhatsappEm).toLocaleString('pt-BR')}</div>}
          </div>
        )}
      </div>
      {regerando && (
        <div className="mt-3 flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-100">
          <Loader2 size={14} className="mt-0.5 shrink-0 animate-spin text-amber-300" />
          <div>
            <b>⏳ Reescrevendo roteiro com Claude...</b> Isso leva alguns minutos; a versão antiga já foi guardada em <span className="font-mono">_versoes</span> e os botões ficam bloqueados até terminar.
            <div className="mt-0.5 text-[11px] text-amber-200/80">{p.regerando.etapa}</div>
          </div>
        </div>
      )}
      {!regerando && p.falhaRegerar && (
        <div className="mt-3 rounded-lg border border-red-500/50 bg-red-500/15 px-3 py-2 text-xs text-red-100">
          🔴 <b>Gerar Novamente falhou:</b> {p.falhaRegerar.erro}{p.falhaRegerar.restaurado ? ' (a versão anterior foi restaurada)' : ''}
        </div>
      )}
      {jobVisivel && (
        <JobView
          jobId={jobVisivel}
          aoTerminar={(j) => {
            recarregarProntos?.();
            if (j?.estado === 'ok' && (j?.validacao?.apenasRoteiro || modoOperacao === 'aprovacao')) {
              aoAbrirRevisaoRoteiro?.(j);
            }
          }}
          aoNaoEncontrar={() => setJob(null)}
          rotuloSaida="O que o Claude respondeu"
        />
      )}

      <ModalTipoFinal
        aberto={modal === 'regerar'}
        titulo={`🔄 Gerar Novamente — ${p.titulo}`}
        descricao={modoOperacao === 'aprovacao'
          ? 'Modo Com Aprovação ativo: o Claude reescreve apenas o roteiro (100% fiel ao resumo original) e para na revisão de diálogos antes de gerar os prompts do Flow. A versão atual fica guardada em _versoes.'
          : p.importada
            ? 'Esta parte já está no Estúdio: ao terminar, a MESMA novela é atualizada (itens iguais, como as referências já geradas, são mantidos).'
            : 'O Claude reescreve roteiro, prompts e legenda desta parte. A versão atual fica guardada em _versoes.'}
        mostrarReaproveitar
        reaproveitarPadrao={p.temRefsExistentes !== false}
        rotuloConfirmar={modoOperacao === 'aprovacao' ? 'Gerar Roteiro Novamente (Com Aprovação)' : 'Gerar Novamente'}
        onFechar={() => setModal(null)}
        onConfirmar={async ({ tipoFinal, observacao, reaproveitarRefs }) => {
          const apenasRoteiro = modoOperacao === 'aprovacao';
          const j = await executar(
            () => fab.regerar({
              slug: p.slug,
              parte: p.parte,
              tipoFinal,
              observacao,
              reaproveitarRefs,
              apenasRoteiro,
              importar: !apenasRoteiro,
              modeloRoteirista,
            }),
            apenasRoteiro ? 'Reescrevendo roteiro para aprovação...' : 'Reescrevendo com o Claude...',
          );
          if (j) { setJob(j.id); setModal(null); }
        }}
      />
      <ModalTipoFinal
        aberto={modal === 'proxima'}
        titulo={`➕ Gerar Parte ${p.parte + 1} — ${serie?.titulo || p.titulo}`}
        descricao="Continua a série herdando a Bíblia, o catálogo de personagens/cenários e as imagens de 01_Referencias."
        rotuloConfirmar={`Gerar Parte ${p.parte + 1}`}
        onFechar={() => setModal(null)}
        onConfirmar={async ({ tipoFinal, observacao }) => {
          const j = await executar(() => fab.gerarParte(p.slug, { parte: p.parte + 1, importar: true, iniciarFila: false, tipoFinal, observacao }), `Gerando Parte ${p.parte + 1}...`);
          if (j) { setJob(j.id); setModal(null); }
        }}
      />
      <ModalDialogos alvo={dialogos} onFechar={() => setDialogos(null)} />
    </div>
  );
}

// ---------- Prontos agrupados: 🎬 Parte Única | 📚 Séries ----------
function ProntosAgrupados({ prontos, series, executar, toast, studio, irParaNovela, recarregarProntos, modoOperacao = 'aprovacao', modeloRoteirista = 'sonnet', aoAbrirRevisaoRoteiro = null }) {
  const { unicas, series: grupos } = useMemo(() => agruparProntos(prontos || []), [prontos]);
  const [aba, setAbaEstado] = useState(() => localStorage.getItem('fns.fabrica.prontosAba') || 'unica');
  const setAba = (a) => { setAbaEstado(a); localStorage.setItem('fns.fabrica.prontosAba', a); };
  const [abertos, setAbertos] = useState(() => new Set());
  const autoSelecionou = useRef(false);

  // abre a aba/pasta da novela ativa no Estúdio (ou a aba que tiver conteúdo)
  useEffect(() => {
    if (autoSelecionou.current || !prontos) return;
    autoSelecionou.current = true;
    const ativa = localStorage.getItem('fns.novela');
    const g = grupos.find((x) => x.partes.some((p) => p.importada?.novelaId === ativa));
    if (g) { setAba('serie'); setAbertos(new Set([g.chave])); return; }
    if (unicas.some((p) => p.importada?.novelaId === ativa)) { setAba('unica'); return; }
    if (aba === 'unica' && !unicas.length && grupos.length) setAba('serie');
    if (aba === 'serie' && !grupos.length && unicas.length) setAba('unica');
  }, [prontos]); // eslint-disable-line react-hooks/exhaustive-deps

  const alternar = (chave) => setAbertos((s) => { const n = new Set(s); n.has(chave) ? n.delete(chave) : n.add(chave); return n; });
  const card = (p, destaque) => (
    <CardPronto key={`${p.slug}-${p.parte}`} p={p} destaque={destaque} executar={executar} toast={toast} studio={studio} irParaNovela={irParaNovela}
      recarregarProntos={recarregarProntos}
      modoOperacao={modoOperacao}
      modeloRoteirista={modeloRoteirista}
      aoAbrirRevisaoRoteiro={aoAbrirRevisaoRoteiro}
      serie={(series || []).find((s) => s.slug === p.slug)} />
  );

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
        <div className="label">Prontos para importar</div>
        <div className="w-72"><AbasPartes aba={aba} setAba={setAba} qtdUnicas={unicas.length} qtdSeries={grupos.length} compacto /></div>
      </div>
      <div className="space-y-3">
        {(prontos || []).length === 0 && <div className="card p-4 text-xs text-zinc-500">Nenhuma história pronta ainda em prontos_para_flow.</div>}
        {aba === 'unica' && (prontos || []).length > 0 && (
          unicas.length ? unicas.map((p, i) => card(p, i === 0)) : <div className="card p-4 text-xs text-zinc-500">Nenhuma história de parte única pronta. Veja a aba 📚 Séries.</div>
        )}
        {aba === 'serie' && (prontos || []).length > 0 && (
          grupos.length === 0 ? <div className="card p-4 text-xs text-zinc-500">Nenhuma série pronta ainda.</div> : grupos.map((g) => {
            const aberto = abertos.has(g.chave);
            const importadas = g.partes.filter((p) => p.importada).length;
            const serieInfo = (series || []).find((s) => s.slug === g.chave);
            return (
              <div key={g.chave} className="card overflow-hidden">
                <button type="button" onClick={() => alternar(g.chave)} className="flex w-full flex-wrap items-center justify-between gap-3 p-4 text-left hover:bg-studio-800/50">
                  <div className="flex min-w-0 items-center gap-2.5">
                    {aberto ? <ChevronDown size={16} className="text-zinc-400" /> : <ChevronRight size={16} className="text-zinc-500" />}
                    {aberto ? <FolderOpen size={17} className="text-amber-300" /> : <Folder size={17} className="text-amber-400/80" />}
                    <span className="truncate text-base font-bold text-white">{serieInfo?.titulo || g.titulo}</span>
                    <span className="rounded bg-studio-700 px-2 py-0.5 text-[11px] text-zinc-300">
                      {g.partes.length}{g.totalPartes > g.partes.length ? `/${g.totalPartes}` : ''} partes
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-3 text-[11px]">
                    <span className="text-emerald-400">✓ {g.partes.filter((p) => p.pronta).length} pronta(s)</span>
                    <span className={importadas ? 'text-violet-300' : 'text-zinc-500'}>📥 {importadas} no Estúdio</span>
                  </div>
                </button>
                {aberto && <div className="space-y-3 border-t border-studio-700 p-3">{g.partes.map((p) => card(p, false))}</div>}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

const CHAVE_CRIADOR_LS = 'fns.fabrica.criadorEstado.v1';
function lerEstadoCriadorSalvo() {
  try {
    const raw = localStorage.getItem(CHAVE_CRIADOR_LS);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

// ---------- Criador ----------
function Criador({ executar, toast, studio, irParaNovela, abrirPadroes }) {
  const salvoInicial = useMemo(() => lerEstadoCriadorSalvo(), []);
  const [cfg, , recfg] = usePoll(() => fab.config(), 0);
  const [modo, setModo] = useState(salvoInicial.modo || 'aprovacao');
  const [origem, setOrigem] = useState(salvoInicial.origem || 'resumo');
  const [texto, setTexto] = useState(salvoInicial.texto || '');
  const [link, setLink] = useState(salvoInicial.link || '');
  const [duracao, setDuracao] = useState(salvoInicial.duracao ?? 3);
  const [tamanho, setTamanho] = useState(Number(salvoInicial.tamanho) === 10 ? 10 : 15);
  const [formato, setFormato] = useState(salvoInicial.formato || 'unica');
  const [partes, setPartes] = useState(salvoInicial.partes ?? 2);
  const [modoGeracaoVideo, setModoGeracaoVideo] = useState(salvoInicial.modoGeracaoVideo || 'elementos');
  const [modeloRoteirista, setModeloRoteirista] = useState(salvoInicial.modeloRoteirista === 'opus' ? 'opus' : 'sonnet'); // Padrão: Sonnet (5x mais econômico); Opus disponível sob escolha
  const [tipoFinal, setTipoFinal] = useState(salvoInicial.tipoFinal || ''); // obrigatorio: 'aberto' | 'fechado'
  const [importarAuto, setImportarAuto] = useState(salvoInicial.importarAuto !== false);
  const [iniciarFila, setIniciarFila] = useState(!!salvoInicial.iniciarFila);
  const [wiz, setWiz] = useState(salvoInicial.wiz || null); // {etapa:'sementes'|'roteiro'|'prompts', jobId, saida, resultado, dialogos}
  const [semente, setSemente] = useState(() => {
    if (salvoInicial.semente && String(salvoInicial.semente).trim()) return salvoInicial.semente;
    if (salvoInicial.wiz?.etapa === 'sementes') {
      return extrairSementeLimpaFront(
        salvoInicial.wiz.sementeGerada || salvoInicial.wiz.resultado?.semente || salvoInicial.wiz.saida || '',
        salvoInicial.wiz.transcricaoViral || salvoInicial.transcricaoViral || '',
      );
    }
    return '';
  });
  const [ajustes, setAjustes] = useState(salvoInicial.ajustes || '');
  const [dialogosRoteiro, setDialogosRoteiro] = useState(salvoInicial.wiz?.dialogos || null);
  const carregado = useRef(Boolean(salvoInicial && (salvoInicial.wiz || salvoInicial.texto || salvoInicial.semente || salvoInicial.tipoFinal)));

  useEffect(() => {
    if (cfg && !carregado.current) {
      carregado.current = true;
      setModo(cfg.modoOperacao || 'aprovacao'); setDuracao(cfg.duracaoTotalMinutos || 3); setTamanho(Number(cfg.tamanhoCenaSegundos) === 10 ? 10 : 15);
      setFormato(cfg.formatoHistoria || 'unica'); setPartes(cfg.numeroPartesPadrao || 2);
      setModoGeracaoVideo(cfg.modoGeracaoVideo === 'frame_inicial' ? 'frame_inicial' : 'elementos');
      setModeloRoteirista(cfg.modeloRoteirista === 'opus' ? 'opus' : 'sonnet');
    }
  }, [cfg]);

  const recuperarEstadoPosReinicio = useCallback(async () => {
    try {
      const [remoto, listaProntos] = await Promise.all([
        fab.estadoCriador().catch(() => null),
        fab.prontos().catch(() => []),
      ]);
      const pend = (listaProntos || []).find((p) => p.temRoteiro && !p.temPrompts);
      if (remoto?.semente && String(remoto.semente).trim()) {
        setSemente((atual) => (atual && atual.trim() ? atual : remoto.semente));
      }
      setWiz((w) => {
        if (remoto?.wiz && !remoto.wiz.jobId) return remoto.wiz;
        if (!w) return pend ? { etapa: 'roteiro', jobId: null, rodando: false, estado: 'ok', resultado: { slug: pend.slug, parte: pend.parte } } : null;
        if (w.etapa === 'roteiro') {
          const res = w.resultado?.slug ? w.resultado : (pend ? { slug: pend.slug, parte: pend.parte } : null);
          if (res?.slug) return { ...w, jobId: null, rodando: false, estado: 'ok', resultado: res };
        }
        if (w.etapa === 'sementes' && (w.saida || w.sementeGerada)) {
          const semLimpa = extrairSementeLimpaFront(w.sementeGerada || w.resultado?.semente || w.saida, w.transcricaoViral);
          if (semLimpa) setSemente((atual) => (atual && atual.trim() ? atual : semLimpa));
          return { ...w, jobId: null, rodando: false, estado: 'ok', validacao: null, sementeGerada: semLimpa || w.sementeGerada };
        }
        return null;
      });
      if (remoto?.wiz?.dialogos?.cenas?.length) setDialogosRoteiro(remoto.wiz.dialogos);
    } catch {
      setWiz(null);
    }
  }, []);

  // Sincroniza com o backend ao montar: restaura se o localStorage estava vazio E limpa/recupera jobId órfão ou semente vazia
  useEffect(() => {
    fab.estadoCriador().then((remoto) => {
      if (remoto?.semente && String(remoto.semente).trim()) {
        setSemente((atual) => (atual && atual.trim() ? atual : remoto.semente));
      }
      if (salvoInicial?.wiz?.jobId && (!remoto?.wiz || remoto.wiz.jobId !== salvoInicial.wiz.jobId)) {
        // O servidor reiniciou e limpou o jobId em memória: substitui imediatamente pelo estado recuperado do disco
        setWiz(remoto?.wiz || null);
        if (remoto?.wiz?.dialogos) setDialogosRoteiro(remoto.wiz.dialogos);
        return;
      }
      if (salvoInicial?.wiz || salvoInicial?.texto) return;
      if (!remoto || (!remoto.wiz && !remoto.texto && !remoto.semente)) return;
      if (remoto.modo) setModo(remoto.modo);
      if (remoto.origem) setOrigem(remoto.origem);
      if (typeof remoto.texto === 'string') setTexto(remoto.texto);
      if (typeof remoto.link === 'string') setLink(remoto.link);
      if (remoto.duracao) setDuracao(remoto.duracao);
      if (remoto.tamanho) setTamanho(Number(remoto.tamanho) === 10 ? 10 : 15);
      if (remoto.formato) setFormato(remoto.formato);
      if (remoto.partes) setPartes(remoto.partes);
      if (remoto.modoGeracaoVideo) setModoGeracaoVideo(remoto.modoGeracaoVideo);
      if (remoto.tipoFinal) setTipoFinal(remoto.tipoFinal);
      if (remoto.wiz) setWiz(remoto.wiz);
      if (typeof remoto.semente === 'string' && remoto.semente.trim()) setSemente(remoto.semente);
      if (typeof remoto.ajustes === 'string') setAjustes(remoto.ajustes);
      if (remoto.wiz?.dialogos) setDialogosRoteiro(remoto.wiz.dialogos);
    }).catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Garante que sempre que uma etapa de sementes concluir com saída válida, a caixa `semente` nunca fique vazia
  useEffect(() => {
    if (wiz?.etapa !== 'sementes') return;
    if (semente && semente.trim()) return;
    const semLimpa = extrairSementeLimpaFront(
      wiz.sementeGerada || wiz.resultado?.semente || wiz.saida || '',
      wiz.transcricaoViral || wiz.resultado?.transcricaoViral || '',
    );
    if (semLimpa) setSemente(semLimpa);
  }, [wiz?.etapa, wiz?.estado, wiz?.saida, wiz?.sementeGerada, wiz?.resultado?.semente]); // eslint-disable-line react-hooks/exhaustive-deps

  // Persiste estado em localStorage + backend sempre que mudar (nao some ao trocar para a aba Estudio & Fila Flow)
  useEffect(() => {
    const snap = {
      modo, origem, texto, link, duracao, tamanho, formato, partes, modoGeracaoVideo, modeloRoteirista,
      tipoFinal, importarAuto, iniciarFila, wiz, semente, ajustes,
    };
    try { localStorage.setItem(CHAVE_CRIADOR_LS, JSON.stringify(snap)); } catch {}
    const t = setTimeout(() => { fab.salvarEstadoCriador(snap).catch(() => {}); }, 400);
    return () => clearTimeout(t);
  }, [modo, origem, texto, link, duracao, tamanho, formato, partes, modoGeracaoVideo, modeloRoteirista, tipoFinal, importarAuto, iniciarFila, wiz, semente, ajustes]);

  // Carrega os dialogos limpos cena a cena (Dona Maria) assim que o roteiro fica pronto para aprovacao
  useEffect(() => {
    if (wiz?.dialogos?.cenas?.length) {
      setDialogosRoteiro(wiz.dialogos);
    }
    if (wiz?.etapa === 'roteiro' && wiz?.estado === 'ok' && wiz?.resultado?.slug) {
      fab.dialogos(wiz.resultado.slug, wiz.resultado.parte || 1)
        .then((d) => { if (d?.cenas?.length) setDialogosRoteiro(d); })
        .catch(() => {});
    }
  }, [wiz?.etapa, wiz?.estado, wiz?.resultado?.slug, wiz?.resultado?.parte, wiz?.dialogos]);

  const numCenasCalc = useMemo(() => {
    const d = Math.max(1, Number(duracao) || 3);
    const s = Number(tamanho) === 10 ? 10 : 15;
    return Math.round((d * 60) / s);
  }, [duracao, tamanho]);

  const config = () => ({
    modoOperacao: modo,
    duracaoTotalMinutos: Number(duracao) || 3,
    tamanhoCenaSegundos: Number(tamanho),
    formatoHistoria: formato,
    numeroPartesPadrao: formato === 'serie' ? Number(partes) || 2 : 1,
    modoGeracaoVideo,
    modeloRoteirista,
  });
  const corpo = () => ({ origem, texto, link, config: config() });
  const [prontos, , recarregarProntos] = usePoll(() => fab.prontos(), 4000);
  const [series] = usePoll(() => fab.series(), 8000);

  const iniciar = async () => {
    if (!tipoFinal) return toast('Escolha o rumo do final: 🔥 Final Aberto Chocante ou ✅ A História se Encerra Aqui.', 'erro');
    if (origem === 'link' && !link.trim()) return toast('Cole o link do vídeo.', 'erro');
    if (origem === 'resumo' && !texto.trim()) return toast('Escreva o resumo da história.', 'erro');
    if (modo === 'automatico') {
      const j = await executar(() => fab.automatico({ ...corpo(), tipoFinal, importar: importarAuto, iniciarFila: importarAuto && iniciarFila }), 'Fábrica trabalhando no modo automático...');
      if (j) setWiz({ etapa: 'automatico', jobId: j.id, rodando: true });
    } else if (origem === 'resumo') {
      // CUSTO ZERO DE SEMENTE: pula direto para a etapa Roteiro usando 100% fielmente o resumo do usuario!
      const resumoLimpo = texto.trim();
      setSemente(resumoLimpo);
      setAjustes('');
      setDialogosRoteiro(null);
      const j = await executar(
        () => fab.roteiro({ semente: resumoLimpo, resumoUsuario: resumoLimpo, origem: 'resumo', ajustes: '', config: config(), tipoFinal }),
        `Gerando roteiro fiel ao seu resumo (${numCenasCalc} cenas de ${Number(tamanho) === 10 ? 10 : 15}s)...`,
      );
      if (j) setWiz({ etapa: 'roteiro', jobId: j.id, rodando: true, origem: 'resumo' });
    } else {
      const j = await executar(() => fab.sementes(corpo()), origem === 'link' ? 'Baixando e analisando o vídeo...' : 'Gerando 5 sementes...');
      if (j) { setSemente(''); setAjustes(''); setDialogosRoteiro(null); setWiz({ etapa: 'sementes', jobId: j.id, rodando: true }); }
    }
  };

  const rotuloBotaoPrincipal = modo === 'automatico'
    ? '⚡ Criar tudo automaticamente'
    : origem === 'resumo'
      ? '🎬 Gerar Roteiro para Aprovação'
      : origem === 'link'
        ? '🔗 Analisar vídeo e criar semente'
        : '🌱 Gerar 5 Sementes';

  return (
    <div className="space-y-5">
      {/* Prontos para importar (Parte Única x Séries agrupadas por título) */}
      <ProntosAgrupados
        prontos={prontos}
        series={series}
        executar={executar}
        toast={toast}
        studio={studio}
        irParaNovela={irParaNovela}
        recarregarProntos={recarregarProntos}
        modoOperacao={modo}
        modeloRoteirista={modeloRoteirista}
        aoAbrirRevisaoRoteiro={(j) => {
          const slug = j?.resultado?.slug || j?.slugAlvo;
          const parte = j?.resultado?.parte || j?.parteAlvo || 1;
          if (!slug) return;
          setWiz({
            etapa: 'roteiro',
            jobId: null,
            rodando: false,
            estado: 'ok',
            saida: j.saida || '',
            resultado: { slug, parte },
            dialogos: j.dialogos || null,
          });
          if (j.dialogos?.cenas?.length) setDialogosRoteiro(j.dialogos);
        }}
      />

      {/* Criador */}
      <Caixa titulo="Criar história nova" icon={Sparkles}>
        <div className="mb-3 grid grid-cols-2 gap-2 md:max-w-md">
          {[
            ['aprovacao', '✋ Com Aprovação', 'Revisa roteiro antes dos prompts', 'Gera o roteiro primeiro para você revisar e aprovar os diálogos antes de gerar os prompts do Flow'],
            ['automatico', '⚡ 100% Automático', 'Gera roteiro e prompts direto', 'Executa roteiro, prompts e legenda em sequência direta'],
          ].map(([v, t, d, tip]) => (
            <button key={v} title={tip} onClick={() => setModo(v)} className={`rounded-lg border p-2.5 text-left transition ${modo === v ? 'border-violet-500/60 bg-violet-500/10' : 'border-white/[0.07] bg-studio-850 hover:border-white/[0.15]'}`}>
              <div className="text-xs font-semibold text-white">{t}</div><div className="text-[11px] text-zinc-500">{d}</div>
            </button>
          ))}
        </div>

        <div className="mb-3 flex flex-wrap gap-2">
          {[['resumo', '📋 Meu Resumo'], ['sementes', '🌱 Sementes Anti-Clichê'], ['link', '🔗 Link Viral']].map(([v, t]) => (
            <button key={v} onClick={() => setOrigem(v)} className={`rounded-lg border px-3 py-1.5 text-xs transition ${origem === v ? 'border-fuchsia-500/60 bg-fuchsia-500/10 text-fuchsia-100' : 'border-white/[0.07] text-zinc-400 hover:text-white'}`}>{t}</button>
          ))}
        </div>
        {origem === 'link' ? (
          <div>
            <input className="input" placeholder="Cole o link (Facebook, Instagram, TikTok, YouTube)..." value={link} onChange={(e) => setLink(e.target.value)} />
            <div className="mt-1 text-[11px] text-zinc-500">Baixado e transcrito localmente no PC (0 tokens).</div>
          </div>
        ) : (
          <div>
            <textarea className="input h-24 resize-y" placeholder={origem === 'resumo' ? 'Escreva o resumo completo da sua história (personagens, conflito e reviravolta final — será seguido 100% à risca)...' : 'Tema ou pedido opcional (ex.: sogra e nora no interior). Deixe vazio para 5 sementes livres.'} value={texto} onChange={(e) => setTexto(e.target.value)} />
          </div>
        )}

        <div className={`mt-3 grid grid-cols-2 gap-3 ${formato === 'serie' ? 'md:grid-cols-5' : 'md:grid-cols-4'}`}>
          <label className="text-xs text-zinc-400">Duração (min)<input type="number" min="1" max="30" className="input mt-1" value={duracao} onChange={(e) => setDuracao(e.target.value)} /></label>
          <label className="text-xs text-zinc-400">Cena ({numCenasCalc} cenas)
            <select className="input mt-1" value={tamanho} onChange={(e) => setTamanho(Number(e.target.value))}><option value="15">15s ({Math.round(((Number(duracao) || 3) * 60) / 15)} cenas · 23–30 pal.)</option><option value="10">10s ({Math.round(((Number(duracao) || 3) * 60) / 10)} cenas · 14–25 pal.)</option></select>
          </label>
          <label className="text-xs text-zinc-400">Formato
            <select className="input mt-1" value={formato} onChange={(e) => setFormato(e.target.value)}><option value="unica">História única</option><option value="serie">Série em partes</option></select>
          </label>
          {formato === 'serie' && (
            <label className="text-xs text-zinc-400">Nº de partes<input type="number" min="2" max="12" className="input mt-1" value={partes} onChange={(e) => setPartes(e.target.value)} /></label>
          )}
          <label className="col-span-2 text-xs text-zinc-400 md:col-span-1">Modo no Flow
            <select className="input mt-1" value={modoGeracaoVideo} onChange={(e) => setModoGeracaoVideo(e.target.value)}>
              <option value="elementos">🧩 Elementos (padrão)</option>
              <option value="frame_inicial">🖼️ Frame Inicial</option>
            </select>
          </label>
        </div>
        <div className="mt-4">
          <div className="label mb-1.5">Rumo do final (obrigatório) {formato === 'serie' && tipoFinal === 'fechado' && <span className="ml-1 normal-case text-amber-300">— atenção: série com final fechado na Parte 1 vira história de parte única</span>}</div>
          <SeletorTipoFinal valor={tipoFinal} onChange={setTipoFinal} />
        </div>
        <div className="mt-4">
          <div className="label mb-1.5">Modelo do roteirista (Criação)</div>
          <div className="inline-flex overflow-hidden rounded-lg border border-white/[0.07]" role="group">
            {[
              ['sonnet', '⚡ Sonnet (Padrão · Econômico)', 'Recomendado: rápido e gasta 5x menos cota na janela de 5h.'],
              ['opus', '🎭 Opus (Dramaturgia máxima)', 'Opcional: maior peso dramático, mas consome ~5x mais cota na janela de 5h.'],
            ].map(([v, t, tip]) => (
              <button
                key={v}
                type="button"
                title={tip}
                onClick={() => { setModeloRoteirista(v); fab.salvarConfig({ modeloRoteirista: v }).catch(() => {}); }}
                className={`px-4 py-1.5 text-xs font-medium transition ${modeloRoteirista === v ? 'bg-violet-500/25 text-violet-100' : 'text-zinc-400 hover:text-white'}`}
              >{t}</button>
            ))}
          </div>
          <span className="ml-3 text-[11px] text-zinc-500">Quando o roteiro já sai válido na 1ª chamada, a Etapa 2/2 é poupada automaticamente (0 tokens extras).</span>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-zinc-400">
          <span className="inline-flex flex-wrap items-center gap-1.5 text-zinc-500">
            Qualidade, resolução e modelos seguirão exatamente o definido em
            <button
              type="button"
              onClick={abrirPadroes}
              className="inline-flex items-center gap-1 font-medium text-violet-300 underline decoration-violet-500/40 underline-offset-2 hover:text-violet-200"
            >
              <Settings2 size={12} /> Padrões
            </button>
          </span>
          {modo === 'automatico' && <>
            <Toggle checked={importarAuto} onChange={setImportarAuto} label="Importar no Estúdio ao terminar" />
            <Toggle checked={importarAuto && iniciarFila} onChange={setIniciarFila} label="Já iniciar a fila no Google Flow" />
          </>}
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button className="btn-primary" disabled={!tipoFinal || (!!wiz && ['sementes', 'roteiro', 'prompts', 'automatico'].includes(wiz.etapa) && wiz.rodando)} title={!tipoFinal ? 'Escolha o rumo do final primeiro' : ''} onClick={iniciar}><Rocket size={15} /> {rotuloBotaoPrincipal}</button>
          <button
            className="btn-ghost text-xs"
            onClick={() =>
              executar(async () => {
                await fab.salvarConfig(config());
                const c = await api.atualizarConfig({ ...(studio.config.padroes || {}), forcarElementos: modoGeracaoVideo !== 'frame_inicial' });
                if (c) studio.setConfig(c);
              }, `Padrões salvos (modo ${modoGeracaoVideo === 'frame_inicial' ? 'Frame Inicial' : 'Elementos'})`).then(recfg)
            }
          >
            Salvar como padrão
          </button>
          {wiz && !wiz.rodando && (
            <button
              type="button"
              className="btn-ghost ml-auto text-xs text-zinc-400"
              onClick={() => {
                setWiz(null);
                setDialogosRoteiro(null);
                setAjustes('');
                try { localStorage.removeItem(CHAVE_CRIADOR_LS); } catch {}
                fab.salvarEstadoCriador({ __limpar: true }).catch(() => {});
              }}
            >
              Limpar aprovação atual
            </button>
          )}
        </div>

        {/* Fluxo com aprovação (persistido ao trocar de aba e recuperado após reinício do servidor) */}
        {(wiz || ((origem === 'sementes' || origem === 'link') && semente.trim())) && (
          <div className="mt-4 border-t border-studio-700 pt-4">
            {/* Stepper visual do fluxo */}
            <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border border-white/[0.06] bg-studio-950/80 px-3 py-2 text-[11px]">
              <span className={`inline-flex items-center gap-1.5 font-semibold ${(!wiz || wiz.etapa === 'sementes') ? 'text-fuchsia-300' : 'text-emerald-400'}`}>
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-white/10 text-[10px]">1</span>
                {origem === 'link' ? 'Link Viral → Semente' : origem === 'resumo' ? 'Meu Resumo' : 'Semente'}
              </span>
              <span className="text-zinc-600">➔</span>
              <span className={`inline-flex items-center gap-1.5 font-semibold ${wiz?.etapa === 'roteiro' ? 'text-fuchsia-300' : (wiz?.etapa === 'prompts' || wiz?.etapa === 'automatico') ? 'text-emerald-400' : 'text-zinc-500'}`}>
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-white/10 text-[10px]">2</span>
                Roteiro &amp; Diálogos (Aprovação)
              </span>
              <span className="text-zinc-600">➔</span>
              <span className={`inline-flex items-center gap-1.5 font-semibold ${(wiz?.etapa === 'prompts' || wiz?.etapa === 'automatico') ? 'text-fuchsia-300' : 'text-zinc-500'}`}>
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-white/10 text-[10px]">3</span>
                ⚡ Prompts pro Flow &amp; Estúdio
              </span>
            </div>

            {wiz?.jobId ? (
              <JobView
                jobId={wiz.jobId}
                aoTerminar={(j) => {
                  const semExtraida = (j.tipo === 'sementes' || wiz?.etapa === 'sementes')
                    ? extrairSementeLimpaFront(j.sementeGerada || j.resultado?.semente || j.saida, j.transcricaoViral || j.resultado?.transcricaoViral)
                    : '';
                  if (semExtraida) {
                    setSemente(semExtraida);
                  }
                  setWiz((w) => ({
                    ...w,
                    rodando: false,
                    saida: j.saida,
                    erro: j.erro || null,
                    sementeGerada: semExtraida || j.sementeGerada || w?.sementeGerada || null,
                    transcricaoViral: j.transcricaoViral || j.resultado?.transcricaoViral || w?.transcricaoViral || null,
                    validacao: (j.tipo === 'sementes' || j.tipo === 'ficha') ? null : j.validacao,
                    resultado: j.resultado,
                    importacao: j.importacao || null,
                    estado: j.estado,
                    dialogos: j.dialogos || w?.dialogos || null,
                  }));
                  if (j.dialogos?.cenas?.length) setDialogosRoteiro(j.dialogos);
                  recarregarProntos();
                }}
                aoNaoEncontrar={() => {
                  recuperarEstadoPosReinicio();
                }}
              />
            ) : wiz?.estado === 'erro' ? (
              <div className="mb-3 space-y-2 rounded-lg border border-red-500/35 bg-red-500/10 p-3 text-xs text-red-200">
                <div>
                  ⚠️ <b>A tarefa anterior falhou ou excedeu o tempo limite:</b> {wiz.erro || 'O Claude CLI não respondeu dentro do limite prudente.'}
                </div>
                {wiz.transcricaoViral && (
                  <div className="text-[11px] text-emerald-300">
                    ⚡ A transcrição deste vídeo já está salva no cache local ({wiz.transcricaoViral.length} caracteres) — você não precisa baixar nem rodar o Whisper de novo!
                  </div>
                )}
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    className="btn-primary py-1 text-xs"
                    onClick={iniciar}
                  >
                    <RefreshCw size={13} /> Tentar Novamente{wiz.transcricaoViral ? ' (Usando Cache 0s)' : ''}
                  </button>
                  {wiz.transcricaoViral && (
                    <button
                      type="button"
                      className="btn-ghost py-1 text-xs"
                      onClick={async () => {
                        const tfEfetivo = tipoFinal || 'fechado';
                        if (!tipoFinal) setTipoFinal(tfEfetivo);
                        setModo('aprovacao');
                        setDialogosRoteiro(null);
                        const j = await executar(
                          () => fab.roteiro({
                            semente: wiz.transcricaoViral,
                            resumoUsuario: wiz.transcricaoViral,
                            origem: 'link',
                            ajustes,
                            config: { ...config(), modoOperacao: 'aprovacao' },
                            tipoFinal: tfEfetivo,
                          }),
                          'Gerando roteiro direto a partir da transcrição em cache...',
                        );
                        if (j) setWiz({ etapa: 'roteiro', jobId: j.id, rodando: true, origem: 'link', transcricaoViral: wiz.transcricaoViral });
                      }}
                    >
                      <FileText size={13} /> 🎬 Gerar Roteiro Direto da Transcrição (Com Aprovação)
                    </button>
                  )}
                </div>
              </div>
            ) : wiz?.etapa === 'sementes' && wiz?.estado === 'ok' ? (
              <div className="mb-3 rounded border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-200">
                ✅ Semente pronta para aprovação — revise/edite o texto abaixo e clique em <b>🎬 Aprovar semente → escrever roteiro</b>.
              </div>
            ) : wiz?.etapa === 'roteiro' && wiz?.estado === 'ok' && wiz?.resultado?.slug ? (
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-200">
                <span>
                  ✅ Roteiro validado (0 erros) · <b>{wiz.resultado.slug}</b> (Parte {wiz.resultado.parte || 1}) pronto para gerar os prompts do Flow
                </span>
                <button
                  type="button"
                  className="btn-primary py-1 text-xs"
                  onClick={async () => {
                    const tfEfetivo = tipoFinal || 'fechado';
                    const j = await executar(
                      () => fab.prompts({ slug: wiz.resultado.slug, parte: wiz.resultado.parte || 1, ajustes, importar: true, iniciarFila, tipoFinal: tfEfetivo }),
                      'Gerando prompts do Flow + legenda do Facebook...',
                    );
                    if (j) setWiz((w) => ({ ...w, etapa: 'prompts', jobId: j.id, rodando: true }));
                  }}
                >
                  <Sparkles size={14} /> ⚡ Gerar Prompts pro Flow
                </button>
              </div>
            ) : null}

            {((wiz?.etapa === 'sementes' && !wiz?.rodando) || (!wiz && (origem === 'sementes' || origem === 'link') && semente.trim())) && (
              <div className="mt-3 space-y-2.5 rounded-lg border border-violet-500/30 bg-studio-950/90 p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="label">1. Cole/edite a SEMENTE que você aprova (pode juntar ideias ou editar livremente)</div>
                  {(wiz?.sementeGerada || wiz?.saida) && (
                    <button
                      type="button"
                      className="btn-ghost px-2 py-0.5 text-[11px]"
                      onClick={() => {
                        const rec = extrairSementeLimpaFront(wiz.sementeGerada || wiz.resultado?.semente || wiz.saida, wiz.transcricaoViral);
                        if (rec) setSemente(rec);
                      }}
                    >
                      Restaurar semente gerada
                    </button>
                  )}
                </div>
                <textarea
                  className="input h-36 resize-y text-xs leading-relaxed"
                  value={semente}
                  onChange={(e) => setSemente(e.target.value)}
                  placeholder="A semente gerada aparece aqui automaticamente (ou cole/escreva sua semente)..."
                />
                {(wiz?.transcricaoViral || wiz?.resultado?.transcricaoViral) && (
                  <details className="rounded border border-studio-700 bg-studio-900/70 px-2.5 py-1.5 text-xs">
                    <summary className="cursor-pointer text-[11px] text-zinc-400">
                      📄 Ver transcrição original extraída do vídeo (salva em cache local — 0 retrabalho)
                    </summary>
                    <pre className="mt-1.5 max-h-40 overflow-y-auto whitespace-pre-wrap font-mono text-[10.5px] text-zinc-300">
                      {wiz.transcricaoViral || wiz.resultado?.transcricaoViral}
                    </pre>
                  </details>
                )}
                <textarea
                  className="input h-14 resize-y text-xs"
                  value={ajustes}
                  onChange={(e) => setAjustes(e.target.value)}
                  placeholder="Ajustes que você quer no roteiro (opcional — ex.: trocar nomes, mudar o ambiente)..."
                />
                {!tipoFinal && (
                  <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-2.5">
                    <div className="mb-1.5 text-xs font-semibold text-amber-200">Escolha o rumo do final para liberar o roteiro:</div>
                    <SeletorTipoFinal valor={tipoFinal} onChange={setTipoFinal} compacto />
                  </div>
                )}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    className="btn-primary"
                    disabled={!semente.trim()}
                    title={!semente.trim() ? 'Preencha ou aguarde a semente acima' : 'Gera o roteiro cena a cena a partir desta semente'}
                    onClick={async () => {
                      const tfEfetivo = tipoFinal || 'fechado';
                      if (!tipoFinal) setTipoFinal(tfEfetivo);
                      const semLimpa = semente.trim();
                      setDialogosRoteiro(null);
                      const j = await executar(
                        () => fab.roteiro({ semente: semLimpa, resumoUsuario: semLimpa, origem, ajustes, config: config(), tipoFinal: tfEfetivo }),
                        `Escrevendo roteiro (${numCenasCalc} cenas de ${Number(tamanho) === 10 ? 10 : 15}s)...`,
                      );
                      if (j) setWiz({ etapa: 'roteiro', jobId: j.id, rodando: true, origem });
                    }}
                  >
                    <FileText size={15} /> 🎬 Aprovar semente → escrever roteiro
                  </button>
                </div>
              </div>
            )}

            {wiz?.etapa === 'roteiro' && wiz?.estado === 'ok' && (
              <div className="mt-3 space-y-3">
                {dialogosRoteiro?.cenas?.length > 0 && (
                  <div className="rounded-lg border border-fuchsia-500/35 bg-studio-950 p-3">
                    <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs font-bold uppercase tracking-wider text-fuchsia-300">
                        👁️ Diálogos Limpos Cena a Cena — Teste da Dona Maria ({dialogosRoteiro.cenas.length} cenas)
                      </div>
                      <span className="text-[11px] text-zinc-500">Clique em qualquer fala para editar direto (0 tokens)</span>
                    </div>
                    <ListaDialogosEditavel
                      slug={wiz.resultado?.slug}
                      parte={wiz.resultado?.parte || 1}
                      dados={dialogosRoteiro}
                      onAtualizar={(novo) => {
                        setDialogosRoteiro(novo);
                        setWiz((w) => (w ? { ...w, dialogos: novo } : w));
                      }}
                    />
                  </div>
                )}
                <div className="label">2. Roteiro pronto! Revise as falas acima e clique para gerar os prompts do Flow:</div>
                <textarea className="input h-14 resize-y" value={ajustes} onChange={(e) => setAjustes(e.target.value)} placeholder="Ajustes opcionais antes de gerar os prompts (ou clique em 'Pedir ajustes no roteiro' para reescrever)..." />
                <div className="flex flex-wrap items-center gap-3">
                  <button className="btn-primary" disabled={!wiz.resultado?.slug} onClick={async () => {
                    const tfEfetivo = tipoFinal || 'fechado';
                    const j = await executar(
                      () => fab.prompts({ slug: wiz.resultado.slug, parte: wiz.resultado.parte || 1, ajustes, importar: true, iniciarFila, tipoFinal: tfEfetivo }),
                      'Gerando prompts do Flow + legenda do Facebook...',
                    );
                    if (j) setWiz((w) => ({ ...w, etapa: 'prompts', jobId: j.id, rodando: true }));
                  }}><Sparkles size={15} /> ⚡ Aprovar Roteiro e Gerar Prompts pro Flow</button>
                  <label className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <input type="checkbox" checked={iniciarFila} onChange={(e) => setIniciarFila(e.target.checked)} />
                    Já iniciar a fila no Google Flow ao terminar
                  </label>
                  <button className="btn-ghost text-xs" disabled={!(semente.trim() || texto.trim())} onClick={async () => {
                    const base = (origem === 'resumo' ? texto.trim() : semente.trim()) || texto.trim() || semente.trim();
                    const tfEfetivo = tipoFinal || 'fechado';
                    setDialogosRoteiro(null);
                    const j = await executar(
                      () => fab.roteiro({ semente: base, resumoUsuario: base, origem, ajustes, config: config(), tipoFinal: tfEfetivo }),
                      'Reescrevendo roteiro com seus ajustes...',
                    );
                    if (j) setWiz({ etapa: 'roteiro', jobId: j.id, rodando: true, origem });
                  }}>🔄 Pedir ajustes no roteiro</button>
                </div>
                {!wiz.resultado?.slug && <div className="text-[11px] text-amber-300">O Claude não informou o slug; use “Prontos para importar” no topo ou refaça a etapa.</div>}
              </div>
            )}

            {(wiz?.etapa === 'prompts' || wiz?.etapa === 'automatico') && wiz?.estado === 'ok' && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-emerald-500/35 bg-emerald-500/10 p-3 text-xs text-emerald-100">
                <div>
                  ✅ <b>Prompts do Flow e legenda gerados com sucesso!</b> A história já está pronta em <b>Prontos para importar</b> no topo.
                </div>
                {(wiz?.importacao?.novelaId || (prontos || []).find((p) => p.slug === wiz?.resultado?.slug)?.importada?.novelaId) && (
                  <button
                    type="button"
                    className="btn-success text-xs"
                    onClick={() => {
                      const idNov = wiz?.importacao?.novelaId || (prontos || []).find((p) => p.slug === wiz?.resultado?.slug)?.importada?.novelaId;
                      if (idNov) irParaNovela?.(idNov);
                    }}
                  >
                    <CheckCircle2 size={14} /> Abrir Novela no Estúdio
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </Caixa>
    </div>
  );
}

// ---------- Séries ----------
function Series({ executar, toast, studio, irParaNovela }) {
  const [series, erro] = usePoll(() => fab.series(), 5000);
  const [jobs, setJobs] = useState({});
  const [aberto, setAberto] = useState({});
  const [iniciarFila, setIniciarFila] = useState(false);
  const [pedido, setPedido] = useState(null); // { slug, parte, titulo } -> modal de tipo de final
  if (erro) return <div className="text-xs text-red-300">{erro}</div>;
  if (!series) return <div className="text-xs text-zinc-500">Carregando...</div>;
  if (!series.length) return <div className="card p-4 text-xs text-zinc-500">Nenhuma série salva ainda.</div>;
  return (
    <div className="space-y-4">
      {series.map((s) => {
        const prox = s.partes.find((p) => p.parte === s.proximaParte);
        const p1 = s.partes.find((p) => p.parte === 1);
        return (
          <Caixa key={s.slug} titulo={`${s.titulo} · ${s.totalPartes} partes`} icon={Library}
            direita={prox && prox.parte > 1 && (
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-[11px] text-zinc-400"><input type="checkbox" checked={iniciarFila} onChange={(e) => setIniciarFila(e.target.checked)} /> iniciar fila</label>
                <button className="btn-primary text-xs" onClick={() => setPedido({ slug: s.slug, parte: prox.parte, titulo: s.titulo })}>
                  ➕ Gerar Parte {prox.parte} (Herdando Referências da Parte 1)
                </button>
              </div>
            )}>
            {s.premissa && <p className="mb-3 text-xs leading-relaxed text-zinc-400">{s.premissa}</p>}
            <div className="mb-3 text-[11px] text-zinc-500">{s.refs.personagens} personagens + {s.refs.cenarios} cenários no catálogo de referências (herdados fisicamente de 01_Referencias nas partes seguintes).</div>
            <div className="space-y-2">
              {s.partes.map((p) => (
                <div key={p.parte} className="rounded-lg border border-studio-700 bg-studio-850 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
                      Parte {p.parte}
                      <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${p.status === 'pronta' ? 'bg-emerald-500/15 text-emerald-300' : 'bg-zinc-500/15 text-zinc-400'}`}>{p.status === 'pronta' ? 'pronta' : 'só resumo salvo'}</span>
                      {p.pronto?.importada && <span className="rounded bg-violet-500/15 px-1.5 py-0.5 text-[10px] text-violet-200">no Estúdio</span>}
                    </div>
                    <div className="flex gap-2">
                      {p.pronto?.importada && <button className="btn-ghost px-2 py-1 text-[11px]" onClick={() => irParaNovela?.(p.pronto.importada.novelaId)}>Abrir no Estúdio</button>}
                      {p.status === 'pronta' && !p.pronto?.importada && <button className="btn-ghost px-2 py-1 text-[11px]" onClick={async () => { const r = await executar(() => fab.importar(s.slug, p.parte), 'Importada!'); if (r) irParaNovela?.(r.novelaId); }}>Importar</button>}
                      {p.parte > 1 && p.status !== 'pronta' && p.parte === s.proximaParte && (
                        <button className="btn-ghost px-2 py-1 text-[11px]" onClick={() => setPedido({ slug: s.slug, parte: p.parte, titulo: s.titulo })}>➕ Gerar Parte {p.parte}</button>
                      )}
                      <button className="btn-ghost px-2 py-1 text-[11px]" onClick={() => setAberto((o) => ({ ...o, [`${s.slug}-${p.parte}`]: !o[`${s.slug}-${p.parte}`] }))}>{aberto[`${s.slug}-${p.parte}`] ? 'Ocultar resumo' : 'Ver resumo'}</button>
                    </div>
                  </div>
                  {p.ganchoDeFim && <div className="mt-1 text-[11px] text-zinc-500">Gancho de fim: {p.ganchoDeFim}</div>}
                  {aberto[`${s.slug}-${p.parte}`] && <pre className="mt-2 max-h-72 overflow-y-auto whitespace-pre-wrap rounded bg-black/30 p-2 font-sans text-xs leading-relaxed text-zinc-300">{p.resumo || '(sem resumo salvo)'}</pre>}
                </div>
              ))}
            </div>
            {jobs[s.slug] && <JobView jobId={jobs[s.slug]} />}
          </Caixa>
        );
      })}
      <ModalTipoFinal
        aberto={!!pedido}
        titulo={pedido ? `➕ Gerar Parte ${pedido.parte} — ${pedido.titulo}` : ''}
        descricao="Continua a série herdando a Bíblia, o catálogo de personagens/cenários e as imagens de 01_Referencias."
        rotuloConfirmar={pedido ? `Gerar Parte ${pedido.parte}` : 'Gerar'}
        onFechar={() => setPedido(null)}
        onConfirmar={async ({ tipoFinal, observacao }) => {
          const alvo = pedido;
          const j = await executar(() => fab.gerarParte(alvo.slug, { parte: alvo.parte, importar: true, iniciarFila, tipoFinal, observacao }), `Gerando Parte ${alvo.parte}...`);
          if (j) { setJobs((o) => ({ ...o, [alvo.slug]: j.id })); setPedido(null); }
        }}
      />
    </div>
  );
}

// ---------- CapCut & WhatsApp & Google Drive ----------
function CapcutZap({ executar, toast, studio }) {
  const [zap, , recarregarZap] = usePoll(() => fab.zapStatus(), 2000);
  const [cap, , recarregarCap] = usePoll(() => fab.capcut(), 3000);
  const [gd, , recarregarGd] = usePoll(() => fab.gdriveStatus(), 2000);
  const [numero, setNumero] = useState('');
  const [mostrarCredsDrive, setMostrarCredsDrive] = useState(false);
  const [jsonCredsDrive, setJsonCredsDrive] = useState('');
  const [clientIdDrive, setClientIdDrive] = useState('');
  const [clientSecretDrive, setClientSecretDrive] = useState('');
  const [subindoManual, setSubindoManual] = useState(false);
  const carregou = useRef(false);
  useEffect(() => { if (cap && !carregou.current) { carregou.current = true; setNumero(cap.destinoWhatsapp || ''); } }, [cap]);
  const comLegenda = studio.novelas.filter((n) => n.legendaFacebook);
  const atual = comLegenda.find((n) => n.id === cap?.novelaAguardandoCapcutId) || null;
  const [legendaLocal, setLegendaLocal] = useState(null);
  const legendaMostrada = legendaLocal && atual && legendaLocal.id === atual.id ? legendaLocal.txt : atual?.legendaFacebook;

  const copiarTexto = async (txt, msg = 'Copiado!') => {
    try { await navigator.clipboard.writeText(txt); toast(msg, 'ok'); } catch { toast('Não foi possível copiar automaticamente.', 'aviso'); }
  };

  const payloadCredsDrive = () => {
    if (jsonCredsDrive.trim()) return { jsonBruto: jsonCredsDrive.trim() };
    if (clientIdDrive.trim() || clientSecretDrive.trim()) return { clientId: clientIdDrive.trim(), clientSecret: clientSecretDrive.trim() };
    return {};
  };

  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="space-y-5">
          <Caixa titulo="WhatsApp (leve, sem navegador)" icon={QrCode}>
            {!zap ? <div className="text-xs text-zinc-500">Carregando...</div> : (
              <>
                <div className={`mb-3 rounded-lg border px-3 py-2 text-xs ${zap.conectado ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-studio-700 bg-studio-850 text-zinc-400'}`}>
                  {zap.conectado ? `✅ Conectado ao número ${zap.numero}${zap.selfJid ? ` (${zap.selfJid})` : ''}` : zap.estado === 'aguardando_qr' ? '📷 Escaneie o QR Code com o WhatsApp do celular (Aparelhos conectados → Conectar um aparelho)' : zap.estado === 'iniciando' ? 'Conectando...' : 'Desconectado'}
                  {zap.ultimoErro && <div className="mt-1 text-amber-300">{zap.ultimoErro}</div>}
                </div>
                {zap.qr && <img src={zap.qr} alt="QR Code do WhatsApp" className="mb-3 h-56 w-56 rounded-lg bg-white p-2" />}
                <div className="flex flex-wrap gap-2">
                  {!zap.conectado && <button className="btn-primary" onClick={() => executar(() => fab.zapConectar()).then(recarregarZap)}><QrCode size={15} /> {zap.estado === 'aguardando_qr' ? 'Gerar novo QR' : 'Conectar / Gerar QR Code'}</button>}
                  {zap.conectado && <button className="btn-ghost" onClick={() => executar(() => fab.zapTeste(numero), 'Mensagem de teste enviada!').then(recarregarZap)}>📲 Enviar Mensagem de Teste pra Mim</button>}
                  {(zap.conectado || zap.temSessaoSalva) && <button className="btn-danger" onClick={() => executar(() => fab.zapDesconectar(), 'WhatsApp desconectado').then(recarregarZap)}>Desconectar</button>}
                </div>
                <label className="mt-3 block text-[11px] text-zinc-500">Número de destino (opcional — vazio = “mensagem para você mesmo”)
                  <div className="mt-1 flex gap-2">
                    <input className="input" placeholder="ex.: 5511999998888" value={numero} onChange={(e) => setNumero(e.target.value)} />
                    <button className="btn-ghost whitespace-nowrap text-xs" onClick={() => executar(() => fab.salvarCapcut({ destinoWhatsapp: numero }), 'Destino salvo').then(recarregarCap)}>Salvar</button>
                  </div>
                </label>
                {(zap.logsEnvio || []).length > 0 && (
                  <div className="mt-3">
                    <div className="label mb-1">Log detalhado do WhatsApp (resolução de JID / envios)</div>
                    <div className="max-h-36 space-y-1 overflow-y-auto rounded-lg border border-studio-700 bg-studio-950 p-2 font-mono text-[10.5px]">
                      {zap.logsEnvio.map((l, i) => (
                        <div key={i} className={l.ok ? 'text-emerald-300' : 'text-red-300'}>
                          <span className="text-zinc-500">{new Date(l.t).toLocaleTimeString('pt-BR')}</span> {l.msg}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </Caixa>

          {/* ===== Card Google Drive Automatico ===== */}
          <Caixa
            titulo="☁️ Google Drive Automático (Link pro iPhone)"
            icon={Cloud}
            direita={gd && (
              <Toggle
                checked={gd.autoUploadCapcut !== false}
                onChange={(v) => executar(() => fab.gdriveConfig({ autoUploadCapcut: v }), v ? 'Upload automático ativado' : 'Upload automático pausado').then(recarregarGd)}
                label={gd.autoUploadCapcut !== false ? 'Automático' : 'Manual'}
              />
            )}
          >
            {!gd ? <div className="text-xs text-zinc-500">Carregando Google Drive...</div> : (
              <>
                <div className={`mb-3 rounded-lg border px-3 py-2 text-xs ${gd.conectado ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-studio-700 bg-studio-850 text-zinc-400'}`}>
                  {gd.conectado ? (
                    <div>
                      ✅ <b>Conectado</b>{gd.email ? ` · ${gd.email}` : ''} · pasta <span className="font-mono text-emerald-100">{gd.pastaNome}</span>
                    </div>
                  ) : (
                    <div>
                      ⚪ <b>Desconectado</b> {gd.temCredenciais ? `· credencial salva (${gd.clientIdParcial})` : '· configure o Client OAuth em 1 minuto abaixo'}
                    </div>
                  )}
                  {gd.ultimoErro && <div className="mt-1 text-amber-300">{gd.ultimoErro}</div>}
                </div>

                <div className="mb-3">
                  <Toggle
                    checked={gd.autoUploadCapcut !== false}
                    onChange={(v) => executar(() => fab.gdriveConfig({ autoUploadCapcut: v })).then(recarregarGd)}
                    label="Subir vídeo exportado do CapCut pro Drive automaticamente"
                  />
                  <div className="mt-1 text-[10.5px] text-zinc-500">
                    No WhatsApp chegam <b>2 mensagens separadas</b>: (1) a legenda limpa do Facebook para copiar com 1 toque e (2) o link do vídeo em qualidade original no Drive para salvar fácil no iPhone.
                  </div>
                </div>

                {gd.uploadAtual && (
                  <div className="mb-3 rounded-lg border border-sky-500/40 bg-sky-500/10 p-2.5 text-xs text-sky-200">
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-1.5 font-medium"><Loader2 size={13} className="animate-spin" /> Subindo {gd.uploadAtual.nome}...</span>
                      <span className="font-mono">{gd.uploadAtual.pct}%</span>
                    </div>
                    <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-studio-900">
                      <div className="h-full bg-sky-400 transition-all" style={{ width: `${gd.uploadAtual.pct}%` }} />
                    </div>
                  </div>
                )}

                {(!gd.temCredenciais || mostrarCredsDrive) && (
                  <div className="mb-3 space-y-2 rounded-lg border border-studio-700 bg-studio-950 p-3 text-xs">
                    <div className="font-semibold text-zinc-200">Passo único (1 min no Google Cloud Console):</div>
                    <ol className="list-decimal space-y-1 pl-4 text-[11px] text-zinc-400">
                      <li>Ative a <b>Google Drive API</b> em <code>console.cloud.google.com</code> → <i>APIs &amp; Services</i>.</li>
                      <li>Em <i>Credentials → Create Credentials → OAuth client ID</i>, crie um app <b>Desktop app</b> (ou <b>Web application</b> adicionando o Redirect URI abaixo).</li>
                      <li>Cole abaixo o conteúdo do JSON baixado (<code>client_secret_*.json</code>) <b>ou</b> o Client ID e Secret:</li>
                    </ol>
                    <div className="flex items-center justify-between gap-2 rounded border border-studio-700 bg-studio-900 px-2 py-1 font-mono text-[10.5px] text-zinc-300">
                      <span className="truncate">{gd.redirectUri}</span>
                      <button type="button" className="btn-ghost px-1.5 py-0.5 text-[10px]" onClick={() => copiarTexto(gd.redirectUri, 'Redirect URI copiado!')}><Copy size={11} /> Copiar</button>
                    </div>
                    <textarea
                      className="input h-16 resize-y font-mono text-[11px]"
                      placeholder='Opcional: cole aqui o JSON inteiro do client_secret_*.json...'
                      value={jsonCredsDrive}
                      onChange={(e) => setJsonCredsDrive(e.target.value)}
                    />
                    <div className="grid gap-2 sm:grid-cols-2">
                      <input className="input text-xs" placeholder="Ou Client ID (...apps.googleusercontent.com)" value={clientIdDrive} onChange={(e) => setClientIdDrive(e.target.value)} />
                      <input className="input text-xs" type="password" placeholder="Client Secret (GOCSPX-...)" value={clientSecretDrive} onChange={(e) => setClientSecretDrive(e.target.value)} />
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-2">
                  {!gd.conectado && (
                    <button
                      className="btn-primary text-xs"
                      onClick={async () => {
                        const r = await executar(
                          () => fab.gdriveConectar(payloadCredsDrive()),
                          '🌐 Navegador aberto! Autorize sua conta Google para concluir.'
                        );
                        if (r?.authUrl) {
                          setJsonCredsDrive(''); setClientSecretDrive(''); setMostrarCredsDrive(false);
                          recarregarGd();
                        }
                      }}
                    >
                      🔗 Conectar Google Drive
                    </button>
                  )}
                  <button
                    className="btn-primary text-xs"
                    disabled={!gd.conectado || !!gd.uploadAtual || subindoManual}
                    title={cap?.ultimoVideoDetectado ? `Último vídeo detectado: ${cap.ultimoVideoDetectado.nome}` : 'Sobe o vídeo mais recente exportado no CapCut e envia o link no WhatsApp'}
                    onClick={async () => {
                      setSubindoManual(true);
                      try {
                        await executar(
                          () => fab.gdriveSubirUltimo(numero),
                          '☁️ Vídeo enviado pro Google Drive e link disparado no WhatsApp!'
                        );
                        recarregarGd();
                        recarregarCap();
                      } finally {
                        setSubindoManual(false);
                      }
                    }}
                  >
                    {subindoManual || gd.uploadAtual ? <Loader2 size={14} className="animate-spin" /> : null}
                    ☁️ Subir Último Vídeo pro Drive e Mandar Link
                  </button>
                  {gd.temCredenciais && !gd.conectado && (
                    <button className="btn-ghost text-xs" onClick={() => setMostrarCredsDrive((v) => !v)}>
                      {mostrarCredsDrive ? 'Ocultar credenciais' : 'Trocar Client ID'}
                    </button>
                  )}
                  {gd.conectado && (
                    <button className="btn-danger text-xs" onClick={() => executar(() => fab.gdriveDesconectar(false), 'Google Drive desconectado').then(recarregarGd)}>
                      Desconectar
                    </button>
                  )}
                </div>
                {cap?.ultimoVideoDetectado && (
                  <div className="mt-1.5 text-[10.5px] text-zinc-500">
                    Último arquivo local detectado: <span className="font-mono text-zinc-300">{cap.ultimoVideoDetectado.nome}</span> ({(cap.ultimoVideoDetectado.tamanho / (1024 * 1024)).toFixed(1)} MB)
                  </div>
                )}

                {gd.ultimoUpload?.webViewLink && (
                  <div className="mt-3 rounded-lg border border-studio-700 bg-studio-950 p-3 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-semibold text-zinc-200">🎬 Último vídeo no Drive: {gd.ultimoUpload.nome}</span>
                      {gd.ultimoUpload.enviadoEm && <span className="text-[10.5px] text-zinc-500">{new Date(gd.ultimoUpload.enviadoEm).toLocaleString('pt-BR')}</span>}
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <a href={gd.ultimoUpload.webViewLink} target="_blank" rel="noreferrer" className="btn-ghost py-1 text-xs text-sky-300 hover:text-sky-200">
                        <ExternalLink size={13} /> Abrir no Drive
                      </a>
                      {gd.ultimoUpload.downloadLink && (
                        <a href={gd.ultimoUpload.downloadLink} target="_blank" rel="noreferrer" className="btn-ghost py-1 text-xs text-emerald-300 hover:text-emerald-200">
                          <Download size={13} /> Link direto (iPhone)
                        </a>
                      )}
                      <button type="button" className="btn-ghost py-1 text-xs" onClick={() => copiarTexto(gd.ultimoUpload.webViewLink, 'Link do Google Drive copiado!')}>
                        <Copy size={13} /> Copiar link
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </Caixa>
        </div>

        <Caixa titulo="Vigia de exportação do CapCut" icon={Smartphone}
          direita={cap && <Toggle checked={!!cap.monitorAtivo} onChange={(v) => executar(() => fab.salvarCapcut({ monitorAtivo: v })).then(recarregarCap)} label={cap.monitorRodando ? 'Ligado' : 'Desligado'} />}>
          {cap && (
            <>
              <div className="label mb-1">Pastas sendo vigiadas em tempo real ({(cap.pastasVigiadas || []).length})</div>
              <div className={`mb-2 space-y-1 rounded-lg border p-2.5 text-[11px] ${cap.pastaExiste ? 'border-studio-700 bg-studio-950 text-zinc-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-200'}`}>
                {(cap.pastasVigiadas || []).length === 0 ? (
                  <div>(nenhuma pasta de exportação encontrada — escolha uma abaixo)</div>
                ) : (
                  (cap.pastasVigiadas || []).map((pv, idx) => (
                    <div key={idx} className="flex flex-wrap items-center justify-between gap-2">
                      <span className="break-all font-mono text-zinc-200">{pv.pasta}</span>
                      <span className="rounded bg-studio-800 px-1.5 py-0.5 text-[10px] text-zinc-400">{pv.origem}</span>
                    </div>
                  ))
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                <button className="btn-ghost text-xs" onClick={() => executar(() => fab.escolherPasta(), 'Pasta atualizada').then(recarregarCap)}>
                  <FolderOpen size={14} /> 📂 Escolher Pasta Customizada
                </button>
                {cap.pastaCustomizada && (
                  <button className="btn-ghost text-xs" onClick={() => executar(() => fab.salvarCapcut({ modoAutomaticoPastas: true }), 'Vigiando automaticamente Vídeos + Área de Trabalho + CapCut').then(recarregarCap)}>
                    🔄 Vigiar Vídeos + Área de Trabalho (automático)
                  </button>
                )}
              </div>
              <div className="mt-1 text-[10px] text-zinc-600">Vídeos antigos já existentes são ignorados. A legenda só dispara quando o novo `.mp4`/`.mov` passar de 1 MB, ficar 5 s sem mudar de tamanho e destravar a escrita.</div>

              <div className="label mb-1 mt-4">🎬 Novela vinculada para envio automático</div>
              <select className="input" value={cap.novelaAguardandoCapcutId || ''} onChange={(e) => { setLegendaLocal(null); executar(() => fab.salvarCapcut({ novelaAguardandoCapcutId: e.target.value || null })).then(recarregarCap); }}>
                <option value="">(automática: novela mais recente com legenda ainda não enviada)</option>
                {comLegenda.map((n) => <option key={n.id} value={n.id}>{n.nome}{n.legendaEnviadaWhatsappEm ? ' — legenda já enviada' : ' — pendente'}</option>)}
              </select>

              {(cap.pendentesWhatsapp || []).length > 0 && (
                <div className="mt-3 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-200">
                  ⚠️ Vídeo(s) pronto(s) no CapCut ({cap.pendentesWhatsapp.join(', ')}) esperando o WhatsApp conectar — a legenda será enviada assim que conectar.
                </div>
              )}
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  className="btn-primary text-xs"
                  onClick={() =>
                    executar(
                      () => fab.testarDisparoCapcut(numero),
                      '🧪 Disparo de legenda enviado! Confira o WhatsApp e o log ao lado.'
                    ).then(() => { recarregarCap(); recarregarZap(); })
                  }
                >
                  🧪 Testar Disparo de Legenda Agora
                </button>
              </div>

              <div className="label mb-1 mt-4">Prévia da legenda do Facebook</div>
              {atual ? (
                <>
                  <Legenda texto={legendaMostrada} />
                  <div className="mt-2 flex flex-wrap gap-2">
                    <button className="btn-ghost text-xs" onClick={async () => { const r = await executar(() => fab.sortearLegenda(atual.id), 'Novas hashtags sorteadas'); if (r) setLegendaLocal({ id: atual.id, txt: r.legendaFacebook }); }}><Dice5 size={14} /> Sortear nova legenda/hashtags</button>
                    <button className="btn-primary text-xs" onClick={() => executar(() => fab.enviarLegenda(atual.id, numero), '📲 Legenda enviada ao WhatsApp!')}><Send size={14} /> 📲 Enviar Legenda Agora</button>
                  </div>
                  {atual.legendaEnviadaWhatsappEm && <div className="mt-1 text-[11px] text-emerald-400">Enviada em {new Date(atual.legendaEnviadaWhatsappEm).toLocaleString('pt-BR')}</div>}
                </>
              ) : <div className="text-xs text-zinc-600">Importe uma parte da Fábrica e escolha a novela acima.</div>}

              <div className="label mb-1 mt-4">Últimos envios automáticos</div>
              <div className="max-h-56 space-y-1 overflow-y-auto text-[11px]">
                {(cap.historico || []).length === 0 && <div className="text-zinc-600">Nenhum envio ainda.</div>}
                {(cap.historico || []).map((h, i) => (
                  <div
                    key={i}
                    className={`rounded border px-2 py-1 ${
                      h.resultado === 'enviada'
                        ? 'border-emerald-500/20 text-emerald-200'
                        : h.resultado === 'drive_enviado'
                          ? 'border-sky-500/25 text-sky-200'
                          : h.resultado === 'erro'
                            ? 'border-red-500/20 text-red-300'
                            : 'border-studio-700 text-zinc-400'
                    }`}
                  >
                    <div>
                      <span className="text-zinc-500">{new Date(h.t).toLocaleString('pt-BR')}</span> · {h.resultado} · {h.novela || '—'} · {h.arquivo} {h.detalhe ? `(${h.detalhe})` : ''}
                    </div>
                    {h.driveLink && (
                      <div className="mt-1 flex flex-wrap gap-3 text-[10.5px]">
                        <a href={h.driveLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sky-300 underline hover:text-sky-200">
                          ☁️ Abrir no Google Drive
                        </a>
                        {h.driveDownloadLink && (
                          <a href={h.driveDownloadLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-emerald-300 underline hover:text-emerald-200">
                            📲 Salvar no iPhone
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </Caixa>
      </div>
    </div>
  );
}

// ---------- Agendamento viral ----------
function Agenda({ executar, toast }) {
  const [ag, erro, recarregar] = usePoll(() => fab.agendamento(), 0);
  const [paginas, setPaginas] = useState('');
  const [horario, setHorario] = useState('08:00');
  const [busca, setBusca] = useState(null);
  const carregou = useRef(false);
  useEffect(() => { if (ag && !carregou.current) { carregou.current = true; setPaginas((ag.paginas || []).join('\n')); setHorario(ag.horario || '08:00'); } }, [ag]);
  if (erro) return <div className="text-xs text-red-300">{erro}</div>;
  if (!ag) return <div className="text-xs text-zinc-500">Carregando...</div>;
  const lista = () => paginas.split('\n').map((s) => s.trim()).filter(Boolean);
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Caixa titulo="Fontes do Facebook (páginas/perfis do seu nicho)" icon={Link2}>
        <textarea className="input h-40 resize-y font-mono text-[11px]" placeholder={'https://www.facebook.com/NomeDaPagina/reels\nhttps://www.facebook.com/outra.pagina'} value={paginas} onChange={(e) => setPaginas(e.target.value)} />
        <div className="mt-2 flex flex-wrap gap-2">
          <button className="btn-ghost" onClick={() => executar(() => fab.salvarAgendamento({ paginas: lista() }), 'Fontes salvas').then(recarregar)}>Salvar fontes</button>
          <button className="btn-ghost" onClick={async () => { const r = await executar(() => fab.buscarAgora(), 'Busca de teste concluída'); if (r) setBusca(r.saida); }}>🔎 Testar busca agora (não gasta tokens)</button>
        </div>
        {busca && <pre className="mt-2 max-h-40 overflow-y-auto whitespace-pre-wrap rounded bg-black/40 p-2 font-mono text-[10px] text-zinc-300">{busca}</pre>}
      </Caixa>
      <Caixa titulo="Horário diário automático" icon={AlarmClock}>
        <div className={`mb-3 rounded-lg border px-3 py-2 text-xs ${ag.ativo ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-studio-700 bg-studio-850 text-zinc-400'}`}>{ag.ativo ? `✅ Ativo todos os dias às ${ag.horario} (o PC precisa estar ligado)` : 'Desligado'}</div>
        <div className="flex items-end gap-2">
          <label className="text-xs text-zinc-400">Horário<input type="time" className="input mt-1 w-32" value={horario} onChange={(e) => setHorario(e.target.value)} /></label>
          <button className="btn-primary" onClick={() => executar(() => fab.salvarAgendamento({ paginas: lista(), horario, ativo: true }), 'Agendamento ativado').then(recarregar)}>Ativar</button>
          <button className="btn-danger" onClick={() => executar(() => fab.salvarAgendamento({ ativo: false }), 'Agendamento removido').then(recarregar)}>Desativar</button>
        </div>
        <div className="mt-2 text-[10px] text-zinc-600">No horário, a Fábrica busca o vídeo mais forte ainda inédito, adapta e salva em prontos_para_flow (modo 100% automático). Depois é só importar aqui.</div>
        <div className="label mb-1 mt-4">Últimos adaptados</div>
        <div className="space-y-1 text-[11px] text-zinc-400">{(ag.adaptados || []).length === 0 ? <div className="text-zinc-600">Nenhum ainda.</div> : ag.adaptados.map((a, i) => <div key={i} className="truncate">• {a.titulo || a.url}</div>)}</div>
        {ag.logRecente && <details className="mt-3"><summary className="cursor-pointer text-[11px] uppercase text-zinc-500">Log do caçador</summary><pre className="mt-1 max-h-40 overflow-y-auto whitespace-pre-wrap rounded bg-black/40 p-2 font-mono text-[10px] text-zinc-400">{ag.logRecente}</pre></details>}
      </Caixa>
    </div>
  );
}

export default function FabricaClaude({ studio, executar, toast, irParaNovela, abrirPadroes }) {
  const [sub, setSub] = useState(() => new URLSearchParams(location.search).get('sub') || localStorage.getItem('fns.fabrica.sub') || 'criador');
  const [diagAberto, setDiagAberto] = useState(false);
  useEffect(() => { localStorage.setItem('fns.fabrica.sub', sub); }, [sub]);
  return (
    <div className="flex h-full flex-col bg-studio-950">
      <div className="flex shrink-0 items-center justify-between gap-2 border-b border-white/[0.07] bg-studio-900/60 px-4 pt-1.5">
        <div className="flex items-center gap-1">
          {SUBS.map((s) => (
            <button key={s.id} onClick={() => setSub(s.id)} className={`flex items-center gap-1.5 rounded-t-lg border-b-2 px-3.5 py-2 text-xs font-medium transition ${sub === s.id ? 'border-fuchsia-500 text-white' : 'border-transparent text-zinc-500 hover:text-zinc-200'}`}>{s.rotulo}</button>
          ))}
        </div>
        {sub !== 'capcut' && (
          <button
            type="button"
            onClick={() => setDiagAberto((v) => !v)}
            className={`mb-1 rounded-md p-1.5 text-xs transition ${diagAberto ? 'bg-violet-500/20 text-violet-300' : 'text-zinc-500 hover:bg-studio-800 hover:text-zinc-300'}`}
            title="Diagnóstico técnico da Fábrica (C:\FabricaClaude · Claude CLI · yt-dlp · ffmpeg · whisper)"
          >
            <Info size={14} />
          </button>
        )}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-5">
        <div className="mx-auto max-w-6xl space-y-4">
          {sub !== 'capcut' && <StatusFabrica executar={executar} forcarAberto={diagAberto} />}
          {sub === 'criador' && <Criador executar={executar} toast={toast} studio={studio} irParaNovela={irParaNovela} abrirPadroes={abrirPadroes} />}
          {sub === 'series' && <Series executar={executar} toast={toast} studio={studio} irParaNovela={irParaNovela} />}
          {sub === 'capcut' && <CapcutZap executar={executar} toast={toast} studio={studio} />}
          {sub === 'fichas' && <FichasVirais executar={executar} toast={toast} Caixa={Caixa} JobView={JobView} />}
          {sub === 'agenda' && <Agenda executar={executar} toast={toast} />}
        </div>
      </div>
    </div>
  );
}
