import React, { useMemo, useState } from 'react';
import {
  Play, FolderOpen, Image as ImageIcon, Video, FileText, Layers, Trash2, Pencil, Check, X, Link2, Sparkles, Boxes, Gauge, Clapperboard, Scissors, RefreshCw, AlertTriangle, MoreHorizontal, Settings2, ChevronDown, ChevronUp,
} from 'lucide-react';
import SeletoresQualidade from './SeletoresQualidade.jsx';
import { useAcoesItem } from './AcoesItem.jsx';
import { api, fab, progressoNovela, statusNovela } from '../api.js';
import { NovelaStatus, Toggle, Modal } from './ui.jsx';
import RoteiroTab from './RoteiroTab.jsx';
import { GaleriaImagens, GaleriaVideos } from './Galerias.jsx';

const ABAS = [
  { id: 'roteiro', rotulo: 'Roteiro & Fila', icon: FileText },
  { id: 'referencias', rotulo: 'Referências', icon: ImageIcon, tipo: 'referencia_imagem' },
  { id: 'imagens', rotulo: 'Imagens-Base', icon: Layers, tipo: 'imagem_base' },
  { id: 'videos', rotulo: 'Vídeos (9:16)', icon: Video, tipo: 'video' },
];

const ROTULO_CURTO_DOWN_VIDEO = {
  original: 'Original (s/ upscale)',
  '720p': '720p HD',
  '1080p': '1080p',
  '4k': '4K',
};

export default function NovelaView({ novela, studio, executar, toast }) {
  const { config, fila } = studio;
  const [aba, setAba] = useState('roteiro');
  const [editNome, setEditNome] = useState(null);
  const [confirmarExcluir, setConfirmarExcluir] = useState(false);
  const [configAberta, setConfigAberta] = useState(false);
  const st = statusNovela(novela, fila);
  const p = progressoNovela(novela);
  const rodandoEsta = fila.rodando && fila.novelaAtual === novela.id;
  const recapturandoEsta = fila.recapturando === novela.id;
  const filaOcupada = !!fila.rodando || !!fila.recapturando;
  const acoes = useAcoesItem(novela, executar);
  const [enviandoCapcut, setEnviandoCapcut] = useState(false);
  const [capcutOk, setCapcutOk] = useState(null);
  const [menuAvancado, setMenuAvancado] = useState(false);
  const [alinharEsquerda, setAlinharEsquerda] = useState(false);
  const [modalLegenda, setModalLegenda] = useState(false);
  const [gerandoLegenda, setGerandoLegenda] = useState(false);
  const [enviandoLegenda, setEnviandoLegenda] = useState(false);
  const [textoLegendaModal, setTextoLegendaModal] = useState(novela.legendaFacebook || '');
  const [zapStatus, setZapStatus] = useState(null);
  const [destinoZap, setDestinoZap] = useState('');

  const carregarStatusZap = async () => {
    try {
      const [z, c] = await Promise.all([fab.zapStatus().catch(() => null), fab.capcut().catch(() => null)]);
      if (z) setZapStatus(z);
      if (c?.destinoWhatsapp !== undefined) setDestinoZap(c.destinoWhatsapp || '');
    } catch {}
  };

  const abrirModalLegenda = async () => {
    setTextoLegendaModal(novela.legendaFacebook || '');
    setModalLegenda(true);
    carregarStatusZap();
    if (!novela.legendaFacebook && (novela.roteiro?.trim() || novela.itens?.length)) {
      setGerandoLegenda(true);
      const r = await executar(() => fab.gerarLegenda(novela.id, { enviarWhatsapp: false }), '✨ Legenda gerada via Claude!');
      setGerandoLegenda(false);
      if (r?.legendaFacebook) setTextoLegendaModal(r.legendaFacebook);
    }
  };

  const padroes = config.padroes || {};
  const modImgAtual = novela.modeloImagem || padroes.modeloImagem || 'Nano Banana 2.1';
  const modVidAtual = novela.modeloVideo || padroes.modeloVideo || 'Omni 1.1 Flash';
  const qGerAtual = novela.qualidadeGeracaoVideo || padroes.qualidadeGeracaoVideo || '720p';
  const qDownVidAtual = novela.qualidadeDownloadVideo || padroes.qualidadeDownloadVideo || '720p';
  const qDownImgAtual = novela.qualidadeDownloadImagem || padroes.qualidadeDownloadImagem || '1k';

  // Detecta se existem videos concluidos com tamanho/hash/chave repetidos (ex.: bug anterior do modo Elementos)
  const videosDuplicados = useMemo(() => {
    const concluidos = (novela.itens || []).filter((i) => i.tipo === 'video' && i.status === 'concluido' && (i.sha256 || i.flowMidiaChave || i.tamanhoBytes));
    const vistos = new Map();
    const repetidos = [];
    for (const v of concluidos) {
      const chave = v.sha256 ? `sha:${v.sha256}` : v.flowMidiaChave ? `url:${v.flowMidiaChave.split('?')[0]}` : `sz:${v.tamanhoBytes}`;
      if (vistos.has(chave)) {
        repetidos.push(`${v.id} = ${vistos.get(chave)}`);
      } else {
        vistos.set(chave, v.id);
      }
    }
    return repetidos;
  }, [novela.itens]);

  const videosFalhos = useMemo(
    () => (novela.itens || []).filter((i) => i.tipo === 'video' && (i.status === 'falha_revisar' || i.status === 'erro')),
    [novela.itens]
  );
  const videosComBackup = useMemo(
    () => (novela.itens || []).filter((i) => i.tipo === 'video' && (i.promptOriginalBackup || i.originalPrompt || i.anexosOriginaisBackup || i.modoDescritivoSemImagem)),
    [novela.itens]
  );

  const dispararRecaptura = () =>
    executar(
      () => api.recapturarVideos(novela.id),
      '🔄 Varrendo o projeto no Google Flow e re-capturando os vídeos prontos (0 créditos)...'
    );

  const atualizar = (dados) => executar(() => api.atualizarNovela(novela.id, dados));

  const modelosImg = config.modelosImagem?.length ? config.modelosImagem : ['Nano Banana'];
  const modelosVid = config.modelosVideo?.length ? config.modelosVideo : ['Omni 1.2 Flash', 'Omni 1.1 Flash'];

  return (
    // pagina unica: o cabecalho rola junto com o conteudo (nada fixo)
    <div className="h-full overflow-y-auto bg-studio-950">
      {/* ===== Cabecalho da novela ===== */}
      <div className="border-b border-white/[0.07] bg-studio-900/60 px-6 pb-0 pt-3.5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            {editNome === null ? (
              <div className="group flex items-center gap-2">
                <h1 className="truncate text-lg font-bold tracking-tight text-white">{novela.nome}</h1>
                <button className="text-zinc-600 opacity-0 transition group-hover:opacity-100 hover:text-white" onClick={() => setEditNome(novela.nome)} title="Renomear"><Pencil size={13} /></button>
                <NovelaStatus status={st} />
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <input className="input w-72 py-1 text-base font-bold" autoFocus value={editNome} onChange={(e) => setEditNome(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { atualizar({ nome: editNome }); setEditNome(null); } if (e.key === 'Escape') setEditNome(null); }} />
                <button className="btn-ghost p-1.5" onClick={() => { atualizar({ nome: editNome }); setEditNome(null); }}><Check size={14} /></button>
                <button className="btn-ghost p-1.5" onClick={() => setEditNome(null)}><X size={14} /></button>
              </div>
            )}
            <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-zinc-500">
              <span>{p.videos.feito}/{p.videos.total} vídeos · {p.todos.feito}/{p.todos.total} itens</span>
              {novela.flowProjectUrl ? (
                <a href={novela.flowProjectUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sky-400 hover:underline" title={novela.flowProjectUrl}>
                  <Link2 size={11} /> Abrir Projeto Flow
                </a>
              ) : (
                <span className="inline-flex items-center gap-1 text-zinc-600"><Link2 size={11} /> Flow cria ao rodar</span>
              )}
            </div>
          </div>

          {/* Botoes principais + Marcar Concluída + menu ••• */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              className={`btn-ghost inline-flex items-center gap-1.5 border ${
                novela.concluidaManualmente
                  ? 'border-emerald-500/50 bg-emerald-500/20 font-semibold text-emerald-200 hover:bg-emerald-500/30'
                  : 'border-white/[0.1] bg-studio-850 text-zinc-200 hover:border-emerald-500/40 hover:bg-emerald-500/15 hover:text-emerald-200'
              }`}
              title={
                novela.concluidaManualmente
                  ? 'Esta história foi marcada como Concluída manualmente e não voltará para a fila automática. Clique para reabrir.'
                  : 'Marcar história como Concluída manualmente (remove da fila e nunca mais puxa automaticamente)'
              }
              onClick={() =>
                executar(
                  () => api.marcarNovelasConcluidas([novela.id], !novela.concluidaManualmente),
                  novela.concluidaManualmente
                    ? `↩️ "${novela.nome}" reaberta para geração na fila!`
                    : `✅ "${novela.nome}" marcada como Concluída manualmente!`
                )
              }
            >
              <span>{novela.concluidaManualmente ? '✅ Concluída (↩️ Reabrir)' : '✅ Marcar Concluída'}</span>
            </button>

            <button
              className="btn inline-flex bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-sm shadow-cyan-950/40 hover:from-cyan-500 hover:to-teal-500"
              disabled={enviandoCapcut || (!p.videos.feito && !novela.concluidaManualmente)}
              title={p.videos.feito || novela.concluidaManualmente ? 'Cria/atualiza o projeto no CapCut PC com todos os vídeos existentes na pasta da novela' : 'Nenhum vídeo concluído ainda'}
              onClick={async () => {
                setEnviandoCapcut(true);
                const r = await executar(() => api.enviarCapcut(novela.id));
                setEnviandoCapcut(false);
                if (r) setCapcutOk(r);
              }}
            >
              <Scissors size={14} /> {enviandoCapcut ? 'Enviando...' : `✂️ CapCut (${p.videos.feito}/${p.videos.total})`}
            </button>

            <button
              className="btn-ghost inline-flex items-center gap-1.5 border border-emerald-500/30 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20"
              title="Gerar legenda provocativa (não-descritiva) com Claude e enviar para o WhatsApp"
              onClick={abrirModalLegenda}
            >
              <span>📲 Legenda WhatsApp</span>
              {novela.legendaEnviadaWhatsappEm ? (
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" title={`Enviada em ${new Date(novela.legendaEnviadaWhatsappEm).toLocaleString('pt-BR')}`} />
              ) : novela.legendaFacebook ? (
                <span className="rounded bg-emerald-500/20 px-1 text-[9.5px] text-emerald-300">Pronta</span>
              ) : null}
            </button>

            <button
              className="btn-primary"
              disabled={rodandoEsta || !novela.itens.length}
              onClick={() =>
                executar(
                  () => api.rodarNovela(novela.id),
                  fila.rodando || fila.pausado ? `"${novela.nome}" adicionada ao final da fila global!` : 'Novela iniciada na fila!'
                )
              }
              title={
                fila.rodando || fila.pausado
                  ? 'Adiciona esta novela ao final da fila global de execução'
                  : 'Inicia a geração dos itens pendentes desta novela no Google Flow'
              }
            >
              <Play size={14} />{' '}
              {rodandoEsta
                ? 'Rodando...'
                : fila.fila?.includes(novela.id)
                  ? `✓ Na Fila (#${fila.fila.indexOf(novela.id) + 1})`
                  : fila.rodando || fila.pausado
                    ? '➕ Enfileirar'
                    : '▷ Rodar'}
            </button>

            <div className="relative">
              <button
                className="btn-ghost px-2 text-zinc-400 hover:text-white"
                title="Mais ações (Pastas, Re-capturar do Flow, Excluir)"
                onClick={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  const limite = (e.currentTarget.closest('.overflow-y-auto') || document.body).getBoundingClientRect().left;
                  setAlinharEsquerda(r.right - 290 < limite);
                  setMenuAvancado((v) => !v);
                }}
              >
                <MoreHorizontal size={15} />
              </button>
              {menuAvancado && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setMenuAvancado(false)} />
                  <div className={`absolute top-full z-40 mt-1.5 w-72 max-w-[calc(100vw-2rem)] rounded-xl border border-white/[0.1] bg-studio-900 p-1.5 shadow-2xl ${alinharEsquerda ? 'left-0' : 'right-0'}`}>
                    <button
                      className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs text-zinc-200 hover:bg-studio-800"
                      onClick={() => { setMenuAvancado(false); executar(() => api.abrirPasta(novela.id), 'Abrindo pasta no Windows Explorer...'); }}
                    >
                      <FolderOpen size={14} className="shrink-0 text-zinc-400" />
                      <span>Abrir Pasta no Windows</span>
                    </button>
                    <button
                      className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs text-zinc-200 hover:bg-studio-800"
                      onClick={() => { setMenuAvancado(false); executar(() => api.abrirPasta(novela.id, '03_Videos'), 'Abrindo 03_Videos...'); }}
                    >
                      <Clapperboard size={14} className="shrink-0 text-violet-400" />
                      <span>Abrir Pasta de Vídeos (03_Videos)</span>
                    </button>
                    <button
                      className="flex w-full items-start gap-2 rounded-lg px-2.5 py-2 text-left text-xs text-cyan-200 hover:bg-cyan-500/10 disabled:opacity-40"
                      disabled={rodandoEsta}
                      onClick={() => {
                        setMenuAvancado(false);
                        executar(
                          () => api.recuperarMidiasPasta(novela.id),
                          `🔄 Mídias da pasta "${novela.pasta}" reconectadas com sucesso!`
                        );
                      }}
                    >
                      <RefreshCw size={14} className="mt-0.5 shrink-0 text-cyan-400" />
                      <span>
                        <span className="font-medium">🔄 Recuperar Mídias da Pasta</span>
                        <span className="block text-[10px] text-zinc-400">Reconecta .mp4/imagens do disco + roteiro_backup.txt</span>
                      </span>
                    </button>
                    <button
                      className="flex w-full items-start gap-2 rounded-lg px-2.5 py-2 text-left text-xs text-zinc-200 hover:bg-studio-800 disabled:opacity-40"
                      disabled={filaOcupada || !p.videos.total || !novela.flowProjectUrl}
                      onClick={() => { setMenuAvancado(false); dispararRecaptura(); }}
                    >
                      <RefreshCw size={14} className={`mt-0.5 shrink-0 text-amber-300 ${recapturandoEsta ? 'animate-spin' : ''}`} />
                      <span>
                        <span className="font-medium">Re-capturar Vídeos do Flow</span>
                        <span className="block text-[10px] text-zinc-500">Baixa vídeos já prontos no projeto (0 créditos)</span>
                      </span>
                    </button>
                    <div className="my-1 border-t border-white/[0.07]" />
                    <button
                      className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs text-red-300 hover:bg-red-500/10"
                      onClick={() => { setMenuAvancado(false); setConfirmarExcluir(true); }}
                    >
                      <Trash2 size={14} className="shrink-0 text-red-400" />
                      <span>Excluir Novela do Estúdio</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Barra-resumo slim de 1 linha para Modelo & Resolucao (expansivel sob demanda) */}
        <div className="mt-2.5 rounded-lg border border-white/[0.07] bg-studio-850/70 px-3 py-1.5">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-1.5 text-zinc-300">
              <Settings2 size={13} className="text-violet-400" />
              <span className="font-medium text-white">{modImgAtual}</span>
              <span className="text-zinc-600">·</span>
              <span className="font-medium text-white">{modVidAtual}</span>
              <span className="text-zinc-600">·</span>
              <span>{qGerAtual} → <b className="text-emerald-300">{ROTULO_CURTO_DOWN_VIDEO[qDownVidAtual] || qDownVidAtual}</b></span>
              <span className="text-zinc-600">·</span>
              <span className="text-zinc-400">Img {String(qDownImgAtual).toUpperCase()}</span>
              <span className="text-zinc-600">·</span>
              <span className="text-zinc-400">{novela.forcarElementos ? 'Elementos' : 'Frame Inicial'}</span>
            </div>
            <button
              type="button"
              onClick={() => setConfigAberta((v) => !v)}
              className="inline-flex items-center gap-1 rounded-md border border-white/[0.08] bg-studio-900 px-2 py-0.5 text-[11px] font-medium text-zinc-300 hover:border-violet-500/40 hover:text-white"
            >
              {configAberta ? <>Ocultar <ChevronUp size={12} /></> : <>Alterar <ChevronDown size={12} /></>}
            </button>
          </div>

          {configAberta && (
            <div className="mt-2.5 space-y-2.5 border-t border-white/[0.07] pt-2.5">
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
                <label className="flex items-center gap-2 text-xs">
                  <Sparkles size={13} className="text-violet-400" />
                  <span className="text-zinc-400">Modelo Imagem</span>
                  <select className="input w-40 py-1 text-xs" value={modImgAtual} onChange={(e) => atualizar({ modeloImagem: e.target.value })}>
                    {[...new Set([...modelosImg, modImgAtual])].map((m) => <option key={m}>{m}</option>)}
                  </select>
                </label>
                <label className="flex items-center gap-2 text-xs">
                  <Video size={13} className="text-fuchsia-400" />
                  <span className="text-zinc-400">Modelo Vídeo</span>
                  <select className="input w-40 py-1 text-xs" value={modVidAtual} onChange={(e) => atualizar({ modeloVideo: e.target.value })}>
                    {[...new Set([...modelosVid, modVidAtual])].map((m) => <option key={m}>{m}</option>)}
                  </select>
                </label>
                <div className="flex items-center gap-2">
                  <Boxes size={13} className="text-amber-400" />
                  <Toggle
                    checked={!!novela.forcarElementos}
                    onChange={(v) => atualizar({ forcarElementos: v })}
                    label="Modo Elementos"
                    title="Quando ligado, todos os vídeos usam o submodo Elementos"
                  />
                </div>
                <button
                  type="button"
                  className="btn-ghost ml-auto py-1 text-[11px]"
                  title="Restaura os modelos e qualidades desta novela para os Padrões Globais do FlowStudio"
                  onClick={() => executar(() => api.atualizarNovela(novela.id, { sincronizarComPadroes: true }), 'Sincronizada com os Padrões globais!')}
                >
                  Usar Padrões Globais
                </button>
              </div>
              <div className="border-t border-white/[0.05] pt-2">
                <SeletoresQualidade compacto valores={novela} padroes={config.padroes} onChange={atualizar} />
              </div>
            </div>
          )}
        </div>

        {/* Abas */}
        <nav className="mt-2.5 flex gap-1 overflow-x-auto">
          {ABAS.map((a) => {
            const I = a.icon;
            const qtd = a.tipo ? novela.itens.filter((i) => i.tipo === a.tipo).length : novela.itens.length;
            const ativa = aba === a.id;
            return (
              <button key={a.id} onClick={() => setAba(a.id)}
                className={`relative flex items-center gap-1.5 whitespace-nowrap rounded-t-lg px-3.5 py-2 text-xs font-medium transition-colors ${ativa ? 'bg-studio-950 text-white' : 'text-zinc-500 hover:text-zinc-200'}`}>
                <I size={13} className={ativa ? 'text-fuchsia-400' : ''} />
                {a.rotulo}
                <span className={`rounded px-1.5 text-[10px] ${ativa ? 'bg-fuchsia-500/20 text-fuchsia-300' : 'bg-studio-800 text-zinc-400'}`}>{qtd}</span>
                {ativa && <span className="absolute inset-x-3 -bottom-px h-0.5 rounded bg-gradient-to-r from-violet-500 to-fuchsia-500" />}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="p-6">
        {videosFalhos.length > 0 && (
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-xs text-rose-100">
            <div className="flex items-start gap-2.5">
              <AlertTriangle size={17} className="mt-0.5 shrink-0 text-rose-400" />
              <div>
                <div className="font-semibold text-rose-200">
                  {videosFalhos.length} cena(s) de vídeo bloqueada(s) no Google Flow ({videosFalhos.map((v) => `{${v.id}}`).join(', ')})
                </div>
                <div className="mt-0.5 text-rose-200/80">
                  Quando o filtro do Veo implica com rosto nas imagens anexadas, escolha abaixo entre manter só <span className="font-mono">imagem_XX</span> suavizada ou gerar pelo <b>Prompt 100% Descritivo (Sem Imagem)</b> puxando roupas, rostos e cenário automaticamente:
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={filaOcupada}
                onClick={() => executar(() => api.acaoLoteItensFalhos(novela.id, 'suavizar_com_imagem', true), `🛡️ ${videosFalhos.length} cena(s) suavizada(s) (só imagem_XX) e enviadas para a fila!`)}
                className="btn border border-sky-400/50 bg-sky-500/20 text-xs font-semibold text-sky-100 hover:bg-sky-500/30 disabled:opacity-40"
              >
                🛡️ Suavizar (com imagem)
              </button>
              <button
                type="button"
                disabled={filaOcupada}
                onClick={() => executar(() => api.acaoLoteItensFalhos(novela.id, 'descritivo_sem_imagem', true), `📝 ${videosFalhos.length} cena(s) convertida(s) para Prompt 100% Descritivo (Sem Imagem) e enviadas para a fila!`)}
                className="btn border border-amber-400/50 bg-amber-500/25 text-xs font-semibold text-amber-100 hover:bg-amber-500/35 disabled:opacity-40"
              >
                📝 Gerar Só por Descrição (Sem Imagem)
              </button>
              {videosComBackup.length > 0 && (
                <button
                  type="button"
                  disabled={filaOcupada}
                  onClick={() => executar(() => api.acaoLoteItensFalhos(novela.id, 'restaurar_original', false), '↺ Prompts e anexos originais restaurados!')}
                  className="btn-ghost text-xs"
                >
                  ↺ Restaurar Original
                </button>
              )}
            </div>
          </div>
        )}
        {videosDuplicados.length > 0 && novela.flowProjectUrl && (
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-xs text-amber-100">
            <div className="flex items-start gap-2.5">
              <AlertTriangle size={17} className="mt-0.5 shrink-0 text-amber-400" />
              <div>
                <div className="font-semibold text-amber-200">
                  Foram detectados {videosDuplicados.length} vídeo(s) repetidos na pasta desta novela ({videosDuplicados.slice(0, 4).join(', ')}{videosDuplicados.length > 4 ? '…' : ''}).
                </div>
                <div className="mt-0.5 text-amber-200/80">
                  Se os vídeos certos já foram gerados no Google Flow, clique ao lado para re-capturar todos os cards da página pelo diálogo único de cada cena <b>sem gastar 1 crédito</b> e depois envie novamente para o CapCut.
                </div>
              </div>
            </div>
            <button
              className="btn border border-amber-400/50 bg-amber-500/25 text-xs font-semibold text-white hover:bg-amber-500/35 disabled:opacity-40"
              disabled={filaOcupada}
              onClick={dispararRecaptura}
            >
              <RefreshCw size={14} className={recapturandoEsta ? 'animate-spin' : ''} />
              {recapturandoEsta ? 'Re-capturando...' : '🔄 Re-capturar Vídeos Prontos do Flow'}
            </button>
          </div>
        )}
        {aba === 'roteiro' && <RoteiroTab novela={novela} fila={fila} executar={executar} toast={toast} acoes={acoes} />}
        {aba === 'referencias' && <GaleriaImagens novela={novela} tipo="referencia_imagem" executar={executar} acoes={acoes} />}
        {aba === 'imagens' && <GaleriaImagens novela={novela} tipo="imagem_base" executar={executar} acoes={acoes} />}
        {aba === 'videos' && <GaleriaVideos novela={novela} executar={executar} acoes={acoes} />}
      </div>
      {acoes.modais}

      <Modal aberto={!!capcutOk} onFechar={() => setCapcutOk(null)} titulo="✂️ Projeto enviado para o CapCut!">
        {capcutOk && (
          <div className="space-y-3 text-sm text-zinc-300">
            <p className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 text-emerald-200">
              Projeto enviado para o CapCut! Se o CapCut estiver aberto, volte para a tela inicial dele para ver o projeto.
            </p>
            <div className="text-xs text-zinc-400">
              <div>Projeto: <b className="text-white">{capcutOk.nomeProjeto}</b> {capcutOk.atualizado ? '(timeline atualizada)' : '(novo)'}</div>
              <div>{capcutOk.cenas.length} cena(s) · {(capcutOk.duracaoTotalUs / 1e6).toFixed(1)}s · canvas 1080×1920 (9:16) · <span className="text-emerald-300">100% original (sem aprimoramento de qualidade)</span></div>
              <div className="mt-2 max-h-40 overflow-y-auto font-mono text-[11px] text-zinc-500">
                {capcutOk.cenas.map((c, i) => <div key={i}>{String(i + 1).padStart(2, '0')}. {c.arquivo} — {c.duracaoSeg}s ({c.largura}×{c.altura})</div>)}
              </div>
              <div className="mt-2 break-all text-[10px] text-zinc-600">{capcutOk.pasta}</div>
            </div>
            <div className="flex justify-end"><button className="btn-primary" onClick={() => setCapcutOk(null)}>OK</button></div>
          </div>
        )}
      </Modal>

      <Modal aberto={modalLegenda} onFechar={() => setModalLegenda(false)} titulo={`📲 Legenda WhatsApp — ${novela.nome}`} largura="max-w-xl">
        <div className="space-y-3 text-xs text-zinc-300">
          <div className="rounded-lg border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-2 text-[11px] text-fuchsia-200">
            <b>Regra Facebook Mobile ativa:</b> Português real do dia a dia ligado ao sentimento da história · <b>95 a 160 caracteres</b> (3 a 4 linhas no celular, sem cortar no &quot;Ver mais&quot;) · Zero travessão (<code>—</code>), zero clichê de IA e zero perguntas (<code>?</code>) · <b>1 a 2 emojis no final</b> + <b>1 linha em branco</b> + <b>2 a 3 hashtags exclusivas da sua lista salva</b> (<code>#historia #novela #motivacional #filme</code>).
          </div>

          <div>
            <div className="mb-1 flex items-center justify-between">
              <span className="label">Texto da legenda (editável)</span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  className="btn-ghost px-2 py-0.5 text-[11px]"
                  disabled={gerandoLegenda}
                  onClick={async () => {
                    setGerandoLegenda(true);
                    const r = await executar(() => fab.gerarLegenda(novela.id, { enviarWhatsapp: false }), '✨ Nova legenda gerada com Claude!');
                    setGerandoLegenda(false);
                    if (r?.legendaFacebook) setTextoLegendaModal(r.legendaFacebook);
                  }}
                >
                  <Sparkles size={12} /> {gerandoLegenda ? 'Gerando no Claude...' : '✨ Gerar com Claude'}
                </button>
                <button
                  type="button"
                  className="btn-ghost px-2 py-0.5 text-[11px]"
                  disabled={gerandoLegenda}
                  onClick={async () => {
                    const r = await executar(() => fab.sortearLegenda(novela.id), '🎲 Hashtags sorteadas!');
                    if (r?.legendaFacebook) setTextoLegendaModal(r.legendaFacebook);
                  }}
                >
                  🎲 Sortear Hashtags
                </button>
                <button
                  type="button"
                  className="btn-ghost px-2 py-0.5 text-[11px]"
                  disabled={!textoLegendaModal.trim()}
                  onClick={() => {
                    navigator.clipboard.writeText(textoLegendaModal.trim());
                    toast?.('📋 Legenda copiada!', 'ok');
                  }}
                >
                  📋 Copiar
                </button>
              </div>
            </div>
            <textarea
              className="input min-h-[130px] resize-y font-sans text-xs leading-relaxed"
              placeholder={gerandoLegenda ? 'Gerando legenda provocativa via Claude...' : 'Clique em "✨ Gerar com Claude" ou digite sua legenda...'}
              value={textoLegendaModal}
              onChange={(e) => setTextoLegendaModal(e.target.value)}
            />
            {textoLegendaModal.trim() !== (novela.legendaFacebook || '').trim() && textoLegendaModal.trim() && (
              <div className="mt-1.5 flex justify-end">
                <button
                  type="button"
                  className="btn-ghost py-1 text-[11px]"
                  onClick={async () => {
                    const r = await executar(() => fab.salvarLegenda(novela.id, textoLegendaModal), 'Legenda salva!');
                    if (r?.legendaFacebook) setTextoLegendaModal(r.legendaFacebook);
                  }}
                >
                  <Check size={12} /> Salvar edição manual
                </button>
              </div>
            )}
          </div>

          {/* Bloco compacto de conexao e destino do WhatsApp */}
          <div className="rounded-lg border border-white/[0.08] bg-studio-950/80 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className={`h-2 w-2 rounded-full ${zapStatus?.conectado ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                <span className="font-medium text-white">
                  WhatsApp: {zapStatus?.conectado ? `Conectado (${zapStatus.meuNumero || 'ativo'})` : zapStatus?.estado || 'Desconectado'}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                {!zapStatus?.conectado ? (
                  <button
                    type="button"
                    className="btn-ghost px-2 py-1 text-[11px]"
                    onClick={async () => {
                      const z = await executar(() => fab.zapConectar(), 'Iniciando conexão do WhatsApp...');
                      if (z) setZapStatus(z);
                      setTimeout(carregarStatusZap, 2500);
                    }}
                  >
                    Conectar QR Code
                  </button>
                ) : (
                  <button
                    type="button"
                    className="btn-ghost px-2 py-1 text-[11px] text-zinc-400"
                    onClick={async () => {
                      const z = await executar(() => fab.zapDesconectar(), 'WhatsApp desconectado');
                      if (z) setZapStatus(z);
                    }}
                  >
                    Desconectar
                  </button>
                )}
                <button type="button" className="btn-ghost px-1.5 py-1 text-[11px]" onClick={carregarStatusZap} title="Atualizar status do WhatsApp">
                  <RefreshCw size={11} />
                </button>
              </div>
            </div>

            {zapStatus?.qrDataUrl && !zapStatus?.conectado && (
              <div className="mt-2.5 flex flex-col items-center rounded-lg bg-white p-3 text-center text-zinc-900">
                <img src={zapStatus.qrDataUrl} alt="QR Code WhatsApp" className="h-44 w-44" />
                <span className="mt-1 text-[11px] font-medium">Escaneie no WhatsApp do celular (Aparelhos conectados)</span>
              </div>
            )}

            <div className="mt-2.5 flex items-center gap-2">
              <input
                className="input py-1 text-xs"
                placeholder="Destino WhatsApp (vazio = enviar para você mesmo)"
                value={destinoZap}
                onChange={(e) => setDestinoZap(e.target.value)}
                onBlur={() => fab.salvarCapcut({ destinoWhatsapp: destinoZap }).catch(() => {})}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <button type="button" className="btn-ghost" onClick={() => setModalLegenda(false)}>
              Fechar
            </button>
            <div className="flex items-center gap-2">
              <button
                type="button"
                className="btn-ghost border border-violet-500/30 bg-violet-500/10 text-violet-200 hover:bg-violet-500/20"
                disabled={gerandoLegenda || enviandoLegenda}
                onClick={async () => {
                  setGerandoLegenda(true);
                  const r = await executar(
                    () => fab.gerarLegenda(novela.id, { enviarWhatsapp: true, numero: destinoZap }),
                    '✨📲 Nova legenda gerada com Claude e enviada ao WhatsApp!'
                  );
                  setGerandoLegenda(false);
                  if (r?.legendaFacebook) setTextoLegendaModal(r.legendaFacebook);
                }}
              >
                <Sparkles size={13} /> Gerar Nova & Enviar
              </button>
              <button
                type="button"
                className="btn-primary"
                disabled={enviandoLegenda || gerandoLegenda}
                onClick={async () => {
                  setEnviandoLegenda(true);
                  if (textoLegendaModal.trim() && textoLegendaModal.trim() !== (novela.legendaFacebook || '').trim()) {
                    await fab.salvarLegenda(novela.id, textoLegendaModal).catch(() => {});
                  }
                  const r = await executar(() => fab.enviarLegenda(novela.id, destinoZap), '📲 Legenda enviada ao WhatsApp!');
                  setEnviandoLegenda(false);
                  if (r?.legendaFacebook) setTextoLegendaModal(r.legendaFacebook);
                }}
              >
                📲 {enviandoLegenda ? 'Enviando...' : 'Enviar para o WhatsApp'}
              </button>
            </div>
          </div>
        </div>
      </Modal>

      <Modal aberto={confirmarExcluir} onFechar={() => setConfirmarExcluir(false)} titulo="Excluir novela?">
        <p className="text-sm text-zinc-400">A novela <b className="text-white">{novela.nome}</b> será removida do estúdio. Os arquivos gerados em <span className="font-mono text-zinc-300">Meus_Projetos_Flow\{novela.pasta}</span> <b>não</b> serão apagados.</p>
        <div className="mt-5 flex justify-end gap-2">
          <button className="btn-ghost" onClick={() => setConfirmarExcluir(false)}>Cancelar</button>
          <button className="btn-danger" onClick={async () => { await executar(() => api.removerNovela(novela.id), 'Novela removida'); setConfirmarExcluir(false); }}><Trash2 size={15} /> Excluir</button>
        </div>
      </Modal>
    </div>
  );
}
