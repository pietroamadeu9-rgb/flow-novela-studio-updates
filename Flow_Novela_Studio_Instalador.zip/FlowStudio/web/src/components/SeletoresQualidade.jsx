import React from 'react';
import { QUALIDADES } from '../api.js';

/** Seletores de qualidade (geracao vs download), 100% sob controle manual do usuario. */
export default function SeletoresQualidade({ valores, onChange, compacto = false, padroes = {} }) {
  return (
    <div className={compacto ? 'flex flex-wrap items-center gap-x-5 gap-y-2' : 'space-y-3'}>
      {Object.entries(QUALIDADES).map(([campo, def]) => (
        <label key={campo} className={compacto ? 'flex items-center gap-2 text-sm' : 'block'}>
          <span className={compacto ? 'text-zinc-400' : 'label mb-1 block'}>{def.rotulo}</span>
          <select
            className={`input py-1.5 ${compacto ? 'w-56' : ''}`}
            value={valores?.[campo] || padroes[campo] || def.opcoes[0][0]}
            onChange={(e) => onChange({ [campo]: e.target.value })}
          >
            {def.opcoes.map(([v, t]) => <option key={v} value={v}>{t}</option>)}
          </select>
        </label>
      ))}
    </div>
  );
}
