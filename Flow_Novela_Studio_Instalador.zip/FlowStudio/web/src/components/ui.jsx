import React, { useEffect } from 'react';
import { X, Loader2, CheckCircle2, AlertTriangle, Clock, CircleDashed, ListOrdered, Ban } from 'lucide-react';

export function Toggle({ checked, onChange, label, title }) {
  return (
    <label className="flex cursor-pointer select-none items-center gap-2 text-sm text-zinc-300" title={title}>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative h-5 w-9 rounded-full transition-colors ${checked ? 'bg-fuchsia-600' : 'bg-studio-600'}`}
      >
        <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${checked ? 'left-[18px]' : 'left-0.5'}`} />
      </button>
      {label}
    </label>
  );
}

export function ProgressBar({ feito, total, cor = 'from-violet-500 to-fuchsia-500' }) {
  const pct = total ? Math.round((feito / total) * 100) : 0;
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-studio-700">
      <div className={`h-full rounded-full bg-gradient-to-r ${cor} transition-all duration-500`} style={{ width: `${pct}%` }} />
    </div>
  );
}

const ESTILOS_STATUS = {
  pendente: { cls: 'text-zinc-400 bg-zinc-500/10 border-zinc-500/20', icon: CircleDashed, txt: 'Pendente' },
  na_fila: { cls: 'text-sky-300 bg-sky-500/10 border-sky-500/30', icon: ListOrdered, txt: 'Na fila' },
  gerando: { cls: 'text-amber-300 bg-amber-500/10 border-amber-500/30', icon: Loader2, txt: 'Gerando', spin: true },
  concluido: { cls: 'text-emerald-300 bg-emerald-500/10 border-emerald-500/30', icon: CheckCircle2, txt: 'Concluído' },
  erro: { cls: 'text-red-300 bg-red-500/10 border-red-500/30', icon: AlertTriangle, txt: 'Erro' },
  falha_revisar: { cls: 'text-rose-300 bg-rose-500/15 border-rose-500/40', icon: AlertTriangle, txt: 'Revisar (3×)' },
  bloqueado_dependencia: { cls: 'text-orange-300 bg-orange-500/10 border-orange-500/30', icon: Ban, txt: 'Dep. bloqueada' },
};

export function ItemStatus({ status }) {
  const s = ESTILOS_STATUS[status] || ESTILOS_STATUS.pendente;
  const I = s.icon;
  return (
    <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[11px] font-medium ${s.cls}`}>
      <I size={12} className={s.spin ? 'animate-spin' : ''} /> {s.txt}
    </span>
  );
}

const ESTILOS_NOVELA = {
  rodando: 'text-amber-300 bg-amber-500/10',
  pausada: 'text-amber-200 bg-amber-500/15 border border-amber-500/30',
  sem_creditos: 'text-amber-200 bg-amber-500/20 border border-amber-500/40',
  na_fila: 'text-sky-300 bg-sky-500/10',
  rascunho: 'text-zinc-400 bg-zinc-500/10',
  invalido: 'text-red-300 bg-red-500/10',
  concluida: 'text-emerald-300 bg-emerald-500/10',
  erro: 'text-red-300 bg-red-500/10',
  revisar: 'text-rose-300 bg-rose-500/15',
  parcial: 'text-violet-300 bg-violet-500/10',
  pronta: 'text-zinc-300 bg-zinc-500/10',
};

export function NovelaStatus({ status }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${ESTILOS_NOVELA[status.chave]}`}>
      {status.chave === 'rodando' && <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-amber-400" />}
      {status.chave === 'na_fila' && <Clock size={10} />}
      {status.rotulo}
    </span>
  );
}

export function Modal({ aberto, onFechar, titulo, children, largura = 'max-w-md' }) {
  useEffect(() => {
    if (!aberto) return;
    const f = (e) => e.key === 'Escape' && onFechar();
    window.addEventListener('keydown', f);
    return () => window.removeEventListener('keydown', f);
  }, [aberto, onFechar]);
  if (!aberto) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onMouseDown={onFechar}>
      <div className={`card w-full ${largura} p-5 shadow-2xl`} onMouseDown={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold text-white">{titulo}</h3>
          <button className="text-zinc-500 hover:text-white" onClick={onFechar}><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Vazio({ icon: I, titulo, texto, children }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-studio-600 py-16 text-center">
      {I && <I size={36} className="text-studio-500" />}
      <div className="text-sm font-medium text-zinc-300">{titulo}</div>
      {texto && <div className="max-w-md text-xs text-zinc-500">{texto}</div>}
      {children}
    </div>
  );
}

export function Toasts({ toasts }) {
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-96 flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`pointer-events-auto rounded-lg border px-4 py-3 text-sm shadow-xl backdrop-blur ${
            t.tipo === 'erro' ? 'border-red-500/40 bg-red-950/90 text-red-100' : t.tipo === 'ok' ? 'border-emerald-500/40 bg-emerald-950/90 text-emerald-100' : 'border-studio-600 bg-studio-850/95 text-zinc-200'
          }`}
        >
          {t.msg}
        </div>
      ))}
    </div>
  );
}
