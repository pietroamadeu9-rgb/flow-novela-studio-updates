import React, { useEffect, useMemo, useState } from 'react';
import { Film, Folder, FolderOpen, ChevronRight, ChevronDown, ChevronUp, Trash2, Clapperboard, CheckCircle2, AlertTriangle, FileEdit, CheckSquare, Square, RotateCcw } from 'lucide-react';
import { api, fab, progressoNovela, statusNovela } from '../api.js';
import { ProgressBar } from './ui.jsx';
import { agruparNovelas, infoSerieNovela, ehRascunhoVazio } from '../agrupamento.js';
import { ModalTipoFinal } from './FabricaModais.jsx';

/** Abas "🎬 Parte Única" | "📚 Séries" reutilizáveis (Estúdio e Fábrica). */
export function AbasPartes({ aba, setAba, qtdUnicas, qtdSeries, compacto = false }) {
  const itens = [['unica', '🎬 Parte Única', qtdUnicas], ['serie', '📚 Séries', qtdSeries]];
  return (
    <div className={`grid grid-cols-2 gap-1 rounded-lg border border-white/[0.07] bg-studio-950 p-1 ${compacto ? '' : 'mb-1.5'}`}>
      {itens.map(([id, rotulo, qtd]) => (
        <button
          key={id}
          type="button"
          onClick={() => setAba(id)}
          className={`flex items-center justify-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium transition ${
            aba === id ? 'bg-violet-500/20 text-white shadow-inner' : 'text-zinc-500 hover:bg-studio-850 hover:text-zinc-200'
          }`}
        >
          {rotulo}
          <span className={`rounded px-1.5 text-[10px] ${aba === id ? 'bg-fuchsia-500/25 text-fuchsia-200' : 'bg-studio-800 text-zinc-400'}`}>{qtd}</span>
        </button>
      ))}
    </div>
  );
}

function StatusIndicadorCurto({ st, n }) {
  if (n?.concluidaManualmente || st.chave === 'concluida') {
    return (
      <span
        className="inline-flex items-center gap-0.5 rounded border border-emerald-500/35 bg-emerald-500/15 px-1.5 py-0.5 text-[9.5px] font-semibold text-emerald-300"
        title={n?.concluidaManualmente ? 'Marcada como Concluída manualmente (não volta para a fila automática)' : 'Todos os itens concluídos'}
      >
        ✅ Concluída
      </span>
    );
  }
  if (st.chave === 'rodando') return <span className="pulse-dot h-2 w-2 shrink-0 rounded-full bg-amber-400" title={st.rotulo || 'Rodando agora'} />;
  if (st.chave === 'pausada') return <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-medium text-amber-200">Pausada</span>;
  if (st.chave === 'revisar' || st.chave === 'invalido' || st.chave === 'sem_creditos') {
    return <span className="rounded bg-rose-500/15 px-1.5 py-0.5 text-[10px] font-medium text-rose-300">{st.rotulo}</span>;
  }
  if (st.chave === 'na_fila') return <span className="rounded bg-sky-500/15 px-1.5 py-0.5 text-[10px] font-medium text-sky-300">Fila</span>;
  return null;
}

function CardNovela({
  n,
  fila,
  ativa,
  onSelecionar,
  rotulo,
  compacto = false,
  onExcluir,
  marcada = false,
  onAlternarMarca,
  onAlternarConcluidaRapido,
}) {
  const p = progressoNovela(n);
  const st = statusNovela(n, fila);
  const posFila = fila.fila?.indexOf(n.id);
  const jaConcluida = Boolean(n.concluidaManualmente || st.chave === 'concluida');
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onSelecionar(n.id)}
      onKeyDown={(e) => { if (e.key === 'Enter') onSelecionar(n.id); }}
      className={`group w-full cursor-pointer rounded-lg border text-left transition-all ${compacto ? 'p-2' : 'p-2.5'} ${
        marcada
          ? 'border-emerald-500/50 bg-emerald-500/10'
          : ativa
            ? 'border-violet-500/50 bg-violet-500/10'
            : 'border-white/[0.05] bg-studio-850/70 hover:border-white/[0.12] hover:bg-studio-800'
      }`}
    >
      <div className="flex items-center justify-between gap-1.5">
        <div className="flex min-w-0 items-center gap-1.5">
          {onAlternarMarca && (
            <button
              type="button"
              title={marcada ? 'Desmarcar história da seleção em lote' : 'Selecionar história para ação em lote'}
              className={`shrink-0 rounded p-0.5 transition ${marcada ? 'text-emerald-400' : 'text-zinc-500 hover:text-zinc-200'}`}
              onClick={(e) => {
                e.stopPropagation();
                onAlternarMarca(n.id);
              }}
            >
              {marcada ? <CheckSquare size={13} /> : <Square size={13} />}
            </button>
          )}
          <Film size={13} className={`shrink-0 ${ativa ? 'text-fuchsia-400' : 'text-zinc-500'}`} />
          <span className="truncate text-xs font-medium text-zinc-100" title={rotulo || n.nome}>{rotulo || n.nome}</span>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          {posFila >= 0 && <span className="text-[10px] text-sky-400">#{posFila + 1}</span>}
          <StatusIndicadorCurto st={st} n={n} />
          <span className="font-mono text-[10.5px] text-zinc-400">{p.videos.feito}/{p.videos.total}</span>
          {onAlternarConcluidaRapido && (
            <button
              type="button"
              title={
                n.concluidaManualmente
                  ? '↩️ Reabrir história para permitir voltar à fila de geração'
                  : '✅ Marcar história como Concluída (remove da fila e nunca mais puxa automaticamente)'
              }
              className={`rounded p-0.5 text-[11px] transition ${
                n.concluidaManualmente
                  ? 'text-emerald-400 hover:bg-studio-700 hover:text-amber-300'
                  : jaConcluida
                    ? 'text-emerald-400/70 hover:text-emerald-300'
                    : 'text-zinc-500 opacity-75 hover:bg-emerald-500/20 hover:text-emerald-300 group-hover:opacity-100'
              }`}
              onClick={(e) => {
                e.stopPropagation();
                onAlternarConcluidaRapido(n, !n.concluidaManualmente);
              }}
            >
              {n.concluidaManualmente ? <RotateCcw size={11} /> : <CheckCircle2 size={12} />}
            </button>
          )}
          {onExcluir && (
            <button
              type="button"
              title="Excluir do estúdio (arquivos de mídia são mantidos)"
              className="rounded p-0.5 text-zinc-600 opacity-0 transition hover:text-red-400 group-hover:opacity-100"
              onClick={(e) => { e.stopPropagation(); onExcluir(n); }}
            >
              <Trash2 size={11} />
            </button>
          )}
        </div>
      </div>
      <div className="mt-1.5"><ProgressBar feito={p.videos.feito} total={p.videos.total} /></div>
    </div>
  );
}

function resumoStatus(partes, fila) {
  let concluidas = 0, andamento = 0, revisar = 0, feito = 0, total = 0;
  for (const { novela } of partes) {
    const st = statusNovela(novela, fila).chave;
    if (st === 'concluida') concluidas++;
    else if (st === 'revisar' || st === 'invalido' || st === 'sem_creditos') revisar++;
    else if (st === 'rodando' || st === 'parcial' || st === 'na_fila') andamento++;
    const p = progressoNovela(novela);
    feito += p.videos.feito; total += p.videos.total;
  }
  return { concluidas, andamento, revisar, feito, total };
}

/** Lista lateral de novelas do Estúdio, separada em Parte Única x Séries + Rascunhos recolhidos no rodapé. */
export default function ListaNovelas({ novelas, fila, selecionada, onSelecionar, executar }) {
  const { ativas, rascunhos } = useMemo(() => {
    const a = [];
    const r = [];
    for (const n of novelas) {
      if (ehRascunhoVazio(n)) r.push(n);
      else a.push(n);
    }
    return { ativas: a, rascunhos: r };
  }, [novelas]);

  const { unicas, series } = useMemo(() => agruparNovelas(ativas), [ativas]);
  const [aba, setAbaEstado] = useState(() => localStorage.getItem('fns.listaAba') || 'unica');
  const setAba = (a) => { setAbaEstado(a); localStorage.setItem('fns.listaAba', a); };
  const [rascunhosAbertos, setRascunhosAbertos] = useState(false);
  const [abertos, setAbertos] = useState(() => {
    try { return new Set(JSON.parse(localStorage.getItem('fns.seriesAbertas') || '[]')); } catch { return new Set(); }
  });
  const alternar = (chave) => setAbertos((s) => {
    const novo = new Set(s);
    novo.has(chave) ? novo.delete(chave) : novo.add(chave);
    localStorage.setItem('fns.seriesAbertas', JSON.stringify([...novo]));
    return novo;
  });

  // seleciona a aba da novela ativa e mantém a pasta da série dela aberta
  useEffect(() => {
    if (!selecionada) return;
    if (rascunhos.some((n) => n.id === selecionada)) {
      setRascunhosAbertos(true);
      return;
    }
    const grupo = series.find((g) => g.partes.some((x) => x.novela.id === selecionada));
    if (grupo) {
      setAba('serie');
      setAbertos((s) => {
        if (s.has(grupo.chave)) return s;
        const novo = new Set(s); novo.add(grupo.chave);
        localStorage.setItem('fns.seriesAbertas', JSON.stringify([...novo]));
        return novo;
      });
    } else if (unicas.some((n) => n.id === selecionada)) {
      setAba('unica');
    }
  }, [selecionada, series.length, unicas.length, rascunhos.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const [marcadas, setMarcadas] = useState(() => new Set());

  // Limpa IDs que não existem mais
  useEffect(() => {
    setMarcadas((prev) => {
      if (!prev.size) return prev;
      const idsValidos = new Set(novelas.map((n) => n.id));
      const filtrado = [...prev].filter((id) => idsValidos.has(id));
      return filtrado.length === prev.size ? prev : new Set(filtrado);
    });
  }, [novelas]);

  const alternarMarca = (id) => {
    setMarcadas((prev) => {
      const novo = new Set(prev);
      novo.has(id) ? novo.delete(id) : novo.add(id);
      return novo;
    });
  };

  const pendentesOuComFalhaIds = useMemo(() => {
    return ativas
      .filter((n) => !n.concluidaManualmente && n.itens?.some((i) => i.status !== 'concluido'))
      .map((n) => n.id);
  }, [ativas]);

  const selecionarPendentesEFalhas = () => {
    setMarcadas(new Set(pendentesOuComFalhaIds));
  };

  const limparSelecao = () => setMarcadas(new Set());

  const novelasMarcadas = useMemo(() => novelas.filter((n) => marcadas.has(n.id)), [novelas, marcadas]);
  const algumaMarcadaConcluida = useMemo(() => novelasMarcadas.some((n) => n.concluidaManualmente), [novelasMarcadas]);
  const algumaMarcadaAberta = useMemo(() => novelasMarcadas.some((n) => !n.concluidaManualmente), [novelasMarcadas]);

  const marcarLote = async (concluida = true) => {
    const ids = [...marcadas];
    if (!ids.length) return;
    const r = await executar(
      () => api.marcarNovelasConcluidas(ids, concluida),
      concluida
        ? `✅ ${ids.length} história(s) marcada(s) como Concluída(s) e removida(s) da fila automática!`
        : `↩️ ${ids.length} história(s) reaberta(s) para a fila de geração!`
    );
    if (r) setMarcadas(new Set());
  };

  const alternarConcluidaRapido = async (n, concluida = true) => {
    await executar(
      () => api.marcarNovelasConcluidas([n.id], concluida),
      concluida
        ? `✅ "${n.nome}" marcada como Concluída (não voltará para a fila automática)!`
        : `↩️ "${n.nome}" reaberta para geração na fila!`
    );
  };

  const excluir = async (n) => {
    if (fila.novelaAtual === n.id && fila.rodando) return executar(async () => { throw new Error('Esta novela está rodando. Pause a fila antes de excluir.'); });
    if (!window.confirm(`Excluir "${n.nome}" do estúdio?\n\nOs arquivos de mídia em Meus_Projetos_Flow NÃO serão apagados.`)) return;
    await executar(() => api.removerNovela(n.id), 'Removida do estúdio');
  };

  const [pedidoProxima, setPedidoProxima] = useState(null); // { slug, parte, titulo }
  const gerarProxima = (g) => {
    const ultima = g.partes[g.partes.length - 1]?.novela;
    if (!ultima?.serieSlug) return;
    const prox = (Number(ultima.numeroParte) || g.partes.length) + 1;
    setPedidoProxima({ slug: ultima.serieSlug, parte: prox, titulo: g.titulo });
  };

  return (
    <>
      <div className="space-y-1.5 px-2.5 pb-1 pt-1">
        <AbasPartes aba={aba} setAba={setAba} qtdUnicas={unicas.length} qtdSeries={series.length} />

        {/* Atalhos de seleção em lote */}
        {ativas.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-1 rounded-md border border-white/[0.06] bg-studio-950/70 px-2 py-1 text-[10.5px] text-zinc-400">
            <button
              type="button"
              onClick={selecionarPendentesEFalhas}
              disabled={!pendentesOuComFalhaIds.length}
              className="font-medium text-sky-300 transition hover:text-sky-200 disabled:text-zinc-600"
              title="Seleciona todas as histórias que ainda têm itens pendentes ou com falha"
            >
              ☑ Selecionar pendentes/falhas ({pendentesOuComFalhaIds.length})
            </button>
            {marcadas.size > 0 ? (
              <button type="button" onClick={limparSelecao} className="text-zinc-400 hover:text-white">
                Limpar ({marcadas.size})
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setMarcadas(new Set(ativas.map((n) => n.id)))}
                className="text-zinc-500 hover:text-zinc-300"
              >
                Todas
              </button>
            )}
          </div>
        )}

        {/* Barra de ação rápida em lote quando 1+ histórias estão selecionadas */}
        {marcadas.size > 0 && (
          <div className="space-y-1 rounded-lg border border-emerald-500/40 bg-emerald-500/10 p-2 shadow-lg">
            <div className="flex items-center justify-between text-[10.5px] font-medium text-emerald-200">
              <span>{marcadas.size} história(s) selecionada(s)</span>
              <button type="button" onClick={limparSelecao} className="text-zinc-400 hover:text-white">✕</button>
            </div>
            <div className="flex flex-col gap-1">
              {algumaMarcadaAberta && (
                <button
                  type="button"
                  onClick={() => marcarLote(true)}
                  className="btn w-full justify-center bg-gradient-to-r from-emerald-600 to-teal-600 py-1.5 text-xs font-semibold text-white shadow-sm hover:from-emerald-500 hover:to-teal-500"
                >
                  ✅ Marcar Concluída(s) ({marcadas.size})
                </button>
              )}
              {algumaMarcadaConcluida && (
                <button
                  type="button"
                  onClick={() => marcarLote(false)}
                  className="btn-ghost w-full justify-center border border-amber-500/35 bg-amber-500/10 py-1 text-[11px] font-medium text-amber-200 hover:bg-amber-500/20"
                >
                  ↩️ Reabrir Selecionadas
                </button>
              )}
            </div>
          </div>
        )}
      </div>
      <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto px-2.5 pb-2.5">
        {ativas.length === 0 && rascunhos.length === 0 && (
          <div className="px-2 py-6 text-center text-xs text-zinc-600">Nenhuma novela ainda.<br />Clique em “+ Nova Novela”.</div>
        )}

        {aba === 'unica' && (
          <>
            {ativas.length > 0 && unicas.length === 0 && <div className="px-2 py-6 text-center text-xs text-zinc-600">Nenhuma história de parte única.<br />Veja a aba 📚 Séries.</div>}
            {unicas.map((n) => (
              <CardNovela
                key={n.id}
                n={n}
                fila={fila}
                ativa={n.id === selecionada}
                marcada={marcadas.has(n.id)}
                onAlternarMarca={alternarMarca}
                onAlternarConcluidaRapido={alternarConcluidaRapido}
                onSelecionar={onSelecionar}
                onExcluir={excluir}
              />
            ))}
          </>
        )}

        {aba === 'serie' && (
          <>
            {ativas.length > 0 && series.length === 0 && <div className="px-2 py-6 text-center text-xs text-zinc-600">Nenhuma série ainda.<br />Séries aparecem aqui agrupadas.</div>}
            {series.map((g) => {
              const aberto = abertos.has(g.chave);
              const r = resumoStatus(g.partes, fila);
              const contemAtiva = g.partes.some((x) => x.novela.id === selecionada);
              const ultima = g.partes[g.partes.length - 1]?.novela;
              const podeGerarProxima = !!ultima?.serieSlug && g.totalPartes > g.partes.length;
              return (
                <div key={g.chave} className={`rounded-lg border ${contemAtiva ? 'border-violet-500/40 bg-violet-500/5' : 'border-white/[0.07] bg-studio-900/90'}`}>
                  <button type="button" onClick={() => alternar(g.chave)} className="w-full rounded-lg p-2.5 text-left hover:bg-studio-850/60">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex min-w-0 items-center gap-1.5">
                        {aberto ? <ChevronDown size={13} className="shrink-0 text-zinc-400" /> : <ChevronRight size={13} className="shrink-0 text-zinc-500" />}
                        {aberto ? <FolderOpen size={14} className="shrink-0 text-amber-300" /> : <Folder size={14} className="shrink-0 text-amber-400/80" />}
                        <span className="truncate text-xs font-semibold text-zinc-100" title={g.titulo}>{g.titulo}</span>
                      </div>
                      <span className="shrink-0 font-mono text-[10.5px] text-zinc-400">
                        {r.feito}/{r.total}
                      </span>
                    </div>
                    <div className="mt-1.5 pl-6"><ProgressBar feito={r.feito} total={r.total} /></div>
                  </button>
                  {aberto && (
                    <div className="space-y-1 border-t border-white/[0.06] p-1.5 pl-3">
                      {g.partes.map(({ novela, parte }) => (
                        <CardNovela
                          key={novela.id}
                          n={novela}
                          fila={fila}
                          compacto
                          ativa={novela.id === selecionada}
                          marcada={marcadas.has(novela.id)}
                          onAlternarMarca={alternarMarca}
                          onAlternarConcluidaRapido={alternarConcluidaRapido}
                          onSelecionar={onSelecionar}
                          onExcluir={excluir}
                          rotulo={parte ? `Parte ${parte}` : novela.nome}
                        />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </>
        )}
      </div>

      {/* Secao colapsavel discreta no rodape para rascunhos vazios (0/0 videos) */}
      {rascunhos.length > 0 && (
        <div className="border-t border-white/[0.07] bg-studio-950/40">
          <button
            type="button"
            onClick={() => setRascunhosAbertos((v) => !v)}
            className="flex w-full items-center justify-between px-3 py-1.5 text-[11px] text-zinc-500 hover:text-zinc-300"
          >
            <span className="flex items-center gap-1.5">
              <FileEdit size={11} /> Rascunhos ({rascunhos.length})
            </span>
            {rascunhosAbertos ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
          </button>
          {rascunhosAbertos && (
            <div className="max-h-36 space-y-1 overflow-y-auto px-2.5 pb-2">
              {rascunhos.map((n) => (
                <div
                  key={n.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => onSelecionar(n.id)}
                  onKeyDown={(e) => { if (e.key === 'Enter') onSelecionar(n.id); }}
                  className={`group flex items-center justify-between gap-2 rounded-md border px-2 py-1 text-xs cursor-pointer ${
                    n.id === selecionada ? 'border-violet-500/40 bg-violet-500/10 text-white' : 'border-white/[0.04] bg-studio-900/60 text-zinc-400 hover:bg-studio-850 hover:text-zinc-200'
                  }`}
                >
                  <span className="truncate">{n.nome}</span>
                  <button
                    type="button"
                    title="Excluir rascunho vazio"
                    className="rounded p-0.5 text-zinc-600 opacity-0 transition hover:text-red-400 group-hover:opacity-100"
                    onClick={(e) => { e.stopPropagation(); excluir(n); }}
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <ModalTipoFinal
        aberto={!!pedidoProxima}
        titulo={pedidoProxima ? `➕ Gerar Parte ${pedidoProxima.parte} — ${pedidoProxima.titulo}` : ''}
        descricao="A Fábrica Claude escreve a próxima parte herdando a Bíblia e as referências já geradas."
        rotuloConfirmar={pedidoProxima ? `Gerar Parte ${pedidoProxima.parte}` : 'Gerar'}
        onFechar={() => setPedidoProxima(null)}
        onConfirmar={async ({ tipoFinal, observacao }) => {
          const alvo = pedidoProxima;
          const j = await executar(() => fab.gerarParte(alvo.slug, { parte: alvo.parte, importar: true, iniciarFila: false, tipoFinal, observacao }), `Gerando Parte ${alvo.parte} na Fábrica Claude (herdando referências)...`);
          if (j) setPedidoProxima(null);
        }}
      />
    </>
  );
}

export { infoSerieNovela };
