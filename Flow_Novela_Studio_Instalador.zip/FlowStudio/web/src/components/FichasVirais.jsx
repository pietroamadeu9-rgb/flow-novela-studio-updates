import React, { useMemo, useState } from 'react';
import { Target, Trash2, Plus, Trophy, Link2, Eye, Save, Loader2 } from 'lucide-react';
import { fab } from '../api.js';
import { Toggle } from './ui.jsx';

const ROTULOS_TIPO = {
  traicao_ciume: 'Traição e ciúme',
  humilhacao_trabalho: 'Humilhação no trabalho',
  heranca_terra: 'Herança e terra',
  dinheiro_divida: 'Dinheiro e dívida',
  familia_sogra: 'Família e sogra',
  vinganca: 'Vingança',
  segredo_passado: 'Segredo do passado',
  outro: 'Outro',
};
const rotuloTipo = (t) => ROTULOS_TIPO[t] || String(t || 'outro').replace(/_/g, ' ');
const fmtViews = (n) => {
  const v = Number(n) || 0;
  if (v >= 1e6) return `${(v / 1e6).toFixed(1).replace('.0', '')} mi`;
  if (v >= 1e3) return `${Math.round(v / 1e3)} mil`;
  return String(v);
};

function CampoNumero({ rotulo, valor, onChange, sufixo }) {
  return (
    <label className="text-[11px] text-zinc-400">
      {rotulo}
      <div className="mt-1 flex items-center gap-1">
        <input type="number" min="0" className="input w-full" value={valor ?? ''} onChange={(e) => onChange(e.target.value)} />
        {sufixo && <span className="text-zinc-500">{sufixo}</span>}
      </div>
    </label>
  );
}

function SeletorTipo({ valor, onChange, tipos }) {
  const lista = tipos?.length ? tipos : Object.keys(ROTULOS_TIPO);
  return (
    <select className="input mt-1" value={valor || ''} onChange={(e) => onChange(e.target.value)}>
      <option value="">(descobrir sozinho)</option>
      {lista.map((t) => <option key={t} value={t}>{rotuloTipo(t)}</option>)}
    </select>
  );
}

function CardFicha({ f, tipos, executar, aoMudar }) {
  const [aberto, setAberto] = useState(false);
  const [m, setM] = useState({ views: f.views || 0, retencao3s: f.retencao3s || 0, retencao30s: f.retencao30s || 0 });
  const mudou = Number(m.views) !== Number(f.views || 0) || Number(m.retencao3s) !== Number(f.retencao3s || 0) || Number(m.retencao30s) !== Number(f.retencao30s || 0);
  return (
    <div className={`rounded-lg border p-3 ${f.ativa ? 'border-white/[0.09] bg-studio-850' : 'border-studio-700 bg-studio-900/50 opacity-70'}`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-sm font-semibold text-white">
            {f.propria && <span title="Novela sua que performou bem"><Trophy size={14} className="text-amber-300" /></span>}
            <span className="truncate">{f.titulo}</span>
            <span className="rounded-md border border-violet-500/30 bg-violet-500/10 px-1.5 py-0.5 text-[10px] font-medium text-violet-200">{rotuloTipo(f.tipoConflito)}</span>
            {f.origem === 'exemplo' && <span className="rounded-md border border-studio-700 px-1.5 py-0.5 text-[10px] font-normal text-zinc-400">exemplo editável</span>}
          </div>
          <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-zinc-400">
            <span className="inline-flex items-center gap-1"><Eye size={12} /> {fmtViews(f.views)} views</span>
            <span>retenção 3s: <b className="text-zinc-200">{f.retencao3s || 0}%</b></span>
            <span>retenção 30s: <b className="text-zinc-200">{f.retencao30s || 0}%</b></span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Toggle checked={!!f.ativa} onChange={(v) => executar(() => fab.atualizarFicha(f.id, { ativa: v }), v ? 'Ficha ativada' : 'Ficha desativada').then(aoMudar)} label={f.ativa ? 'Ativa' : 'Inativa'} title="Só fichas ativas entram como referência na criação" />
          <button className="btn-ghost px-2 py-1 text-[11px]" onClick={() => setAberto((v) => !v)}>{aberto ? 'Fechar' : 'Detalhes'}</button>
          <button
            className="btn-danger px-2 py-1"
            title="Excluir ficha"
            onClick={() => { if (window.confirm(`Excluir a ficha "${f.titulo}"?`)) executar(() => fab.excluirFicha(f.id), 'Ficha excluída').then(aoMudar); }}
          ><Trash2 size={13} /></button>
        </div>
      </div>
      {f.gancho3s && <div className="mt-2 text-xs text-zinc-300"><span className="text-zinc-500">Gancho (3s):</span> {f.gancho3s}</div>}
      {aberto && (
        <div className="mt-3 space-y-3 border-t border-studio-700 pt-3 text-xs text-zinc-300">
          <div className="grid grid-cols-3 gap-3 md:max-w-lg">
            <CampoNumero rotulo="Views" valor={m.views} onChange={(v) => setM((x) => ({ ...x, views: v }))} />
            <CampoNumero rotulo="Retenção 3s" sufixo="%" valor={m.retencao3s} onChange={(v) => setM((x) => ({ ...x, retencao3s: v }))} />
            <CampoNumero rotulo="Retenção 30s" sufixo="%" valor={m.retencao30s} onChange={(v) => setM((x) => ({ ...x, retencao30s: v }))} />
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <button className="btn-primary px-3 py-1 text-xs" disabled={!mudou} onClick={() => executar(() => fab.atualizarFicha(f.id, { views: Number(m.views) || 0, retencao3s: Number(m.retencao3s) || 0, retencao30s: Number(m.retencao30s) || 0 }), 'Métricas salvas').then(aoMudar)}><Save size={12} /> Salvar métricas</button>
            <Toggle checked={!!f.propria} onChange={(v) => executar(() => fab.atualizarFicha(f.id, { propria: v }), v ? 'Marcada como novela sua' : 'Desmarcada').then(aoMudar)} label="É uma novela minha campeã" title="Fichas próprias têm prioridade na hora de criar" />
          </div>
          {f.conflitoConcreto && <div><span className="text-zinc-500">Conflito:</span> {f.conflitoConcreto}</div>}
          {f.ironiaDramatica && <div><span className="text-zinc-500">Ironia dramática:</span> {f.ironiaDramatica}</div>}
          {Array.isArray(f.estrutura) && f.estrutura.length > 0 && (
            <div><div className="text-zinc-500">Estrutura (causa → efeito)</div><ol className="ml-4 list-decimal space-y-0.5">{f.estrutura.map((e, i) => <li key={i}>{e}</li>)}</ol></div>
          )}
          {Array.isArray(f.melhoresFalas) && f.melhoresFalas.length > 0 && (
            <div><div className="text-zinc-500">Melhores falas</div><ul className="ml-4 list-disc space-y-0.5">{f.melhoresFalas.map((e, i) => <li key={i}>“{e}”</li>)}</ul></div>
          )}
          {f.virada && <div><span className="text-zinc-500">Virada:</span> {f.virada}</div>}
          {f.finalFisgada && <div><span className="text-zinc-500">Final-fisgada:</span> {f.finalFisgada}</div>}
          {(f.ritmo || f.tom) && <div className="text-zinc-400">{f.ritmo ? `Ritmo: ${f.ritmo}` : ''}{f.ritmo && f.tom ? ' · ' : ''}{f.tom ? `Tom: ${f.tom}` : ''}</div>}
        </div>
      )}
    </div>
  );
}

export default function FichasVirais({ executar, toast, Caixa, JobView }) {
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState(null);
  const [prontos, setProntos] = useState([]);
  const [job, setJob] = useState(null);
  const [modo, setModo] = useState('extrair'); // extrair | promover | manual
  const [link, setLink] = useState('');
  const [transcricao, setTranscricao] = useState('');
  const [tipo, setTipo] = useState('');
  const [met, setMet] = useState({ views: '', retencao3s: '', retencao30s: '' });
  const [alvo, setAlvo] = useState('');
  const [manual, setManual] = useState({ titulo: '', gancho3s: '', conflitoConcreto: '' });
  const [ocupado, setOcupado] = useState(false);

  const recarregar = React.useCallback(async () => {
    try { setDados(await fab.fichas()); setErro(null); } catch (e) { setErro(e.message); }
  }, []);
  React.useEffect(() => { recarregar(); fab.prontos().then((p) => setProntos(Array.isArray(p) ? p.filter((x) => x.temRoteiro) : [])).catch(() => {}); }, [recarregar]);

  const metricas = () => ({ views: Number(met.views) || 0, retencao3s: Number(met.retencao3s) || 0, retencao30s: Number(met.retencao30s) || 0 });
  const tipos = dados?.tipos || [];
  const fichas = dados?.fichas || [];
  const ativas = useMemo(() => fichas.filter((f) => f.ativa).length, [fichas]);

  const extrair = async () => {
    if (!link.trim() && transcricao.trim().length < 40) return toast('Cole um link viral ou a transcrição do vídeo.', 'erro');
    setOcupado(true);
    const j = await executar(() => fab.extrairFicha({ link: link.trim(), transcricao: transcricao.trim(), tipoConflito: tipo || null, ...metricas() }), 'Extraindo a ficha do vídeo...');
    setOcupado(false);
    if (j) setJob(j.id);
  };
  const promover = async () => {
    const p = prontos.find((x) => `${x.slug}|${x.parte}` === alvo);
    if (!p) return toast('Escolha a novela campeã.', 'erro');
    setOcupado(true);
    const r = await executar(() => fab.promoverFicha({ slug: p.slug, parte: p.parte, tipoConflito: tipo || null, ...metricas() }), 'Ficha criada a partir da sua novela (0 tokens)');
    setOcupado(false);
    if (r) { setAlvo(''); recarregar(); }
  };
  const salvarManual = async () => {
    if (!manual.titulo.trim()) return toast('Dê um título para a ficha.', 'erro');
    const r = await executar(() => fab.criarFicha({ ...manual, tipoConflito: tipo || undefined, ...metricas() }), 'Ficha cadastrada');
    if (r) { setManual({ titulo: '', gancho3s: '', conflitoConcreto: '' }); recarregar(); }
  };

  return (
    <div className="space-y-5">
      <Caixa titulo="Fichas Virais — o que já funcionou vira referência" icon={Target}
        direita={<span className="text-[11px] text-zinc-500">{ativas} ativa(s) de {fichas.length}</span>}>
        <p className="mb-3 text-xs text-zinc-400">
          Cada ficha guarda só a estrutura que prendeu a audiência (não o vídeo). Ao criar uma história, a Fábrica escolhe 2–3 fichas ativas do mesmo tipo de conflito e usa como referência de ritmo e virada, sem copiar nomes, objetos ou falas.
        </p>
        <div className="mb-3 flex flex-wrap gap-2">
          {[['extrair', '🔗 De um vídeo viral'], ['promover', '🏆 Da minha novela campeã'], ['manual', '✍️ Cadastro manual']].map(([v, t]) => (
            <button key={v} onClick={() => setModo(v)} className={`rounded-lg border px-3 py-1.5 text-xs transition ${modo === v ? 'border-fuchsia-500/60 bg-fuchsia-500/10 text-fuchsia-100' : 'border-white/[0.07] text-zinc-400 hover:text-white'}`}>{t}</button>
          ))}
        </div>

        {modo === 'extrair' && (
          <div className="space-y-2">
            <div className="relative">
              <Link2 size={14} className="absolute left-2.5 top-3 text-zinc-500" />
              <input className="input pl-8" placeholder="Link viral (Facebook, Instagram, TikTok, YouTube) — baixado e transcrito no seu PC" value={link} onChange={(e) => setLink(e.target.value)} />
            </div>
            <textarea className="input h-20 resize-y" placeholder="…ou cole aqui a transcrição do vídeo (se não colar link)" value={transcricao} onChange={(e) => setTranscricao(e.target.value)} />
            <div className="text-[11px] text-zinc-500">Gasta 1 chamada curta do Claude (Sonnet) para resumir a estrutura em uma ficha enxuta.</div>
          </div>
        )}
        {modo === 'promover' && (
          <div className="space-y-2">
            <select className="input" value={alvo} onChange={(e) => setAlvo(e.target.value)}>
              <option value="">Escolha a novela que bombou…</option>
              {prontos.map((p) => <option key={`${p.slug}|${p.parte}`} value={`${p.slug}|${p.parte}`}>{(p.titulo || p.slug)} — Parte {p.parte}</option>)}
            </select>
            <div className="text-[11px] text-zinc-500">Não gasta tokens: a ficha é montada lendo o seu roteiro. Informe as métricas reais para ela ganhar prioridade.</div>
          </div>
        )}
        {modo === 'manual' && (
          <div className="space-y-2">
            <input className="input" placeholder="Título da ficha (ex.: A patroa que acusou a diarista)" value={manual.titulo} onChange={(e) => setManual((x) => ({ ...x, titulo: e.target.value }))} />
            <input className="input" placeholder="Gancho dos primeiros 3 segundos" value={manual.gancho3s} onChange={(e) => setManual((x) => ({ ...x, gancho3s: e.target.value }))} />
            <input className="input" placeholder="Conflito concreto em uma frase" value={manual.conflitoConcreto} onChange={(e) => setManual((x) => ({ ...x, conflitoConcreto: e.target.value }))} />
          </div>
        )}

        <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
          <label className="text-[11px] text-zinc-400">Tipo de conflito<SeletorTipo valor={tipo} onChange={setTipo} tipos={tipos} /></label>
          <CampoNumero rotulo="Views" valor={met.views} onChange={(v) => setMet((x) => ({ ...x, views: v }))} />
          <CampoNumero rotulo="Retenção 3s" sufixo="%" valor={met.retencao3s} onChange={(v) => setMet((x) => ({ ...x, retencao3s: v }))} />
          <CampoNumero rotulo="Retenção 30s" sufixo="%" valor={met.retencao30s} onChange={(v) => setMet((x) => ({ ...x, retencao30s: v }))} />
        </div>
        <div className="mt-3">
          {modo === 'extrair' && <button className="btn-primary" disabled={ocupado} onClick={extrair}>{ocupado ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />} Extrair ficha</button>}
          {modo === 'promover' && <button className="btn-primary" disabled={ocupado} onClick={promover}><Trophy size={14} /> Promover a ficha</button>}
          {modo === 'manual' && <button className="btn-primary" onClick={salvarManual}><Save size={14} /> Salvar ficha</button>}
        </div>
        {job && <JobView jobId={job} aoTerminar={(j) => { recarregar(); if (j?.estado === 'ok') setJob(null); }} aoNaoEncontrar={() => setJob(null)} rotuloSaida="O que o Claude respondeu" />}
      </Caixa>

      <Caixa titulo="Banco de fichas" icon={Trophy}>
        {erro && <div className="text-xs text-red-300">{erro}</div>}
        {!dados && !erro && <div className="text-xs text-zinc-500">Carregando...</div>}
        {dados && fichas.length === 0 && <div className="text-xs text-zinc-500">Nenhuma ficha ainda.</div>}
        <div className="space-y-2">
          {fichas.map((f) => <CardFicha key={`${f.id}-${f.atualizadaEm || ''}-${f.ativa}-${f.propria}`} f={f} tipos={tipos} executar={executar} aoMudar={recarregar} />)}
        </div>
      </Caixa>
    </div>
  );
}
