import React, { useMemo, useState } from 'react';
import { RotateCw, PencilLine, Save, CheckSquare, Square, GitBranch } from 'lucide-react';
import { api, ROTULOS_TIPO } from '../api.js';
import { Modal } from './ui.jsx';

/** Todos os itens que dependem (direta ou indiretamente) do item via [refs]. */
export function dependentes(novela, id) {
  const resultado = [];
  const fila = [id];
  const vistos = new Set([id]);
  while (fila.length) {
    const atual = fila.shift();
    for (const it of novela.itens) {
      if (!vistos.has(it.id) && it.refs?.includes(atual)) { vistos.add(it.id); resultado.push(it); fila.push(it.id); }
    }
  }
  return novela.itens.filter((i) => resultado.includes(i)); // ordem do roteiro
}

/** Acoes por item: "↻ Regenerar" (com modal de cascata seletiva) e "✎ Editar Prompt". */
export function useAcoesItem(novela, executar) {
  const [regen, setRegen] = useState(null); // { item, deps, marcados:Set }
  const [edicao, setEdicao] = useState(null); // { item, texto }

  const pedirRegenerar = (item, opcoes = {}) => {
    const atualizarCapcut = Boolean(opcoes?.atualizarCapcut);
    const deps = dependentes(novela, item.id).filter((d) => d.status === 'concluido' || d.arquivo);
    if (!deps.length) {
      return executar(
        () => api.regerar(novela.id, item.id, [], { atualizarCapcut }),
        atualizarCapcut
          ? `🔄✂️ {${item.id}} enviado para regenerar e substituir no CapCut!`
          : `🔄 {${item.id}} enviado para regenerar (só na pasta do Estúdio)`
      );
    }
    setRegen({ item, deps, marcados: new Set(), atualizarCapcut });
  };
  const pedirEditar = (item) => setEdicao({ item, texto: item.prompt });
  const pedirSuavizarComImagem = (item) =>
    executar(() => api.suavizarItemComImagem(novela.id, item.id, true), `🛡️ {${item.id}} suavizado (mantida só imagem_XX) e enviado para a fila!`);
  const pedirDescritivoSemImagem = (item) =>
    executar(() => api.gerarItemPorDescricaoSemImagem(novela.id, item.id, true), `📝 {${item.id}} convertido para Prompt 100% Descritivo (sem imagem) e enviado para a fila!`);
  const pedirRestaurarOriginal = (item) =>
    executar(() => api.restaurarPromptOriginal(novela.id, item.id), `↺ {${item.id}} restaurado para o prompt e anexos originais.`);
  const pedirMarcarFeitoManual = (item, feito = true) =>
    executar(
      () => api.marcarItemFeitoManual(novela.id, item.id, feito),
      feito ? `✅ {${item.id}} marcado como Feito manual!` : `↩️ {${item.id}} reaberto para geração.`
    );

  const confirmarRegen = async (ids) => {
    const atualizarCapcut = Boolean(regen?.atualizarCapcut);
    const r = await executar(() => api.regerar(novela.id, regen.item.id, ids, { atualizarCapcut }),
      ids.length ? `↻ {${regen.item.id}} + ${ids.length} dependente(s) na fila` : `↻ Apenas {${regen.item.id}} na fila`);
    if (r) setRegen(null);
  };

  const modais = (
    <>
      <Modal aberto={!!regen} onFechar={() => setRegen(null)} titulo={regen ? `↻ Regenerar {${regen.item.id}}` : ''} largura="max-w-lg">
        {regen && (
          <div className="space-y-4">
            <p className="text-sm text-zinc-400">
              Estes itens já gerados usam <span className="chip">{regen.item.id}</span> (direta ou indiretamente).
              Marque quais você quer <b className="text-white">regenerar em cascata</b> com a versão nova:
            </p>
            <div className="max-h-72 space-y-1 overflow-y-auto rounded-lg border border-studio-700 bg-studio-950 p-2">
              {regen.deps.map((d) => {
                const on = regen.marcados.has(d.id);
                return (
                  <button key={d.id} className={`flex w-full items-center gap-3 rounded-md px-2 py-1.5 text-left text-sm hover:bg-studio-800 ${on ? 'text-white' : 'text-zinc-400'}`}
                    onClick={() => { const s = new Set(regen.marcados); on ? s.delete(d.id) : s.add(d.id); setRegen({ ...regen, marcados: s }); }}>
                    {on ? <CheckSquare size={16} className="text-fuchsia-400" /> : <Square size={16} />}
                    <span className="font-mono">{`{${d.id}}`}</span>
                    <span className="text-[11px] text-zinc-600">{ROTULOS_TIPO[d.tipo]}</span>
                    <span className="ml-auto flex items-center gap-1 text-[10px] text-zinc-600"><GitBranch size={11} />{d.refs.join(', ')}</span>
                  </button>
                );
              })}
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex gap-2">
                <button className="btn-ghost text-xs" onClick={() => setRegen({ ...regen, marcados: new Set(regen.deps.map((d) => d.id)) })}>Selecionar todos</button>
                <button className="btn-ghost text-xs" onClick={() => setRegen({ ...regen, marcados: new Set() })}>Limpar</button>
              </div>
              <div className="flex gap-2">
                <button className="btn-ghost" onClick={() => confirmarRegen([])}>Apenas esta {regen.item.tipo === 'video' ? 'cena' : 'imagem'}</button>
                <button className="btn-primary" disabled={!regen.marcados.size} onClick={() => confirmarRegen([...regen.marcados])}>
                  <RotateCw size={14} /> Regenerar + {regen.marcados.size}
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      <Modal aberto={!!edicao} onFechar={() => setEdicao(null)} titulo={edicao ? `✎ Editar prompt de {${edicao.item.id}}` : ''} largura="max-w-2xl">
        {edicao && (
          <div className="space-y-3">
            {(edicao.item.promptOriginalBackup || edicao.item.originalPrompt) && (edicao.item.promptOriginalBackup || edicao.item.originalPrompt) !== edicao.texto && (
              <div className="flex items-center justify-between gap-2 rounded-lg border border-violet-500/30 bg-violet-500/10 px-3 py-2 text-xs text-violet-200">
                <span className="truncate" title={edicao.item.promptOriginalBackup || edicao.item.originalPrompt}>✨ Este prompt foi ajustado/convertido. Você pode restaurar o original.</span>
                <button className="btn-ghost shrink-0 py-1 text-[11px]" onClick={() => setEdicao({ ...edicao, texto: edicao.item.promptOriginalBackup || edicao.item.originalPrompt })}>
                  Restaurar original
                </button>
              </div>
            )}
            <textarea className="input min-h-[220px] resize-y font-mono text-[12.5px] leading-relaxed" autoFocus value={edicao.texto} onChange={(e) => setEdicao({ ...edicao, texto: e.target.value })} />
            <div className="flex justify-end gap-2">
              <button className="btn-ghost" onClick={() => setEdicao(null)}>Cancelar</button>
              <button className="btn-ghost" onClick={async () => { const r = await executar(() => api.atualizarItem(novela.id, edicao.item.id, { prompt: edicao.texto }), 'Prompt salvo'); if (r) setEdicao(null); }}>
                <Save size={14} /> Salvar
              </button>
              <button className="btn-primary" onClick={async () => {
                const r = await executar(() => api.atualizarItem(novela.id, edicao.item.id, { prompt: edicao.texto }), 'Prompt salvo');
                if (r) { const it = { ...edicao.item, prompt: edicao.texto }; setEdicao(null); pedirRegenerar(it); }
              }}>
                <RotateCw size={14} /> Salvar e Regenerar
              </button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );

  return { pedirRegenerar, pedirEditar, pedirSuavizarComImagem, pedirDescritivoSemImagem, pedirRestaurarOriginal, pedirMarcarFeitoManual, modais };
}

/** Par de botoes padrao para cards e listas + botoes rapidos de destrave quando falhar por politica/rosto no Flow. */
export function BotoesItem({ item, novela, acoes, compacto = false }) {
  const bloqueado = item.status === 'gerando' || !novela.validacao?.ok;
  const ehVideo = item.tipo === 'video';
  const ehFalhaVideo = ehVideo && (item.status === 'falha_revisar' || item.status === 'erro');
  const temBackup = Boolean(item.promptOriginalBackup || item.originalPrompt || item.anexosOriginaisBackup || item.modoDescritivoSemImagem);
  const naoConcluido = item.status !== 'concluido';
  if (compacto) {
    return (
      <div className="flex flex-col items-end gap-1">
        <div className="flex items-center gap-1">
          {naoConcluido ? (
            <button
              type="button"
              disabled={item.status === 'gerando'}
              onClick={() => acoes.pedirMarcarFeitoManual(item, true)}
              title="Marcar este item como resolvido manualmente para a fila continuar só o restante da história"
              className="rounded border border-emerald-500/40 bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-200 transition hover:bg-emerald-500/25 disabled:opacity-30"
            >
              ✓ Feito manual
            </button>
          ) : item.feitoManual ? (
            <button
              type="button"
              onClick={() => acoes.pedirMarcarFeitoManual(item, false)}
              title="Marcado como concluído manualmente — clique para reabrir como pendente"
              className="rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 text-[10px] text-emerald-300 transition hover:bg-studio-800"
            >
              ✓ Manual
            </button>
          ) : null}
          <button className="rounded p-1 text-zinc-500 hover:bg-studio-800 hover:text-sky-300" title="✎ Editar Prompt" onClick={() => acoes.pedirEditar(item)}><PencilLine size={14} /></button>
          {ehVideo ? (
            <>
              <button
                type="button"
                className="rounded border border-white/[0.08] bg-studio-850 px-1.5 py-0.5 text-[10.5px] font-medium text-zinc-200 transition hover:border-fuchsia-500/40 hover:bg-studio-800 hover:text-white disabled:opacity-30"
                title="Regenerar Normal: regenera apenas o vídeo no Flow e substitui o .mp4 na pasta do projeto, sem tocar no CapCut"
                disabled={bloqueado}
                onClick={() => acoes.pedirRegenerar(item, { atualizarCapcut: false })}
              >
                🔄 Regenerar
              </button>
              <button
                type="button"
                className="rounded border border-cyan-500/40 bg-cyan-500/15 px-1.5 py-0.5 text-[10.5px] font-semibold text-cyan-200 transition hover:bg-cyan-500/25 disabled:opacity-30"
                title="Regenerar e substituir no CapCut"
                disabled={bloqueado}
                onClick={() => acoes.pedirRegenerar(item, { atualizarCapcut: true })}
              >
                🔄✂️
              </button>
            </>
          ) : (
            <button
              className="rounded p-1 text-zinc-500 hover:bg-studio-800 hover:text-fuchsia-300 disabled:opacity-30"
              title="↻ Regenerar"
              disabled={bloqueado}
              onClick={() => acoes.pedirRegenerar(item, { atualizarCapcut: false })}
            >
              <RotateCw size={14} />
            </button>
          )}
        </div>
        {(ehFalhaVideo || temBackup) && (
          <div className="flex flex-wrap justify-end gap-1">
            {ehVideo && (
              <>
                <button
                  type="button"
                  disabled={bloqueado}
                  onClick={() => acoes.pedirSuavizarComImagem(item)}
                  title="Remove ref_* extras mantendo só imagem_XX, suaviza gatilhos e já põe na fila"
                  className="rounded border border-sky-500/40 bg-sky-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-sky-200 hover:bg-sky-500/25 disabled:opacity-30"
                >
                  🛡️ Suavizar (com imagem)
                </button>
                <button
                  type="button"
                  disabled={bloqueado}
                  onClick={() => acoes.pedirDescritivoSemImagem(item)}
                  title="Converte para Prompt 100% Descritivo (puxa roupas/rostos/cenário de ref_* + imagem_XX, zera anexos) e já dispara na fila"
                  className="rounded border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-amber-200 hover:bg-amber-500/25 disabled:opacity-30"
                >
                  📝 Gerar Só por Descrição (Sem Imagem)
                </button>
              </>
            )}
            {temBackup && (
              <button
                type="button"
                disabled={bloqueado}
                onClick={() => acoes.pedirRestaurarOriginal(item)}
                title="Restaura o prompt e os anexos originais intactos"
                className="rounded border border-studio-600 bg-studio-800 px-1.5 py-0.5 text-[10px] text-zinc-300 hover:bg-studio-700 disabled:opacity-30"
              >
                ↺ Restaurar Original
              </button>
            )}
          </div>
        )}
      </div>
    );
  }
  return (
    <div className="space-y-1.5">
      {ehVideo ? (
        <>
          <div className="grid grid-cols-[1fr_auto] gap-1.5">
            <button
              type="button"
              className="btn-ghost justify-center py-1.5 text-xs"
              disabled={bloqueado}
              title="Regenera apenas o vídeo desta cena no Flow e substitui o .mp4 na pasta do projeto, sem tocar no projeto do CapCut"
              onClick={() => acoes.pedirRegenerar(item, { atualizarCapcut: false })}
            >
              🔄 Regenerar
            </button>
            <button
              type="button"
              className="inline-flex items-center justify-center gap-1 rounded-lg border border-cyan-500/40 bg-cyan-500/15 px-2.5 py-1.5 text-xs font-semibold text-cyan-200 transition hover:bg-cyan-500/25 disabled:opacity-30"
              disabled={bloqueado}
              title="Regenerar e substituir no CapCut"
              onClick={() => acoes.pedirRegenerar(item, { atualizarCapcut: true })}
            >
              🔄✂️
            </button>
          </div>
          <button type="button" className="btn-ghost w-full justify-center py-1 text-[11px]" onClick={() => acoes.pedirEditar(item)}>
            ✎ Editar Prompt
          </button>
        </>
      ) : (
        <div className="grid grid-cols-2 gap-1.5">
          <button className="btn-ghost py-1.5 text-xs" onClick={() => acoes.pedirEditar(item)}>✎ Editar Prompt</button>
          <button className="btn-ghost py-1.5 text-xs" disabled={bloqueado} onClick={() => acoes.pedirRegenerar(item, { atualizarCapcut: false })}>↻ Regenerar</button>
        </div>
      )}
      {naoConcluido ? (
        <button
          type="button"
          disabled={item.status === 'gerando'}
          onClick={() => acoes.pedirMarcarFeitoManual(item, true)}
          title="Marcar este vídeo/imagem como resolvido manualmente para continuar só o restante da história"
          className="w-full rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-2 py-1 text-[11px] font-semibold text-emerald-200 transition hover:bg-emerald-500/25 disabled:opacity-30"
        >
          ✓ Feito manual
        </button>
      ) : item.feitoManual ? (
        <button
          type="button"
          onClick={() => acoes.pedirMarcarFeitoManual(item, false)}
          title="Marcado como concluído manualmente — clique para reabrir como pendente"
          className="w-full rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-2 py-1 text-[10.5px] text-emerald-300 transition hover:bg-studio-800"
        >
          ✓ Feito manual (↩️ Reabrir)
        </button>
      ) : null}
      {(ehFalhaVideo || temBackup) && item.tipo === 'video' && (
        <div className="space-y-1 pt-0.5">
          <button
            type="button"
            disabled={bloqueado}
            onClick={() => acoes.pedirSuavizarComImagem(item)}
            title="Remove ref_* extras mantendo só imagem_XX, suaviza gatilhos e já põe na fila"
            className="w-full rounded-lg border border-sky-500/40 bg-sky-500/15 px-2 py-1 text-[11px] font-semibold text-sky-200 transition hover:bg-sky-500/25 disabled:opacity-30"
          >
            🛡️ Suavizar (com imagem)
          </button>
          <button
            type="button"
            disabled={bloqueado}
            onClick={() => acoes.pedirDescritivoSemImagem(item)}
            title="Converte para Prompt 100% Descritivo (puxa roupas/rostos/cenário de ref_* + imagem_XX, zera anexos) e já dispara na fila"
            className="w-full rounded-lg border border-amber-500/40 bg-amber-500/15 px-2 py-1 text-[11px] font-semibold text-amber-200 transition hover:bg-amber-500/25 disabled:opacity-30"
          >
            📝 Gerar Só por Descrição (Sem Imagem)
          </button>
          {temBackup && (
            <button
              type="button"
              disabled={bloqueado}
              onClick={() => acoes.pedirRestaurarOriginal(item)}
              title="Restaura o prompt e os anexos originais intactos"
              className="w-full rounded-lg border border-studio-600 bg-studio-800 px-2 py-1 text-[10.5px] text-zinc-300 transition hover:bg-studio-700 disabled:opacity-30"
            >
              ↺ Restaurar Original
            </button>
          )}
        </div>
      )}
    </div>
  );
}
