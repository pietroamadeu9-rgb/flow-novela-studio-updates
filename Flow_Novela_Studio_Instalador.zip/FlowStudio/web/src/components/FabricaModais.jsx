import React, { useEffect, useState } from 'react';
import { Loader2, RotateCw, MessageSquareText, Pencil, Check, X } from 'lucide-react';
import { fab } from '../api.js';
import { Modal } from './ui.jsx';

/** Conta palavras exatamente como validar_novela.mjs. */
export function contarPalavrasFalaFront(t) {
  return (String(t || '').match(/[\p{L}\p{N}]+(?:['’-][\p{L}\p{N}]+)*/gu) || []).length;
}

/** Avalia se a contagem de palavras da cena esta na faixa ideal (10s: 14-25, referência 18-21, max 20 c/ 3 falas | 15s: 23-30, max 27 c/ 3 falas). Cena SEM fala = cena muda (permitida, até 2 por história). */
export function avaliarPalavrasCena(totalPalavras, duracaoSeg = 15, qtdFalas = 2) {
  const eh10 = Number(duracaoSeg) === 10;
  if (!qtdFalas || totalPalavras < 1) return { ok: true, muda: true, min: 0, max: 0, rotulo: 'cena muda · só ação' };
  const min = eh10 ? 14 : 23;
  const max = qtdFalas >= 3 ? (eh10 ? 20 : 27) : (eh10 ? 25 : 30);
  const ok = totalPalavras >= min && totalPalavras <= max;
  const rotulo = ok
    ? `${totalPalavras} palavras · ideal`
    : totalPalavras < min
    ? `${totalPalavras} palavras · curto (${min}–${max})`
    : `${totalPalavras} palavras · longo (${min}–${max})`;
  return { ok, min, max, rotulo };
}

/** Escolha clara e obrigatoria do rumo do final. */
export function SeletorTipoFinal({ valor, onChange, compacto = false }) {
  const opcoes = [
    ['aberto', '🔥 Final Aberto Chocante', 'Gancho forte para continuação', 'Vai ter próxima parte — Armadilha na penúltima cena + Choque concreto na última cena'],
    ['fechado', '✅ A História se Encerra Aqui', 'Desfecho completo na última cena', 'Final fechado — resolve todos os conflitos com justiça na última cena'],
  ];
  return (
    <div className={`grid gap-2 ${compacto ? 'grid-cols-1' : 'sm:grid-cols-2'}`}>
      {opcoes.map(([v, t, d, tip]) => (
        <button
          key={v}
          type="button"
          title={tip}
          onClick={() => onChange(v)}
          className={`rounded-lg border p-2.5 text-left transition ${
            valor === v
              ? v === 'aberto' ? 'border-orange-500/60 bg-orange-500/10' : 'border-emerald-500/60 bg-emerald-500/10'
              : 'border-white/[0.07] bg-studio-850 hover:border-white/[0.15]'
          }`}
        >
          <div className="text-xs font-semibold text-white">{t}</div>
          <div className="text-[11px] text-zinc-500">{d}</div>
        </button>
      ))}
    </div>
  );
}

export function BadgeTipoFinal({ tipo }) {
  if (!tipo) return null;
  return tipo === 'aberto'
    ? <span className="rounded bg-orange-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-orange-300">🔥 final aberto</span>
    : <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-300">✅ final fechado</span>;
}

/**
 * Lista de dialogos cena a cena com edicao inline de falas (salva direto no roteiro_humano.md sem gastar cota do Claude).
 */
export function ListaDialogosEditavel({ slug, parte = 1, dados, onAtualizar, alturaMax = 'max-h-96' }) {
  const [editando, setEditando] = useState(null); // { cena, falaIndex, texto }
  const [salvando, setSalvando] = useState(false);
  const [erroLocal, setErroLocal] = useState(null);

  if (!dados?.cenas?.length) return null;
  const durPadrao = Number(dados.tamanhoCenaSegundos) === 10 ? 10 : 15;

  const salvarEdicao = async () => {
    if (!editando || !slug || salvando) return;
    const limpo = String(editando.texto || '').trim();
    if (!limpo) return;
    setSalvando(true);
    setErroLocal(null);
    try {
      const atualizado = await fab.editarFala({
        slug,
        parte: parte || 1,
        cena: editando.cena,
        falaIndex: editando.falaIndex,
        texto: limpo,
      });
      if (atualizado) onAtualizar?.(atualizado);
      setEditando(null);
    } catch (e) {
      setErroLocal(e.message);
    } finally {
      setSalvando(false);
    }
  };

  return (
    <div className="space-y-2">
      {erroLocal && (
        <div className="rounded border border-red-500/30 bg-red-500/10 px-2.5 py-1.5 text-xs text-red-200">{erroLocal}</div>
      )}
      <div className={`${alturaMax} space-y-2 overflow-y-auto pr-1`}>
        {dados.cenas.map((c) => {
          const durCena = Number(c.duracaoSegundos) || durPadrao;
          const totalCena = c.falas.reduce((acc, f, idx) => {
            if (editando && editando.cena === c.cena && editando.falaIndex === idx) {
              return acc + contarPalavrasFalaFront(editando.texto);
            }
            return acc + (Number(f.palavras) || contarPalavrasFalaFront(f.texto));
          }, 0);
          const av = avaliarPalavrasCena(totalCena, durCena, c.falas.length);

          return (
            <div key={c.cena} className="rounded-lg border border-white/[0.07] bg-studio-900/75 p-2.5">
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-fuchsia-300">
                  Cena {String(c.cena).padStart(2, '0')}
                  {c.etapa ? <span className="ml-1 font-normal normal-case text-zinc-400">· {c.etapa}</span> : null}
                </div>
                <span
                  className={`rounded px-1.5 py-0.5 font-mono text-[10px] font-medium ${
                    av.ok ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                  }`}
                  title={`Faixa ideal para cena de ${durCena}s com ${c.falas.length} fala(s): ${av.min} a ${av.max} palavras`}
                >
                  {av.rotulo}
                </span>
              </div>
              {c.falas.length === 0 && <div className="text-xs text-zinc-500">(cena muda — sem falas; o prompt de vídeo leva a instrução de lábios fechados)</div>}
              <div className="space-y-1">
                {c.falas.map((f, i) => {
                  const estaEditando = editando && editando.cena === c.cena && editando.falaIndex === i;
                  const palFala = estaEditando ? contarPalavrasFalaFront(editando.texto) : (Number(f.palavras) || contarPalavrasFalaFront(f.texto));
                  const maxFala = durCena === 10 ? 14 : 16;

                  if (estaEditando) {
                    return (
                      <div key={i} className="rounded-md border border-violet-500/40 bg-studio-950 p-2">
                        <div className="mb-1 flex items-center justify-between text-[11px]">
                          <span className="font-bold text-white">{f.quem} <span className="font-normal text-zinc-500">[{f.emocao}]</span></span>
                          <span className={`font-mono text-[10px] ${palFala <= maxFala ? 'text-zinc-400' : 'text-amber-300'}`}>
                            fala: {palFala}/{maxFala} pal.
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <input
                            autoFocus
                            className="input py-1 text-xs"
                            value={editando.texto}
                            onChange={(e) => setEditando({ ...editando, texto: e.target.value })}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') salvarEdicao();
                              if (e.key === 'Escape') setEditando(null);
                            }}
                          />
                          <button type="button" className="btn-primary px-2 py-1 text-xs" disabled={salvando} onClick={salvarEdicao} title="Salvar no roteiro_humano.md">
                            {salvando ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
                          </button>
                          <button type="button" className="btn-ghost px-2 py-1 text-xs" onClick={() => setEditando(null)} title="Cancelar">
                            <X size={12} />
                          </button>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={i}
                      role="button"
                      tabIndex={0}
                      title={slug ? 'Clique para editar esta fala diretamente no roteiro (0 tokens)' : undefined}
                      onClick={() => slug && setEditando({ cena: c.cena, falaIndex: i, texto: f.texto })}
                      onKeyDown={(e) => { if (e.key === 'Enter' && slug) setEditando({ cena: c.cena, falaIndex: i, texto: f.texto }); }}
                      className={`group flex items-start justify-between gap-2 rounded px-1.5 py-0.5 text-xs leading-relaxed text-zinc-100 transition ${
                        slug ? 'cursor-pointer hover:bg-studio-800/80' : ''
                      }`}
                    >
                      <div>
                        <b className="text-white">{f.quem}:</b> <span>“{f.texto}”</span>
                        {f.emocao && <span className="ml-1.5 text-[11px] text-zinc-500">[{f.emocao}]</span>}
                      </div>
                      {slug && (
                        <span className="mt-0.5 inline-flex shrink-0 items-center gap-1 text-[10px] text-zinc-500 opacity-0 transition group-hover:opacity-100">
                          <Pencil size={10} /> {palFala}p
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/**
 * Modal de tipo de final para "➕ Gerar Parte N" e "🔄 Gerar Novamente".
 * onConfirmar({ tipoFinal, observacao, reaproveitarRefs }) deve devolver uma Promise.
 */
export function ModalTipoFinal({ aberto, titulo, descricao, mostrarReaproveitar = false, reaproveitarPadrao = true, rotuloConfirmar = 'Gerar', onConfirmar, onFechar }) {
  const [tipoFinal, setTipoFinal] = useState('');
  const [observacao, setObservacao] = useState('');
  const [reaproveitar, setReaproveitar] = useState(reaproveitarPadrao);
  const [enviando, setEnviando] = useState(false);
  useEffect(() => { if (aberto) { setTipoFinal(''); setObservacao(''); setReaproveitar(reaproveitarPadrao); setEnviando(false); } }, [aberto, reaproveitarPadrao]);
  return (
    <Modal aberto={aberto} onFechar={onFechar} titulo={titulo} largura="max-w-xl">
      <div className="space-y-4">
        {descricao && <p className="text-xs text-zinc-400">{descricao}</p>}
        <div>
          <div className="label mb-1.5">Rumo do final (obrigatório)</div>
          <SeletorTipoFinal valor={tipoFinal} onChange={setTipoFinal} />
        </div>
        <label className="block text-xs text-zinc-400">Observação rápida (opcional)
          <textarea className="input mt-1 h-16 resize-y text-xs" placeholder='Ex.: "deixe mais simples", "mude o motivo da briga"' value={observacao} onChange={(e) => setObservacao(e.target.value)} />
        </label>
        {mostrarReaproveitar && (
          <label className="flex items-start gap-2 rounded-lg border border-white/[0.07] bg-studio-950 p-2.5 text-xs text-zinc-300">
            <input type="checkbox" className="mt-0.5" checked={reaproveitar} onChange={(e) => setReaproveitar(e.target.checked)} />
            <span>
              <b>Reaproveitar personagens/cenários (ref_*) já existentes</b>
              <span className="block text-[11px] text-zinc-500">Mantém os mesmos personagens/cenários do Bloco 1 (0 créditos extras).</span>
            </span>
          </label>
        )}
        <div className="flex justify-end gap-2">
          <button className="btn-ghost" onClick={onFechar}>Cancelar</button>
          <button
            className="btn-primary"
            disabled={!tipoFinal || enviando}
            title={!tipoFinal ? 'Escolha o rumo do final' : ''}
            onClick={async () => {
              setEnviando(true);
              try { await onConfirmar({ tipoFinal, observacao: observacao.trim(), reaproveitarRefs: mostrarReaproveitar ? reaproveitar : true }); }
              finally { setEnviando(false); }
            }}
          >
            {enviando ? <Loader2 size={14} className="animate-spin" /> : <RotateCw size={14} />} {rotuloConfirmar}
          </button>
        </div>
      </div>
    </Modal>
  );
}

/** "👁️ Ler Só Diálogos": falas das cenas com edicao inline direta no roteiro_humano.md. */
export function ModalDialogos({ alvo, onFechar }) {
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState(null);
  useEffect(() => {
    if (!alvo) return;
    setDados(null); setErro(null);
    fab.dialogos(alvo.slug, alvo.parte).then(setDados).catch((e) => setErro(e.message));
  }, [alvo]);
  return (
    <Modal aberto={!!alvo} onFechar={onFechar} titulo={<span className="inline-flex items-center gap-2"><MessageSquareText size={16} className="text-fuchsia-400" /> Diálogos {dados?.titulo ? `— ${dados.titulo}` : ''}</span>} largura="max-w-2xl">
      {erro && <div className="rounded border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-200">{erro}</div>}
      {!dados && !erro && <div className="flex items-center gap-2 text-xs text-zinc-500"><Loader2 size={14} className="animate-spin" /> Lendo roteiro...</div>}
      {dados && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-[11px] text-zinc-500">
            <span>Clique em qualquer fala para editar direto no roteiro (0 tokens).</span>
            <span>{dados.tipoFinal === 'aberto' ? '🔥 Final aberto' : '✅ Final fechado'}</span>
          </div>
          <ListaDialogosEditavel
            slug={alvo?.slug}
            parte={alvo?.parte || 1}
            dados={dados}
            onAtualizar={setDados}
            alturaMax="max-h-[60vh]"
          />
        </div>
      )}
    </Modal>
  );
}
