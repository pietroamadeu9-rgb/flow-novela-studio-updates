import React, { useEffect, useMemo, useState } from 'react';
import {
  Wand2, AlertOctagon, AlertTriangle, CheckCircle2, Image as ImageIcon, Layers, Video, RotateCw, ChevronDown, ChevronRight, ClipboardPaste, EyeOff, RefreshCw, ShieldCheck,
} from 'lucide-react';
import { api, ROTULOS_SUBMODO, ROTULOS_TIPO } from '../api.js';
import { ItemStatus } from './ui.jsx';
import { BotoesItem } from './AcoesItem.jsx';

const COR_TIPO = {
  referencia_imagem: 'text-sky-300 bg-sky-500/10 border-sky-500/30',
  imagem_base: 'text-violet-300 bg-violet-500/10 border-violet-500/30',
  video: 'text-fuchsia-300 bg-fuchsia-500/10 border-fuchsia-500/30',
};

function contemBloco1Referencias(t) {
  const s = String(t || '');
  return /\bBLOCO\s*1\s*[—–-]*\s*REFER[ÊE]NCIAS/i.test(s) || (/\{ref_[\w-]+\}/i.test(s) && /\{Cena\s*\d+\}/i.test(s));
}

export default function RoteiroTab({ novela, fila, executar, toast, acoes }) {
  const [texto, setTexto] = useState(novela.roteiro || '');
  const [processando, setProcessando] = useState(false);
  const [recuperando, setRecuperando] = useState(false);
  const [filtro, setFiltro] = useState('todos');
  const [verIgnoradas, setVerIgnoradas] = useState(false);
  const [autoEnfileirar, setAutoEnfileirar] = useState(() => localStorage.getItem('fns.autoEnfileirar') !== '0');
  const alterado = texto !== (novela.roteiro || '');
  const { erros = [], avisos = [] } = novela.validacao || {};
  const rodandoEsta = fila.rodando && fila.novelaAtual === novela.id;
  const qtdConcluidos = useMemo(() => (novela.itens || []).filter((i) => i.status === 'concluido').length, [novela.itens]);
  const qtdVideosConcluidos = useMemo(() => (novela.itens || []).filter((i) => i.tipo === 'video' && i.status === 'concluido').length, [novela.itens]);

  useEffect(() => {
    setTexto(novela.roteiro || '');
  }, [novela.id, novela.roteiro]);

  const recuperarMidiasDaPasta = async () => {
    if (recuperando) return;
    setRecuperando(true);
    try {
      const r = await api.recuperarMidiasPasta(novela.id);
      if (r?.novela?.roteiro) setTexto(r.novela.roteiro);
      const rec = r?.recuperados || {};
      toast?.(
        `✅ Mídias recuperadas da pasta "${novela.pasta}": ${rec.videos || 0} vídeo(s), ${rec.imagensBase || 0} imagem(ns)-base e ${rec.referencias || 0} referência(s)!`,
        'ok'
      );
    } catch (e) {
      toast?.(e.message || 'Falha ao recuperar mídias da pasta', 'erro');
    } finally {
      setRecuperando(false);
    }
  };

  const dispararProcessamento = async (txtAlvo, { origemPaste = false, forcarIniciar = false, forcarSubstituicao = false } = {}) => {
    const conteudo = typeof txtAlvo === 'string' ? txtAlvo : texto;
    if (rodandoEsta) return;
    if (!conteudo.trim()) {
      if (qtdConcluidos > 0 && !forcarSubstituicao) {
        const confirmarLimpar = window.confirm(
          `⚠️ PROTEÇÃO ANTI-PERDA: Esta novela já possui ${qtdVideosConcluidos} vídeo(s) e ${qtdConcluidos} mídia(s) concluída(s) na pasta.\n\nApagar o roteiro iria desvincular a lista da tela. Deseja restaurar o roteiro salvo desta novela?`
        );
        if (confirmarLimpar) {
          setTexto(novela.roteiro || '');
          toast?.('🛡️ Roteiro e vídeos concluídos preservados!', 'ok');
          return;
        }
      }
      return;
    }
    setProcessando(true);
    try {
      const r = await api.processarRoteiro(novela.id, conteudo, {
        autoEnfileirar,
        iniciarFila: forcarIniciar,
        forcarSubstituicao,
      });
      setProcessando(false);
      if (r) {
        const msg = r.autoEnfileirada
          ? `⚡ Roteiro processado e adicionado automaticamente ao final da fila global!`
          : origemPaste
            ? '⚡ Roteiro colado e processado automaticamente (Bloco 1, 2 e 3)!'
            : 'Roteiro processado!';
        toast?.(msg, 'ok');
      }
    } catch (e) {
      setProcessando(false);
      if (e?.requerConfirmacao) {
        const ok = window.confirm(
          `${e.message}\n\nDeseja realmente substituir o roteiro desta novela por outra história?\n• Clique em CANCELAR para manter seus vídeos prontos na tela (e crie "+ Nova Novela" para a história nova).\n• Clique em OK apenas se quiser substituir mesmo assim.`
        );
        if (ok) {
          return dispararProcessamento(conteudo, { origemPaste, forcarIniciar, forcarSubstituicao: true });
        }
        setTexto(novela.roteiro || '');
        toast?.('🛡️ Substituição cancelada — seus vídeos e roteiro originais foram mantidos!', 'ok');
        return;
      }
      toast?.(e.message || 'Erro ao processar roteiro', 'erro');
    }
  };

  const processar = () => dispararProcessamento(texto);

  const colar = async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (t) {
        setTexto(t);
        if (contemBloco1Referencias(t)) {
          dispararProcessamento(t, { origemPaste: true });
        }
      }
    } catch {}
  };

  const aoColarTextarea = (e) => {
    const colado = e.clipboardData?.getData('text') || '';
    if (!colado) return;
    const el = e.currentTarget;
    const ini = typeof el?.selectionStart === 'number' ? el.selectionStart : 0;
    const fim = typeof el?.selectionEnd === 'number' ? el.selectionEnd : texto.length;
    const novoTexto = texto.slice(0, ini) + colado + texto.slice(fim);
    if (contemBloco1Referencias(novoTexto)) {
      e.preventDefault();
      setTexto(novoTexto);
      dispararProcessamento(novoTexto, { origemPaste: true });
    }
  };

  const itens = useMemo(
    () => {
      if (filtro === 'todos') return novela.itens;
      if (filtro === 'revisar') return novela.itens.filter((i) => i.status === 'falha_revisar' || i.status === 'bloqueado_dependencia' || i.status === 'erro');
      return novela.itens.filter((i) => i.tipo === filtro);
    },
    [novela.itens, filtro]
  );
  const contagem = (s) => novela.itens.filter((i) => i.status === s).length;
  const qtdFalhas = contagem('erro') + contagem('falha_revisar') + contagem('bloqueado_dependencia');

  return (
    <div className="grid gap-6 xl:grid-cols-[minmax(380px,0.9fr)_minmax(0,1.4fr)]">
      {/* ===== Coluna do roteiro ===== */}
      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold text-white">Roteiro completo</h2>
            <p className="text-xs text-zinc-500">Cole os blocos de Referências, Imagens-Base e Prompts de Vídeo (auto-parse ao colar).</p>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              className="btn-ghost border border-cyan-500/30 bg-cyan-500/10 py-1.5 text-xs text-cyan-200 hover:bg-cyan-500/20"
              disabled={recuperando || rodandoEsta}
              onClick={recuperarMidiasDaPasta}
              title="Varre a pasta desta novela (01_Referencias, 02_Imagens_Base, 03_Videos) + roteiro_backup.txt e reconecta todos os vídeos e imagens já salvos sem regerar nada"
            >
              <RefreshCw size={13} className={recuperando ? 'animate-spin' : ''} />
              {recuperando ? 'Recuperando...' : '🔄 Recuperar Mídias da Pasta'}
            </button>
            <button className="btn-ghost py-1.5 text-xs" onClick={colar}><ClipboardPaste size={13} /> Colar</button>
          </div>
        </div>
        <textarea
          className="input min-h-[450px] flex-1 resize-y font-mono text-[12.5px] leading-relaxed"
          spellCheck={false}
          placeholder={'BLOCO 1 — REFERÊNCIAS\n{ref_bia}\n(i) Retrato vertical de Bia...\n\nBLOCO 2 — IMAGENS-BASE\n{imagem_01}\n(i) [ref_bia] [ref_cozinha] Fotografia...\n\nBLOCO 3 — PROMPTS DE VÍDEO\n{Cena 01}\n(v) [imagem_01] Exactly 10 seconds, vertical 9:16...'}
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onPaste={aoColarTextarea}
        />
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-white/[0.06] bg-studio-900/70 px-3 py-2 text-xs text-zinc-300">
          <label className="flex cursor-pointer items-center gap-2" title="Quando outra novela já estiver rodando (ou na fila), coloca esta novela automaticamente no final da fila global assim que o roteiro for válido">
            <input
              type="checkbox"
              checked={autoEnfileirar}
              onChange={(e) => {
                const v = e.target.checked;
                setAutoEnfileirar(v);
                localStorage.setItem('fns.autoEnfileirar', v ? '1' : '0');
              }}
            />
            <span>⚡ Entrar automaticamente no final da fila global se a fila estiver ativa</span>
          </label>
          {alterado && <span className="text-xs text-amber-400">alterações não processadas</span>}
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-primary flex-1 py-2.5" disabled={processando || !texto.trim() || rodandoEsta} onClick={processar}>
            <Wand2 size={16} /> {processando ? 'Processando...' : 'Processar Roteiro'}
          </button>
          <button
            className="btn-success py-2.5 text-xs"
            disabled={processando || !texto.trim() || rodandoEsta}
            title="Processa o roteiro e já coloca na fila global (iniciando imediatamente se estiver parada)"
            onClick={() => dispararProcessamento(texto, { forcarIniciar: true })}
          >
            ⚡ Processar & Enfileirar
          </button>
        </div>
        <div className="rounded-lg border border-studio-700 bg-studio-900 p-3 text-[11px] leading-relaxed text-zinc-500">
          <b className="text-zinc-400">Regras:</b> <span className="font-mono text-zinc-300">{'{id}'}</span> define o nome do arquivo ·{' '}
          <span className="font-mono text-sky-300">(i) texto</span> = referência ·{' '}
          <span className="font-mono text-violet-300">(i) [refs] texto</span> = imagem-base ·{' '}
          <span className="font-mono text-fuchsia-300">(v) [refs] texto</span> = vídeo (10/15 s lido do texto). Títulos são ignorados.
        </div>
      </section>

      {/* ===== Coluna de resultado ===== */}
      <section className="flex min-w-0 flex-col gap-4">
        <div className="grid grid-cols-3 gap-3">
          <Resumo icon={ImageIcon} cor="text-sky-400" titulo="Bloco 1 · Referências" valor={novela.resumo?.referencias || 0} />
          <Resumo icon={Layers} cor="text-violet-400" titulo="Bloco 2 · Imagens-Base" valor={novela.resumo?.imagensBase || 0} />
          <Resumo icon={Video} cor="text-fuchsia-400" titulo="Bloco 3 · Vídeos" valor={novela.resumo?.videos || 0} />
        </div>

        {novela.processadoEm && (
          erros.length ? (
            <div className="rounded-xl border border-red-500/40 bg-red-500/10 p-4">
              <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-red-300">
                <AlertOctagon size={16} /> {erros.length} problema(s) impedem a fila de rodar
              </div>
              <ul className="space-y-1 text-xs text-red-200/90">
                {erros.map((e, i) => <li key={i}><span className="font-mono text-red-400">linha {e.linha}:</span> {e.msg}</li>)}
              </ul>
            </div>
          ) : (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
              <CheckCircle2 size={16} /> Todas as [referências] citadas estão declaradas antes do uso. Pronto para a fila.
            </div>
          )
        )}
        {avisos.length > 0 && (
          <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-amber-300"><AlertTriangle size={15} /> {avisos.length} aviso(s)</div>
            <ul className="space-y-1 text-xs text-amber-200/80">
              {avisos.map((e, i) => <li key={i}><span className="font-mono text-amber-400">linha {e.linha}:</span> {e.msg}</li>)}
            </ul>
          </div>
        )}
        {novela.ignoradas?.length > 0 && (
          <div className="rounded-lg border border-studio-700 bg-studio-900">
            <button className="flex w-full items-center gap-2 px-3 py-2 text-xs text-zinc-500 hover:text-zinc-300" onClick={() => setVerIgnoradas(!verIgnoradas)}>
              {verIgnoradas ? <ChevronDown size={13} /> : <ChevronRight size={13} />}<EyeOff size={13} /> {novela.ignoradas.length} linha(s) ignorada(s) (títulos/cabeçalhos)
            </button>
            {verIgnoradas && (
              <div className="max-h-40 space-y-0.5 overflow-y-auto px-3 pb-3 font-mono text-[11px] text-zinc-600">
                {novela.ignoradas.map((l, i) => <div key={i} className="truncate"><span className="text-zinc-700">{l.linha}:</span> {l.texto}</div>)}
              </div>
            )}
          </div>
        )}

        {/* Fila detalhada */}
        <div className="card overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-studio-700 px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="text-sm font-semibold text-white">Fila detalhada</div>
              <span className="inline-flex items-center gap-1 rounded border border-emerald-500/25 bg-emerald-500/10 px-1.5 py-0.5 text-[10px] text-emerald-300" title="Backup automático salvo em Meus_Projetos_Flow/roteiro_backup.txt e trava anti-perda ativa">
                <ShieldCheck size={11} /> Trava Anti-Perda Ativa
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-[11px] text-zinc-500">
              <span>✅ {contagem('concluido')}</span>
              <span>⏳ {contagem('gerando')}</span>
              <span>🕒 {contagem('na_fila') + contagem('pendente')}</span>
              <span className={qtdFalhas ? 'font-semibold text-rose-300' : ''}>⚠️ {qtdFalhas}</span>
              <button
                type="button"
                className="btn-ghost border border-cyan-500/30 bg-cyan-500/10 px-2 py-1 text-[11px] text-cyan-200 hover:bg-cyan-500/20"
                disabled={recuperando || rodandoEsta}
                onClick={recuperarMidiasDaPasta}
                title="Reconecta todos os .mp4 e imagens já salvos na pasta desta novela"
              >
                <RefreshCw size={11} className={recuperando ? 'animate-spin' : ''} />
                🔄 Recuperar Mídias da Pasta
              </button>
              <select className="input w-40 py-1 text-xs" value={filtro} onChange={(e) => setFiltro(e.target.value)}>
                <option value="todos">Todos os blocos</option>
                <option value="referencia_imagem">Referências</option>
                <option value="imagem_base">Imagens-Base</option>
                <option value="video">Vídeos</option>
                {qtdFalhas > 0 && <option value="revisar">⚠️ Revisar / Bloqueados ({qtdFalhas})</option>}
              </select>
            </div>
          </div>
          {novela.itens.length === 0 ? (
            <div className="flex flex-col items-center gap-3 px-4 py-12 text-center text-sm text-zinc-500">
              <div>Cole o roteiro e clique em “Processar Roteiro” — ou recupere mídias já geradas na pasta desta novela:</div>
              <button
                type="button"
                className="btn border border-cyan-500/40 bg-cyan-500/15 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/25"
                disabled={recuperando || rodandoEsta}
                onClick={recuperarMidiasDaPasta}
              >
                <RefreshCw size={13} className={recuperando ? 'animate-spin' : ''} />
                🔄 Recuperar Mídias da Pasta
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 z-10 bg-studio-850 text-[10px] uppercase tracking-wider text-zinc-500">
                  <tr>
                    <th className="px-3 py-2">#</th><th className="px-3 py-2">Arquivo</th><th className="px-3 py-2">Tipo / Submodo</th>
                    <th className="px-3 py-2">Referências</th><th className="px-3 py-2">Prompt</th><th className="px-3 py-2">Status</th><th className="px-3 py-2"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-studio-800">
                  {itens.map((it) => (
                    <tr key={it.id} className={`align-top hover:bg-studio-850/60 ${fila.itemAtual === it.id && fila.novelaAtual === novela.id ? 'bg-amber-500/5' : ''}`}>
                      <td className="px-3 py-2.5 font-mono text-zinc-600">{it.ordem}</td>
                      <td className="px-3 py-2.5">
                        <div className="font-mono font-semibold text-zinc-100">{`{${it.id}}`}</div>
                        <div className="font-mono text-[10px] text-zinc-600">{it.caminhoRelativo}</div>
                      </td>
                      <td className="px-3 py-2.5">
                        <span className={`inline-block rounded border px-1.5 py-0.5 text-[10px] font-medium ${COR_TIPO[it.tipo]}`}>{ROTULOS_TIPO[it.tipo]}</span>
                        <div className="mt-1 text-[10.5px] text-zinc-500">{ROTULOS_SUBMODO[it.submodo]} · {it.proporcao}{it.duracao ? ` · ${it.duracao}s` : ''}</div>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex max-w-[220px] flex-wrap gap-1">
                          {it.refs.length ? it.refs.map((r, i) => (
                            <span key={r} className={`chip ${it.refsFaltando?.includes(r) ? '!border-red-500/50 !text-red-300' : ''}`}><span className="text-zinc-600">{i + 1}.</span>{r}</span>
                          )) : <span className="text-zinc-700">—</span>}
                        </div>
                      </td>
                      <td className="max-w-[320px] px-3 py-2.5 text-zinc-400">
                        <div className="line-clamp-2" title={it.prompt}>{it.prompt}</div>
                        {(it.geradoPorDescricaoSemImagem || it.modoDescritivoSemImagem) ? (
                          <div className="mt-1 inline-flex items-center gap-1 rounded border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-amber-200" title={`Original: ${it.promptOriginalBackup || it.originalPrompt || ''}`}>
                            {it.status === 'concluido' ? '📝 Gerado por descrição (sem imagem)' : '📝 Prompt 100% Descritivo (sem imagem)'}
                          </div>
                        ) : (it.originalPrompt || it.promptOriginalBackup) && (it.originalPrompt || it.promptOriginalBackup) !== it.prompt ? (
                          <div className="mt-1 inline-flex items-center gap-1 rounded border border-violet-500/30 bg-violet-500/10 px-1.5 py-0.5 text-[10px] text-violet-300" title={`Original: ${it.promptOriginalBackup || it.originalPrompt}`}>
                            ✨ Prompt ajustado ({it.promptAutoAjustado === 'claude-cli' ? 'Claude CLI' : 'auto'})
                          </div>
                        ) : null}
                      </td>
                      <td className="px-3 py-2.5">
                        <ItemStatus status={it.status} />
                        {it.tentativaAtual > 0 && (
                          <div className="mt-1 text-[10px] font-semibold text-amber-300">Tentativa {it.tentativaAtual}/3</div>
                        )}
                        {it.progresso && <div className="mt-1 text-[10px] text-amber-400">{it.progresso}</div>}
                        {it.erro && <div className="mt-1 max-w-[220px] text-[10px] text-red-400" title={it.erro}>{it.erro}</div>}
                      </td>
                      <td className="px-3 py-2.5">
                        <BotoesItem item={it} novela={novela} acoes={acoes} compacto />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function Resumo({ icon: I, cor, titulo, valor }) {
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2 text-[11px] font-medium text-zinc-500"><I size={14} className={cor} /> {titulo}</div>
      <div className="mt-1 text-3xl font-bold text-white">{valor}</div>
      <div className="text-[10px] text-zinc-600">itens encontrados</div>
    </div>
  );
}
