@echo off
setlocal
title Parar Flow Novela Studio
echo.
echo Encerrando o servidor do Flow Novela Studio (porta 3456)...
powershell -NoProfile -Command "$conns = Get-NetTCPConnection -LocalPort 3456 -State Listen -ErrorAction SilentlyContinue; if (-not $conns) { Write-Host 'Nenhum servidor rodando na porta 3456.'; exit 0 }; $pids = $conns | Select-Object -ExpandProperty OwningProcess -Unique; foreach ($id in $pids) { if ($id -gt 0) { $proc = Get-Process -Id $id -ErrorAction SilentlyContinue; if ($proc -and $proc.ProcessName -match '^node') { Stop-Process -Id $id -Force; Write-Host ('Servidor encerrado com seguranca (PID ' + $id + ').') } } }"
timeout /t 2 >nul
endlocal
exit /b 0
