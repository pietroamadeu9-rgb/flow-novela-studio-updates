@echo off
setlocal
title Flow Novela Studio
cd /d "%~dp0"

echo.
echo  ==============================================
echo     FLOW NOVELA STUDIO - iniciando...
echo  ==============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao encontrado. Instale em https://nodejs.org e tente de novo.
  pause
  exit /b 1
)

if not exist "node_modules\express" (
  echo Instalando dependencias pela primeira vez...
  call npm.cmd install --no-audit --no-fund
  if errorlevel 1 ( echo [ERRO] Falha no npm install. & pause & exit /b 1 )
)

if not exist "web\dist\index.html" (
  echo Compilando a interface...
  call npm.cmd run build
  if errorlevel 1 ( echo [ERRO] Falha no build da interface. & pause & exit /b 1 )
)

rem --- Servidor ja esta rodando? ---
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:3456/api/status | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  echo Iniciando servidor local na porta 3456...
  start "Flow Novela Studio - Servidor (nao feche esta janela)" /min cmd /k "node server\index.js"
) else (
  echo Servidor ja estava rodando.
)

rem --- Aguarda o servidor responder (ate ~20s) ---
set /a TENT=0
:aguardar
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:3456/api/status | Out-Null; exit 0 } catch { exit 1 }"
if not errorlevel 1 goto pronto
set /a TENT+=1
if %TENT% GEQ 20 (
  echo [ERRO] O servidor nao respondeu. Veja a janela "Flow Novela Studio - Servidor".
  pause
  exit /b 1
)
timeout /t 1 /nobreak >nul
goto aguardar

:pronto
echo Servidor pronto! Abrindo o estudio no Microsoft Edge...

set "EDGE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

if defined EDGE (
  start "" "%EDGE%" --app=http://localhost:3456 --window-size=1500,920
) else (
  start "" msedge --app=http://localhost:3456 2>nul || start "" http://localhost:3456
)

endlocal
exit /b 0
