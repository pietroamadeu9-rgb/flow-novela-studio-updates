// =========================================================================
//  Flow Novela Studio — Publicador Automático de Atualização via GitHub
//  - Verifica/instala GitHub CLI (gh) e guia login único se necessário
//  - Compila (npm run build), incrementa versão em version.json e package.json
//  - Gera Flow_Novela_Studio_Instalador.zip limpo e audita entradas do ZIP
//    (garantia estrita: ZERO .env, ZERO chaves, ZERO pastas de novelas/vídeos)
//  - Cria/atualiza repositório dedicado contendo APENAS:
//      1) version.json
//      2) Flow_Novela_Studio_Instalador.zip
// =========================================================================
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync, execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname);
const ARQ_VERSION = path.join(ROOT, 'version.json');
const ARQ_PKG = path.join(ROOT, 'package.json');
const ZIP_INSTALADOR = path.join(ROOT, 'Flow_Novela_Studio_Instalador.zip');
const REPO_NOME_PADRAO = 'flow-novela-studio-updates';

function lerJson(arq, padrao = {}) {
  try {
    return JSON.parse(fs.readFileSync(arq, 'utf8').replace(/^\uFEFF/, ''));
  } catch {
    return padrao;
  }
}

function salvarJson(arq, obj) {
  fs.writeFileSync(arq, JSON.stringify(obj, null, 2) + '\n', 'utf8');
}

function incrementarVersaoPatch(vStr) {
  const partes = String(vStr || '1.0.0')
    .trim()
    .replace(/^v/i, '')
    .split('.')
    .map((n) => Number(n) || 0);
  while (partes.length < 3) partes.push(0);
  partes[2] += 1;
  return `${partes[0]}.${partes[1]}.${partes[2]}`;
}

function localizarGhExe() {
  const candidatos = [
    path.join(process.env.ProgramFiles || 'C:\\Program Files', 'GitHub CLI', 'gh.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'Programs', 'GitHub CLI', 'gh.exe'),
    path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'GitHub CLI', 'gh.exe'),
  ];
  for (const c of candidatos) {
    if (c && fs.existsSync(c)) return c;
  }
  const r = spawnSync('where.exe', ['gh'], { encoding: 'utf8', windowsHide: true });
  if (r.status === 0 && r.stdout.trim()) {
    return r.stdout.trim().split(/\r?\n/)[0].trim();
  }
  return null;
}

function garantirGhInstalado() {
  let gh = localizarGhExe();
  if (gh) return gh;
  console.log('📦 GitHub CLI (gh) não encontrado. Instalando automaticamente via winget...');
  spawnSync(
    'winget.exe',
    ['install', '--id', 'GitHub.cli', '--accept-package-agreements', '--accept-source-agreements', '--silent'],
    { stdio: 'inherit' }
  );
  gh = localizarGhExe();
  if (!gh) {
    throw new Error('Não foi possível localizar o GitHub CLI (gh.exe). Instale com: winget install GitHub.cli');
  }
  return gh;
}

function verificarAutenticacaoGh(ghExe, { interativo = true } = {}) {
  const st = spawnSync(ghExe, ['auth', 'status'], { encoding: 'utf8', windowsHide: true });
  if (st.status === 0) {
    const userRes = spawnSync(ghExe, ['api', 'user', '--jq', '.login'], { encoding: 'utf8', windowsHide: true });
    const login = (userRes.stdout || '').trim();
    if (login) return { autenticado: true, login };
  }
  if (!interativo) {
    return { autenticado: false, login: null };
  }
  console.log('\n==============================================================');
  console.log('  LOGIN ÚNICO NO GITHUB (NECESSÁRIO APENAS NA 1ª VEZ)');
  console.log('==============================================================');
  console.log('1) Escolha "GitHub.com" -> "HTTPS" -> "Login with a web browser"');
  console.log('2) Copie o código de 8 letras mostrado abaixo e autorize no navegador.\n');
  const loginProc = spawnSync(ghExe, ['auth', 'login', '--hostname', 'github.com', '-p', 'https', '--web'], {
    stdio: 'inherit',
  });
  if (loginProc.status !== 0) {
    throw new Error('Login no GitHub não foi concluído.');
  }
  const userRes = spawnSync(ghExe, ['api', 'user', '--jq', '.login'], { encoding: 'utf8', windowsHide: true });
  const login = (userRes.stdout || '').trim();
  if (!login) throw new Error('Não foi possível obter o usuário logado no GitHub.');
  return { autenticado: true, login };
}

/**
 * Audita todas as entradas dentro do arquivo Flow_Novela_Studio_Instalador.zip
 * para garantir que NUNCA contenha .env, chaves/tokens ou novelas/vídeos.
 */
export function auditarZipDistribuicao(zipAbs) {
  if (!fs.existsSync(zipAbs)) throw new Error(`Arquivo ZIP não encontrado: ${zipAbs}`);
  const psAudit = `
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [System.IO.Compression.ZipFile]::OpenRead('${zipAbs.replace(/'/g, "''")}')
    try {
      foreach ($e in $z.Entries) {
        Write-Output $e.FullName
      }
    } finally {
      $z.Dispose()
    }
  `;
  const saida = execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psAudit], {
    encoding: 'utf8',
    windowsHide: true,
  });
  const entradas = saida.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const proibidos = entradas.filter((e) => {
    const norm = e.replace(/\\/g, '/');
    const base = path.posix.basename(norm);
    if (base.toLowerCase() === '.env') return true;
    if (/gdrive_(token|credentials)\.json/i.test(base)) return true;
    if (/whatsapp_auth/i.test(norm)) return true;
    if (/dados\/novelas\/.+/i.test(norm) && !/dados\/novelas\/$/.test(norm)) return true;
    if (/Meus_Projetos_Flow\/.+/i.test(norm) && !/Meus_Projetos_Flow\/$/.test(norm)) return true;
    if (/\.(mp4|mov|mkv)$/i.test(base)) return true;
    return false;
  });
  if (proibidos.length > 0) {
    throw new Error(`BLOQUEIO DE SEGURANÇA: O ZIP contém arquivos sensíveis ou de novelas: ${proibidos.join(', ')}`);
  }
  return { ok: true, totalEntradas: entradas.length };
}

async function main() {
  const args = process.argv.slice(2);
  const semBump = args.includes('--no-bump');
  const apenasPrepararLocal = args.includes('--prepare-only');
  const naoInterativo = args.includes('--non-interactive');
  const notaArgIdx = args.indexOf('--notes');
  const notaCustom = notaArgIdx >= 0 && args[notaArgIdx + 1] ? args[notaArgIdx + 1] : '';

  console.log('\n==============================================================');
  console.log('   FLOW NOVELA STUDIO — PUBLICAR ATUALIZAÇÃO (AUTO-UPDATER)');
  console.log('==============================================================\n');

  // 1) Verifica GitHub CLI e login
  const ghExe = garantirGhInstalado();
  const auth = verificarAutenticacaoGh(ghExe, { interativo: !naoInterativo && !apenasPrepararLocal });

  // 2) Compila o frontend (npm run build)
  console.log('[1/4] Compilando interface (npm run build)...');
  const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const buildRes = spawnSync(npmCmd, ['run', 'build'], { cwd: ROOT, stdio: 'inherit', shell: true });
  if (buildRes.status !== 0) {
    throw new Error('Falha ao compilar a interface com npm run build.');
  }

  // 3) Atualiza version.json e package.json (com URLs do repositório dedicado)
  const verAtual = lerJson(ARQ_VERSION, { version: '1.1.0' });
  const pkgAtual = lerJson(ARQ_PKG, { version: '1.1.0' });
  const novaVersao = semBump ? String(verAtual.version || pkgAtual.version || '1.1.0') : incrementarVersaoPatch(verAtual.version || pkgAtual.version);

  const repoFull = auth.login ? `${auth.login}/${REPO_NOME_PADRAO}` : (verAtual.repo || '');
  const novoVersionObj = {
    version: novaVersao,
    releasedAt: new Date().toISOString(),
    repo: repoFull,
    branch: 'main',
    versionUrl: repoFull ? `https://raw.githubusercontent.com/${repoFull}/main/version.json` : '',
    zipUrl: repoFull ? `https://raw.githubusercontent.com/${repoFull}/main/Flow_Novela_Studio_Instalador.zip` : '',
    notes:
      notaCustom ||
      verAtual.notes ||
      'Blindagem de inicialização em janela de App (--app), gerador de legendas conectado à história com tamanhos variados e hashtags separadas, e Auto-Update via GitHub',
  };

  salvarJson(ARQ_VERSION, novoVersionObj);
  pkgAtual.version = novaVersao;
  salvarJson(ARQ_PKG, pkgAtual);
  console.log(`[2/4] Versão atualizada para v${novaVersao}${repoFull ? ` (repo: ${repoFull})` : ''}.`);

  // 4) Gera o Flow_Novela_Studio_Instalador.zip limpo e audita segurança
  console.log('[3/4] Gerando Flow_Novela_Studio_Instalador.zip limpo e auditando segurança...');
  const pacRes = spawnSync(process.execPath, [path.join(ROOT, 'gerar_pacote.mjs')], { cwd: ROOT, stdio: 'inherit' });
  if (pacRes.status !== 0) {
    throw new Error('Falha ao gerar Flow_Novela_Studio_Instalador.zip.');
  }
  const auditoria = auditarZipDistribuicao(ZIP_INSTALADOR);
  console.log(`      Auditoria de segurança APROVADA (${auditoria.totalEntradas} arquivos verificados: ZERO .env, ZERO chaves, ZERO novelas/vídeos).`);

  if (!auth.autenticado || apenasPrepararLocal) {
    console.log('\n⚠️ Pacote local e version.json preparados com sucesso.');
    if (!auth.autenticado) {
      console.log('Para publicar no GitHub, rode PUBLICAR_ATUALIZACAO.bat (ou execute: gh auth login) e confirme no navegador.');
    }
    return;
  }

  // 5) Cria/atualiza o repositório dedicado no GitHub contendo APENAS version.json e Flow_Novela_Studio_Instalador.zip
  console.log(`[4/4] Publicando APENAS version.json + Flow_Novela_Studio_Instalador.zip em https://github.com/${repoFull}...`);
  const viewRepo = spawnSync(ghExe, ['repo', 'view', repoFull], { encoding: 'utf8', windowsHide: true });
  if (viewRepo.status !== 0) {
    console.log(`      Criando repositório dedicado de distribuição ${repoFull}...`);
    const createRepo = spawnSync(
      ghExe,
      ['repo', 'create', REPO_NOME_PADRAO, '--public', '--description', 'Canal oficial de Auto-Update do Flow Novela Studio (apenas version.json e pacote limpo)'],
      { stdio: 'inherit' }
    );
    if (createRepo.status !== 0) {
      throw new Error(`Não foi possível criar o repositório ${repoFull}.`);
    }
  }

  // Prepara diretório git temporário isolado contendo EXCLUSIVAMENTE version.json e Flow_Novela_Studio_Instalador.zip
  const pubDir = path.join(os.tmpdir(), `fns_github_dist_${Date.now()}`);
  fs.rmSync(pubDir, { recursive: true, force: true });
  fs.mkdirSync(pubDir, { recursive: true });

  try {
    fs.copyFileSync(ARQ_VERSION, path.join(pubDir, 'version.json'));
    fs.copyFileSync(ZIP_INSTALADOR, path.join(pubDir, 'Flow_Novela_Studio_Instalador.zip'));

    // Verifica que na pasta de publicação só existem exatamente esses 2 arquivos
    const arqsPub = fs.readdirSync(pubDir).sort();
    if (arqsPub.length !== 2 || arqsPub[0] !== 'Flow_Novela_Studio_Instalador.zip' || arqsPub[1] !== 'version.json') {
      throw new Error(`Pasta de publicação contém arquivos inesperados: ${arqsPub.join(', ')}`);
    }

    const tokenRes = spawnSync(ghExe, ['auth', 'token'], { encoding: 'utf8', windowsHide: true });
    const ghToken = (tokenRes.stdout || '').trim();
    const remoteUrl = ghToken
      ? `https://x-access-token:${ghToken}@github.com/${repoFull}.git`
      : `https://github.com/${repoFull}.git`;

    const rodarGit = (gitArgs) => {
      const r = spawnSync('git', gitArgs, { cwd: pubDir, encoding: 'utf8', windowsHide: true });
      if (r.status !== 0) {
        throw new Error(`Erro git ${gitArgs[0]}: ${r.stderr || r.stdout}`);
      }
      return r.stdout;
    };

    rodarGit(['init', '-b', 'main']);
    rodarGit(['config', 'user.name', auth.login]);
    rodarGit(['config', 'user.email', `${auth.login}@users.noreply.github.com`]);
    rodarGit(['add', 'version.json', 'Flow_Novela_Studio_Instalador.zip']);
    rodarGit(['commit', '-m', `Release v${novaVersao}`]);
    rodarGit(['remote', 'add', 'origin', remoteUrl]);
    rodarGit(['push', '-u', 'origin', 'main', '--force']);

    console.log('\n==============================================================');
    console.log(`  ✅ ATUALIZAÇÃO v${novaVersao} PUBLICADA COM SUCESSO NO GITHUB!`);
    console.log(`  Repositório: https://github.com/${repoFull}`);
    console.log(`  O PC do seu amigo já receberá a v${novaVersao} automaticamente`);
    console.log(`  ao abrir o Flow Novela Studio ou clicar em "🔄 Atualizar"!`);
    console.log('==============================================================\n');
  } finally {
    try { fs.rmSync(pubDir, { recursive: true, force: true }); } catch {}
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main().catch((e) => {
    console.error(`\n[ERRO] ${e.message}\n`);
    process.exit(1);
  });
}
