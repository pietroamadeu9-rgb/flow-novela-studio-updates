@echo off
setlocal EnableDelayedExpansion
title Flow Novela Studio - Instalador Automatico (1 Clique)
color 0B
cd /d "%~dp0"

rem --- Se o usuario clicou no INSTALAR_TUDO.bat da raiz do ZIP e existe a subpasta FlowStudio ---
if not exist "package.json" (
  if exist "%~dp0FlowStudio\package.json" (
    cd /d "%~dp0FlowStudio"
  )
)

set "ORIGEM_DIR=%CD%"
set "DESTINO_DIR=C:\FlowStudio"

echo.
echo  ==============================================================
echo     FLOW NOVELA STUDIO - INSTALADOR AUTOMATICO DE 1 CLIQUE
echo  ==============================================================
echo.

rem --- a) Copiar automaticamente para C:\FlowStudio se extraido em outro lugar ---
echo [1/6] Preparando a pasta oficial em C:\FlowStudio...
if /I not "%ORIGEM_DIR%"=="%DESTINO_DIR%" (
  echo       Copiando arquivos de "%ORIGEM_DIR%" para "%DESTINO_DIR%"...
  if not exist "%DESTINO_DIR%" mkdir "%DESTINO_DIR%"
  robocopy "%ORIGEM_DIR%" "%DESTINO_DIR%" /E /NFL /NDL /NJH /NJS /NC /NS /XD node_modules .git >nul
  echo       Arquivos copiados com sucesso para C:\FlowStudio!
) else (
  echo       Pasta ja esta em C:\FlowStudio.
)
cd /d "%DESTINO_DIR%"
if not exist "dados" mkdir "dados"
if not exist "dados\novelas" mkdir "dados\novelas"
if not exist "Meus_Projetos_Flow" mkdir "Meus_Projetos_Flow"

rem --- b) Verificar Node.js; se nao tiver, instalar via winget ou MSI oficial e atualizar PATH na mesma sessao ---
echo.
echo [2/6] Verificando o Node.js...
set "PATH=%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;%PATH%"
for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "PATH=%%B;%PATH%"
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "PATH=%%B;%PATH%"

where node >nul 2>nul
if errorlevel 1 (
  echo       Node.js nao encontrado. Instalando automaticamente ^(aguarde 1 a 2 minutos^)...
  where winget >nul 2>nul
  if not errorlevel 1 (
    echo       Instalando Node.js LTS via winget...
    winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements --silent
  )
  set "PATH=%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;%PATH%"
  for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "PATH=%%B;%PATH%"
  for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "PATH=%%B;%PATH%"
  where node >nul 2>nul
  if errorlevel 1 (
    echo       Baixando e instalando o instalador oficial (.msi) do Node.js LTS...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $msi=Join-Path $env:TEMP 'node_lts_x64.msi'; $url='https://nodejs.org/dist/v22.14.0/node-v22.14.0-x64.msi'; try { $idx=Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json' -TimeoutSec 15; $lts=$idx | Where-Object { $_.lts -and $_.files -contains 'win-x64-msi' } | Select-Object -First 1; if ($lts) { $url='https://nodejs.org/dist/' + $lts.version + '/node-' + $lts.version + '-x64.msi' } } catch {}; Write-Host ('      Baixando ' + $url + '...'); Invoke-WebRequest -Uri $url -OutFile $msi -UseBasicParsing; Write-Host '      Executando instalador do Node.js...'; $p=Start-Process msiexec.exe -ArgumentList '/i', $msi, '/passive', '/norestart' -Wait -PassThru; Remove-Item $msi -Force -ErrorAction SilentlyContinue"
  )
  set "PATH=%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;%PATH%"
  for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "PATH=%%B;%PATH%"
  for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "PATH=%%B;%PATH%"
)

where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Nao foi possivel instalar o Node.js automaticamente.
  echo Verifique sua conexao com a internet e execute INSTALAR_TUDO.bat novamente.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do echo       Node.js pronto e ativo: %%v

rem --- c) Rodar npm install do projeto automaticamente ---
echo.
echo [3/6] Instalando pacotes do Flow Novela Studio (npm install)...
call npm.cmd install --omit=dev --no-audit --no-fund
if not exist "node_modules\express\package.json" (
  echo [ERRO] Falha ao instalar dependencias do projeto. Verifique sua internet e tente novamente.
  pause
  exit /b 1
)
echo       Pacotes do projeto instalados com sucesso!

rem --- d) Instalar automaticamente o Claude Code e abrir o login na tela ---
echo.
echo [4/6] Instalando o Claude Code (@anthropic-ai/claude-code)...
call npm.cmd install -g @anthropic-ai/claude-code --no-audit --no-fund
set "PATH=%APPDATA%\npm;%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%PATH%"

if exist "%APPDATA%\npm\claude.cmd" (
  call "%APPDATA%\npm\claude.cmd" auth status >nul 2>nul
  if errorlevel 1 (
    echo.
    echo  ==============================================================
    echo   LOGIN DO CLAUDE:
    echo   Faca login na conta do Claude que abriu no navegador
    echo   e depois volte aqui!
    echo  ==============================================================
    echo.
    call "%APPDATA%\npm\claude.cmd" auth login
  ) else (
    echo       Conta do Claude ja esta conectada neste computador!
  )
) else (
  where claude >nul 2>nul
  if not errorlevel 1 (
    echo.
    echo  ==============================================================
    echo   LOGIN DO CLAUDE:
    echo   Faca login na conta do Claude que abriu no navegador
    echo   e depois volte aqui!
    echo  ==============================================================
    echo.
    call claude auth login
  )
)

rem --- e) Criar atalho "Flow Novela Studio" direto na Area de Trabalho apontando para INICIAR_APP.vbs ---
echo.
echo [5/6] Criando atalho "Flow Novela Studio" na sua Area de Trabalho...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$root = 'C:\FlowStudio'; $desks = @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:USERPROFILE 'Desktop')); if ($env:OneDrive) { $desks += (Join-Path $env:OneDrive 'Desktop'); $desks += (Join-Path $env:OneDrive 'Area de Trabalho') }; $ws = New-Object -ComObject WScript.Shell; $wscriptExe = Join-Path $env:SystemRoot 'System32\wscript.exe'; $vbs = Join-Path $root 'INICIAR_APP.vbs'; foreach ($d in ($desks | Select-Object -Unique)) { if ($d -and (Test-Path $d)) { $lnk = Join-Path $d 'Flow Novela Studio.lnk'; $s = $ws.CreateShortcut($lnk); $s.TargetPath = $wscriptExe; $s.Arguments = '"' + $vbs + '"'; $s.WorkingDirectory = $root; $ico = Join-Path $root 'flow-studio.ico'; if (Test-Path $ico) { $s.IconLocation = $ico + ',0' }; $s.WindowStyle = 1; $s.Description = 'Flow Novela Studio'; $s.Save(); Write-Host ('      Atalho criado em: ' + $lnk) } }"

rem --- f) Abrir Google Chrome em chrome://extensions e abrir a pasta da extensao ao lado ---
echo.
echo [6/6] Abrindo o Google Chrome e a pasta da extensao ao lado...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$extDir = 'C:\FlowStudio\extensao-chrome'; Start-Process explorer.exe -ArgumentList $extDir; try { Set-Clipboard -Value 'chrome://extensions' } catch {}; $cands = @((Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'), (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'), (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')); $chrome = $cands | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1; if ($chrome) { Start-Process $chrome -ArgumentList '--new-window', 'chrome://extensions'; Start-Sleep -Milliseconds 1400; try { $ws = New-Object -ComObject WScript.Shell; if ($ws.AppActivate('Chrome')) { Start-Sleep -Milliseconds 300; $ws.SendKeys('^l'); Start-Sleep -Milliseconds 150; $ws.SendKeys('chrome://extensions{ENTER}') } } catch {} } else { Start-Process 'msedge.exe' -ArgumentList '--new-window', 'edge://extensions' -ErrorAction SilentlyContinue }"

echo.
echo  ==============================================================
echo     TUDO INSTALADO COM SUCESSO! FALTA SO ATIVAR A EXTENSAO:
echo  ==============================================================
echo.
echo   O Google Chrome e a janelinha da pasta ja abriram na sua tela:
echo.
echo   1^) No canto superior direito do Chrome ^(em chrome://extensions^),
echo      ligue a chavinha "Modo do desenvolvedor".
echo.
echo   2^) Clique no botao "Carregar sem compactacao" ^(canto superior
echo      esquerdo^) e selecione a pasta que abriu ao lado:
echo      C:\FlowStudio\extensao-chrome
echo.
echo   3^) Pronto! Depois e so dar 2 cliques no atalho
echo      "Flow Novela Studio" que foi criado na sua Area de Trabalho!
echo  ==============================================================
echo.
pause
endlocal
exit /b 0
