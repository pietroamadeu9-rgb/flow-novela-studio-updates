' ====================================================================
'  Flow Novela Studio - Lancador Silencioso em Modo Aplicativo Desktop
'  - Aciona launcher.mjs com flag 0 (100% oculto, zero janela preta CMD)
' ====================================================================
Option Explicit

Dim WshShell, fso, pastaRaiz, nodeExe, launcherPath

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

If fso.FolderExists("C:\FlowStudio") And fso.FileExists("C:\FlowStudio\launcher.mjs") Then
  pastaRaiz = "C:\FlowStudio"
Else
  pastaRaiz = fso.GetParentFolderName(WScript.ScriptFullName)
End If

WshShell.CurrentDirectory = pastaRaiz
launcherPath = pastaRaiz & "\launcher.mjs"

Function LocalizarNodeExe()
  Dim candidatos(2), i, caminho
  candidatos(0) = WshShell.ExpandEnvironmentStrings("%ProgramFiles%\nodejs\node.exe")
  candidatos(1) = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\nodejs\node.exe")
  candidatos(2) = WshShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\nodejs\node.exe")
  For i = 0 To UBound(candidatos)
    caminho = candidatos(i)
    If fso.FileExists(caminho) Then
      LocalizarNodeExe = caminho
      Exit Function
    End If
  Next
  LocalizarNodeExe = "node.exe"
End Function

nodeExe = LocalizarNodeExe()

On Error Resume Next
WshShell.Run """" & nodeExe & """ """ & launcherPath & """", 0, False
On Error GoTo 0
