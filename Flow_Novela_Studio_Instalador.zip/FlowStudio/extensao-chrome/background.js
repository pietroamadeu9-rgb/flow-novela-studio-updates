// =============================================================
//  Flow Novela Studio - Service Worker da extensao (Manifest V3)
//  - Conexao WebSocket automatica com ws://localhost:3456 (reconecta sozinha)
//  - Repassa comandos do app local para a aba do Google Flow
//  - Envia o mapeamento DOM para dados/flow-dom-map.json
// =============================================================

const SERVIDOR_HTTP = 'http://localhost:3456';
const SERVIDOR_WS = 'ws://localhost:3456/extensao';
const FLOW_PADRAO = 'https://flow.google.com/';
// Aceita os dois enderecos do Google Flow
const FLOW_MATCH = ['https://flow.google.com/*', 'https://labs.google/*'];
const ARQUIVOS_CONTENT = ['content/domMapper.js', 'content/flowAutomation.js', 'content/content.js'];
const VERSAO = chrome.runtime.getManifest().version;

let ws = null;
let conectado = false;
let tentativas = 0;
let timerReconexao = null;
let timerPing = null;
let seq = 0;
const aguardandoAck = new Map();

// ---------------- Conexao -----------------
function atualizarBadge() {
  chrome.action.setBadgeText({ text: conectado ? '' : '!' });
  chrome.action.setBadgeBackgroundColor({ color: conectado ? '#10b981' : '#f59e0b' });
  chrome.action.setTitle({ title: conectado ? 'Flow Novela Studio — Conectado' : 'Flow Novela Studio — Aguardando o app local...' });
}

function enviar(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(obj));
    return true;
  }
  return false;
}

function agendarReconexao() {
  clearTimeout(timerReconexao);
  const espera = Math.min(1000 * 2 ** tentativas, 10000);
  tentativas++;
  timerReconexao = setTimeout(conectar, espera);
}

async function conectar() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  clearTimeout(timerReconexao);
  try {
    ws = new WebSocket(SERVIDOR_WS);
  } catch {
    agendarReconexao();
    return;
  }
  ws.onopen = async () => {
    conectado = true;
    tentativas = 0;
    atualizarBadge();
    const aba = await acharAbaFlow();
    enviar({ type: 'hello', role: 'extension', versao: VERSAO, navegador: navigator.userAgent, flowAberto: !!aba });
    clearInterval(timerPing);
    // ping a cada 20s mantem o service worker acordado (Chrome 116+)
    timerPing = setInterval(() => enviar({ type: 'ping' }), 20000);
    chrome.runtime.sendMessage({ tipo: 'status_mudou' }).catch(() => {});
  };
  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    tratarMensagemServidor(msg);
  };
  ws.onclose = () => {
    conectado = false;
    clearInterval(timerPing);
    atualizarBadge();
    for (const [, p] of aguardandoAck) p.reject(new Error('Conexão com o app caiu.'));
    aguardandoAck.clear();
    chrome.runtime.sendMessage({ tipo: 'status_mudou' }).catch(() => {});
    agendarReconexao();
  };
  ws.onerror = () => {};
}

async function tratarMensagemServidor(msg) {
  switch (msg.type) {
    case 'bem_vindo':
    case 'seletores':
      if (msg.seletores) await chrome.storage.local.set({ flowSeletores: msg.seletores });
      if (msg.config) await chrome.storage.local.set({ flowConfig: msg.config });
      // Se o manifest.json em disco subiu de versao, recarrega o Service Worker automaticamente
      if (msg.versaoExtensaoDisco && msg.versaoExtensaoDisco !== VERSAO) {
        enviar({ type: 'log', nivel: 'info', msg: `Atualizando extensão em memória (${VERSAO} → ${msg.versaoExtensaoDisco})...` });
        setTimeout(() => chrome.runtime.reload(), 250);
        break;
      }
      // avisa abas abertas do Flow
      (await chrome.tabs.query({ url: FLOW_MATCH })).forEach((t) =>
        chrome.tabs.sendMessage(t.id, { acao: 'seletores_atualizados', seletores: msg.seletores }).catch(() => {})
      );
      break;
    case 'dom_map_salvo': {
      const p = aguardandoAck.get(msg.requestId);
      if (p) { aguardandoAck.delete(msg.requestId); msg.ok ? p.resolve(msg) : p.reject(new Error(msg.erro)); }
      break;
    }
    case 'recarregar_extensao':
      enviar({ type: 'log', nivel: 'info', msg: 'Recarregando extensão automaticamente após atualização...' });
      setTimeout(() => chrome.runtime.reload(), 200);
      break;
    case 'comando':
      executarComando(msg.comando, msg.payload || {})
        .then((data) => enviar({ type: 'resposta', requestId: msg.requestId, ok: true, data }))
        .catch((e) => enviar({ type: 'resposta', requestId: msg.requestId, ok: false, erro: e?.message || String(e) }));
      break;
  }
}

// ---------------- Abas do Google Flow -----------------
/** true para flow.google.com/* e labs.google/.../tools/flow */
function ehAbaFlow(url) {
  try {
    const u = new URL(url);
    if (u.hostname === 'flow.google.com') return true;
    if (u.hostname === 'labs.google' && /\/tools\/flow/.test(u.pathname)) return true;
  } catch {}
  return false;
}

// ---------- Prefixo de conta Google "/u/<X>/" e URL base dinamica ----------
/** Extrai o indice da conta ("0", "1", ...) de "/u/<X>/" ou "?authuser=<X>" (null se nao houver). */
function contaDaUrl(url) {
  try {
    const u = new URL(url);
    const m = u.pathname.match(/^\/u\/(\d+)(?=\/|$)/);
    if (m) return m[1];
    const au = u.searchParams.get('authuser');
    return au && /^\d+$/.test(au) ? au : null;
  } catch { return null; }
}

/** Detecta a URL inicial (home) exata a partir da aba aberta do usuario (flow.google.com ou /fx/pt/tools/flow). */
function baseHomeDaUrl(url) {
  try {
    const u = new URL(url);
    const conta = contaDaUrl(url);
    if (u.hostname === 'flow.google.com') {
      return conta != null ? `https://flow.google.com/u/${conta}/` : 'https://flow.google.com/';
    }
    if (u.hostname === 'labs.google' && /\/tools\/flow/.test(u.pathname)) {
      const m = u.pathname.match(/^(?:\/u\/\d+)?(?:\/fx(?:\/[a-zA-Z-]+)?)?\/tools\/flow/i);
      const base = `${u.origin}${m ? m[0] : '/fx/pt/tools/flow'}`;
      const au = u.searchParams.get('authuser');
      return au && /^\d+$/.test(au) && !/^\/u\/\d+/.test(u.pathname) ? `${base}?authuser=${au}` : base;
    }
  } catch {}
  return null;
}

/** Garante que a URL do Flow preserve dinamicamente o /u/<X>/ da aba aberta do usuario. */
function aplicarConta(url, conta) {
  if (!url) return url;
  try {
    const u = new URL(url);
    if (u.hostname === 'flow.google.com') {
      const resto = u.pathname.replace(/^\/u\/\d+(?=\/|$)/, '') || '/';
      if (conta == null) {
        u.pathname = resto.startsWith('/') ? resto : '/' + resto;
      } else {
        u.pathname = `/u/${conta}${resto.startsWith('/') ? resto : '/' + resto}`;
      }
      return u.toString();
    }
    if (u.hostname === 'labs.google' && /\/tools\/flow/.test(u.pathname) && conta != null) {
      if (/^\/u\/\d+(?=\/|$)/.test(u.pathname)) {
        u.pathname = u.pathname.replace(/^\/u\/\d+/, `/u/${conta}`);
      } else if (u.searchParams.has('authuser')) {
        u.searchParams.set('authuser', String(conta));
      }
      return u.toString();
    }
    return url;
  } catch { return url; }
}

async function lembrarConta(url) {
  if (!url || !ehAbaFlow(url)) return;
  const c = contaDaUrl(url);
  const home = baseHomeDaUrl(url);
  await chrome.storage.local.set({
    flowConta: c,
    ...(home ? { flowBaseHome: home } : {}),
  });
}

/** Conta da aba aberta do usuario (fonte da verdade); se nao houver aba aberta, usa a ultima vista neste PC. */
async function contaAtual(aba) {
  if (aba?.url && ehAbaFlow(aba.url)) {
    const c = contaDaUrl(aba.url);
    await lembrarConta(aba.url);
    return c;
  }
  const { flowConta } = await chrome.storage.local.get('flowConta');
  return flowConta ?? null;
}

/** URL da home do Flow preservando dinamicamente o host (/fx/pt/tools/flow ou flow.google.com) e o /u/<X>/ do usuario. */
async function urlHomeFlow(aba) {
  if (aba?.url && ehAbaFlow(aba.url)) {
    await lembrarConta(aba.url);
    const homeAba = baseHomeDaUrl(aba.url);
    if (homeAba) return homeAba;
  }
  const { flowBaseHome, flowConta, flowConfig, flowSeletores } = await chrome.storage.local.get([
    'flowBaseHome', 'flowConta', 'flowConfig', 'flowSeletores',
  ]);
  if (flowBaseHome && ehAbaFlow(flowBaseHome)) return aplicarConta(flowBaseHome, flowConta ?? contaDaUrl(flowBaseHome));
  let base = flowSeletores?.flowUrlInicial || flowConfig?.flowUrlInicial || FLOW_PADRAO;
  if (!/^https:\/\/flow\.google\.com\//.test(base) && !/^https:\/\/labs\.google\//.test(base)) base = FLOW_PADRAO;
  if (/^https:\/\/flow\.google\.com\//.test(base)) base = 'https://flow.google.com/';
  return aplicarConta(base, flowConta ?? null);
}

async function acharAbaFlow() {
  const abas = (await chrome.tabs.query({ url: FLOW_MATCH })).filter((t) => ehAbaFlow(t.url || ''));
  if (!abas.length) return null;
  const [focada] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return (
    abas.find((t) => t.id === focada?.id) ||
    abas.find((t) => t.active && /\/project\//.test(t.url)) ||
    abas.find((t) => /\/project\//.test(t.url)) ||
    abas.find((t) => t.active) ||
    abas.find((t) => /flow\.google\.com/.test(t.url)) ||
    abas[0]
  );
}

function aguardarCarregamento(tabId, timeout = 45000) {
  return new Promise((resolve) => {
    const fim = setTimeout(() => { chrome.tabs.onUpdated.removeListener(ouvir); resolve(); }, timeout);
    function ouvir(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(fim);
        chrome.tabs.onUpdated.removeListener(ouvir);
        setTimeout(resolve, 1200);
      }
    }
    chrome.tabs.onUpdated.addListener(ouvir);
    chrome.tabs.get(tabId).then((t) => { if (t.status === 'complete') { clearTimeout(fim); chrome.tabs.onUpdated.removeListener(ouvir); resolve(); } }).catch(() => {});
  });
}

async function navegar(aba, url) {
  await chrome.tabs.update(aba.id, { url, active: true });
  await new Promise((r) => setTimeout(r, 400));
  await aguardarCarregamento(aba.id);
  const atual = await chrome.tabs.get(aba.id);
  await lembrarConta(atual.url || '');
  return atual;
}

/** Garante uma aba do Flow aberta; se url for informada, navega para ela preservando /u/<conta>/. */
async function garantirAbaFlow(url) {
  let aba = await acharAbaFlow();
  const conta = await contaAtual(aba);
  if (url) url = aplicarConta(url, conta);
  if (!aba) {
    const destino = url || (await urlHomeFlow(null));
    aba = await chrome.tabs.create({ url: destino, active: true });
    await aguardarCarregamento(aba.id);
    const atual = await chrome.tabs.get(aba.id);
    await lembrarConta(atual.url || '');
    return atual;
  }
  if (url && !(aba.url || '').startsWith(url.replace(/[?#].*$/, ''))) return await navegar(aba, url);
  return aba;
}

/** Vai para a home do Flow na MESMA conta (/u/<n>/) da aba do usuario. */
async function irParaHomeFlow() {
  const aba = await acharAbaFlow();
  const home = await urlHomeFlow(aba);
  if (!aba) return await garantirAbaFlow(home);
  if (/\/project\//.test(aba.url || '') || contaDaUrl(aba.url) !== contaDaUrl(home)) return await navegar(aba, home);
  return aba;
}

/** Injeta os content scripts nas abas do Flow ja abertas (ao instalar/recarregar/iniciar). */
async function injetarNasAbasAbertas() {
  const abas = (await chrome.tabs.query({ url: FLOW_MATCH })).filter((t) => ehAbaFlow(t.url || ''));
  for (const t of abas) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ARQUIVOS_CONTENT });
      await lembrarConta(t.url);
    } catch (e) {
      console.warn('Não foi possível injetar na aba', t.url, e?.message);
    }
  }
  if (abas.length) reportarStatusFlow();
}

/** Envia mensagem ao content script; injeta os scripts se ainda nao estiverem na pagina. */
async function enviarParaAba(tabId, mensagem) {
  try {
    return await chrome.tabs.sendMessage(tabId, mensagem);
  } catch (e) {
    if (!/Receiving end does not exist|Could not establish connection/i.test(e?.message || '')) throw e;
    await chrome.scripting.executeScript({ target: { tabId }, files: ARQUIVOS_CONTENT });
    await new Promise((r) => setTimeout(r, 300));
    return await chrome.tabs.sendMessage(tabId, mensagem);
  }
}

async function enviarParaAbaOuErro(tabId, mensagem) {
  const r = await enviarParaAba(tabId, mensagem);
  if (!r) throw new Error('A aba do Google Flow não respondeu.');
  if (r.ok === false) throw new Error(r.erro || 'Falha na aba do Google Flow.');
  return r.data ?? r;
}

// ---------------- Comandos vindos do app -----------------
async function criarNovoProjetoNaContaAtiva(payload = {}) {
  const abaOriginal = await acharAbaFlow();
  const conta = await contaAtual(abaOriginal);
  const aba = await irParaHomeFlow();
  await chrome.tabs.update(aba.id, { active: true });
  let r;
  try {
    r = await enviarParaAbaOuErro(aba.id, { acao: 'criar_projeto', payload: { ...payload, conta } });
  } catch (e) {
    // Se o Flow recarregou a pagina ao abrir o projeto, o content script morre antes de responder.
    await new Promise((ok) => setTimeout(ok, 2500));
    const atual = await chrome.tabs.get(aba.id);
    if (!/\/project\//.test(atual.url || '')) throw e;
    await aguardarCarregamento(aba.id);
    r = { url: atual.url, contaPagina: contaDaUrl(atual.url) };
    try { await enviarParaAbaOuErro(aba.id, { acao: 'renomear_projeto', payload: { nome: payload.nome } }); } catch {}
  }
  const contaPagina = r.contaPagina !== undefined ? r.contaPagina : contaDaUrl(r.url || '');
  if (r.url && conta != null && contaPagina !== conta) {
    const corrigida = aplicarConta(r.url, conta);
    enviar({ type: 'log', nivel: 'aviso', msg: `Flow mudou de conta (/u/${contaPagina ?? '-'}/). Corrigindo para /u/${conta}/.` });
    await navegar(aba, corrigida);
    r.url = corrigida;
  }
  r.conta = conta;
  return r;
}

async function executarComando(comando, payload) {
  switch (comando) {
    case 'status': {
      const aba = await acharAbaFlow();
      return { flowAberto: !!aba, flowUrl: aba?.url || null, conta: await contaAtual(aba), versao: VERSAO };
    }
    case 'mapear':
      return await capturarMapa(payload);
    case 'criar_projeto':
      return await criarNovoProjetoNaContaAtiva(payload);
    case 'abrir_projeto': {
      const abaAntes = await acharAbaFlow();
      const contaAtiva = await contaAtual(abaAntes);
      // v1.9.6: troca de conta quando acabam os creditos — o usuario abriu MANUALMENTE outra conta/projeto na aba ativa.
      // Adota o projeto aberto (ou cria um novo na conta nova) sem redirecionar de volta para a conta sem creditos.
      if (!payload?.naoRecriarProjeto && abaAntes?.url && payload?.url) {
        const pidAba = (abaAntes.url.match(/\/project\/([^/?#]+)/) || [])[1] || null;
        const pidAlvo = (payload.url.match(/\/project\/([^/?#]+)/) || [])[1] || null;
        const contaAlvo = contaDaUrl(payload.url);
        const contaMudou = contaAtiva != null && contaAlvo != null && contaAtiva !== contaAlvo;
        if (pidAba && pidAlvo && pidAba !== pidAlvo && (contaMudou || payload.adotarProjetoAbertoSeDiferente)) {
          await chrome.tabs.update(abaAntes.id, { active: true });
          const pronto = await enviarParaAbaOuErro(abaAntes.id, { acao: 'aguardar_pronto', payload: { url: abaAntes.url } });
          if (!pronto?.inacessivel) {
            enviar({ type: 'log', nivel: 'aviso', msg: `Conta/projeto trocado manualmente na aba do Flow (/u/${contaAtiva ?? '-'}/) — adotando este projeto para continuar a novela.` });
            return { ...pronto, url: abaAntes.url, adotadoProjetoAberto: true, contaAnterior: contaAlvo };
          }
        }
        if (!pidAba && contaMudou && ehAbaFlow(abaAntes.url)) {
          enviar({ type: 'log', nivel: 'aviso', msg: `Aba do Flow está na conta /u/${contaAtiva}/ (projeto anterior era da /u/${contaAlvo}/) — criando projeto novo nesta conta.` });
          const novo = await criarNovoProjetoNaContaAtiva({ nome: payload.nome || 'Novela', novelaId: payload.novelaId });
          return { ...novo, recriadoEmNovaConta: true, motivoAnterior: 'troca manual de conta' };
        }
      }
      let motivoRecriar = null;
      try {
        const aba = await garantirAbaFlow(payload.url);
        await chrome.tabs.update(aba.id, { active: true });
        if (!/\/project\//.test(aba.url || '')) {
          motivoRecriar = 'Redirecionado para fora do projeto anterior (outra conta ou 404)';
        } else {
          const pronto = await enviarParaAbaOuErro(aba.id, { acao: 'aguardar_pronto', payload });
          if (pronto?.inacessivel) {
            motivoRecriar = pronto.motivo || 'Projeto anterior não encontrado nesta conta';
          } else {
            return pronto;
          }
        }
      } catch (e) {
        motivoRecriar = e?.message || 'Falha ao acessar o projeto anterior';
      }
      if (payload?.naoRecriarProjeto) {
        throw new Error(`Não foi possível abrir o projeto original no Google Flow (${motivoRecriar}). Verifique se a aba do Flow está logada na mesma conta Google onde os vídeos foram gerados.`);
      }
      // ETAPA 2: Nao falhar! Cria automaticamente um Novo Projeto na conta Google ativa atual.
      enviar({
        type: 'log',
        nivel: 'aviso',
        msg: `Projeto anterior inacessível na conta atual${contaAtiva != null ? ` (/u/${contaAtiva}/)` : ''} (${motivoRecriar}). Criando novo projeto automaticamente...`,
      });
      const novo = await criarNovoProjetoNaContaAtiva({ nome: payload.nome || 'Novela', novelaId: payload.novelaId });
      return { ...novo, recriadoEmNovaConta: true, motivoAnterior: motivoRecriar };
    }
    case 'limpar_composer': {
      const aba = await acharAbaFlow();
      if (!aba) return { ok: false };
      return await enviarParaAba(aba.id, { acao: 'limpar_composer', payload }).catch(() => ({ ok: false }));
    }
    case 'executar_item': {
      // sempre dentro do projeto DESTA novela (nunca mistura ativos entre novelas)
      const aba = await garantirAbaFlow(payload.novela?.flowProjectUrl || undefined);
      await chrome.tabs.update(aba.id, { active: true });
      await chrome.windows.update(aba.windowId, { focused: true }).catch(() => {});
      const r = await enviarParaAbaOuErro(aba.id, { acao: 'executar_item', payload });
      // NUNCA repassar URL crua: o Node (e o service worker) nao tem a sessao do Google e recebe a pagina de login (HTML).
      if (!r.base64 && !r.arquivoLocal) throw new Error('A extensão não obteve o arquivo gerado (nem download nem mídia validada).');
      delete r.url;
      return r;
    }
    case 'baixar_item': {
      const aba = await garantirAbaFlow(payload.novela?.flowProjectUrl || undefined);
      await chrome.tabs.update(aba.id, { active: true });
      const r = await enviarParaAbaOuErro(aba.id, { acao: 'baixar_item', payload });
      if (!r.base64 && !r.arquivoLocal) throw new Error('Não foi possível obter o arquivo do Flow.');
      delete r.url;
      return r;
    }
    case 'escanear_videos_projeto': {
      const urlAlvo = payload.flowProjectUrl || payload.novela?.flowProjectUrl || undefined;
      const aba = await garantirAbaFlow(urlAlvo);
      await chrome.tabs.update(aba.id, { active: true });
      await chrome.windows.update(aba.windowId, { focused: true }).catch(() => {});
      await enviarParaAbaOuErro(aba.id, { acao: 'aguardar_pronto', payload: { url: urlAlvo } });
      return await enviarParaAbaOuErro(aba.id, { acao: 'escanear_videos_projeto', payload });
    }
    case 'baixar_card_escaneado': {
      const urlAlvo = payload.novela?.flowProjectUrl || payload.flowProjectUrl || undefined;
      const aba = await garantirAbaFlow(urlAlvo);
      await chrome.tabs.update(aba.id, { active: true });
      await chrome.windows.update(aba.windowId, { focused: true }).catch(() => {});
      const r = await enviarParaAbaOuErro(aba.id, { acao: 'baixar_card_escaneado', payload });
      if (!r.base64 && !r.arquivoLocal) throw new Error('Não foi possível obter o arquivo de vídeo do card escaneado.');
      delete r.url;
      return r;
    }
    case 'recarregar_extensao': {
      setTimeout(() => chrome.runtime.reload(), 200);
      return { ok: true, recarregando: true };
    }
    default:
      throw new Error(`Comando desconhecido: ${comando}`);
  }
}

// ---------------- Mapeamento DOM -----------------
async function capturarMapa({ modo = 'novo', rotulo = '' } = {}) {
  const aba = await acharAbaFlow();
  if (!aba) throw new Error('Abra o Google Flow (flow.google.com) em uma aba antes de mapear.');
  const relatorio = await enviarParaAbaOuErro(aba.id, { acao: 'mapear', payload: { rotulo } });
  const r = await enviarMapaServidor({ modo, rotulo, relatorio });
  const resumo = {
    ok: true,
    modo,
    rotulo: rotulo || (modo === 'novo' ? 'Captura principal' : 'Captura complementar'),
    elementos: relatorio.elementos?.length || 0,
    menus: relatorio.menusAbertos?.length || 0,
    ativos: relatorio.ativos?.length || 0,
    totalCapturas: r.totalCapturas,
    numero: r.numero,
    quando: new Date().toISOString(),
  };
  await chrome.storage.local.set({ ultimoMapa: resumo });
  chrome.runtime.sendMessage({ tipo: 'mapa_concluido', resumo }).catch(() => {});
  return resumo;
}

function enviarMapaServidor(dados) {
  if (conectado) {
    return new Promise((resolve, reject) => {
      const requestId = `m${Date.now()}_${++seq}`;
      const t = setTimeout(() => { aguardandoAck.delete(requestId); reject(new Error('Servidor não confirmou o salvamento do mapa.')); }, 30000);
      aguardandoAck.set(requestId, {
        resolve: (v) => { clearTimeout(t); resolve(v); },
        reject: (e) => { clearTimeout(t); reject(e); },
      });
      enviar({ type: 'dom_map', requestId, ...dados });
    });
  }
  // Fallback HTTP
  return fetch(`${SERVIDOR_HTTP}/api/dom-map`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados),
  }).then(async (r) => {
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.erro || `HTTP ${r.status}`);
    return j;
  }).catch((e) => { throw new Error(`App local não está rodando (abra o Iniciar_Flow_Studio.bat). ${e.message}`); });
}

// ---------------- Captura de downloads do Flow (resolucao maxima) -----------------
// O content script clica em "Download > maior resolução"; aqui o arquivo é salvo em
// Downloads/FlowNovelaStudio_tmp/ e o caminho é enviado ao servidor, que move para a pasta da novela.
let capturaDl = null;

function extensaoDownload(item) {
  const m = (item.filename || '').match(/\.([a-z0-9]{2,5})$/i);
  if (m) return m[1].toLowerCase();
  const mime = item.mime || '';
  if (mime.includes('mp4')) return 'mp4';
  if (mime.includes('png')) return 'png';
  if (mime.includes('jpeg')) return 'jpg';
  if (mime.includes('webp')) return 'webp';
  return 'bin';
}

function iniciarCapturaDownload(nomeBase, timeoutMs = 600000, inicioMs = 0) {
  if (capturaDl) capturaDl.rejeitar(new Error('Captura substituída por outra.'));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      if (capturaDl?.timer === timer) capturaDl = null;
      reject(new Error('O download do Flow não terminou a tempo.'));
    }, timeoutMs);
    // se nenhum download COMECAR em inicioMs, desiste cedo (o content usa a midia direta)
    const timerInicio = inicioMs > 0 ? setTimeout(() => {
      if (capturaDl?.timer === timer && capturaDl.id == null) capturaDl.rejeitar(new Error(`O Flow não iniciou nenhum download em ${Math.round(inicioMs / 1000)}s.`));
    }, inicioMs) : null;
    capturaDl = {
      nomeBase: String(nomeBase || 'arquivo').replace(/\.[a-z0-9]{2,5}$/i, '').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_'),
      id: null,
      timer,
      resolver: (v) => { clearTimeout(timer); clearTimeout(timerInicio); capturaDl = null; resolve(v); },
      rejeitar: (e) => { clearTimeout(timer); clearTimeout(timerInicio); capturaDl = null; reject(e); },
    };
  });
}

chrome.downloads.onCreated.addListener((item) => {
  if (capturaDl && capturaDl.id == null) capturaDl.id = item.id;
});

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const c = capturaDl;
  if (c && (c.id == null || c.id === item.id)) {
    c.id = item.id;
    suggest({ filename: `FlowNovelaStudio_tmp/${Date.now()}_${c.nomeBase}.${extensaoDownload(item)}`, conflictAction: 'uniquify' });
    return;
  }
  suggest();
});

chrome.downloads.onChanged.addListener(async (delta) => {
  const c = capturaDl;
  if (!c || delta.id !== c.id) return;
  // SO conclui quando o navegador marca 'complete' (nunca durante in_progress/.crdownload)
  if (delta.state?.current === 'complete') {
    const [it] = await chrome.downloads.search({ id: delta.id });
    if (!it?.filename) return c.rejeitar(new Error('Download concluído mas sem caminho de arquivo.'));
    if (it.exists === false) return c.rejeitar(new Error('O arquivo baixado não existe mais no disco.'));
    if (/\.crdownload$|\.tmp$/i.test(it.filename)) return c.rejeitar(new Error('Download ainda temporário (.crdownload).'));
    if (/text\/html|application\/json/i.test(it.mime || '')) return c.rejeitar(new Error(`O Flow devolveu ${it.mime} em vez da mídia (provável página de login).`));
    const bytes = it.fileSize || it.totalBytes || it.bytesReceived || 0;
    if (bytes > 0 && bytes < 10 * 1024) return c.rejeitar(new Error(`Arquivo baixado pequeno demais (${bytes} bytes).`));
    c.resolver({ arquivoLocal: it.filename, mime: it.mime, bytes, url: it.finalUrl || it.url });
  } else if (delta.state?.current === 'interrupted') {
    c.rejeitar(new Error(`Download interrompido (${delta.error?.current || 'erro'}).`));
  }
});

/** Baixa uma URL pelo proprio navegador (usa os cookies/sessao do usuario) e devolve o caminho no disco. */
async function baixarUrlNavegador(url, nomeBase, timeoutMs = 300000) {
  if (!/^https:/.test(url || '')) throw new Error('URL inválida para download.');
  const p = iniciarCapturaDownload(nomeBase, timeoutMs, 60000);
  try {
    await chrome.downloads.download({ url, saveAs: false, conflictAction: 'uniquify' });
  } catch (e) {
    capturaDl?.rejeitar(e);
  }
  return p;
}

// ---------------- Eventos confiaveis (isTrusted) via chrome.debugger -----------------
// O Flow ignora cliques/teclas sinteticos em varios controles (envio, menus, "Concluir" do renomear).
// Sessao PERSISTENTE: anexa 1 vez e solta depois de 12s sem uso (a faixa "depurando" aparece 1 vez so).
const sessoesDebugger = new Map(); // tabId -> { timer, desde }
const esperasEventos = new Set();

chrome.debugger.onDetach.addListener((src) => sessoesDebugger.delete(src.tabId));
chrome.debugger.onEvent.addListener((src, metodo, params) => {
  for (const e of [...esperasEventos]) {
    if (e.tabId === src.tabId && e.metodo === metodo) { esperasEventos.delete(e); clearTimeout(e.timer); e.resolve(params); }
  }
});
function esperarEvento(tabId, metodo, timeoutMs) {
  return new Promise((resolve, reject) => {
    const e = { tabId, metodo, resolve };
    e.timer = setTimeout(() => { esperasEventos.delete(e); reject(new Error(`Evento ${metodo} não chegou em ${timeoutMs / 1000}s.`)); }, timeoutMs);
    esperasEventos.add(e);
  });
}

async function garantirDebugger(tabId) {
  let s = sessoesDebugger.get(tabId);
  let novo = false;
  if (!s) {
    try { await chrome.debugger.attach({ tabId }, '1.3'); novo = true; }
    catch (e) { if (!/already attached/i.test(e?.message || '')) throw e; }
    s = { desde: Date.now() };
    sessoesDebugger.set(tabId, s);
  }
  clearTimeout(s.timer);
  s.timer = setTimeout(() => { chrome.debugger.detach({ tabId }).catch(() => {}); sessoesDebugger.delete(tabId); }, 12000);
  if (novo) await new Promise((r) => setTimeout(r, 450)); // a faixa do debugger desloca a pagina
  return novo;
}

async function comDebugger(tabId, fn) {
  await garantirDebugger(tabId);
  const r = await fn((metodo, params) => chrome.debugger.sendCommand({ tabId }, metodo, params));
  await garantirDebugger(tabId); // renova o tempo da sessao
  return r;
}

/** Garante coordenadas positivas validas (nunca 0,0) e zero leitura de atributo injetado no DOM. */
function normalizarCoordsValidas(x, y) {
  const cx = Number(x);
  const cy = Number(y);
  const xFinal = Number.isFinite(cx) && cx > 4 ? Math.round(cx) : Math.round(120 + Math.random() * 80);
  const yFinal = Number.isFinite(cy) && cy > 4 ? Math.round(cy) : Math.round(120 + Math.random() * 80);
  return [xFinal, yFinal];
}

async function cliqueConfiavel(tabId, x, y) {
  return comDebugger(tabId, async (cmd) => {
    const [cx, cy] = normalizarCoordsValidas(x, y);
    const base = { x: cx, y: cy, button: 'left', clickCount: 1 };
    await cmd('Input.dispatchMouseEvent', { type: 'mouseMoved', x: Math.max(4, cx - 6), y: Math.max(4, cy - 6) });
    await cmd('Input.dispatchMouseEvent', { type: 'mouseMoved', x: cx, y: cy });
    await new Promise((r) => setTimeout(r, 80));
    await cmd('Input.dispatchMouseEvent', { ...base, type: 'mousePressed', buttons: 1 });
    await new Promise((r) => setTimeout(r, 60));
    await cmd('Input.dispatchMouseEvent', { ...base, type: 'mouseReleased', buttons: 0 });
    return true;
  });
}

/** Passa o mouse real por cima (hover de verdade: o Flow mostra os botoes do card so com :hover). */
async function hoverConfiavel(tabId, x, y) {
  return comDebugger(tabId, async (cmd) => {
    const [cx, cy] = normalizarCoordsValidas(x, y);
    await cmd('Input.dispatchMouseEvent', { type: 'mouseMoved', x: Math.max(4, cx - 10), y: Math.max(4, cy - 10) });
    await cmd('Input.dispatchMouseEvent', { type: 'mouseMoved', x: cx, y: cy });
    return true;
  });
}

const TECLAS = {
  Enter: { code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13, text: '\r' },
  Backspace: { code: 'Backspace', windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 },
  Delete: { code: 'Delete', windowsVirtualKeyCode: 46, nativeVirtualKeyCode: 46 },
  Escape: { code: 'Escape', windowsVirtualKeyCode: 27, nativeVirtualKeyCode: 27 },
  End: { code: 'End', windowsVirtualKeyCode: 35, nativeVirtualKeyCode: 35 },
};

/** key: 'Enter' | 'Backspace' | 'Delete' | 'Escape' | 'End' | 'ctrl+a' */
async function teclaConfiavel(tabId, key) {
  return comDebugger(tabId, async (cmd) => {
    if (String(key).toLowerCase() === 'ctrl+a') {
      await cmd('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: 2, commands: ['selectAll'] });
      await cmd('Input.dispatchKeyEvent', { type: 'keyUp', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: 2 });
      return true;
    }
    const k = TECLAS[key] || { code: key, windowsVirtualKeyCode: 0 };
    await cmd('Input.dispatchKeyEvent', { type: k.text ? 'keyDown' : 'rawKeyDown', key, ...k, unmodifiedText: k.text });
    await cmd('Input.dispatchKeyEvent', { type: 'keyUp', key, code: k.code, windowsVirtualKeyCode: k.windowsVirtualKeyCode, nativeVirtualKeyCode: k.nativeVirtualKeyCode });
    return true;
  });
}

async function textoConfiavel(tabId, texto) {
  return comDebugger(tabId, async (cmd) => { await cmd('Input.insertText', { text: texto }); return true; });
}

/**
 * Upload REAL de um arquivo do PC no Flow:
 *  - se o alvo marcado for um <input type=file>: DOM.setFileInputFiles direto;
 *  - senao: intercepta a janela "Abrir arquivo", clica (de verdade) no botao marcado e entrega o arquivo.
 */
async function uploadConfiavel(tabId, arquivoAbs, x, y, ehFileInput = false) {
  return comDebugger(tabId, async (cmd) => {
    await cmd('DOM.enable').catch(() => {});
    await cmd('Page.enable').catch(() => {});
    if (ehFileInput) {
      const r = await cmd('Runtime.evaluate', { expression: `document.querySelector('input[type="file"]')` });
      if (r?.result?.objectId) {
        await cmd('DOM.setFileInputFiles', { files: [arquivoAbs], objectId: r.result.objectId });
        return { modo: 'input' };
      }
    }
    await cmd('Page.setInterceptFileChooserDialog', { enabled: true });
    try {
      const espera = esperarEvento(tabId, 'Page.fileChooserOpened', 8000);
      const [cx, cy] = normalizarCoordsValidas(x, y);
      const base = { x: cx, y: cy, button: 'left', clickCount: 1 };
      await cmd('Input.dispatchMouseEvent', { type: 'mouseMoved', x: cx, y: cy });
      await cmd('Input.dispatchMouseEvent', { ...base, type: 'mousePressed', buttons: 1 });
      await cmd('Input.dispatchMouseEvent', { ...base, type: 'mouseReleased', buttons: 0 });
      const ev = await espera;
      await cmd('DOM.setFileInputFiles', { files: [arquivoAbs], backendNodeId: ev.backendNodeId });
      return { modo: 'seletor-de-arquivo' };
    } finally {
      await cmd('Page.setInterceptFileChooserDialog', { enabled: false }).catch(() => {});
    }
  });
}

/** Le um arquivo salvo no PC pelo servidor local e devolve em base64 (para colar/soltar no Flow). */
async function arquivoLocalBase64(url) {
  if (!/^http:\/\/(localhost|127\.0\.0\.1):3456\//.test(url || '')) throw new Error('URL local inválida.');
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Servidor local respondeu ${r.status}`);
  const mime = r.headers.get('content-type') || 'application/octet-stream';
  const buf = new Uint8Array(await r.arrayBuffer());
  let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return { base64: btoa(bin), mime, tamanho: buf.length };
}

// ---------------- Mensagens do popup e do content script -----------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // vindas do content script
  const confiaveis = ['clique_confiavel', 'tecla_confiavel', 'texto_confiavel', 'hover_confiavel', 'upload_confiavel', 'arquivo_local'];
  if (confiaveis.includes(msg?.tipo)) {
    const tabId = sender.tab?.id;
    const acao = {
      clique_confiavel: () => cliqueConfiavel(tabId, msg.x, msg.y),
      hover_confiavel: () => hoverConfiavel(tabId, msg.x, msg.y),
      tecla_confiavel: () => teclaConfiavel(tabId, msg.key),
      texto_confiavel: () => textoConfiavel(tabId, msg.texto),
      upload_confiavel: () => uploadConfiavel(tabId, msg.arquivoAbs, msg.x, msg.y, msg.ehFileInput),
      arquivo_local: () => arquivoLocalBase64(msg.url),
    }[msg.tipo]();
    acao.then((r) => sendResponse({ ok: true, ...(r && typeof r === 'object' ? r : {}) }))
      .catch((e) => sendResponse({ ok: false, erro: e?.message || String(e) }));
    return true;
  }
  if (msg?.tipo === 'download_capturar') {
    iniciarCapturaDownload(msg.nomeBase, msg.timeoutMs, msg.inicioMs)
      .then((r) => sendResponse({ ok: true, ...r }))
      .catch((e) => sendResponse({ ok: false, erro: e.message }));
    return true;
  }
  if (msg?.tipo === 'baixar_url') {
    baixarUrlNavegador(msg.url, msg.nomeBase, msg.timeoutMs)
      .then((r) => sendResponse({ ok: true, ...r }))
      .catch((e) => sendResponse({ ok: false, erro: e.message }));
    return true;
  }
  if (msg?.tipo === 'tamanho_url') {
    fetch(msg.url, { credentials: 'include' })
      .then(async (r) => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return (await r.arrayBuffer()).byteLength; })
      .then((tamanho) => sendResponse({ ok: true, tamanho }))
      .catch((e) => sendResponse({ ok: false, erro: e.message }));
    return true;
  }
  if (msg?.tipo === 'download_cancelar') { capturaDl?.rejeitar(new Error('Cancelado.')); return; }
  if (msg?.tipo === 'progresso') { enviar({ type: 'progresso', ...msg }); return; }
  if (msg?.tipo === 'log') { enviar({ type: 'log', msg: msg.msg, nivel: msg.nivel }); return; }
  if (msg?.tipo === 'clique_gravado') { enviar({ type: 'clique_gravado', descricao: msg.descricao }); return; }

  // vindas do popup
  if (!msg?.acao) return;
  (async () => {
    switch (msg.acao) {
      case 'status': {
        if (!conectado) conectar();
        const aba = await acharAbaFlow();
        const { ultimoMapa, flowSeletores } = await chrome.storage.local.get(['ultimoMapa', 'flowSeletores']);
        let gravando = false;
        if (aba) { try { gravando = !!(await enviarParaAba(aba.id, { acao: 'status_gravacao' }))?.gravando; } catch {} }
        return { conectado, flowAberto: !!aba, flowUrl: aba?.url || null, conta: await contaAtual(aba), ultimoMapa, calibrado: !!flowSeletores?.calibrado, gravando, versao: VERSAO };
      }
      case 'reconectar':
        tentativas = 0; try { ws?.close(); } catch {} conectar();
        return { ok: true };
      case 'mapear': {
        if (msg.atraso > 0) {
          setTimeout(() => capturarMapa(msg).catch((e) => {
            chrome.storage.local.set({ ultimoMapa: { ok: false, erro: e.message, quando: new Date().toISOString() } });
            chrome.runtime.sendMessage({ tipo: 'mapa_concluido', resumo: { ok: false, erro: e.message } }).catch(() => {});
          }), msg.atraso * 1000);
          return { ok: true, agendado: true };
        }
        return await capturarMapa(msg);
      }
      case 'gravar': {
        const aba = await acharAbaFlow();
        if (!aba) throw new Error('Abra o Google Flow primeiro.');
        return await enviarParaAbaOuErro(aba.id, { acao: 'gravar_cliques', payload: { ligado: !!msg.ligado } });
      }
      case 'abrir_flow':
        await irParaHomeFlow();
        return { ok: true };
      case 'abrir_estudio':
        await chrome.tabs.create({ url: SERVIDOR_HTTP });
        return { ok: true };
      case 'escanear_videos_projeto':
      case 'baixar_card_escaneado':
        return await executarComando(msg.acao, msg.payload || {});
      default:
        throw new Error('Ação desconhecida');
    }
  })()
    .then((r) => sendResponse({ ok: true, ...r }))
    .catch((e) => sendResponse({ ok: false, erro: e?.message || String(e) }));
  return true;
});

// Informa o app quando abas do Flow abrem/fecham
async function reportarStatusFlow() {
  const aba = await acharAbaFlow();
  enviar({ type: 'status_extensao', flowAberto: !!aba, flowUrl: aba?.url || null });
}
chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (info.status === 'complete') {
    if (tab?.url && ehAbaFlow(tab.url)) lembrarConta(tab.url);
    reportarStatusFlow();
  }
});
chrome.tabs.onRemoved.addListener(() => reportarStatusFlow());

// Reconexao garantida mesmo se o service worker for reiniciado
chrome.alarms.create('fns-keepalive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'fns-keepalive') { conectar(); enviar({ type: 'ping' }); } });
chrome.runtime.onStartup.addListener(() => { conectar(); injetarNasAbasAbertas(); });
chrome.runtime.onInstalled.addListener(() => { conectar(); injetarNasAbasAbertas(); });

atualizarBadge();
conectar();
injetarNasAbasAbertas();
