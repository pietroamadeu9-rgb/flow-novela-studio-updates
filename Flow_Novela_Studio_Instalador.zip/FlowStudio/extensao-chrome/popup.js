// Popup do Flow Novela Studio
const $ = (id) => document.getElementById(id);
let estado = {};

function enviar(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (r) => {
      if (chrome.runtime.lastError) resolve({ ok: false, erro: chrome.runtime.lastError.message });
      else resolve(r || { ok: false, erro: 'Sem resposta' });
    });
  });
}

function mostrar(texto, tipo = 'info') {
  const el = $('resultado');
  el.textContent = texto;
  el.className = `resultado ${tipo}`;
}

function setDot(id, classe) { $(id).className = `dot ${classe}`; }

function descreverMapa(m) {
  if (!m) return '';
  if (m.ok === false) return `❌ Falha no último mapeamento: ${m.erro}`;
  return `✅ ${m.rotulo} salva (#${m.numero})\n${m.elementos} elementos · ${m.menus} menus abertos · ${m.ativos} ativos\nTotal no mapa: ${m.totalCapturas} captura(s) → dados/flow-dom-map.json`;
}

async function atualizarStatus() {
  const r = await enviar({ acao: 'status' });
  estado = r || {};
  $('versao').textContent = r.versao || chrome.runtime.getManifest().version;

  setDot('dotServidor', r.conectado ? 'ok' : 'aviso');
  $('txtServidor').textContent = r.conectado ? 'Conectado ao Flow Novela Studio ✅' : 'Aguardando o app local (Iniciar_Flow_Studio.bat)...';

  setDot('dotFlow', r.flowAberto ? 'ok' : 'erro');
  if (r.flowAberto) {
    let host = '';
    try { host = new URL(r.flowUrl).hostname; } catch {}
    $('txtFlow').textContent = `Google Flow aberto (${host}${r.conta != null ? ` · conta /u/${r.conta}/` : ''})`;
    $('txtFlow').title = r.flowUrl || '';
  } else {
    $('txtFlow').textContent = 'Nenhuma aba do Google Flow aberta (flow.google.com)';
  }

  setDot('dotCalib', r.calibrado ? 'ok' : 'aviso');
  $('txtCalib').textContent = r.calibrado ? 'Automação calibrada e pronta' : 'Automação: aguardando calibragem (Etapa 3)';

  const semFlow = !r.flowAberto;
  ['btnMapear', 'btnComplementar', 'btnAtrasado', 'btnGravar'].forEach((id) => ($(id).disabled = semFlow));

  $('btnGravar').classList.toggle('ativo', !!r.gravando);
  $('btnGravar').textContent = r.gravando ? '⏹ Parar gravação de cliques' : '⏺ Gravar meus cliques';

  if (r.ultimoMapa && $('resultado').classList.contains('oculto')) {
    mostrar(descreverMapa(r.ultimoMapa), r.ultimoMapa.ok === false ? 'erro' : 'ok');
  }
}

async function mapear(modo, atraso = 0) {
  const rotulo = $('rotulo').value.trim();
  const botoes = ['btnMapear', 'btnComplementar', 'btnAtrasado'];
  botoes.forEach((id) => ($(id).disabled = true));
  mostrar(atraso ? `⏱ Captura agendada para daqui ${atraso}s.\nAbra agora o menu/submenu no Google Flow.` : '🔍 Varrendo a página do Google Flow...', 'info');
  const r = await enviar({ acao: 'mapear', modo, rotulo, atraso });
  botoes.forEach((id) => ($(id).disabled = false));
  if (!r.ok) return mostrar(`❌ ${r.erro}`, 'erro');
  if (r.agendado) return; // o popup provavelmente vai fechar; o resultado fica salvo
  mostrar(descreverMapa(r), 'ok');
  $('rotulo').value = '';
}

$('btnMapear').onclick = () => mapear('novo');
$('btnComplementar').onclick = () => mapear('complementar');
$('btnAtrasado').onclick = () => mapear('complementar', Number($('atraso').value));
$('atraso').onchange = () => ($('segAtraso').textContent = $('atraso').value);
$('btnGravar').onclick = async () => {
  const r = await enviar({ acao: 'gravar', ligado: !estado.gravando });
  if (!r.ok) mostrar(`❌ ${r.erro}`, 'erro');
  else mostrar(r.gravando ? '⏺ Gravando. Clique nos menus do Flow; os cliques entram na próxima captura.' : `⏹ Gravação parada (${r.cliquesPendentes} clique(s) aguardando a próxima captura).`, 'info');
  atualizarStatus();
};
$('btnReconectar').onclick = async () => { await enviar({ acao: 'reconectar' }); setTimeout(atualizarStatus, 800); };
$('btnAbrirFlow').onclick = async () => { await enviar({ acao: 'abrir_flow' }); setTimeout(atualizarStatus, 1500); };
$('btnEstudio').onclick = () => enviar({ acao: 'abrir_estudio' });

chrome.runtime.onMessage.addListener((m) => {
  if (m?.tipo === 'status_mudou') atualizarStatus();
  if (m?.tipo === 'mapa_concluido') mostrar(descreverMapa(m.resumo), m.resumo.ok === false ? 'erro' : 'ok');
});

atualizarStatus();
setInterval(atualizarStatus, 3000);
