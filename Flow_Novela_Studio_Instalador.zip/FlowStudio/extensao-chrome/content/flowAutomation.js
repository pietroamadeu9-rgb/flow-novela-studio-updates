// =============================================================
//  Flow Novela Studio - Automacao REAL do Google Flow (Etapa 3)
//  Calibrada com dados/flow-dom-map.json (flow.google.com).
//  Seletores: dados/flow-selectors.json -> chrome.storage.local.flowSeletores
// =============================================================
(function () {
  const NS = (window.FlowStudio = window.FlowStudio || {});
  // reinjecao segura: remove o ouvinte de storage da instancia anterior
  if (NS.automation?._ouvinteStorage) { try { chrome.storage.onChanged.removeListener(NS.automation._ouvinteStorage); } catch {} }

  const M = () => NS.mapper;

  // ---------- Enderecos aceitos e prefixo dinamico de conta /u/<X>/ ----------
  const HOSTS_FLOW = ['flow.google.com', 'labs.google'];
  const ehPaginaFlow = (url = location.href) => {
    try { const u = new URL(url); return u.hostname === 'flow.google.com' || (u.hostname === 'labs.google' && /\/tools\/flow/.test(u.pathname)); } catch { return false; }
  };
  function contaDaUrl(url = location.href) {
    try {
      const u = new URL(url, location.href);
      const m = u.pathname.match(/^\/u\/(\d+)(?=\/|$)/);
      if (m) return m[1];
      const au = u.searchParams.get('authuser');
      return au && /^\d+$/.test(au) ? au : null;
    } catch { return null; }
  }
  const contaAtual = () => contaDaUrl(location.href);
  function aplicarConta(url, conta = contaAtual()) {
    if (!url) return url;
    try {
      const u = new URL(url, location.href);
      if (u.hostname === 'flow.google.com') {
        const resto = u.pathname.replace(/^\/u\/\d+(?=\/|$)/, '') || '/';
        u.pathname = conta == null
          ? (resto.startsWith('/') ? resto : '/' + resto)
          : `/u/${conta}${resto.startsWith('/') ? resto : '/' + resto}`;
        return u.toString();
      }
      if (u.hostname === 'labs.google' && /\/tools\/flow/.test(u.pathname) && conta != null) {
        if (/^\/u\/\d+(?=\/|$)/.test(u.pathname)) u.pathname = u.pathname.replace(/^\/u\/\d+/, `/u/${conta}`);
        else if (u.searchParams.has('authuser')) u.searchParams.set('authuser', String(conta));
      }
      return u.toString();
    } catch { return url; }
  }
  function urlHome() {
    if (location.hostname === 'flow.google.com') return aplicarConta('https://flow.google.com/');
    const m = location.pathname.match(/^(?:\/u\/\d+)?(?:\/fx(?:\/[a-zA-Z-]+)?)?\/tools\/flow/i);
    if (m) {
      const base = `${location.origin}${m[0]}`;
      const au = new URLSearchParams(location.search).get('authuser');
      return au && /^\d+$/.test(au) && !/^\/u\/\d+/.test(location.pathname) ? `${base}?authuser=${au}` : base;
    }
    return SEL?.flowUrlLabs || 'https://labs.google/fx/pt/tools/flow';
  }

  // ---------- Erros ----------
  class NaoCalibradoError extends Error {
    constructor(chave) {
      super(`Seletor "${chave}" não está configurado em dados/flow-selectors.json.`);
      this.name = 'NaoCalibradoError';
    }
  }
  class ErroFatal extends Error { constructor(m) { super(m); this.name = 'ErroFatal'; } }

  // ---------- Seletores ----------
  let SEL = {};
  async function carregarSeletores() {
    const { flowSeletores } = await chrome.storage.local.get('flowSeletores');
    SEL = flowSeletores || {};
    return SEL;
  }
  const ouvinteStorage = (mud, area) => {
    if (area === 'local' && mud.flowSeletores) SEL = mud.flowSeletores.newValue || {};
  };
  chrome.storage.onChanged.addListener(ouvinteStorage);

  function obter(caminho, obrigatorio = true) {
    const v = caminho.split('.').reduce((o, k) => (o == null ? o : o[k]), SEL);
    if ((v == null || v === '') && obrigatorio) throw new NaoCalibradoError(caminho);
    return v;
  }
  function substituir(spec, vars = {}) {
    if (spec == null) return spec;
    if (typeof spec === 'string') return spec.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
    if (Array.isArray(spec)) return spec.map((s) => substituir(s, vars));
    if (typeof spec === 'object') return Object.fromEntries(Object.entries(spec).map(([k, v]) => [k, substituir(v, vars)]));
    return spec;
  }

  // ---------- utilitarios ----------
  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  const humano = (min = 150, max = 400) => dormir(min + Math.random() * (max - min));
  const normal = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const limpar = (s, n = 200) => { const t = String(s || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n) + '…' : t; };
  /** Normaliza nome de modelo: sem emoji/simbolos ("🍌 Nano Banana 2.1" -> "nano banana 2.1") */
  const normModelo = (s) => normal(String(s || '').replace(/[^\p{L}\p{N}.\s]/gu, ' '));
  const rotulo = (el) => M().nomeAcessivel(el) || (M().textosIcones(el) || []).join(' ') || limpar(el.innerText, 60);

  function progresso(ctx, texto) {
    try { chrome.runtime.sendMessage({ tipo: 'progresso', novelaId: ctx?.novelaId, itemId: ctx?.itemId, texto }); } catch {}
  }
  function logExt(msg, nivel = 'info') {
    try { chrome.runtime.sendMessage({ tipo: 'log', msg, nivel }); } catch {}
  }

  // ---------- localizadores ----------
  function confere(valor, esperado, spec) {
    if (esperado == null) return true;
    if (spec.regex) { try { return new RegExp(esperado, 'i').test(valor || ''); } catch { return false; } }
    if (spec.exato) return normal(valor) === normal(esperado);
    return normal(valor) === normal(esperado) || normal(valor).includes(normal(esperado));
  }

  /** Testa os filtros (nome/texto/aria/placeholder/icone) de UM spec contra um elemento. */
  function passaFiltros(el, spec) {
    if (!el || el.nodeType !== 1) return false;
    if (spec.css && !el.matches(spec.css)) return false;
    if (spec.role && el.getAttribute('role') !== spec.role) return false;
    if (spec.nome != null && !confere(M().nomeAcessivel(el), spec.nome, spec)) return false;
    if (spec.texto != null && !confere(el.innerText || el.textContent, spec.texto, spec)) return false;
    if (spec.ariaLabel != null && !confere(el.getAttribute('aria-label'), spec.ariaLabel, spec)) return false;
    if (spec.placeholder != null && !confere(el.getAttribute('placeholder'), spec.placeholder, spec)) return false;
    if (spec.icone != null && !(M().textosIcones(el) || []).includes(spec.icone)) return false;
    return true;
  }
  /** Aceita spec unico ou lista de alternativas. */
  function combinaAlguma(el, specs) {
    const lista = Array.isArray(specs) ? specs : [specs];
    return lista.some((s) => passaFiltros(el, typeof s === 'string' ? { css: s } : s));
  }

  function localizarTodos(spec, raiz = document, { visivel = true } = {}) {
    if (!spec) return [];
    if (Array.isArray(spec)) {
      for (const s of spec) { const r = localizarTodos(s, raiz, { visivel }); if (r.length) return r; }
      return [];
    }
    if (typeof spec === 'string') spec = { css: spec };
    let raizes = [raiz];
    if (spec.dentroDe) { raizes = localizarTodos(spec.dentroDe, raiz); if (!raizes.length) return []; }
    let cands = [];
    for (const r of raizes) {
      const base = spec.css || (spec.role ? `[role="${spec.role}"]` : 'button, a, [role], input, textarea');
      cands.push(...(r === document ? M().buscarProfundo(base) : [...r.querySelectorAll(base)]));
    }
    const vis = spec.visivel === false ? false : visivel;
    cands = cands.filter((el) => (!vis || M().visivel(el)) && passaFiltros(el, { ...spec, css: null, role: spec.css ? spec.role : null }));
    if (typeof spec.indice === 'number') {
      const i = spec.indice < 0 ? cands.length + spec.indice : spec.indice;
      return cands[i] ? [cands[i]] : [];
    }
    return cands;
  }
  const localizar = (spec, raiz, opts) => localizarTodos(spec, raiz, opts)[0] || null;

  async function aguardar(fn, { timeout = 15000, intervalo = 250, descricao = 'condição' } = {}) {
    const fim = Date.now() + timeout;
    let ultimoErro = null;
    while (Date.now() < fim) {
      try { const r = await fn(); if (r) return r; }
      catch (e) { if (e instanceof NaoCalibradoError || e instanceof ErroFatal) throw e; ultimoErro = e; }
      await dormir(intervalo);
    }
    throw new Error(`Tempo esgotado aguardando ${descricao}.${ultimoErro ? ' (' + ultimoErro.message + ')' : ''}`);
  }
  async function aguardarElemento(caminho, vars, opts = {}) {
    const spec = substituir(obter(caminho), vars);
    return aguardar(() => localizar(spec), { descricao: `"${caminho}"`, ...opts });
  }

  // ---------- eventos reais (MODO FURTIVO: coordenadas validas dentro do elemento, nunca 0,0 e ZERO atributos no DOM) ----------
  function limparResiduosDomFurtivo() {
    try {
      const ov = document.getElementById('flow-studio-overlay');
      if (ov) ov.remove();
      document.querySelectorAll('[data-fns-alvo]').forEach((x) => x.removeAttribute('data-fns-alvo'));
    } catch {}
  }
  limparResiduosDomFurtivo();

  function coordenadasValidasElemento(el) {
    const r = el.getBoundingClientRect();
    const w = Math.max(10, r.width || 28);
    const h = Math.max(10, r.height || 28);
    // Ponto natural dentro da regiao central (35% a 65%) do elemento, nunca (0,0)
    const offsetX = w * (0.35 + Math.random() * 0.30);
    const offsetY = h * (0.35 + Math.random() * 0.30);
    const x = Math.max(6, Math.round(r.left + offsetX));
    const y = Math.max(6, Math.round(r.top + offsetY));
    const screenX = Math.max(6, Math.round((window.screenX || 0) + x));
    const screenY = Math.max(6, Math.round((window.screenY || 0) + y));
    return { x, y, screenX, screenY, rect: r };
  }

  function hover(el) {
    if (!el) return;
    el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    const { x, y, screenX, screenY } = coordenadasValidasElemento(el);
    const o = { bubbles: true, composed: true, clientX: x, clientY: y, screenX, screenY, view: window };
    const topo = document.elementFromPoint(x, y) || el;
    const cadeia = [];
    for (let n = topo; n && n !== document.documentElement; n = n.parentElement) { cadeia.push(n); if (n === el) break; }
    if (!cadeia.includes(el)) cadeia.push(el);
    cadeia.reverse().forEach((n) => {
      n.dispatchEvent(new PointerEvent('pointerover', { ...o, pointerType: 'mouse' }));
      n.dispatchEvent(new PointerEvent('pointerenter', { ...o, bubbles: false, pointerType: 'mouse' }));
      n.dispatchEvent(new MouseEvent('mouseover', o));
      n.dispatchEvent(new MouseEvent('mouseenter', { ...o, bubbles: false }));
    });
    topo.dispatchEvent(new PointerEvent('pointermove', { ...o, pointerType: 'mouse' }));
    topo.dispatchEvent(new MouseEvent('mousemove', o));
  }

  async function cliqueReal(el) {
    if (!el) throw new Error('Elemento para clicar não encontrado.');
    el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    await dormir(80);
    const { x, y, screenX, screenY } = coordenadasValidasElemento(el);
    let alvo = document.elementFromPoint(x, y);
    if (!alvo || !(alvo === el || el.contains(alvo))) alvo = el;
    const c = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX, screenY, button: 0 };
    const p = { ...c, pointerId: 1, pointerType: 'mouse', isPrimary: true };
    alvo.dispatchEvent(new PointerEvent('pointerover', p));
    alvo.dispatchEvent(new PointerEvent('pointerenter', { ...p, bubbles: false }));
    alvo.dispatchEvent(new MouseEvent('mouseover', c));
    alvo.dispatchEvent(new PointerEvent('pointerdown', { ...p, buttons: 1 }));
    alvo.dispatchEvent(new MouseEvent('mousedown', { ...c, buttons: 1 }));
    if (typeof el.focus === 'function') el.focus({ preventScroll: true });
    await dormir(45 + Math.random() * 65);
    alvo.dispatchEvent(new PointerEvent('pointerup', p));
    alvo.dispatchEvent(new MouseEvent('mouseup', c));
    alvo.dispatchEvent(new MouseEvent('click', c));
    await humano();
  }

  function tecla(alvo, key, code, keyCode) {
    alvo = alvo || document.activeElement || document.body;
    const tipos = key === 'Enter' ? ['keydown', 'keypress', 'keyup'] : ['keydown', 'keyup'];
    for (const tipo of tipos) {
      const ev = new KeyboardEvent(tipo, { key, code: code || key, bubbles: true, cancelable: true, composed: true, shiftKey: false, ctrlKey: false, altKey: false, metaKey: false });
      Object.defineProperty(ev, 'keyCode', { get: () => keyCode });
      Object.defineProperty(ev, 'which', { get: () => keyCode });
      alvo.dispatchEvent(ev);
    }
  }

  function definirValorInput(el, valor) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, valor);
    el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: String(valor) }));
  }

  /** Cola texto disparando eventos reais de input (input/textarea e editores contenteditable). */
  async function digitarTexto(el, texto) {
    el.scrollIntoView({ block: 'center' });
    el.focus();
    await dormir(80);
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      el.select?.();
      const ok = document.execCommand('insertText', false, texto);
      if (!ok || normal(el.value) !== normal(texto)) {
        definirValorInput(el, '');
        el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: texto }));
        definirValorInput(el, texto);
      }
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      // Editor rico (flow-rich-text-editor): foco + selecao total + insertText (gera beforeinput/input confiaveis)
      selecionarTudo(el);
      let ok = false;
      try { ok = document.execCommand('insertText', false, texto); } catch {}
      await dormir(120);
      if (!ok || normal(el.innerText) !== normal(texto)) {
        // Fallback: beforeinput -> altera o DOM -> input (para editores que leem o DOM)
        selecionarTudo(el);
        const antes = new InputEvent('beforeinput', { bubbles: true, cancelable: true, composed: true, inputType: 'insertReplacementText', data: texto });
        const cancelado = !el.dispatchEvent(antes);
        if (!cancelado || normal(el.innerText) !== normal(texto)) {
          el.textContent = '';
          const p = document.createElement('p');
          p.textContent = texto;
          el.appendChild(p);
        }
        el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: texto }));
        // ultimo recurso sintetico: evento de colar
        if (normal(el.innerText) !== normal(texto)) {
          selecionarTudo(el);
          const dt = new DataTransfer();
          dt.setData('text/plain', texto);
          el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        }
      }
      // posiciona o cursor no fim (alguns editores so sincronizam no selectionchange)
      const sel = window.getSelection();
      const r = document.createRange();
      r.selectNodeContents(el); r.collapse(false);
      sel.removeAllRanges(); sel.addRange(r);
      document.dispatchEvent(new Event('selectionchange'));
    }
    await humano(250, 500);
    const atual = el.value ?? el.innerText;
    if (normal(atual) !== normal(texto)) throw new Error('O texto não foi inserido corretamente no campo do Flow.');
  }

  function selecionarTudo(el) {
    el.focus();
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    sel.removeAllRanges();
    sel.addRange(range);
  }

  // ---------- eventos CONFIAVEIS (isTrusted) via background + chrome.debugger ----------
  function chamarBg(msg) {
    return new Promise((res) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => res(chrome.runtime.lastError ? { ok: false, erro: chrome.runtime.lastError.message } : r || { ok: false }));
      } catch (e) { res({ ok: false, erro: e.message }); }
    });
  }
  /** Calcula coordenadas validas dentro do elemento SEM injetar nenhum atributo customizado no DOM da pagina. */
  async function comMarcador(el, msg) {
    if (!el) return { ok: false, erro: 'elemento ausente' };
    el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    await dormir(130);
    const { x, y } = coordenadasValidasElemento(el);
    const ehFileInput = el.tagName === 'INPUT' && (el.type || '').toLowerCase() === 'file';
    return await chamarBg({ ...msg, x, y, ehFileInput });
  }
  const cliqueConfiavel = (el) => comMarcador(el, { tipo: 'clique_confiavel' });
  const hoverConfiavel = (el) => comMarcador(el, { tipo: 'hover_confiavel' });
  const uploadConfiavel = (el, arquivoAbs) => comMarcador(el, { tipo: 'upload_confiavel', arquivoAbs });
  /** Clique real (debugger); se o debugger nao estiver disponivel, clique sintetico completo. */
  async function cliqueForte(el) {
    const r = await cliqueConfiavel(el);
    if (!r?.ok) await cliqueReal(el);
    return r?.ok ? 'real' : 'sintetico';
  }
  const teclaConfiavel = (key) => chamarBg({ tipo: 'tecla_confiavel', key });
  const textoConfiavel = (texto) => chamarBg({ tipo: 'texto_confiavel', texto });

  // ---------- overlays (menus/popovers do Angular CDK) ----------
  function overlaysAbertos() {
    const panes = [...document.querySelectorAll('.cdk-overlay-pane')].filter((p) => p.children.length && M().visivel(p));
    const backdrops = [...document.querySelectorAll('.cdk-overlay-backdrop')].filter((b) => b.getBoundingClientRect().width > 0);
    return { panes, backdrops, algum: panes.length > 0 || backdrops.length > 0 };
  }
  async function fecharOverlays(max = 4) {
    for (let i = 0; i < max; i++) {
      const o = overlaysAbertos();
      if (!o.algum) return;
      tecla(document.activeElement || document.body, 'Escape', 'Escape', 27);
      await dormir(350);
      const o2 = overlaysAbertos();
      if (o2.backdrops.length) { await cliqueReal(o2.backdrops[o2.backdrops.length - 1]); await dormir(300); }
    }
  }

  // =============================================================
  //  CONFIGURACOES (painel "Gatilho de configurações")
  // =============================================================
  const painelAberto = () => localizar(obter('configuracoes.painel'));

  async function abrirConfiguracoes() {
    if (painelAberto()) return;
    await fecharOverlays();
    await cliqueReal(await aguardarElemento('configuracoes.gatilho', {}, { timeout: 10000 }));
    await aguardar(painelAberto, { timeout: 6000, descricao: 'o painel de configurações abrir' });
    await dormir(300);
  }

  async function fecharConfiguracoes() {
    for (let i = 0; i < 3 && painelAberto(); i++) {
      tecla(document.activeElement || document.body, 'Escape', 'Escape', 27);
      await dormir(400);
      if (painelAberto()) {
        const bd = overlaysAbertos().backdrops.pop();
        if (bd) await cliqueReal(bd); else await cliqueReal(localizar(obter('configuracoes.gatilho')));
        await dormir(400);
      }
    }
  }

  function grupo(chave) {
    const nome = obter(`configuracoes.grupos.${chave}`);
    return localizar(substituir(obter('configuracoes.grupo'), { nome }));
  }

  /** Seleciona um radio dentro de um grupo flow-toggles. spec = alternativas ou funcao(radios)->radio */
  async function escolherRadio(chave, spec, { opcional = false } = {}) {
    const nomeGrupo = obter(`configuracoes.grupos.${chave}`);
    const g = await aguardar(() => grupo(chave), { timeout: opcional ? 1500 : 6000, descricao: `o grupo "${nomeGrupo}"` }).catch(() => null);
    if (!g) {
      if (opcional) return false;
      throw new Error(`Grupo "${nomeGrupo}" não apareceu no painel de configurações do Flow.`);
    }
    const radios = [...g.querySelectorAll('[role="radio"]')];
    const alvo = typeof spec === 'function' ? spec(radios) : radios.find((r) => combinaAlguma(r, spec));
    if (!alvo) {
      if (opcional) return false;
      throw new Error(`Opção não encontrada em "${nomeGrupo}". Disponíveis: ${radios.map(rotulo).join(', ')}`);
    }
    const jaMarcado = (el) => el.getAttribute('aria-checked') === 'true' || el.getAttribute('aria-pressed') === 'true';
    if (!jaMarcado(alvo)) {
      await cliqueReal(alvo);
      let marcou = await aguardar(() => !alvo.isConnected || jaMarcado(alvo), { timeout: 1500 }).catch(() => false);
      if (!marcou && alvo.isConnected) {
        // Fallback real via chrome.debugger quando o Flow ignora clique sintetico no radio
        await cliqueForte(alvo);
        marcou = await aguardar(() => !alvo.isConnected || jaMarcado(alvo), { timeout: 2500 }).catch(() => false);
      }
      if (!marcou && alvo.isConnected && !opcional) {
        throw new Error(`Não consegui ativar a opção "${rotulo(alvo)}" no grupo "${nomeGrupo}" do Flow.`);
      }
      await dormir(250);
    }
    return alvo;
  }

  async function selecionarModelo(nome, ctx) {
    if (!nome) return;
    const btn = await aguardar(() => localizar(obter('configuracoes.botaoModelo')), { timeout: 4000 }).catch(() => null);
    if (!btn) { progresso(ctx, 'Seletor de modelo não encontrado — mantendo o atual'); return; }
    const alvo = normModelo(nome);
    const atual = normModelo((btn.innerText || '').replace(/arrow_drop_down/g, ''));
    if (atual && (atual === alvo || atual.startsWith(alvo + ' ') || atual.includes(alvo))) return;
    await cliqueReal(btn);
    const itens = await aguardar(() => { const l = localizarTodos(obter('configuracoes.itemMenu')); return l.length ? l : null; },
      { timeout: 5000, descricao: 'o menu de modelos abrir' });
    const pontuados = itens.map((el) => {
      const linha = normModelo((el.innerText || '').split('\n')[0]);
      const tudo = normModelo(el.innerText);
      const s = linha === alvo ? 3 : linha.startsWith(alvo) || tudo.startsWith(alvo) ? 2 : tudo.includes(alvo) ? 1 : 0;
      return { el, s, len: linha.length, linha };
    }).filter((p) => p.s > 0).sort((a, b) => b.s - a.s || a.len - b.len);
    if (!pontuados.length) {
      const disp = itens.map((e) => limpar((e.innerText || '').split('\n')[0], 40)).join(', ');
      tecla(document.activeElement, 'Escape', 'Escape', 27);
      throw new Error(`Modelo "${nome}" não existe no Flow. Disponíveis: ${disp}`);
    }
    await cliqueReal(pontuados[0].el);
    await aguardar(() => !pontuados[0].el.isConnected || !M().visivel(pontuados[0].el), { timeout: 3000 }).catch(() => {});
    await dormir(400);
  }

  const numeroResolucao = (t) => {
    t = String(t || '');
    if (/gif/i.test(t)) return -1;
    const p = t.match(/(\d{3,4})\s*p\b/i); if (p) return Number(p[1]);
    const k = t.match(/(\d)\s*k\b/i); if (k) return Number(k[1]) * 1000;
    if (/original/i.test(t)) return 1;
    return 0;
  };

  /** Qualidade de GERACAO do video conforme definida manualmente no FlowStudio (360p / 720p / 1080p / 4K). */
  async function definirResolucaoGeracao(q, ctx) {
    const bruto = numeroResolucao(q || '720p') || 720;
    const alvo = bruto === 4000 ? 2160 : bruto;
    return escolherRadio('resolucao', (radios) => {
      const lista = radios
        .map((r) => { const n = numeroResolucao(rotulo(r)); return { r, n: n === 4000 ? 2160 : n }; })
        .filter((x) => x.n > 0);
      if (!lista.length) return null;
      const exato = lista.find((x) => x.n === alvo);
      if (exato) return exato.r;
      const menores = lista.filter((x) => x.n < alvo).sort((a, b) => b.n - a.n);
      const esc = menores[0] || lista.sort((a, b) => a.n - b.n)[0];
      logExt(`Qualidade de geração ${q} não existe neste modelo — usando ${rotulo(esc.r)}.`, 'aviso');
      progresso(ctx, `Geração em ${rotulo(esc.r)}`);
      return esc.r;
    }, { opcional: true });
  }
  const definirResolucaoMaxima = () => definirResolucaoGeracao('1080p');

  /** Le a duracao atual (segundos) do slider ou do texto do gatilho ("Vídeo · 720p · 10s"). */
  function lerDuracao(slider) {
    const fontes = [slider?.closest('flow-duration-slider'), slider?.parentElement?.parentElement, localizar(obter('configuracoes.gatilho'))];
    for (const f of fontes) {
      const m = (f?.innerText || '').match(/(\d{1,2})\s*s\b/);
      if (m) return Number(m[1]);
    }
    return null;
  }

  async function definirDuracao(seg, ctx) {
    // Modelos com botoes (Omni 1.1 Flash: 4s/6s/8s/10s)
    const g = await aguardar(() => grupo('duracao'), { timeout: 1200 }).catch(() => null);
    if (g) {
      const radios = [...g.querySelectorAll('[role="radio"]')];
      const valores = radios.map((r) => ({ r, v: parseInt(rotulo(r), 10) })).filter((x) => !isNaN(x.v));
      let esc = valores.find((x) => x.v === seg);
      if (!esc) {
        esc = valores.sort((a, b) => Math.abs(a.v - seg) - Math.abs(b.v - seg))[0];
        if (!esc) throw new Error('Não encontrei as opções de duração.');
        logExt(`Este modelo não tem ${seg}s — usando ${esc.v}s.`, 'aviso');
        progresso(ctx, `Modelo sem ${seg}s: usando ${esc.v}s`);
      }
      if (esc.r.getAttribute('aria-checked') !== 'true') await cliqueReal(esc.r);
      return esc.v;
    }
    // Modelos com slider (Omni 1.2 Flash)
    const s = await aguardar(() => localizar(obter('configuracoes.sliderDuracao'), document, { visivel: false }), { timeout: 2000 }).catch(() => null);
    if (!s) { progresso(ctx, 'Controle de duração não encontrado — mantendo o atual'); return null; }
    const min = Number(s.min || 0), max = Number(s.max || 100), step = Number(s.step || 1) || 1;
    const por = async (v) => {
      definirValorInput(s, String(v));
      s.dispatchEvent(new Event('change', { bubbles: true }));
      await dormir(220);
      return lerDuracao(s);
    };
    let lido = await por(Math.min(max, Math.max(min, seg)));
    if (lido === seg || lido == null) return lido ?? seg;
    let melhor = null;
    for (let v = min; v <= max; v += step) {
      lido = await por(v);
      if (lido === seg) return seg;
      if (lido != null && (!melhor || Math.abs(lido - seg) < Math.abs(melhor.l - seg))) melhor = { v, l: lido };
    }
    if (melhor) {
      await por(melhor.v);
      logExt(`Duração de ${seg}s indisponível neste modelo — usando ${melhor.l}s.`, 'aviso');
      return melhor.l;
    }
    return null;
  }

  async function selecionarQuantidadeResultadosNoPainel(qtdAlvo = 1, { opcional = true } = {}) {
    const n = Number(qtdAlvo) === 4 ? 4 : 1;
    const chaveOp = n === 4 ? 'configuracoes.opcoes.quantidade_4' : 'configuracoes.opcoes.quantidade_1';
    const opPadrao = obter(chaveOp, false) || (n === 4
      ? [{ nome: 'x4', exato: true }, { texto: '^(x?4|4x)$', regex: true }]
      : [{ nome: 'x1', exato: true }, { texto: '^(x?1|1x)$', regex: true }]);
    return escolherRadio('quantidade', (radios) => {
      const porSpec = radios.find((r) => combinaAlguma(r, opPadrao));
      if (porSpec) return porSpec;
      const reAlvo = n === 4 ? /\b(?:x\s*4|4\s*x|4)\b/i : /\b(?:x\s*1|1\s*x|1)\b/i;
      const porRegex = radios.find((r) => reAlvo.test(rotulo(r)) || reAlvo.test(r.innerText || ''));
      if (porRegex) return porRegex;
      return n === 4 ? radios[radios.length - 1] : radios[0];
    }, { opcional });
  }

  async function restaurarQuantidadePadrao1x(ctx) {
    try {
      await fecharOverlays();
      await abrirConfiguracoes();
      await selecionarQuantidadeResultadosNoPainel(1, { opcional: true });
      await fecharConfiguracoes();
      logExt('Seletor de quantidade do Google Flow restaurado automaticamente para 1x.', 'info');
    } catch {
      try { await fecharConfiguracoes(); } catch {}
    }
  }

  async function configurar({ ehVideo, submodo, modelo, duracao, qualidadeGeracao, quantidadeResultados = 1 }, ctx) {
    const op = (k) => obter(`configuracoes.opcoes.${k}`);
    await abrirConfiguracoes();
    progresso(ctx, `Modo ${ehVideo ? 'Vídeo' : 'Imagem'}`);
    await escolherRadio('modo', op(ehVideo ? 'video' : 'imagem'));
    await dormir(400);
    progresso(ctx, `Modelo ${modelo}`);
    await selecionarModelo(modelo, ctx);
    if (!painelAberto()) await abrirConfiguracoes();
    if (ehVideo) {
      const usarElementos = submodo === 'elementos_video';
      progresso(ctx, usarElementos ? 'Tipo: Elementos / Ingredientes' : 'Tipo: Frames (Frame Inicial)');
      await escolherRadio('tipoVideo', op(usarElementos ? 'elementos' : 'frames'));
      progresso(ctx, `Qualidade de geração ${qualidadeGeracao || '720p'}`);
      await definirResolucaoGeracao(qualidadeGeracao || '720p', ctx);
      progresso(ctx, `Duração ${duracao}s`);
      await definirDuracao(duracao || 10, ctx);
    }
    progresso(ctx, 'Proporção 9:16');
    await escolherRadio('proporcao', op('proporcao_9_16'));
    const qtdAlvo = (!ehVideo && Number(quantidadeResultados) === 4) ? 4 : 1;
    if (qtdAlvo === 4) {
      progresso(ctx, '⚡ Modo Burst 4x: selecionando 4 resultados simultâneos para destravar imagem');
      logExt(`⚡ Modo Burst 4x ativado no seletor de quantidade do Google Flow para {${ctx?.itemId || 'imagem'}}.`, 'aviso');
    }
    const q = await selecionarQuantidadeResultadosNoPainel(qtdAlvo, { opcional: true });
    if (!q) logExt(`Não encontrei "Quantidade de resultados x${qtdAlvo}" — conferir no painel.`, 'aviso');
    await fecharConfiguracoes();
    // Garantia pos-fechamento: se pediu Elementos, o slot "Início" (exclusivo do modo Frame Inicial) NAO pode continuar ativo!
    if (ehVideo && submodo === 'elementos_video' && localizar(obter('ingredientes.slotInicio', false))) {
      logExt('O slot "Início" ainda estava visível — reforçando clique real na aba Elementos...', 'aviso');
      await abrirConfiguracoes();
      const gTipo = grupo('tipoVideo');
      const rElem = gTipo ? [...gTipo.querySelectorAll('[role="radio"]')].find((r) => combinaAlguma(r, op('elementos'))) : null;
      if (rElem) { await cliqueForte(rElem); await dormir(400); }
      await fecharConfiguracoes();
      // Nunca gerar em Frame Inicial por engano quando o modo Elementos foi pedido: se o slot "Início" persistir, falha com mensagem clara (o runner tenta de novo).
      if (localizar(obter('ingredientes.slotInicio', false))) {
        throw new Error('O Flow continuou em "Frame Inicial" mesmo pedindo o modo Elementos / Ingredientes. Vou tentar de novo antes de gerar.');
      }
      logExt('Modo Elementos / Ingredientes confirmado após o reforço.', 'ok');
    }
    const g = localizar(obter('configuracoes.gatilho'));
    const icones = M().textosIcones(g) || [];
    if (g && !icones.includes('crop_9_16')) throw new Error('A proporção 9:16 não ficou selecionada no Flow.');
  }

  // =============================================================
  //  INGREDIENTES (referencias por nome exato)
  // =============================================================
  const barra = () => localizar(obter('ingredientes.barra'), document, { visivel: false });
  function contarIngredientes() {
    const b = barra();
    if (!b) return 0;
    return Math.max(b.querySelectorAll('img').length, b.querySelectorAll(obter('ingredientes.chip')).length);
  }

  // ---------- v1.9.6: barreira de upload concluido + cache de ativos por projectId ----------
  const RE_TEXTO_UPLOAD = /\b(uploading|enviando|carregando|fazendo upload|processando|processing|loading)\b/i;
  const SEL_OCUPADO = '[role="progressbar"], mat-progress-spinner, mat-spinner, mat-progress-bar, .mat-mdc-progress-spinner, [aria-busy="true"], [class*="skeleton"], [class*="shimmer"]';

  /** Lista os motivos que indicam upload ainda pendente (chips da barra de comando + cards de imagem da galeria + avisos). */
  function indicadoresUploadPendentes() {
    const motivos = [];
    const b = barra();
    if (b) {
      if (b.querySelector(SEL_OCUPADO)) motivos.push('chip anexado com spinner/progresso');
      if (RE_TEXTO_UPLOAD.test(b.innerText || '')) motivos.push('chip anexado com texto de envio');
      for (const im of b.querySelectorAll('img')) {
        if (!im.complete || !im.naturalWidth) motivos.push('miniatura do chip ainda carregando');
        else if (/^(blob|data):/i.test(im.currentSrc || im.src || '')) motivos.push('miniatura ainda local (blob)');
      }
    }
    for (const t of tiles().slice(0, 14)) {
      if (ehTileDeVideo(t)) continue; // video em geracao nao e upload
      if (t.querySelector(SEL_OCUPADO) || RE_TEXTO_UPLOAD.test(t.innerText || '')) {
        motivos.push(`galeria: "${limpar(t.getAttribute('aria-label') || 'imagem', 30)}" ainda enviando`);
      }
    }
    for (const txt of avisosVisiveisForaDoPrompt()) {
      if (/upload|enviando arquivo|carregando arquivo|uploading/i.test(txt)) motivos.push(`aviso: ${limpar(txt, 60)}`);
    }
    return motivos;
  }

  /**
   * BARREIRA ESTRITA: espera TODAS as imagens anexadas terminarem de subir no Google Flow
   * (sem spinner/skeleton/aria-busy/texto de envio, miniaturas completas e registradas) + estabilizador extra.
   */
  async function aguardarUploadsConcluidos({ esperado = 0, ctx = null, timeoutMs = null, estabilizadorMs = 2500, lancarErro = true, rotulo = '' } = {}) {
    const qtd = Math.max(1, esperado || contarIngredientes() || 1);
    const limite = timeoutMs ?? 90000 * qtd;
    const inicio = Date.now();
    let estavelDesde = null;
    let soBlobDesde = null;
    let ultimoAviso = 0;
    const avaliar = () => {
      let motivos = indicadoresUploadPendentes();
      if (esperado && contarIngredientes() < esperado) motivos.push(`${contarIngredientes()}/${esperado} anexo(s) na caixa de comando`);
      const soBlob = motivos.length > 0 && motivos.every((m) => m.startsWith('miniatura ainda local'));
      if (soBlob) {
        soBlobDesde = soBlobDesde ?? Date.now();
        if (Date.now() - soBlobDesde > 30000) motivos = []; // Flow manteve preview local mas sem nenhum outro sinal de envio
      } else {
        soBlobDesde = null;
      }
      return motivos;
    };
    while (Date.now() - inicio < limite) {
      const motivos = avaliar();
      if (!motivos.length) {
        estavelDesde = estavelDesde ?? Date.now();
        if (Date.now() - estavelDesde >= 1200) {
          if (estabilizadorMs > 0) {
            progresso(ctx, `Imagens 100% enviadas — estabilizando ${Math.round(estabilizadorMs / 100) / 10}s antes de gerar`);
            await dormir(estabilizadorMs);
            if (avaliar().length) { estavelDesde = null; continue; }
          }
          return { ok: true, ms: Date.now() - inicio };
        }
      } else {
        estavelDesde = null;
        if (Date.now() - ultimoAviso > 5000) {
          ultimoAviso = Date.now();
          progresso(ctx, `Aguardando upload concluir no Flow (${motivos[0]}) · ${Math.round((Date.now() - inicio) / 1000)}s`);
        }
      }
      await dormir(400);
    }
    if (lancarErro) {
      throw new Error(`[FALHA_TECNICA] O upload das imagens não concluiu no Google Flow em ${Math.round(limite / 1000)}s${rotulo ? ` (${rotulo})` : ''}.`);
    }
    return { ok: false, ms: Date.now() - inicio };
  }

  /** projectId da URL atual do Flow (/project/<id>). */
  function projectIdDaUrl(url = location.href) {
    const m = String(url || '').match(/\/project\/([^/?#]+)/);
    return m ? m[1] : null;
  }
  const CHAVE_CACHE_ATIVOS = 'fnsAtivosPorProjeto';
  let cacheAtivosProjeto = null;
  async function carregarCacheAtivos() {
    if (cacheAtivosProjeto) return cacheAtivosProjeto;
    try { cacheAtivosProjeto = (await chrome.storage.local.get(CHAVE_CACHE_ATIVOS))[CHAVE_CACHE_ATIVOS] || {}; } catch { cacheAtivosProjeto = {}; }
    return cacheAtivosProjeto;
  }
  /** O ativo (`ref_*` / `imagem_NN`) ja foi enviado a ESTE projeto do Flow (mesmo numa tentativa que falhou)? */
  async function ativoJaSubidoNoProjeto(nome) {
    const pid = projectIdDaUrl();
    if (!pid) return false;
    const c = await carregarCacheAtivos();
    return !!c[pid]?.nomes?.includes(nome);
  }
  async function marcarAtivoNoProjeto(nome) {
    const pid = projectIdDaUrl();
    if (!pid || !nome) return;
    const c = await carregarCacheAtivos();
    const reg = c[pid] || { nomes: [] };
    if (!reg.nomes.includes(nome)) reg.nomes.push(nome);
    reg.em = Date.now();
    c[pid] = reg;
    const pids = Object.keys(c).sort((a, b) => (c[b].em || 0) - (c[a].em || 0));
    for (const velho of pids.slice(40)) delete c[velho];
    try { await chrome.storage.local.set({ [CHAVE_CACHE_ATIVOS]: c }); } catch {}
  }

  /** Assim que o upload concluir, renomeia o ativo recem-enviado (`ref_cida.jpg` -> `ref_cida`) na galeria do projeto. */
  async function renomearAtivoEnviado(nome, info, ctx) {
    const alvo = normal(nome);
    const nomesArquivo = [info?.nomeArquivo, info?.nomeArquivo && semExtMidia(info.nomeArquivo)].filter(Boolean).map(normal);
    const qtdAntes = contarIngredientes();
    rolarGradeTopo();
    await dormir(700);
    const imagens = tiles().filter((t) => !ehTileDeVideo(t)).slice(0, 30);
    if (imagens.some((t) => normal(t.getAttribute('aria-label')) === alvo)) return true;
    const tile = imagens.find((t) => nomesArquivo.includes(normal(t.getAttribute('aria-label'))));
    if (!tile) return false;
    progresso(ctx, `Renomeando upload para "${nome}" na galeria do projeto`);
    const ok = await renomearAtivo(tile, nome, ctx);
    await fecharOverlays();
    if (contarIngredientes() < qtdAntes) logExt(`Renomear "${nome}" retirou o anexo da caixa — será re-selecionado da galeria.`, 'aviso');
    return ok;
  }

  /** Sobe o arquivo do PC, espera 100% do upload, registra no cache do projeto e renomeia imediatamente. */
  async function subirEPrepararAtivo(nome, comoInicio, ctx, info) {
    await anexarPorArquivoLocal(nome, comoInicio, ctx, info);
    progresso(ctx, `Aguardando upload de "${nome}" concluir 100% no Flow...`);
    await aguardarUploadsConcluidos({ ctx, estabilizadorMs: 0, rotulo: nome });
    await marcarAtivoNoProjeto(nome);
    try {
      const ren = await renomearAtivoEnviado(nome, info, ctx);
      if (ren) logExt(`Upload "${nome}" concluído e renomeado no projeto atual do Flow.`, 'ok');
    } catch (e) {
      logExt(`Upload de "${nome}" concluído, mas não consegui renomear agora: ${e.message}`, 'aviso');
    }
  }

  async function limparIngredientes() {
    for (let i = 0; i < 15; i++) {
      const b = barra();
      if (!b) return;
      const x = [...b.querySelectorAll('mat-icon, [role="img"]')].find((e) => (e.textContent || '').trim() === 'cancel');
      if (!x) return;
      await cliqueReal(x);
      await dormir(350);
    }
  }

  function opcoesVisiveis() { return localizarTodos(obter('ingredientes.opcaoAtivo')); }
  const semExtMidia = (s) => String(s || '').replace(/\.(png|jpe?g|webp|mp4)$/i, '');
  /** Opcao da biblioteca com o NOME EXATO (aceita tambem o nome com extensao quando foi feito upload do PC). */
  function acharOpcaoExata(nome, chave) {
    const alvo = normal(nome);
    const tipos = /^(imagem|imagens|video|videos|image|images|elemento|frame|personagem)$/i;
    const ops = opcoesVisiveis();
    // 1o: a MESMA midia gerada (garante a versao NOVA apos um "Regenerar", mesmo se houver nome repetido)
    if (chave) {
      const porChave = ops.find((o) => [...o.querySelectorAll('img, video')].some((m) => chaveMidia(m) === chave));
      if (porChave) return porChave;
    }
    for (const o of ops) {
      const linhas = (o.innerText || '').split('\n').map((s) => s.trim()).filter(Boolean);
      if (linhas.some((l) => normal(l) === alvo || normal(semExtMidia(l)) === alvo)) return o;
      const n = normal(M().nomeAcessivel(o));
      if (n === alvo || normal(semExtMidia(n)) === alvo) return o;
      if (n.startsWith(alvo + ' ') && tipos.test(n.slice(alvo.length + 1))) return o;
      const nSemExt = n.replace(/\.(png|jpe?g|webp|mp4)(?=\s|$)/i, '');
      if (nSemExt.startsWith(alvo + ' ') && tipos.test(nSemExt.slice(alvo.length + 1))) return o;
    }
    return null;
  }

  class AtivoNaoEncontrado extends Error {}

  /** Uma tentativa: "+" -> aba Imagens -> pesquisar nome -> card exato -> "Incluir no comando". */
  async function anexarReferenciaUmaVez(nome, comoInicio, ctx, info, { rapido = false } = {}) {
    await fecharOverlays();
    const antes = contarIngredientes();
    let gatilho = comoInicio ? localizar(obter('ingredientes.slotInicio')) : null;
    if (!gatilho) gatilho = await aguardarElemento('ingredientes.botaoAdicionar', {}, { timeout: 8000 });
    await cliqueReal(gatilho);
    await aguardar(() => localizar(obter('ingredientes.popover')), { timeout: 8000, descricao: 'a janela de recursos abrir' });
    await dormir(500);
    const aba = localizar(obter('ingredientes.abaImagens', false));
    if (aba && aba.getAttribute('aria-selected') !== 'true') { await cliqueReal(aba); await dormir(600); }
    const busca = localizar(obter('ingredientes.busca'));
    const pesquisar = async (texto) => {
      if (!busca || !busca.isConnected) return;
      await cliqueReal(busca);
      await digitarTexto(busca, texto);
      await dormir(1200);
    };
    await pesquisar(nome);
    let opc = await aguardar(() => acharOpcaoExata(nome, info?.midiaChave), { timeout: rapido ? 3500 : 6000 }).catch(() => null);
    if (!opc && busca && !rapido) {
      // a biblioteca pode demorar 1-2s para indexar um ativo recem-renomeado: limpa e pesquisa de novo
      await pesquisar('');
      await dormir(800);
      opc = acharOpcaoExata(nome, info?.midiaChave);
      if (!opc) { await pesquisar(nome); opc = await aguardar(() => acharOpcaoExata(nome, info?.midiaChave), { timeout: 6000 }).catch(() => null); }
    }
    if (!opc) {
      const disp = opcoesVisiveis().map((o) => limpar((o.innerText || '').split('\n')[0], 30)).slice(0, 15).join(', ');
      await fecharOverlays();
      throw new AtivoNaoEncontrado(`Ativo "${nome}" não encontrado com nome exato na biblioteca do projeto. Visíveis: ${disp || 'nenhum'}`);
    }
    await cliqueReal(opc);
    const incl = await aguardar(() => localizar(obter('ingredientes.incluir')) || (contarIngredientes() > antes ? 'ok' : null),
      { timeout: 8000 }).catch(() => null);
    if (incl && incl !== 'ok') await cliqueReal(incl);
    await aguardar(() => contarIngredientes() > antes, { timeout: 12000, descricao: `"${nome}" aparecer na caixa de comando` });
    await dormir(400);
    if (localizar(obter('ingredientes.popover'))) await fecharOverlays();
  }

  /**
   * Anexa uma referencia sem apagar as anteriores, com suporte a re-upload sob demanda entre contas/projetos:
   * - Se `info.jaExisteNoProjetoAtual === false` (novo projeto em outra conta Google), sobe o arquivo salvo no PC direto!
   * - Se ja deveria estar no projeto atual, busca pelo nome -> repara nome se preciso -> fallback para upload do PC.
   */
  async function anexarReferencia(nome, comoInicio, ctx, info, ativosSubidos = null) {
    const registrar = () => { if (Array.isArray(ativosSubidos) && !ativosSubidos.includes(nome)) ativosSubidos.push(nome); };
    const temArquivo = !!(info?.arquivoUrl || info?.arquivoAbs);

    // (a) upload de uma tentativa recem-falhada ainda carregando? espera terminar antes de qualquer coisa
    await aguardarUploadsConcluidos({ ctx, estabilizadorMs: 0, timeoutMs: 90000, lancarErro: false });

    // (b) cache por projectId: ja foi subido a ESTE projeto (mesmo que a geracao anterior tenha falhado)?
    const jaNoCache = await ativoJaSubidoNoProjeto(nome);
    if (jaNoCache) logExt(`"${nome}" já foi enviado a este projeto — reutilizando da galeria (sem novo upload).`, 'info');

    if (!jaNoCache && info && info.jaExisteNoProjetoAtual === false && temArquivo) {
      // checagem rapida na galeria antes de subir (evita duplicata se o servidor nao soube da subida anterior)
      try {
        await anexarReferenciaUmaVez(nome, comoInicio, ctx, info, { rapido: true });
        await marcarAtivoNoProjeto(nome);
        logExt(`"${nome}" já existia na galeria deste projeto — selecionado sem novo upload.`, 'info');
        registrar();
        return true;
      } catch (e) {
        if (!(e instanceof AtivoNaoEncontrado)) throw e;
      }
      logExt(`Re-upload sob demanda: enviando "${nome}" do PC para o projeto atual do Flow.`, 'info');
      await subirEPrepararAtivo(nome, comoInicio, ctx, info);
      registrar();
      return true;
    }

    for (let t = 1; t <= 3; t++) {
      try {
        await anexarReferenciaUmaVez(nome, comoInicio, ctx, info);
        await marcarAtivoNoProjeto(nome);
        registrar();
        return true;
      } catch (e) {
        if (!(e instanceof AtivoNaoEncontrado)) throw e;
        if (t === 1) { progresso(ctx, `"${nome}" ainda não apareceu na biblioteca — aguardando e tentando de novo`); await dormir(2000); continue; }
        if (t === 2) {
          const ok = await repararNomeAtivo(nome, info, ctx).catch((er) => { logExt(`Reparo do nome "${nome}" falhou: ${er.message}`, 'aviso'); return false; });
          if (ok) { logExt(`Ativo "${nome}" localizado no projeto e renomeado — tentando anexar de novo.`, 'info'); await dormir(2000); continue; }
        }
        // FALLBACK ETERNO / NOVA CONTA: envia o arquivo salvo no PC (Meus_Projetos_Flow) direto para o projeto atual do Flow
        if (temArquivo) {
          logExt(`"${nome}" não está na biblioteca deste projeto — fazendo upload automático do disco.`, 'aviso');
          await subirEPrepararAtivo(nome, comoInicio, ctx, info);
          registrar();
          return true;
        }
        throw new Error(e.message + ' (e não há arquivo salvo no PC para enviar).');
      }
    }
  }

  function base64ParaFile(base64, mime, nomeArquivo) {
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], nomeArquivo, { type: mime || 'image/jpeg', lastModified: Date.now() });
  }

  /** Botao de upload dentro do "+" (ou do menu "adicionar arquivos" do cabecalho). */
  function acharBotaoUpload(raiz = document) {
    const cands = M().buscarProfundo('button, [role="menuitem"], [role="button"], [role="tab"], label').filter((b) => raiz === document || raiz.contains(b));
    return cands.find((b) => {
      const txt = `${M().nomeAcessivel(b)} ${b.innerText || ''}`;
      const ic = M().textosIcones(b) || [];
      return /upload|enviar|carregar|fazer upload|do computador|do dispositivo|importar|adicionar arquivo|selecionar arquivo/i.test(txt)
        || ic.some((i) => /upload|file_upload|upload_file|add_photo_alternate|cloud_upload|attach_file|drive_folder_upload/.test(i));
    }) || null;
  }

  /**
   * Anexa a referencia a partir do ARQUIVO LOCAL do PC (funciona dias depois, mesmo sem nome no Flow).
   * Tenta: colar no prompt -> soltar na caixa de comando -> <input type=file> -> upload real (debugger).
   */
  async function anexarPorArquivoLocal(nome, comoInicio, ctx, info) {
    progresso(ctx, `Enviando "${nome}" do PC para o Flow`);
    let file = null;
    if (info.arquivoUrl) {
      const r = await chamarBg({ tipo: 'arquivo_local', url: info.arquivoUrl });
      if (r?.ok) file = base64ParaFile(r.base64, r.mime, info.nomeArquivo || `${nome}.jpg`);
      else logExt(`Não consegui ler o arquivo local de "${nome}": ${r?.erro}`, 'aviso');
    }
    const novoIngrediente = (antes) => aguardar(() => contarIngredientes() > antes, { timeout: 15000, intervalo: 400 }).then(() => true).catch(() => false);
    const metodos = [];
    if (file) {
      metodos.push(['colar no prompt', async () => {
        const campo = campoPrompt(); campo.focus();
        const dt = new DataTransfer(); dt.items.add(file);
        campo.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true, composed: true }));
      }]);
      metodos.push(['soltar na caixa de comando', async () => {
        const alvo = compositor() || campoPrompt();
        const r = alvo.getBoundingClientRect();
        const dt = new DataTransfer(); dt.items.add(file);
        for (const tipo of ['dragenter', 'dragover', 'drop']) {
          alvo.dispatchEvent(new DragEvent(tipo, { dataTransfer: dt, bubbles: true, cancelable: true, composed: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }));
          await dormir(120);
        }
      }]);
      metodos.push(['input de arquivo da página', async () => {
        const inp = M().buscarProfundo('input[type="file"]').find((i) => !i.accept || /image|\*/.test(i.accept));
        if (!inp) throw new Error('nenhum <input type=file> na página');
        const dt = new DataTransfer(); dt.items.add(file);
        inp.files = dt.files;
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
      }]);
    }
    const metodoDebugger = info.arquivoAbs ? ['upload real pelo seletor de arquivos (debugger)', async () => {
      let gatilho = comoInicio ? localizar(obter('ingredientes.slotInicio')) : null;
      gatilho = gatilho || localizar(obter('ingredientes.botaoAdicionar'));
      if (gatilho) {
        await cliqueForte(gatilho);
        await aguardar(() => localizar(obter('ingredientes.popover')), { timeout: 6000 }).catch(() => null);
        await dormir(500);
      }
      const pop = localizar(obter('ingredientes.popover'));
      const inpPop = pop ? [...pop.querySelectorAll('input[type="file"]')][0] : null;
      if (inpPop) { const r = await uploadConfiavel(inpPop, info.arquivoAbs); if (r?.ok) { await dormir(2500); return; } }
      let botao = acharBotaoUpload(pop || document);
      if (!botao) {
        await fecharOverlays();
        const menuArq = localizar({ css: 'button', ariaLabel: 'adicionar arquivos', regex: true });
        if (menuArq) { await cliqueForte(menuArq); await dormir(600); botao = acharBotaoUpload(document); }
      }
      if (!botao) {
        const inpGeral = M().buscarProfundo('input[type="file"]')[0];
        if (inpGeral) { const r = await uploadConfiavel(inpGeral, info.arquivoAbs); if (r?.ok) { await dormir(2500); return; } }
        throw new Error('não achei o botão de upload do Flow');
      }
      const r = await uploadConfiavel(botao, info.arquivoAbs);
      if (!r?.ok) throw new Error(r?.erro || 'upload real falhou');
      await dormir(2500);
    }] : null;

    // No modo Frame Inicial ("Início"), prioriza o upload dentro do slot "Início" antes de paste/drop genericos
    if (comoInicio && metodoDebugger) metodos.unshift(metodoDebugger);
    else if (metodoDebugger) metodos.push(metodoDebugger);
    for (const [nomeMetodo, acao] of metodos) {
      await fecharOverlays();
      const antes = contarIngredientes();
      try { await acao(); } catch (e) { logExt(`Anexar "${nome}" por ${nomeMetodo}: ${e.message}`, 'aviso'); continue; }
      if (await novoIngrediente(antes)) {
        logExt(`"${nome}" anexado a partir do arquivo do PC (${nomeMetodo}).`, 'ok');
        await fecharOverlays();
        return true;
      }
      // upload pode ter criado o ativo sem incluir: tenta achar pelo nome do arquivo e incluir
      if (nomeMetodo.startsWith('upload')) {
        for (const n of [nome, info.nomeArquivo].filter(Boolean)) {
          try { await anexarReferenciaUmaVez(n, comoInicio, ctx, null); logExt(`"${nome}" enviado do PC e incluído no comando.`, 'ok'); return true; } catch {}
        }
      }
    }
    await fecharOverlays();
    throw new Error(`Não consegui anexar "${nome}": não está na biblioteca do Flow e o envio do arquivo do PC também falhou.`);
  }

  // =============================================================
  //  PROMPT + ENVIO
  // =============================================================
  const campoPrompt = () => localizar(obter('prompt.campo'));
  const desabilitado = (b) => !b || b.disabled || b.getAttribute('aria-disabled') === 'true' || b.hasAttribute('disabled');

  /** Container do compositor (flow-base-prompt-box) que contem o campo de prompt. */
  function compositor() {
    const campo = campoPrompt();
    const sel = obter('prompt.compositor', false) || 'flow-base-prompt-box';
    return campo?.closest(sel) || localizar(sel) || campo?.parentElement?.parentElement?.parentElement || null;
  }

  /**
   * Botao principal de envio (seta ->). Ordem:
   * 1) seletores do flow-selectors.json (estrutura flow-generate-icon-button, type=submit, aria-label/icone flexiveis)
   * 2) posicao estrutural: botao mais a direita da barra inferior do compositor com seta/send ou type=submit
   */
  function acharBotaoEnviar() {
    const comp = compositor();
    const ignorar = (b) => combinaAlguma(b, obter('prompt.naoEnviar', false) || []);
    const specs = obter('prompt.gerar');
    for (const s of Array.isArray(specs) ? specs : [specs]) {
      const achados = localizarTodos(s, comp || document).filter((b) => !ignorar(b));
      if (achados.length) return achados.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right)[0];
    }
    if (!comp) return null;
    const botoes = [...comp.querySelectorAll('button, [role="button"]')].filter((b) => M().visivel(b) && !ignorar(b));
    const comSeta = botoes.filter((b) => b.type === 'submit' || (M().textosIcones(b) || []).some((i) => /arrow_forward|arrow_upward|send|north|play_arrow/.test(i)));
    const lista = comSeta.length ? comSeta : botoes;
    return lista.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right || b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom)[0] || null;
  }

  async function colarPrompt(texto, ctx) {
    const campo = await aguardarElemento('prompt.campo', {}, { timeout: 10000 });
    await cliqueReal(campo);
    await digitarTexto(campo, texto);
    // o estado reativo do Flow reconheceu o texto? (botao de envio destrava)
    const liberou = await aguardar(() => { const b = acharBotaoEnviar(); return b && !desabilitado(b); }, { timeout: 3000 }).catch(() => false);
    if (liberou) return;
    progresso(ctx, 'Reforçando digitação do prompt (eventos confiáveis)');
    logExt('O botão de envio não destravou com a digitação simulada — usando digitação confiável (debugger).', 'aviso');
    selecionarTudo(campo);
    const r = await textoConfiavel(texto);
    if (!r?.ok) logExt(`Digitação confiável falhou: ${r?.erro || '?'}`, 'aviso');
    await dormir(600);
    if (normal(campo.innerText) !== normal(texto)) {
      // o insertText confiavel pode ter somado ao texto existente: refaz do zero
      selecionarTudo(campo);
      document.execCommand('delete', false);
      await textoConfiavel(texto);
      await dormir(600);
    }
  }

  // =============================================================
  //  DETECCAO DE CREDITOS ESGOTADOS, PROJETO INACESSIVEL, ATIVIDADE INCOMUM E FALHAS
  // =============================================================
  const RE_ATIVIDADE_INCOMUM = /atividade\s+incomum|unusual\s+activity|extens[oõ]es?\s+do\s+navegador\s+que\s+modificam\s+a\s+p[aá]gina|browser\s+extensions?\s+that\s+modify|tr[aá]fego\s+incomum|unusual\s+traffic|automated\s+queries|consulta[s]?\s+automatizada|detectamos\s+uma?\s+atividade\s+incomum|bloqueio\s+tempor[aá]rio\s+de\s+seguran[cç]a/i;
  const RE_CREDITOS = /cr[eé]ditos?\s+(?:insuficientes?|esgotados?|acabaram)|sem\s+cr[eé]ditos?|n[aã]o\s+(?:h[aá]|tem|possui)\s+cr[eé]ditos?|saldo\s+de\s+cr[eé]ditos?\s+insuficiente|out\s+of\s+(?:ai\s+)?credits?|not\s+enough\s+(?:ai\s+)?credits?|insufficient\s+(?:ai\s+)?credits?|no\s+(?:ai\s+)?credits?\s+(?:left|remaining)|monthly\s+credit\s+limit|limite\s+de\s+cr[eé]ditos?\s+atingido|quota\s+exceeded|cota\s+excedida/i;
  const RE_PROJETO_INACESSIVEL = /projeto\s+n[aã]o\s+encontrado|project\s+not\s+found|n[aã]o\s+foi\s+poss[ií]vel\s+(?:abrir|carregar|encontrar)\s+o\s+projeto|unable\s+to\s+(?:open|load|find)\s+(?:the\s+)?project|voc[eê]\s+n[aã]o\s+tem\s+(?:acesso|permiss[aã]o)|you\s+don.?t\s+have\s+(?:access|permission)|acesso\s+negado|access\s+denied|permiss[aã]o\s+negada|permission\s+denied|\berro\s*(?:403|404)\b|\b(?:403|404)\s*(?:forbidden|not\s+found)\b|p[aá]gina\s+n[aã]o\s+encontrada|page\s+not\s+found/i;
  const RE_POLITICA_OU_FALHA = /falh|n[aã]o\s+foi\s+poss[ií]vel\s*(?:gerar|criar)?|nao\s+foi\s+possivel|couldn.?t\s+(?:generate|create)|unable\s+to\s+(?:generate|create)|can.?t\s+(?:generate|create)|erro\s+ao\s+gerar|something\s+went\s+wrong|failed|viola(?:tes?|r|ç[aã]o)?|pol[ií]tica|policy|guidelines|diretrizes|bloquead|blocked|unsafe|inappropriate|impr[oó]pri|tente\s+outro\s+comando|try\s+a\s+different\s+prompt|conte[uú]do\s+n[aã]o\s+permitido/i;

  function detectarAtividadeIncomum(antes = null) {
    for (const txt of avisosVisiveisForaDoPrompt()) {
      if (RE_ATIVIDADE_INCOMUM.test(txt)) return txt;
    }
    // Só inspeciona tiles se `antes` foi fornecido e APENAS para cards NOVOS desta tentativa (jamais cards antigos que já estavam na grade!)
    if (antes && antes.tiles) {
      for (const t of tiles().slice(0, 6)) {
        if (antes.tiles.has(t)) continue;
        const txt = t.innerText || '';
        if (RE_ATIVIDADE_INCOMUM.test(txt) && !/n[aã]o\s+houve\s+cobran[cç]a|no\s+charge|not\s+charged/i.test(txt)) {
          return limpar(txt, 220);
        }
      }
    }
    return null;
  }

  /** Remove da grade do Flow cards vazios que falharam em tentativas anteriores (clicando no botão `delete` do card falho). */
  async function excluirCardsFalhosVisiveis() {
    try {
      const RE = reErro();
      const candidatos = tiles().slice(0, 8);
      for (const t of candidatos) {
        if (ehCardJaRenomeado(t)) continue;
        if (chavesMidiaDoTile(t).length > 0) continue;
        const txt = t.innerText || '';
        const carregando = Boolean(/\b(\d{1,3})\s*%/.test(txt) || t.querySelector('[role="progressbar"], mat-progress-spinner, mat-spinner, mat-progress-bar'));
        if (carregando) continue;
        const falha = motivoFalhaNoCard(t, RE);
        if (!falha) continue;
        const btnDel = [...t.querySelectorAll('button')].find((b) => {
          const ic = M().textosIcones(b) || [];
          const aria = `${b.getAttribute('aria-label') || ''} ${M().nomeAcessivel(b) || ''}`;
          return ic.includes('delete') || /excluir|delete|remover|apagar/i.test(aria);
        });
        if (btnDel && M().visivel(btnDel)) {
          await cliqueReal(btnDel).catch(() => {});
          await dormir(220);
        }
      }
    } catch {}
  }

  function avisosVisiveisForaDoPrompt() {
    const campo = localizar(obter('prompt.campo', false) || 'div[role="textbox"]');
    const nos = [...document.querySelectorAll('[role="alert"], [role="status"], [role="dialog"], mat-snack-bar-container, .mat-mdc-snack-bar-container, simple-snack-bar, [aria-live="assertive"], [aria-live="polite"]')];
    return nos
      .filter((el) => M().visivel(el) && (!campo || (!campo.contains(el) && !el.contains(campo))))
      .map((el) => limpar(el.innerText || el.textContent || '', 240))
      .filter(Boolean);
  }

  function detectarCreditosEsgotados() {
    for (const txt of avisosVisiveisForaDoPrompt()) {
      if (RE_CREDITOS.test(txt)) return txt;
    }
    const comp = compositor();
    const campo = campoPrompt();
    if (comp) {
      const txtComp = [...comp.querySelectorAll('*')]
        .filter((e) => !e.children.length && (!campo || !campo.contains(e)))
        .map((e) => e.textContent || '')
        .join(' ');
      if (RE_CREDITOS.test(txtComp)) return limpar(txtComp, 200);
      const b = acharBotaoEnviar();
      const dicaBotao = `${b?.getAttribute('aria-label') || ''} ${b?.getAttribute('title') || ''}`;
      if (RE_CREDITOS.test(dicaBotao)) return limpar(dicaBotao, 200);
    }
    for (const t of tiles().slice(0, 3)) {
      const txt = t.innerText || '';
      if (RE_CREDITOS.test(txt)) return limpar(txt, 200);
    }
    return null;
  }

  function detectarProjetoInacessivel() {
    for (const txt of avisosVisiveisForaDoPrompt()) {
      if (RE_PROJETO_INACESSIVEL.test(txt)) return txt;
    }
    if (!localizar(obter('prompt.campo', false) || 'div[role="textbox"]')) {
      const textoPagina = limpar(document.body?.innerText || '', 600);
      if (RE_PROJETO_INACESSIVEL.test(textoPagina)) return textoPagina;
    }
    return null;
  }

  /** Fecha toasts/avisos de erro, limpa ingredientes e apaga texto travado na caixa de comando. */
  async function limparComposer({ limparTexto = true } = {}) {
    try {
      // Nunca remover chips no meio de um upload de tentativa anterior (isso causava re-upload duplicado em loop)
      await aguardarUploadsConcluidos({ estabilizadorMs: 0, timeoutMs: 90000, lancarErro: false });
      // Fecha snackbars / dialogs de erro se houver botao de dispensar/fechar
      const botoesAviso = [...document.querySelectorAll('mat-snack-bar-container button, .mat-mdc-snack-bar-container button, [role="alert"] button, [role="dialog"] button')]
        .filter((b) => M().visivel(b) && /fechar|dispensar|ok|entendi|dismiss|close|got\s*it|cancelar/i.test(`${M().nomeAcessivel(b)} ${b.innerText || ''}`));
      for (const b of botoesAviso.slice(0, 3)) { try { await cliqueReal(b); } catch {} }
      await fecharOverlays();
      await excluirCardsFalhosVisiveis();
      await limparIngredientes();
      if (limparTexto) {
        const campo = campoPrompt();
        if (campo && (campo.innerText || campo.value || '').trim()) {
          campo.focus();
          selecionarTudo(campo);
          try { document.execCommand('delete', false); } catch {}
          if ((campo.innerText || '').trim()) {
            await teclaConfiavel('ctrl+a').catch(() => {});
            await teclaConfiavel('Backspace').catch(() => {});
          }
        }
      }
    } catch {}
    return { ok: true };
  }

  /** A geracao comecou? (prompt saiu da caixa, apareceu card novo, ou o botao virou "parar"/sumiu) */
  function geracaoIniciou(antes, texto, btn) {
    const ativIncomum = detectarAtividadeIncomum();
    if (ativIncomum) throw new ErroFatal(`[ATIVIDADE_INCOMUM] ${ativIncomum}`);
    const semCred = detectarCreditosEsgotados();
    if (semCred) throw new ErroFatal(`[CREDITOS_ESGOTADOS] ${semCred}`);
    const projInacessivel = detectarProjetoInacessivel();
    if (projInacessivel) throw new ErroFatal(`[PROJETO_INACESSIVEL] ${projInacessivel}`);

    const alerta = avisosVisiveisForaDoPrompt().find((t) => reErro().test(t) || RE_POLITICA_OU_FALHA.test(t));
    if (alerta) {
      if (RE_ATIVIDADE_INCOMUM.test(alerta)) throw new ErroFatal('[ATIVIDADE_INCOMUM] ' + limpar(alerta));
      throw new ErroFatal('[BLOQUEIO_FLOW] Google Flow recusou o envio: ' + limpar(alerta));
    }

    const campo = campoPrompt();
    if (campo && normal(campo.innerText) !== normal(texto)) return 'prompt limpo';
    if (antes && tiles().slice(0, 4).some((t) => !antes.tiles.has(t) && !chavesMidiaDoTile(t).some((k) => antes.chaves.has(k)))) return 'card novo';
    if (btn && !btn.isConnected) return 'botão trocado';
    const b = acharBotaoEnviar();
    if (b && /parar|stop|cancel/i.test(b.getAttribute('aria-label') || '')) return 'botão parar';
    return null;
  }

  async function enviar(antes, texto, ctx) {
    const ativAntes = detectarAtividadeIncomum();
    if (ativAntes) throw new ErroFatal(`[ATIVIDADE_INCOMUM] ${ativAntes}`);
    const semCredAntes = detectarCreditosEsgotados();
    if (semCredAntes) throw new ErroFatal(`[CREDITOS_ESGOTADOS] ${semCredAntes}`);

    let btn;
    try {
      btn = await aguardar(() => {
        const ai = detectarAtividadeIncomum();
        if (ai) throw new ErroFatal(`[ATIVIDADE_INCOMUM] ${ai}`);
        const sc = detectarCreditosEsgotados();
        if (sc) throw new ErroFatal(`[CREDITOS_ESGOTADOS] ${sc}`);
        const b = acharBotaoEnviar();
        return b && !desabilitado(b) ? b : null;
      }, { timeout: 15000, descricao: 'o botão de envio (→) destravar' });
    } catch (e) {
      if (e instanceof ErroFatal) throw e;
      const ai = detectarAtividadeIncomum();
      if (ai) throw new ErroFatal(`[ATIVIDADE_INCOMUM] ${ai}`);
      const sc = detectarCreditosEsgotados();
      if (sc) throw new ErroFatal(`[CREDITOS_ESGOTADOS] ${sc}`);
      const b = acharBotaoEnviar();
      throw new Error(b ? `[FALHA_TECNICA] O botão de envio (${rotulo(b) || '→'}) continuou desabilitado: o Flow não reconheceu o prompt.`
        : '[FALHA_TECNICA] Não encontrei o botão de envio (→) na barra do prompt.');
    }

    // Foco natural + pausa humanizada obrigatória de 300ms a 700ms antes de clicar em Gerar (→)
    const cPrompt = campoPrompt();
    if (cPrompt && typeof cPrompt.focus === 'function') {
      try { cPrompt.focus({ preventScroll: true }); } catch {}
    }
    await humano(300, 700);

    const espera = (ms) => aguardar(() => geracaoIniciou(antes, texto, btn), { timeout: ms, intervalo: 250 }).catch((e) => { if (e instanceof ErroFatal) throw e; return null; });

    const tentativas = [
      ['clique com coordenadas válidas no botão →', async () => {
        const bAlvo = acharBotaoEnviar() || btn;
        hover(bAlvo);
        await dormir(60 + Math.random() * 90);
        await cliqueReal(bAlvo);
      }],
      ['clique confiável (debugger) com coordenadas válidas no botão →', async () => {
        const bAlvo = acharBotaoEnviar() || btn;
        const r = await cliqueConfiavel(bAlvo);
        if (!r?.ok) throw new Error(r?.erro || 'debugger indisponível');
      }],
      ['tecla Enter no campo de prompt', async () => {
        const c = campoPrompt();
        if (c) c.focus({ preventScroll: true });
        tecla(c, 'Enter', 'Enter', 13);
      }],
      ['Enter confiável (debugger) no prompt', async () => {
        const c = campoPrompt();
        if (c) c.focus({ preventScroll: true });
        const r = await teclaConfiavel('Enter');
        if (!r?.ok) throw new Error(r?.erro || 'debugger indisponível');
      }],
    ];
    for (const [nome, acao] of tentativas) {
      const b = acharBotaoEnviar();
      if (b && desabilitado(b) && !geracaoIniciou(antes, texto, btn)) await aguardar(() => !desabilitado(acharBotaoEnviar()), { timeout: 4000 }).catch(() => {});
      try { await acao(); } catch (e) { if (e instanceof ErroFatal) throw e; logExt(`Envio por ${nome} falhou: ${e.message}`, 'aviso'); continue; }
      const ok = await espera(nome.includes('confiável') ? 3500 : 2500);
      if (ok) {
        if (nome !== tentativas[0][0]) logExt(`Geração iniciada via ${nome}.`, 'info');
        progresso(ctx, `Enviado (${ok})`);
        return;
      }
      progresso(ctx, `Envio ainda não iniciou — tentando ${nome === tentativas[tentativas.length - 1][0] ? 'última opção' : 'outra forma'}`);
    }
    const scFim = detectarCreditosEsgotados();
    if (scFim) throw new ErroFatal(`[CREDITOS_ESGOTADOS] ${scFim}`);
    throw new Error('[FALHA_TECNICA] O Flow não iniciou a geração após clicar em → (clique, Enter, submit e cliques confiáveis). O prompt continua na caixa.');
  }

  // =============================================================
  //  RESULTADOS (grade virtualizada de ativos + casamento por prompt)
  // =============================================================
  const tiles = () => M().buscarProfundo(obter('resultado.tile'));
  const reErro = () => new RegExp(obter('resultado.regexErro', false) || 'falh|failed', 'i');

  /** Normaliza URL de midia removendo query strings (?Expires=...&Signature=...&authuser=...), hashes e /u/<N>/ */
  function normalizarUrlMidia(src) {
    if (!src || typeof src !== 'string') return null;
    const limpa = src.trim();
    if (!limpa || limpa.startsWith('data:') || limpa.startsWith('blob:')) return null;
    try {
      const u = new URL(limpa, location.href);
      let pathname = u.pathname || '/';
      if (u.hostname === 'flow.google.com' || u.hostname === 'labs.google') {
        pathname = pathname.replace(/^\/u\/\d+(?=\/|$)/, '') || '/';
      }
      pathname = pathname.replace(/\/+$/, '') || '/';
      return `${u.protocol.toLowerCase()}//${u.host.toLowerCase()}${pathname}`;
    } catch {
      return limpa.split(/[?#]/)[0].replace(/\/+$/, '') || null;
    }
  }

  function chaveMidia(m) {
    if (!m) return null;
    const src = m.tagName === 'VIDEO'
      ? (m.currentSrc || m.src || m.querySelector('source')?.src || m.poster)
      : (m.currentSrc || m.src);
    return normalizarUrlMidia(src);
  }

  function midiasDoTile(t) {
    if (!t) return [];
    return [...t.querySelectorAll('video, img')].filter((m) => {
      if (m.closest('flow-ingredient-chip, flow-image-ingredient-chip, [aria-label="Elemento"]')) return false;
      if (m.tagName === 'VIDEO') return true;
      const r = m.getBoundingClientRect();
      return (r.width >= 60 && r.height >= 60) || ((m.naturalWidth || 0) >= 80 && (m.naturalHeight || 0) >= 80);
    });
  }

  /**
   * Coleta TODAS as chaves normalizadas de um card (poster <img> + <video src> + <source src> + video.poster).
   * Essencial no Google Flow: cards de video ociosos mostram apenas <img src="/asb/POSTER"> e so montam
   * <video src="/asb/VIDEO"> ao passar o mouse ou re-renderizar. Guardar TODAS as chaves garante que um card antigo
   * JAMAIS pareca "novo" quando seu <video> hidratar depois!
   */
  function chavesMidiaDoTile(t) {
    if (!t) return [];
    const set = new Set();
    for (const m of midiasDoTile(t)) {
      const cands = m.tagName === 'VIDEO'
        ? [m.currentSrc, m.src, m.poster, ...[...m.querySelectorAll('source')].map((s) => s.src)]
        : [m.currentSrc, m.src];
      for (const c of cands) {
        const k = normalizarUrlMidia(c);
        if (k) set.add(k);
      }
    }
    return [...set];
  }

  function ehTileDeVideo(t) {
    if (!t) return false;
    if (t.querySelector('flow-video-tile, video')) return true;
    const ic = M().textosIcones(t) || [];
    if (ic.some((i) => /^(play_circle|play_arrow|videocam|movie)$/.test(i))) return true;
    const txt = t.innerText || '';
    if (/\b(270p|360p|720p|1080p|2160p)\b/i.test(txt)) return true;
    return [...t.querySelectorAll('img')].some((im) => /v[ií]deo/i.test(im.alt || ''));
  }

  /** Card que JA foi renomeado pelo FlowStudio (`cena_*`, `imagem_*`, `ref_*`): JAMAIS pode ser selecionado como "novo"! */
  function ehCardJaRenomeado(tile) {
    const aria = normal(tile?.getAttribute('aria-label') || '');
    if (!aria) return false;
    return /^(cena[\s_-]*\d+|imagem[\s_-]*\d+|ref[\s_-]*[a-z0-9_]+)/i.test(aria) || /_(antigo|old)$/i.test(aria);
  }

  /** Botao "Reutilizar comando" (icone `redo`) dentro do card: carrega o prompt original + chips na barra inferior sem gastar creditos! */
  function acharBotaoReutilizarNoTile(tile) {
    if (!tile) return null;
    return [...tile.querySelectorAll('button')].find((b) => {
      const aria = `${b.getAttribute('aria-label') || ''} ${M().nomeAcessivel(b) || ''}`;
      const ic = M().textosIcones(b) || [];
      return /reutilizar\s+comando|reuse\s+prompt|usar\s+comando/i.test(aria) || ic.includes('redo');
    }) || null;
  }

  /**
   * No modo Grade (Grid View), o Google Flow nao exibe `<flow-batch-info>` ao lado dos cards.
   * Nesse caso, clicar em "Reutilizar comando" (`redo`) no card copia instantaneamente o prompt original completo
   * e os chips `imagem_NN`/`ref_*` para o compositor inferior (0 creditos gastos)!
   */
  async function inspecionarPromptEChipsDoCard(tile, { limparDepois = false } = {}) {
    if (!tile) return { promptLimpo: '', chips: [], chipsChaves: [] };

    // 1) Se estiver no modo Lista (com `<flow-batch-info>` presente no DOM), le direto sem tocar no compositor
    const bloco = blocoLoteDoTile(tile);
    const temBatchInfo = !!(bloco && bloco !== tile && bloco.querySelector('flow-batch-info'));
    if (temBatchInfo) {
      const promptLimpo = await lerPromptLimpoDoTile(tile, { expandir: true });
      const info = bloco.querySelector('flow-batch-info');
      const chips = [...(info?.querySelectorAll('flow-ingredient-chip, flow-image-ingredient-chip, [aria-label]') || [])]
        .map((el) => `${el.getAttribute('aria-label') || ''} ${el.innerText || ''}`.trim())
        .filter(Boolean);
      const chipsChaves = [...(info?.querySelectorAll('flow-ingredient-chip img, flow-image-ingredient-chip img') || [])]
        .map((im) => normalizarUrlMidia(im.currentSrc || im.src))
        .filter(Boolean);
      if (promptLimpo && promptLimpo.length >= 20) {
        return { promptLimpo, chips, chipsChaves };
      }
    }

    // 2) Modo Grade (Grid View): inspeciona via botao `redo` ("Reutilizar comando") do proprio card
    const campo = campoPrompt();
    if (!campo) return { promptLimpo: '', chips: [], chipsChaves: [] };

    try {
      await fecharOverlays();
      await limparIngredientes();
      if ((campo.innerText || campo.textContent || '').trim()) {
        campo.focus();
        selecionarTudo(campo);
        try { document.execCommand('delete', false); } catch {}
        if ((campo.innerText || '').trim()) campo.textContent = '';
      }

      tile.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
      await dormir(150);
      hoverCard(tile);
      await hoverConfiavel(midiasDoTile(tile)[0] || tile).catch(() => {});
      await dormir(220);

      const btnRedo = await aguardar(() => { hoverCard(tile); return acharBotaoReutilizarNoTile(tile); }, { timeout: 2000, intervalo: 250 }).catch(() => null);
      if (!btnRedo) return { promptLimpo: '', chips: [], chipsChaves: [] };

      await cliqueForte(btnRedo);
      await aguardar(
        () => {
          const cp = campoPrompt();
          return ((cp?.innerText || cp?.textContent || '').trim().length >= 15) || contarIngredientes() > 0;
        },
        { timeout: 2800, intervalo: 180 }
      ).catch(() => null);
      await dormir(120);

      const cpAtual = campoPrompt();
      const promptLimpo = normal(String(cpAtual?.innerText || cpAtual?.textContent || '').replace(/[“”«»„]/g, '"').replace(/[‘’]/g, "'"));
      const b = barra();
      const chips = [...(b?.querySelectorAll('flow-image-ingredient-chip, [aria-label]') || [])]
        .map((el) => `${el.getAttribute('aria-label') || ''} ${el.innerText || ''}`.trim())
        .filter(Boolean);
      const chipsChaves = [...(b?.querySelectorAll('img') || [])]
        .map((im) => normalizarUrlMidia(im.currentSrc || im.src))
        .filter(Boolean);

      return { promptLimpo, chips, chipsChaves };
    } finally {
      if (limparDepois) {
        await limparComposer({ limparTexto: true }).catch(() => {});
      }
    }
  }

  /** Encontra o container da linha de lote (que agrupa `flow-grid-tile-container` + `flow-batch-info`). */
  function blocoLoteDoTile(tile) {
    let p = tile?.parentElement;
    for (let i = 0; i < 7 && p && p !== document.body; i++) {
      if (p.tagName === 'CDK-VIRTUAL-SCROLL-VIEWPORT' || p.tagName === 'MAIN') break;
      if (p.querySelector('flow-batch-info') && p.querySelectorAll('flow-grid-tile-container').length <= 4) {
        return p;
      }
      p = p.parentElement;
    }
    return tile?.parentElement?.parentElement || tile;
  }

  /** Expande "Ampliar comando" no bloco do card se o prompt estiver recolhido com reticencias. */
  async function expandirPromptDoBloco(tile) {
    const bloco = blocoLoteDoTile(tile);
    if (!bloco) return;
    const info = bloco.querySelector('flow-batch-info') || bloco;
    const botoes = [...info.querySelectorAll('flow-expandable-prompt button, button')];
    const btnAmp = botoes.find((b) => {
      const aria = `${b.getAttribute('aria-label') || ''} ${M().nomeAcessivel(b) || ''}`;
      if (/recolher|collapse|mostrar\s+menos|show\s+less/i.test(aria)) return false;
      if (/ampliar\s+comando|expand\s+prompt|mostrar\s+mais|show\s+more|ver\s+mais/i.test(aria)) return true;
      if (b.closest('flow-expandable-prompt')) {
        const ic = M().textosIcones(b) || [];
        return ic.some((x) => /^(keyboard_arrow_down|expand_more)$/.test(x));
      }
      return false;
    });
    if (btnAmp && M().visivel(btnAmp)) {
      try {
        btnAmp.click();
        await dormir(160);
      } catch {}
    }
  }

  /**
   * Le o texto limpo do prompt exibido ao lado do card (ignorando chips de ingredientes no modo Elementos,
   * icones Material e botoes de acao).
   */
  async function lerPromptLimpoDoTile(tile, { expandir = false } = {}) {
    if (!tile) return '';
    if (expandir) await expandirPromptDoBloco(tile);
    const bloco = blocoLoteDoTile(tile);
    const alvo = bloco?.querySelector('flow-expandable-prompt') || bloco?.querySelector('flow-batch-info');
    if (!alvo) return '';
    const clone = alvo.cloneNode(true);
    clone
      .querySelectorAll('flow-ingredient-chip, flow-image-ingredient-chip, [aria-label="Elemento"], button, mat-icon, [role="img"], [aria-hidden="true"]')
      .forEach((el) => el.remove());
    return normal(String(clone.textContent || '').replace(/[“”«»„]/g, '"').replace(/[‘’]/g, "'"));
  }

  function extrairFalasPromptLocal(prompt) {
    const txt = String(prompt || '').replace(/[“”«»„]/g, '"');
    const out = [];
    const re = /"([^"\n]{6,260})"/g;
    let m;
    while ((m = re.exec(txt))) {
      const f = normal(m[1]).replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, '');
      if (f.length >= 6 && !out.includes(f)) out.push(f);
    }
    return out;
  }

  function assinaturaPromptLocal(prompt, outrosPrompts = []) {
    const normP = normal(String(prompt || '').replace(/[“”«»„]/g, '"').replace(/[‘’]/g, "'"));
    const outrosNorm = (outrosPrompts || [])
      .map((p) => normal(String(p || '').replace(/[“”«»„]/g, '"').replace(/[‘’]/g, "'")))
      .filter((p) => p && p !== normP);
    const exclusivo = (s) => s && s.length >= 10 && outrosNorm.every((o) => !o.includes(s));

    const falas = extrairFalasPromptLocal(prompt);
    const falasExclusivas = falas.filter(exclusivo);
    const trechosExclusivos = [];
    const mOpen = normP.match(/opening shot:\s*([^."]{15,140})/);
    if (mOpen && exclusivo(mOpen[1].trim())) trechosExclusivos.push(mOpen[1].trim());
    const passo = Math.max(24, Math.floor(normP.length / 18));
    for (let pos = 0; pos + 48 <= normP.length && trechosExclusivos.length < 10; pos += passo) {
      const sub = normP.slice(pos, pos + 48).trim();
      if (exclusivo(sub) && !trechosExclusivos.some((t) => t.includes(sub) || sub.includes(t))) {
        trechosExclusivos.push(sub);
      }
    }
    return { normP, falas, falasExclusivas, trechosExclusivos, outrosPromptsRaw: outrosPrompts };
  }

  /** Confere se `promptCard` (sem chips) realmente pertence a `item` e nao a outra cena da novela. */
  function cardConfereComItem(promptCard, item, outrosPrompts = []) {
    if (!promptCard || promptCard.length < 20) return true; // layout sem bloco de texto visivel
    const card = normal(String(promptCard).replace(/[“”«»„]/g, '"').replace(/[‘’]/g, "'"));
    const ass = assinaturaPromptLocal(item?.prompt || '', outrosPrompts);

    // 1) Se o card contem fala exclusiva de OUTRA cena, rejeita na hora!
    for (const op of outrosPrompts || []) {
      if (!op || normal(op) === ass.normP) continue;
      const falasOutro = extrairFalasPromptLocal(op).filter((f) => !ass.normP.includes(f));
      if (falasOutro.some((f) => f.length >= 10 && card.includes(f))) return false;
    }

    // 2) Se o card ja mostra o prompt expandido (ou longo), exige bater fala ou trecho exclusivo desta cena
    if (ass.falasExclusivas.some((f) => card.includes(f))) return true;
    if (ass.trechosExclusivos.some((t) => card.includes(t))) return true;
    if (ass.falas.length > 0 && card.length > 320) {
      // Card expandido longo mas nenhuma fala desta cena apareceu -> nao e o card desta cena!
      return ass.falas.some((f) => card.includes(f));
    }

    // 3) Se o prompt no DOM ainda estiver truncado curto (< 320 chars), precisa ser prefixo real do prompt deste item
    const prefixoLimpo = card.replace(/…|\.\.\.$/, '').trim();
    if (prefixoLimpo.length >= 25 && ass.normP.includes(prefixoLimpo)) return true;
    if (card === ass.normP || card.includes(ass.normP)) return true;
    return false;
  }

  function obterViewportGrade() {
    return (
      M().buscarProfundo('cdk-virtual-scroll-viewport')[0] ||
      tiles()[0]?.closest('cdk-virtual-scroll-viewport') ||
      null
    );
  }

  function rolarGradeTopo() {
    const vp = obterViewportGrade();
    if (vp) {
      vp.scrollTop = 0;
      vp.dispatchEvent(new Event('scroll'));
    }
    const t = tiles()[0];
    let p = (vp || t)?.parentElement;
    while (p && p !== document.body) {
      if (p.scrollHeight > p.clientHeight + 20 && p.scrollTop > 0) p.scrollTop = 0;
      p = p.parentElement;
    }
  }

  async function snapshotResultados(chavesProibidasExtras = []) {
    rolarGradeTopo();
    await dormir(1200);
    const ts = tiles();
    const chaves = new Set((chavesProibidasExtras || []).map(normalizarUrlMidia).filter(Boolean));
    for (const t of ts) {
      chavesMidiaDoTile(t).forEach((k) => chaves.add(k));
      const v = t.querySelector('video');
      const vUrl = normalizarUrlMidia(v?.currentSrc || v?.src || v?.querySelector('source')?.src || '');
      if (vUrl) chaves.add(vUrl);
    }
    return { chaves, tiles: new Set(ts) };
  }

  /** Detecta se um card novo falhou/bloqueou (texto de erro, icone de erro/bloqueio ou botao de retry sem spinner). */
  function motivoFalhaNoCard(t, RE) {
    const txt = limpar(t.innerText || '', 240);
    if (txt && (RE.test(txt) || RE_POLITICA_OU_FALHA.test(txt))) return txt;
    const icones = M().textosIcones(t) || [];
    const temIconeErro = icones.some((ic) => /^(error|error_outline|warning|warning_amber|report|report_problem|block|gpp_bad)$/.test(ic));
    const botoesCard = [...t.querySelectorAll('button')].map((b) => `${M().nomeAcessivel(b)} ${b.innerText || ''}`);
    const temBotaoRetry = botoesCard.some((b) => /tentar\s+novamente|try\s+again|retry/i.test(b));
    if (temIconeErro || temBotaoRetry) return txt || 'Card com erro/bloqueio no Google Flow';
    return null;
  }

  async function aguardarRenderizacao(antes, { item = null, ehVideo = false, outrosPrompts = [] } = {}, timeoutMs, ctx) {
    const inicio = Date.now();
    let errosSeguidos = 0;
    let ultimoScroll = 0;
    const cardsRejeitadosPrompt = new Set();
    const RE = reErro();
    return aguardar(async () => {
      if (Date.now() - ultimoScroll > 6000) {
        ultimoScroll = Date.now();
        rolarGradeTopo();
      }
      const ativIncomum = detectarAtividadeIncomum(antes);
      if (ativIncomum) throw new ErroFatal(`[ATIVIDADE_INCOMUM] ${ativIncomum}`);
      const semCred = detectarCreditosEsgotados();
      if (semCred) throw new ErroFatal(`[CREDITOS_ESGOTADOS] ${semCred}`);
      const projInacessivel = detectarProjetoInacessivel();
      if (projInacessivel) throw new ErroFatal(`[PROJETO_INACESSIVEL] ${projInacessivel}`);

      const alerta = avisosVisiveisForaDoPrompt().find((t) => RE.test(t) || RE_POLITICA_OU_FALHA.test(t) || RE_ATIVIDADE_INCOMUM.test(t));
      if (alerta) {
        if (RE_ATIVIDADE_INCOMUM.test(alerta) && !/n[aã]o\s+houve\s+cobran[cç]a|no\s+charge/i.test(alerta)) {
          throw new ErroFatal('[ATIVIDADE_INCOMUM] ' + limpar(alerta));
        }
        throw new ErroFatal('[BLOQUEIO_FLOW] Google Flow: ' + limpar(alerta));
      }

      const ts = tiles().slice(0, 16);
      let pct = null;
      let algumCarregando = false;
      let temCardNovo = false;
      const falhasNovas = [];

      // PASSO 1: Prioridade absoluta para QUALQUER card novo que tenha gerado mídia válida (no modo Burst 4x, basta 1 das 4 imagens passar!)
      for (const t of ts) {
        // REGRA 1: Ignora imediatamente qualquer card que ja tenha sido renomeado (`cena_*`, `imagem_*`, `ref_*`)!
        if (ehCardJaRenomeado(t)) continue;

        const txt = t.innerText || '';
        const todasChaves = chavesMidiaDoTile(t);
        // REGRA 2: Ignora qualquer card que compartilhe URL base com `antes.chaves` (`urlsAntes` sem query string)
        // ou ja tenha sido rejeitado na conferencia do prompt!
        const pertenceAntes = todasChaves.some((k) => antes.chaves.has(k) || cardsRejeitadosPrompt.has(k));
        const m = txt.match(/\b(\d{1,3})\s*%/);
        const carregando = Boolean(m || t.querySelector('[role="progressbar"], mat-progress-spinner, mat-spinner, mat-progress-bar'));
        if (!antes.tiles.has(t) && !pertenceAntes) {
          temCardNovo = true;
          if (carregando) {
            algumCarregando = true;
            if (m) pct = m[1] + '%';
          }
        }

        if (pertenceAntes) continue;

        if (!todasChaves.length) {
          if (!antes.tiles.has(t) && !carregando) {
            const falhaCard = motivoFalhaNoCard(t, RE);
            if (falhaCard) falhasNovas.push(falhaCard);
          } else if (m) {
            pct = m[1] + '%';
          }
          continue;
        }

        if (carregando) {
          algumCarregando = true;
          if (m) pct = m[1] + '%';
          continue;
        }
        if (ehVideo && !ehTileDeVideo(t)) continue;

        // Hidrata o <video> e exige URL de <video> INEDITA (inexistente em `urlsAntes`)
        t.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
        if (ehVideo) {
          hoverCard(t);
          await hoverConfiavel(midiasDoTile(t)[0] || t).catch(() => {});
          await aguardar(
            () => {
              const v = t.querySelector('video');
              return v && (v.currentSrc || v.src || v.querySelector('source')?.src);
            },
            { timeout: 2800, intervalo: 250 }
          ).catch(() => null);
        }

        const chavesFinais = chavesMidiaDoTile(t);
        if (!chavesFinais.length || chavesFinais.some((k) => antes.chaves.has(k) || cardsRejeitadosPrompt.has(k))) continue;
        if (ehVideo) {
          const vd = t.querySelector('video');
          const urlVdNorm = normalizarUrlMidia(vd?.currentSrc || vd?.src || vd?.querySelector('source')?.src || '');
          if (!urlVdNorm || antes.chaves.has(urlVdNorm)) continue;
        }

        // REGRA 3: Confere o trecho unico do prompt/fala desta `{Cena NN}` (tanto em modo Lista quanto em modo Grade via `redo`!)
        if (item?.prompt) {
          const insp = await inspecionarPromptEChipsDoCard(t, { limparDepois: true });
          if (insp.promptLimpo && !cardConfereComItem(insp.promptLimpo, item, outrosPrompts)) {
            chavesFinais.forEach((k) => cardsRejeitadosPrompt.add(k));
            continue;
          }
        }

        const midias = midiasDoTile(t);
        const midiaPrincipal = ehVideo
          ? midias.find((el) => el.tagName === 'VIDEO' && chaveMidia(el))
          : midias.find((el) => el.tagName === 'IMG' && el.complete && el.naturalWidth > 0);
        if (!midiaPrincipal) continue;

        return { tile: t, midia: midiaPrincipal, todasChaves: chavesFinais };
      }

      // PASSO 2: Se NENHUM card gerou mídia válida e NENHUM card novo continua carregando (todos os cards do lote falharam)
      if (!algumCarregando && falhasNovas.length > 0) {
        if (++errosSeguidos >= 2) {
          throw new ErroFatal('[BLOQUEIO_FLOW] O Flow recusou ou falhou nesta geração: ' + falhasNovas[0]);
        }
      } else {
        errosSeguidos = 0;
      }

      const seg = Math.round((Date.now() - inicio) / 1000);
      // Protecao contra congelamento: se apos 35s nao ha nenhum card novo nem barra de progresso ativa
      const btnEnvio = acharBotaoEnviar();
      const botaoParar = btnEnvio && /parar|stop|cancel/i.test(btnEnvio.getAttribute('aria-label') || '');
      if (seg >= 35 && !algumCarregando && !temCardNovo && !botaoParar) {
        throw new ErroFatal('[FALHA_TECNICA] O Flow descartou ou não iniciou a geração (nenhum card em renderização após 35s).');
      }
      progresso(ctx, `Gerando no Flow… ${pct ? pct + ' · ' : ''}${seg}s`);
      return null;
    }, { timeout: timeoutMs, intervalo: 1000, descricao: 'o Google Flow terminar de gerar' });
  }

  // =============================================================
  //  ATIVO: renomear + baixar em resolucao maxima
  // =============================================================
  /** Hover completo no card e na midia: o Flow so mostra os botoes de acao (⋮) com o mouse em cima. */
  function hoverCard(tile) {
    tile.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    hover(tile);
    const midia = midiasDoTile(tile)[0] || tile.querySelector('img, video');
    if (midia) hover(midia);
    const r = (midia || tile).getBoundingClientRect();
    const o = { bubbles: true, composed: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, view: window };
    for (const alvo of [tile, midia].filter(Boolean)) {
      alvo.dispatchEvent(new PointerEvent('pointerenter', { ...o, bubbles: false, pointerType: 'mouse' }));
      alvo.dispatchEvent(new MouseEvent('mouseenter', { ...o, bubbles: false }));
      alvo.dispatchEvent(new PointerEvent('pointermove', { ...o, pointerType: 'mouse' }));
      alvo.dispatchEvent(new MouseEvent('mouseover', o));
    }
  }

  async function abrirMenuTile(tile) {
    await fecharOverlays();
    hoverCard(tile);
    await dormir(600);
    const btn = await aguardar(() => { hoverCard(tile); return [...tile.querySelectorAll('button')].find((b) => combinaAlguma(b, obter('ativo.botaoMais'))); },
      { timeout: 5000, intervalo: 500, descricao: 'o botão ⋮ "Mais opções" do card' });
    hover(btn);
    await cliqueReal(btn);
    let abriu = await aguardar(() => localizarTodos('[role="menuitem"]').length, { timeout: 2500 }).catch(() => false);
    if (!abriu) {
      // botao escondido por CSS :hover -> clique confiavel (mouse real passa por cima)
      await cliqueConfiavel(btn);
      abriu = await aguardar(() => localizarTodos('[role="menuitem"]').length, { timeout: 3000 }).catch(() => false);
    }
    if (!abriu) throw new Error('O menu ⋮ do card não abriu.');
    await dormir(250);
  }

  const acharTile = (nome) => tiles().find((t) => normal(t.getAttribute('aria-label')) === normal(nome));

  /** O nome aparece em algum card/rotulo da grade (fora do cabecalho do projeto e da caixa de prompt)? */
  function nomeVisivelNaGrade(nome) {
    if (acharTile(nome)) return true;
    const alvo = normal(nome);
    return tiles().some((t) => {
      const bloco = t.parentElement?.parentElement || t;
      return [...bloco.querySelectorAll('*')].some((e) => !e.children.length && normal(e.textContent) === alvo && !e.closest('header, flow-base-prompt-box'));
    });
  }

  /** Editor "Renomear bloco" aberto (overlay do card) — nunca o titulo do projeto no cabecalho. */
  function editorNomeAberto() {
    return localizarTodos(obter('ativo.editorNome'), document, { visivel: false })
      .filter((e) => !e.closest('header'))
      .find((e) => {
        const campo = e.querySelector(obter('ativo.inputNome', false) || 'input, textarea, [contenteditable="true"]');
        return campo && !campo.closest('header') && M().visivel(campo);
      }) || null;
  }
  const campoDoEditor = (ed) => ed?.querySelector(obter('ativo.inputNome', false) || 'input, textarea, [contenteditable="true"]');
  const botaoDoEditor = (ed, chave) => ed ? [...ed.querySelectorAll('button')].find((b) => combinaAlguma(b, obter(chave))) : null;

  /** Limpa por completo e insere o nome exato com eventos reais (input + change). */
  async function preencherNome(inp, nome, confiavel) {
    inp.scrollIntoView({ block: 'center' });
    inp.focus();
    inp.select?.();
    try { document.execCommand('selectAll', false); document.execCommand('delete', false); } catch {}
    definirValorInput(inp, '');
    await dormir(80);
    if (confiavel) {
      inp.focus(); inp.select?.();
      const r = await textoConfiavel(nome);
      if (!r?.ok) logExt(`Digitação confiável do nome falhou: ${r?.erro || '?'}`, 'aviso');
    } else {
      let ok = false;
      try { ok = document.execCommand('insertText', false, nome); } catch {}
      if (!ok || inp.value !== nome) {
        inp.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: nome }));
        definirValorInput(inp, nome);
      }
    }
    if (inp.value !== nome) definirValorInput(inp, nome);
    inp.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: nome }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    inp.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: nome.slice(-1) }));
    await dormir(200);
    if (inp.value !== nome) throw new Error(`O campo de nome ficou "${inp.value}" em vez de "${nome}".`);
  }

  /** Ativo com esse nome exato aparece na busca da biblioteca (+ -> Pesquisar recursos)? */
  async function nomeExisteNaBusca(nome) {
    try {
      await fecharOverlays();
      const add = localizar(obter('ingredientes.botaoAdicionar'));
      if (!add) return false;
      await cliqueReal(add);
      await aguardar(() => localizar(obter('ingredientes.popover')), { timeout: 6000 });
      await dormir(400);
      const aba = localizar(obter('ingredientes.abaImagens', false));
      if (aba && aba.getAttribute('aria-selected') !== 'true') { await cliqueReal(aba); await dormir(500); }
      const busca = localizar(obter('ingredientes.busca'));
      if (busca) { await cliqueReal(busca); await digitarTexto(busca, nome); }
      return !!(await aguardar(() => acharOpcaoExata(nome), { timeout: 5000 }).catch(() => null));
    } finally {
      await fecharOverlays();
    }
  }

  /** Abre o menu ⋮ do card com mouse REAL (hover + clique via debugger); sintetico so como reserva. */
  async function abrirMenuTileReal(tile) {
    await fecharOverlays();
    tile.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    await dormir(300);
    hoverCard(tile);
    await hoverConfiavel(midiasDoTile(tile)[0] || tile); // :hover de verdade revela os botoes do card
    await dormir(400);
    const btn = await aguardar(() => [...tile.querySelectorAll('button')].find((b) => combinaAlguma(b, obter('ativo.botaoMais'))),
      { timeout: 5000, descricao: 'o botão ⋮ do card' });
    const temMenu = () => localizarTodos('[role="menuitem"]').length > 0;
    await cliqueForte(btn);
    if (!(await aguardar(temMenu, { timeout: 2500 }).catch(() => false))) {
      await cliqueReal(btn);
      if (!(await aguardar(temMenu, { timeout: 2500 }).catch(() => false))) throw new Error('O menu ⋮ do card não abriu.');
    }
    await dormir(250);
  }

  /**
   * Renomeia o card com o {id} exato usando interacoes REAIS (debugger) e so retorna true
   * depois de ler o nome gravado no card (ou na busca da biblioteca). Ate 3 tentativas.
   */
  async function renomearAtivo(tile, nome, ctx) {
    const chaveTile = midiasDoTile(tile).map(chaveMidia).find(Boolean) || null;
    const reacharTile = () => (tile.isConnected ? tile : null)
      || (chaveTile && tiles().find((t) => midiasDoTile(t).some((m) => chaveMidia(m) === chaveTile))) || null;
    const gravouNoCard = () => { const t = reacharTile(); return !!t && normal(t.getAttribute('aria-label')) === normal(nome); };

    for (let tentativa = 1; tentativa <= 3; tentativa++) {
      const t = reacharTile();
      if (!t) throw new Error('O card do ativo sumiu da grade antes de renomear.');
      if (gravouNoCard()) return true;
      progresso(ctx, `Renomeando para "${nome}" (tentativa ${tentativa}/3)`);
      try {
        // 1) estabiliza layout/animacao (principalmente o 1o card de um projeto novo)
        await dormir(1000);
        t.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
        await dormir(200);
        // 2) ⋮ -> Renomear com clique real
        await abrirMenuTileReal(t);
        const item = await aguardar(() => localizarTodos(obter('ativo.itemRenomear'))[0], { timeout: 5000, descricao: 'a opção "Renomear"' });
        await cliqueForte(item);
        let editor = await aguardar(editorNomeAberto, { timeout: 3000 }).catch(() => null);
        if (!editor) { await cliqueReal(item); editor = await aguardar(editorNomeAberto, { timeout: 4000, descricao: 'o campo "Renomear bloco"' }); }
        const inp = campoDoEditor(editor);

        // 3) foco real no campo -> Ctrl+A -> apagar -> digitar o {id} (tudo com teclado real)
        await cliqueForte(inp);
        inp.focus();
        await dormir(150);
        const a = await teclaConfiavel('ctrl+a');
        if (a?.ok) {
          await teclaConfiavel('Backspace');
          await dormir(100);
          await textoConfiavel(nome);
          await dormir(250);
        }
        if (inp.value !== nome) await preencherNome(inp, nome, false); // reserva sem debugger
        if (inp.value !== nome) throw new Error(`o campo ficou "${inp.value}"`);

        // 4) SEM tirar o foco: clique real no ✓ "Concluir" pelas coordenadas exatas; Enter real como reforco
        const editorFechou = () => !editor.isConnected || !M().visivel(inp);
        const ok = botaoDoEditor(editor, 'ativo.confirmarNome');
        if (ok) await cliqueForte(ok); else { inp.focus(); await teclaConfiavel('Enter'); }
        await dormir(800);
        if (!editorFechou()) {
          if (inp.value !== nome) { inp.focus(); await teclaConfiavel('ctrl+a'); await textoConfiavel(nome); }
          inp.focus();
          const r = await teclaConfiavel('Enter');
          if (!r?.ok) tecla(inp, 'Enter', 'Enter', 13);
          await dormir(800);
        }

        // 5) VERIFICACAO REAL: nome exibido no card (ou na busca da biblioteca)
        const noCard = await aguardar(gravouNoCard, { timeout: 4000, intervalo: 400 }).catch(() => false);
        if (noCard) { logExt(`Nome "${nome}" confirmado no card (tentativa ${tentativa}).`, 'info'); return true; }
        if (editorFechou() && await nomeExisteNaBusca(nome)) { logExt(`Nome "${nome}" confirmado na busca da biblioteca.`, 'info'); return true; }
        logExt(`Renomear "${nome}": a tentativa ${tentativa} não gravou o nome no Flow.`, 'aviso');
      } catch (e) {
        logExt(`Renomear "${nome}" (tentativa ${tentativa}) falhou: ${e.message}`, 'aviso');
      }
      // fecha o editor sem salvar antes de tentar de novo
      const ed = editorNomeAberto();
      const cancelar = botaoDoEditor(ed, 'ativo.cancelarNome');
      if (cancelar) await cliqueForte(cancelar);
      await fecharOverlays();
      await dormir(800);
    }
    return false;
  }

  async function tamanhoDaUrl(src) {
    try {
      const r = await fetch(src, { credentials: 'include' });
      if (!r.ok) throw new Error();
      return (await r.blob()).size;
    } catch {
      const r = await chamarBg({ tipo: 'tamanho_url', url: src });
      return r?.ok ? r.tamanho : null;
    }
  }

  /**
   * Reparo: quando um ativo nao foi renomeado no Flow, acha o card dele no projeto
   * (pela chave da midia gerada ou pelo tamanho exato do arquivo salvo no PC) e renomeia com o {id}.
   */
  async function repararNomeAtivo(nome, info, ctx) {
    if (!info) return false;
    await fecharOverlays();
    progresso(ctx, `Procurando o card de "${nome}" no projeto para renomear`);
    rolarGradeTopo();
    await dormir(1000);
    const lista = tiles();
    let alvo = null;
    if (info.midiaChave) alvo = lista.find((t) => midiasDoTile(t).some((m) => chaveMidia(m) === info.midiaChave));
    if (!alvo && info.tamanhoBytes) {
      for (const t of lista.slice(0, 40)) {
        if (normal(t.getAttribute('aria-label')) === normal(nome)) { alvo = t; break; }
        const img = [...t.querySelectorAll('img')].sort((a, b) => (b.naturalWidth || 0) - (a.naturalWidth || 0))[0];
        const src = img?.currentSrc || img?.src;
        if (!src) continue;
        if ((await tamanhoDaUrl(src)) === info.tamanhoBytes) { alvo = t; break; }
      }
    }
    if (!alvo) return false;
    progresso(ctx, `Renomeando card existente para "${nome}"`);
    return !!(await renomearAtivo(alvo, nome, ctx));
  }

  function pedirCapturaDownload(nomeBase, timeoutMs, inicioMs) {
    const promessa = new Promise((res, rej) => {
      chrome.runtime.sendMessage({ tipo: 'download_capturar', nomeBase, timeoutMs, inicioMs }, (r) => {
        if (chrome.runtime.lastError) return rej(new Error(chrome.runtime.lastError.message));
        if (r?.ok) res(r); else rej(new Error(r?.erro || 'Falha no download'));
      });
    });
    promessa.catch(() => {});
    return { promessa, cancelar: () => { try { chrome.runtime.sendMessage({ tipo: 'download_cancelar' }); } catch {} } };
  }

  // ---------- qualidade de DOWNLOAD (100% controlada pelo FlowStudio) ----------
  function infoOpcaoDownload(el, ehVideo) {
    const t = limpar(el.innerText || rotulo(el), 80);
    let n = numeroResolucao(t);
    if (ehVideo && n === 1000) n = 1080; // "1K" em video = 1080p
    if (ehVideo && n === 4000) n = 2160; // "4K" em video = 2160p
    if (!ehVideo && n === 2160) n = 4000; // "2160p" em imagem = 4K
    return {
      el, t, n,
      aprimorada: /aprimor|upscal|enhanc|melhorad/i.test(t),
      original: /original/i.test(t),
      gif: /gif/i.test(t),
      proibido: /\b8\s*k\b|4320/i.test(t),
    };
  }

  /**
   * Escolhe a opcao do submenu de Download exatamente conforme a configuracao do FlowStudio:
   *  video: 'original' | '720p' | '1080p' | '4k'   imagem: 'original' | '1k' | '2k' | '4k'
   */
  function escolherOpcaoDownload(opcoes, { ehVideo, pref, genRes }) {
    const todas = opcoes.map((el) => infoOpcaoDownload(el, ehVideo));
    const ok = todas.filter((o) => !o.gif && !o.proibido);
    if (!ok.length) return null;
    const diretas = ok.filter((o) => !o.aprimorada);
    const escolherOriginal = () =>
      ok.find((o) => o.original) || diretas.find((o) => genRes && o.n === genRes) ||
      diretas.sort((a, b) => a.n - b.n)[0] || ok.sort((a, b) => a.n - b.n)[0];
    let alvo = String(pref || 'original').toLowerCase();
    if (alvo === 'original') return escolherOriginal();
    let N = numeroResolucao(alvo);
    if (ehVideo && N === 1000) N = 1080;
    if (ehVideo && N === 4000) N = 2160;
    if (!ehVideo && N === 2160) N = 4000;
    if (!N) return escolherOriginal();
    // geracao ja tem a resolucao pedida -> download direto, sem reprocessar
    if (ehVideo && genRes && N <= genRes) {
      return diretas.find((o) => o.n === N) || ok.find((o) => o.original) || escolherOriginal();
    }
    const exatas = ok.filter((o) => o.n === N);
    if (exatas.length) return exatas.find((o) => !o.aprimorada) || exatas[0];
    const abaixo = ok.filter((o) => o.n > 1 && o.n < N).sort((a, b) => b.n - a.n);
    return abaixo[0] || escolherOriginal();
  }

  async function blobParaBase64(blob) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload = () => res(String(fr.result).split(',')[1]);
      fr.onerror = () => rej(fr.error);
      fr.readAsDataURL(blob);
    });
  }

  /** Confere o cabecalho real: MP4 = "ftyp" nos bytes 4-8; imagem = JPEG/PNG/WEBP. Rejeita HTML. */
  async function validarBlob(blob, ehVideo) {
    const b = new Uint8Array(await blob.slice(0, 16).arrayBuffer());
    const s = String.fromCharCode(...b);
    if (/^\s*</.test(s)) return 'o servidor devolveu HTML (página de login/erro), não a mídia';
    if (ehVideo) {
      if (blob.size < 50 * 1024) return `arquivo pequeno demais (${blob.size} bytes)`;
      if (s.slice(4, 8) !== 'ftyp') return 'cabeçalho não é de MP4 (sem "ftyp")';
      return null;
    }
    if (blob.size < 10 * 1024) return `imagem pequena demais (${blob.size} bytes)`;
    const jpg = b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
    const png = s.startsWith('\x89PNG');
    const webp = s.startsWith('RIFF') && s.slice(8, 12) === 'WEBP';
    return jpg || png || webp ? null : 'cabeçalho de imagem inválido';
  }

  /**
   * Alternativa sem o menu: le a midia do card no content script (sessao da pagina) e VALIDA o arquivo;
   * se nao der, pede ao navegador para baixar a URL (chrome.downloads, com os cookies do usuario).
   * Nunca devolve uma URL crua para o servidor Node baixar (ele nao tem login -> recebia HTML).
   */
  async function arquivoDeMidia(tile, item) {
    const ehVideo = item?.tipo === 'video';
    tile.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    hoverCard(tile);
    await hoverConfiavel(midiasDoTile(tile)[0] || tile).catch(() => {});
    await dormir(1500);
    if (ehVideo && !tile.querySelector('video[src], video source[src]')) {
      await aguardar(
        () => {
          hoverCard(tile);
          const v = tile.querySelector('video');
          return v && (v.currentSrc || v.src || v.querySelector('source')?.src);
        },
        { timeout: 3500, intervalo: 350 }
      ).catch(() => null);
    }
    const midias = midiasDoTile(tile);
    const video = midias.find((m) => m.tagName === 'VIDEO' && (m.currentSrc || m.src || m.querySelector('source')?.src));
    const img = midias.filter((m) => m.tagName === 'IMG').sort((a, b) => (b.naturalWidth || 0) - (a.naturalWidth || 0))[0];
    const src = ehVideo ? (video?.currentSrc || video?.src || video?.querySelector('source')?.src) : (img?.currentSrc || img?.src);
    if (!src) throw new Error(ehVideo ? 'O card não tem o <video> carregado para baixar.' : 'Não encontrei a imagem gerada no card.');
    const urlMidia = normalizarUrlMidia(src);
    const todasChaves = chavesMidiaDoTile(tile);
    if (src.startsWith('blob:') || src.startsWith('data:')) {
      const blob = await (await fetch(src)).blob();
      const erro = await validarBlob(blob, ehVideo);
      if (erro) throw new Error(`Mídia do card inválida: ${erro}.`);
      return { base64: await blobParaBase64(blob), mime: blob.type, tamanho: blob.size, origem: 'midia-direta', urlMidia, todasChaves };
    }
    try {
      const resp = await fetch(src, { credentials: 'include' });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const tipo = resp.headers.get('content-type') || '';
      if (/text\/html|application\/json/i.test(tipo)) throw new Error(`resposta ${tipo}`);
      const blob = await resp.blob();
      const erro = await validarBlob(blob, ehVideo);
      if (erro) throw new Error(erro);
      return { base64: await blobParaBase64(blob), mime: blob.type, tamanho: blob.size, origem: 'midia-direta', urlMidia, todasChaves };
    } catch (e) {
      logExt(`Leitura direta da mídia falhou (${e.message}); baixando pelo navegador.`, 'aviso');
    }
    const r = await chamarBg({ tipo: 'baixar_url', url: src, nomeBase: item?.arquivoNome || item?.id || 'midia', timeoutMs: 5 * 60 * 1000 });
    if (!r?.ok) throw new Error(`Download pelo navegador falhou: ${r?.erro || '?'}`);
    return {
      arquivoLocal: r.arquivoLocal,
      mime: r.mime,
      tamanho: r.bytes,
      origem: 'midia-direta-navegador',
      urlMidia,
      urlDownload: normalizarUrlMidia(r.url || ''),
      todasChaves,
    };
  }

  /**
   * Download pelo menu ⋮ > Download > opcao escolhida (qualidade configurada).
   * Usa hover/clique real via debugger e NUNCA perde referencia do card correto.
   */
  async function baixarArquivo(tile, item, novela, ctx) {
    const ehVideo = item.tipo === 'video';
    const pref = ehVideo ? (novela?.qualidadeDownloadVideo || '1080p') : (novela?.qualidadeDownloadImagem || '2k');
    const brutoGen = ehVideo ? (numeroResolucao(novela?.qualidadeGeracaoVideo || '720p') || 720) : 0;
    const genRes = brutoGen === 4000 ? 2160 : brutoGen;
    const chavesOriginais = chavesMidiaDoTile(tile);
    const reacharCardExato = () => {
      if (tile.isConnected) return tile;
      if (chavesOriginais.length) {
        const achado = tiles().find((t) => chavesMidiaDoTile(t).some((k) => chavesOriginais.includes(k)));
        if (achado) return achado;
      }
      return null;
    };

    let captura = null;
    try {
      const cardMenu = reacharCardExato();
      if (!cardMenu) throw new Error('O card alvo saiu do DOM antes de abrir o menu de download.');
      await abrirMenuTileReal(cardMenu);
      const itemDl = await aguardar(() => localizarTodos(obter('ativo.itemDownload'))[0], { timeout: 5000, descricao: 'a opção "Download" no menu ⋮' });
      const antesItens = new Set(localizarTodos('[role="menuitem"]'));
      const novas = () => { const l = localizarTodos('[role="menuitem"]').filter((e) => !antesItens.has(e)); return l.length ? l : null; };

      // Primeiro tenta abrir o submenu por hover real (sem fechar o menu com clique precoce!)
      hover(itemDl);
      await hoverConfiavel(itemDl).catch(() => {});
      let opcoes = await aguardar(novas, { timeout: 2200 }).catch(() => null);

      if (!opcoes) {
        // Caso clicar em Download dispare download direto (ex.: imagem sem submenu) OU abra o submenu no clique:
        // ja arma captura antes de clicar para nunca perder o onCreated!
        captura = pedirCapturaDownload(item.arquivoNome || item.id, 5 * 60000, 12000);
        await cliqueForte(itemDl);
        opcoes = await aguardar(novas, { timeout: 2500 }).catch(() => null);
        if (!opcoes) {
          // Sem submenu: aguarda ate 12s pelo download direto iniciado pelo clique em Download
          const rDireto = await captura.promessa;
          const cAtual = reacharCardExato();
          const todasChaves = cAtual ? chavesMidiaDoTile(cAtual) : chavesOriginais;
          return {
            arquivoLocal: rDireto.arquivoLocal,
            mime: rDireto.mime,
            tamanho: rDireto.bytes,
            resolucao: 'original',
            upscale: false,
            origem: 'download-flow',
            urlDownload: normalizarUrlMidia(rDireto.url || ''),
            urlMidia: todasChaves[0] || null,
            todasChaves,
          };
        }
        // Abriu submenu -> cancela captura curta e arma com o prazo adequado da resolucao escolhida
        captura.cancelar();
        captura = null;
      }

      logExt(`Submenu de download: ${opcoes.map((o) => limpar(o.innerText || rotulo(o), 30)).join(' | ')}`, 'info');
      const e = escolherOpcaoDownload(opcoes, { ehVideo, pref, genRes });
      if (!e) throw new Error('Nenhuma opção de download compatível encontrada no menu.');
      const escolha = e.el;
      const rotuloEsc = e.t;
      const upscale = e.aprimorada;

      const minVideoUpscale = pref === '4k' ? 20 : (pref === '1080p' ? 15 : 8);
      const inicio = ehVideo ? (upscale ? minVideoUpscale * 60000 : 45000) : (upscale ? 240000 : 35000);
      captura = pedirCapturaDownload(item.arquivoNome || item.id, inicio + 5 * 60000, inicio);
      await dormir(250);
      progresso(ctx, `Baixando: ${rotuloEsc}${upscale ? ' (o Flow está aprimorando — pode levar alguns minutos)' : ''}`);
      const rClick = await cliqueConfiavel(escolha);
      if (!rClick?.ok) await cliqueReal(escolha);
      const r = await captura.promessa;
      const cFim = reacharCardExato();
      const todasChaves = cFim ? chavesMidiaDoTile(cFim) : chavesOriginais;
      return {
        arquivoLocal: r.arquivoLocal,
        mime: r.mime,
        tamanho: r.bytes,
        resolucao: rotuloEsc,
        upscale,
        origem: 'download-flow',
        urlDownload: normalizarUrlMidia(r.url || ''),
        urlMidia: todasChaves[0] || null,
        todasChaves,
      };
    } catch (e) {
      captura?.cancelar();
      await fecharOverlays();
      logExt(`Download pelo menu falhou (${e.message}). Usando a mídia original do card (validada).`, 'aviso');
      progresso(ctx, 'Baixando a mídia original do card (alternativa validada)');
      const cardFallback = reacharCardExato();
      if (!cardFallback) throw new Error(`O card de {${item.id}} desmontou da lista virtualizada durante o download.`);
      return await arquivoDeMidia(cardFallback, item);
    }
  }
  const baixarMaxima = (tile, item, ctx) => baixarArquivo(tile, item, { qualidadeDownloadVideo: '1080p', qualidadeDownloadImagem: '2k' }, ctx);

  /**
   * Localiza na lista virtualizada um card que possua alguma das `chavesAlvo` (ou case pelo prompt unico),
   * rolando do topo ao fim sem NUNCA usar fallback cego como `tiles()[0]`.
   */
  async function localizarCardNaListaVirtual({ chavesAlvo = [], scrollSugerido = null, item = null, outrosPrompts = [], chavesProibidas = [], exigirVideo = false } = {}) {
    const alvosNorm = (chavesAlvo || []).map(normalizarUrlMidia).filter(Boolean);
    const proibidasNorm = new Set((chavesProibidas || []).map(normalizarUrlMidia).filter(Boolean));
    const vp = obterViewportGrade();

    const inspecionarMontados = async () => {
      for (const t of tiles()) {
        if (exigirVideo && !ehTileDeVideo(t)) continue;
        const chaves = chavesMidiaDoTile(t);
        if (!chaves.length) continue;
        if (proibidasNorm.size && chaves.some((k) => proibidasNorm.has(k))) continue;

        if (alvosNorm.length) {
          if (chaves.some((k) => alvosNorm.includes(k))) return t;
          continue;
        }
        if (item?.prompt) {
          const pCard = await lerPromptLimpoDoTile(t, { expandir: true });
          if (pCard && pCard.length >= 25 && cardConfereComItem(pCard, item, outrosPrompts)) {
            return t;
          }
        }
      }
      return null;
    };

    if (vp && typeof scrollSugerido === 'number' && scrollSugerido >= 0) {
      vp.scrollTop = scrollSugerido;
      vp.dispatchEvent(new Event('scroll'));
      await dormir(650);
      const direto = await inspecionarMontados();
      if (direto) return direto;
    }

    rolarGradeTopo();
    await dormir(800);
    let achado = await inspecionarMontados();
    if (achado || !vp) return achado;

    const passo = Math.max(260, Math.floor(vp.clientHeight * 0.62));
    for (let i = 0; i < 65; i++) {
      const antesScroll = vp.scrollTop;
      vp.scrollTop = antesScroll + passo;
      vp.dispatchEvent(new Event('scroll'));
      await dormir(600);
      achado = await inspecionarMontados();
      if (achado) return achado;
      if (Math.abs(vp.scrollTop - antesScroll) < 4) break;
    }
    return null;
  }

  /** Localiza o card de um item ja gerado (pela chave da midia, pelo prompt unico ou pelo nome), rolando a grade se preciso. */
  async function acharTileDoItem(item, outrosPrompts = []) {
    const porChave = item.flowMidiaChave
      ? await localizarCardNaListaVirtual({
          chavesAlvo: [item.flowMidiaChave, ...(item.flowMidiaUrls || [])],
          exigirVideo: item.tipo === 'video',
        })
      : null;
    if (porChave) return porChave;

    if (item?.prompt) {
      const porPrompt = await localizarCardNaListaVirtual({
        item,
        outrosPrompts,
        exigirVideo: item.tipo === 'video',
      });
      if (porPrompt) return porPrompt;
    }

    // Ultimo recurso apenas por aria-label exato (nunca tiles()[0]!)
    rolarGradeTopo();
    await dormir(700);
    let t = acharTile(item.id);
    const vp = obterViewportGrade();
    for (let i = 0; !t && vp && i < 45; i++) {
      const ant = vp.scrollTop;
      vp.scrollTop += Math.max(260, Math.floor(vp.clientHeight * 0.65));
      vp.dispatchEvent(new Event('scroll'));
      await dormir(550);
      t = acharTile(item.id);
      if (Math.abs(vp.scrollTop - ant) < 4) break;
    }
    return t || null;
  }

  /**
   * 2a) Garante que o filtro do topo e da barra lateral mostrem TODOS os ativos/videos (e nunca fiquem presos em "Imagens").
   */
  async function garantirFiltroTodosAtivos(modoPreferido = 'dashboard') {
    try {
      await fecharOverlays();
      // 1) Limpa campo de busca do cabecalho se houver texto filtrando a grade
      const inpBusca = localizar({ css: 'header input[aria-label*="Pesquisar"], input[aria-label="Pesquisar"]', visivel: false });
      if (inpBusca && String(inpBusca.value || '').trim()) {
        definirValorInput(inpBusca, '');
        inpBusca.dispatchEvent(new Event('change', { bubbles: true }));
        tecla(inpBusca, 'Escape', 'Escape', 27);
        await dormir(500);
      }

      // 2) Se houver chips/botoes de filtro no topo marcando apenas "Imagens" / "Favoritos", volta para "Todos" / desmarca
      const chipsTopo = [...document.querySelectorAll('header [aria-selected="true"], header [aria-pressed="true"], mat-chip-option[aria-selected="true"]')];
      for (const ch of chipsTopo) {
        const txt = normal(ch.innerText || M().nomeAcessivel(ch) || '');
        if (/^(imagens?|images?|favoritos?|favorites?)$/.test(txt)) {
          await cliqueReal(ch).catch(() => {});
          await dormir(400);
        }
      }

      // 3) Barra lateral do projeto (`flow-project-nav-list` / `mat-nav-list`): clica em `dashboard` (Todos os ativos) ou `videocam` (Videos)
      const navList = localizar({ css: 'flow-project-nav-list, mat-nav-list[aria-label*="Navegar"]', visivel: false });
      if (navList) {
        const botoesNav = [...navList.querySelectorAll('button, a[role="listitem"], [mat-list-item]')].filter((b) => M().visivel(b));
        const acharPorIcone = (ic) => botoesNav.find((b) => (M().textosIcones(b) || []).includes(ic));
        const btnAlvo = acharPorIcone(modoPreferido) || acharPorIcone('dashboard');
        if (btnAlvo) {
          const ativo = btnAlvo.getAttribute('aria-current') === 'page'
            || btnAlvo.getAttribute('aria-selected') === 'true'
            || btnAlvo.classList.contains('mdc-list-item--activated');
          if (!ativo) {
            await cliqueReal(btnAlvo).catch(() => {});
            await dormir(750);
          }
        }
      }
    } catch {}
  }

  /**
   * Hidrata o elemento <video> dentro de um card (hover real) e extrai sua URL real de midia + URL base sem query string.
   */
  async function hidratarExtrairVideoDoTile(tile) {
    if (!tile) return { videoUrlReal: null, videoUrlBase: null, chaves: [] };
    let v = tile.querySelector('video');
    let src = v?.currentSrc || v?.src || v?.querySelector('source')?.src || '';
    if (!src) {
      tile.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
      hoverCard(tile);
      await hoverConfiavel(midiasDoTile(tile)[0] || tile).catch(() => {});
      await aguardar(
        () => {
          hoverCard(tile);
          const vd = tile.querySelector('video');
          return vd && (vd.currentSrc || vd.src || vd.querySelector('source')?.src);
        },
        { timeout: 2400, intervalo: 250 }
      ).catch(() => null);
      v = tile.querySelector('video');
      src = v?.currentSrc || v?.src || v?.querySelector('source')?.src || '';
    }
    const videoUrlBase = normalizarUrlMidia(src);
    const chaves = [...new Set([videoUrlBase, ...chavesMidiaDoTile(tile)].filter(Boolean))];
    return { videoUrlReal: src || null, videoUrlBase: videoUrlBase || chaves[0] || null, chaves };
  }

  /** Pontua um card escaneado contra uma cena especifica IGNORANDO titulos renomeados errados (`Cena 06` / `Cena 12`). */
  function pontuarCardLocal(card, item, outrosPrompts = []) {
    const pCard = normal(String(card?.promptLimpo || '').replace(/[“”«»„]/g, '"').replace(/[‘’]/g, "'"));
    const ass = assinaturaPromptLocal(item?.prompt || '', outrosPrompts);
    let pts = 0;

    // Se expuser chip `imagem_NN`, pontua ou rejeita se pertencer a outra cena
    const refsCena = new Set((item?.refs || []).map(normal));
    for (const ch of card?.chips || []) {
      const mImg = normal(ch).match(/\b(imagem[\s_-]*\d+)\b/i);
      if (mImg) {
        const idImg = normal(mImg[1].replace(/[\s-]+/g, '_'));
        if (refsCena.has(idImg)) pts += 180;
        else return -500;
      }
    }

    if (pCard && pCard.length >= 20) {
      for (const op of outrosPrompts || []) {
        if (!op || normal(op) === ass.normP) continue;
        const falasOutro = extrairFalasPromptLocal(op).filter((f) => !ass.normP.includes(f));
        if (falasOutro.some((f) => f.length >= 10 && pCard.includes(f))) return -500;
      }
      for (const f of ass.falasExclusivas) if (pCard.includes(f)) pts += 150;
      for (const f of ass.falas) if (pCard.includes(f)) pts += 60;
      for (const t of ass.trechosExclusivos) if (pCard.includes(t)) pts += 35;
      if (pCard === ass.normP || pCard.includes(ass.normP)) pts += 80;
    }
    return pts > 0 ? pts : -1;
  }

  /** Baixa de novo um item ja gerado (e tambem suporta `modo: 'recapturar_cena_v194'` caso o SW ainda esteja em v1.9.4). */
  async function baixarItem(payload = {}) {
    const { novela, item, outrosPrompts = [], modo, forcarNovoScan, chavesProibidas = [] } = payload;
    if (modo === 'recapturar_cena_v194') {
      if (forcarNovoScan || !NS._cacheScanRecaptura || NS._cacheScanRecaptura.pathname !== location.pathname) {
        const scan = await escanearVideosDoProjeto({ novelaId: novela?.id });
        NS._cacheScanRecaptura = { pathname: location.pathname, em: Date.now(), scan };
      }
      const proibidasSet = new Set((chavesProibidas || []).map(normalizarUrlMidia).filter(Boolean));
      const candidatos = (NS._cacheScanRecaptura.scan?.cards || [])
        .filter((c) => !c.chaves.some((k) => proibidasSet.has(k)))
        .map((c) => ({ card: c, pts: pontuarCardLocal(c, item, outrosPrompts) }))
        .filter((x) => x.pts > 0)
        .sort((a, b) => b.pts - a.pts);
      const cardAlvo = candidatos[0]?.card || null;
      if (!cardAlvo) {
        throw new Error(`Não encontrei card de vídeo único correspondente ao diálogo de {${item.id}} na página do Flow.`);
      }
      const resDl = await baixarCardEscaneado({
        novela,
        item,
        cardAlvo,
        chavesProibidas,
        outrosPrompts,
        renomear: true,
      });
      return {
        ...resDl,
        totalCardsVideo: NS._cacheScanRecaptura.scan?.totalCardsVideo || 0,
      };
    }

    const ctx = { novelaId: novela.id, itemId: item.id };
    await verificarCalibragem();
    await fecharOverlays();
    const tile = await acharTileDoItem(item, outrosPrompts);
    if (!tile) throw new Error(`Não encontrei o card de {${item.id}} no projeto do Flow.`);
    const todasChaves = chavesMidiaDoTile(tile);
    const midiaChave = todasChaves[0] || item.flowMidiaChave || null;
    const arquivo = await baixarArquivo(tile, item, novela, ctx);
    await fecharOverlays();
    return {
      ...arquivo,
      nomeAtivo: normal(tile.getAttribute('aria-label')) === normal(item.id) ? item.id : null,
      midiaChave,
      todasChaves: [...new Set([...todasChaves, ...(arquivo.todasChaves || [])])],
    };
  }

  /**
   * 3) Varre a pagina aberta do projeto no Google Flow de ponta a ponta (lista virtualizada):
   *    a) NAO confia nos titulos renomeados atuais (`Cena 06` / `Cena 12`);
   *    b) Rola a galeria do inicio ao fim coletando todos os cards de `<video>` distintos (URLs base unicas);
   *    c) Inspeciona o prompt original completo + chips `imagem_NN` de cada card (tanto em Lista quanto em Grade via `Reutilizar comando` `redo`);
   *    d) Registra a ordem visual/cronologica exata na grade para desempate garantido.
   */
  async function escanearVideosDoProjeto({ novelaId } = {}) {
    const ctx = { novelaId, itemId: null };
    await verificarCalibragem();
    await fecharOverlays();
    const padrao = obter('projeto.padraoUrlProjeto', false) || '/project/';
    if (!location.pathname.includes(padrao)) {
      throw new Error('A aba do Google Flow não está dentro de um projeto aberto.');
    }

    progresso(ctx, 'Garantindo exibição de todos os vídeos no projeto...');
    await garantirFiltroTodosAtivos('dashboard');

    const executarPassadaDeScroll = async () => {
      const vp = obterViewportGrade();
      rolarGradeTopo();
      await dormir(1000);

      const cards = []; // [{ idScan, chaves, videoUrlReal, videoUrlBase, ariaLabel, promptLimpo, chips, chipsChaves, scrollTop, yAbs, xAbs, ordemTopo }]
      const urlsBaseVistas = new Set();

      const coletarParadaAtual = async (scrollRef) => {
        const visiveis = tiles().filter((t) => ehTileDeVideo(t));
        for (const t of visiveis) {
          const txt = t.innerText || '';
          const carregando = Boolean(/\b(\d{1,3})\s*%/.test(txt) || t.querySelector('[role="progressbar"], mat-progress-spinner, mat-spinner'));
          if (carregando) continue;

          const chavesIniciais = chavesMidiaDoTile(t);
          const existente = chavesIniciais.length
            ? cards.find((c) => c.chaves.some((k) => chavesIniciais.includes(k)))
            : null;

          if (existente) {
            if (!existente.videoUrlReal) {
              const hid = await hidratarExtrairVideoDoTile(t);
              if (hid.videoUrlReal) existente.videoUrlReal = hid.videoUrlReal;
              if (hid.videoUrlBase) existente.videoUrlBase = hid.videoUrlBase;
              for (const k of hid.chaves) if (!existente.chaves.includes(k)) existente.chaves.push(k);
            }
            if (!existente.promptLimpo || existente.promptLimpo.length < 60) {
              const insp = await inspecionarPromptEChipsDoCard(t, { limparDepois: false });
              if (insp.promptLimpo && insp.promptLimpo.length > (existente.promptLimpo?.length || 0)) {
                existente.promptLimpo = insp.promptLimpo;
                existente.chips = insp.chips;
                existente.chipsChaves = insp.chipsChaves;
              }
            }
            continue;
          }

          const rectAntes = t.getBoundingClientRect();
          const yAbs = Math.round((vp ? vp.scrollTop : scrollRef) + rectAntes.top);
          const xAbs = Math.round(rectAntes.left);

          const hid = await hidratarExtrairVideoDoTile(t);
          if (!hid.chaves.length) continue;
          if (hid.videoUrlBase && urlsBaseVistas.has(hid.videoUrlBase)) continue;
          if (hid.chaves.some((k) => urlsBaseVistas.has(k))) continue;

          progresso(ctx, `Lendo prompt/fala original do vídeo #${cards.length + 1} no Flow...`);
          const insp = await inspecionarPromptEChipsDoCard(t, { limparDepois: false });
          const ariaLabel = (t.getAttribute('aria-label') || '').trim();
          if (hid.videoUrlBase) urlsBaseVistas.add(hid.videoUrlBase);
          hid.chaves.forEach((k) => urlsBaseVistas.add(k));

          cards.push({
            idScan: `card_${cards.length + 1}`,
            chaves: hid.chaves,
            videoUrlReal: hid.videoUrlReal,
            videoUrlBase: hid.videoUrlBase,
            ariaLabel,
            promptLimpo: insp.promptLimpo || '',
            chips: insp.chips || [],
            chipsChaves: insp.chipsChaves || [],
            scrollTop: vp ? vp.scrollTop : scrollRef,
            yAbs,
            xAbs,
            ordemTopo: cards.length,
          });
        }
      };

      await coletarParadaAtual(0);

      if (vp) {
        const passo = Math.max(240, Math.floor(vp.clientHeight * 0.55));
        for (let passoIdx = 1; passoIdx <= 85; passoIdx++) {
          const antes = vp.scrollTop;
          vp.scrollTop = antes + passo;
          vp.dispatchEvent(new Event('scroll'));
          await dormir(650);
          progresso(ctx, `Varrendo galeria virtualizada do Flow… (${cards.length} vídeo(s) único(s) lido(s))`);
          await coletarParadaAtual(vp.scrollTop);
          if (Math.abs(vp.scrollTop - antes) < 4) break;
        }
        rolarGradeTopo();
        await dormir(600);
      }

      // Ordena pela posicao real na grade (topo->baixo com tolerancia de linha de 45px, esquerda->direita)
      cards.sort((a, b) => {
        const dy = (a.yAbs ?? 0) - (b.yAbs ?? 0);
        if (Math.abs(dy) > 45) return dy;
        return (a.xAbs ?? 0) - (b.xAbs ?? 0);
      });
      cards.forEach((c, idx) => { c.ordemTopo = idx; });

      return cards;
    };

    try {
      let cards = await executarPassadaDeScroll();
      if (cards.length === 0) {
        await garantirFiltroTodosAtivos('videocam');
        cards = await executarPassadaDeScroll();
      }
      const comPrompt = cards.filter((c) => c.promptLimpo && c.promptLimpo.length >= 30).length;
      logExt(
        `Varredura concluída: ${cards.length} vídeo(s) único(s) encontrado(s) no Flow (${comPrompt}/${cards.length} com prompt/fala original lido!).`,
        cards.length > 0 ? 'ok' : 'aviso'
      );
      return { totalCardsVideo: cards.length, cards, projetoUrl: location.href };
    } finally {
      await limparComposer({ limparTexto: true }).catch(() => {});
    }
  }

  /**
   * Baixa a midia diretamente a partir de uma `videoUrlReal` ja extraida durante a varredura (fallback ultrarrapido).
   */
  async function baixarPelaUrlExtraida(urlReal, item, todasChaves = []) {
    if (!urlReal || !/^https?:/.test(urlReal)) throw new Error('URL direta ausente.');
    const urlMidia = normalizarUrlMidia(urlReal);
    try {
      const resp = await fetch(urlReal, { credentials: 'include' });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const tipo = resp.headers.get('content-type') || '';
      if (/text\/html|application\/json/i.test(tipo)) throw new Error(`resposta ${tipo}`);
      const blob = await resp.blob();
      const erro = await validarBlob(blob, true);
      if (erro) throw new Error(erro);
      return { base64: await blobParaBase64(blob), mime: blob.type, tamanho: blob.size, origem: 'midia-url-escaneada', urlMidia, todasChaves };
    } catch {
      const r = await chamarBg({ tipo: 'baixar_url', url: urlReal, nomeBase: item?.arquivoNome || item?.id || 'cena', timeoutMs: 5 * 60 * 1000 });
      if (!r?.ok) throw new Error(`Download direto falhou: ${r?.erro || '?'}`);
      return {
        arquivoLocal: r.arquivoLocal,
        mime: r.mime,
        tamanho: r.bytes,
        origem: 'midia-url-navegador',
        urlMidia,
        urlDownload: normalizarUrlMidia(r.url || ''),
        todasChaves,
      };
    }
  }

  /**
   * Rola ate um card especifico previamente escaneado (ou localiza um card de recuperacao sem repetir chaves proibidas),
   * corrige o nome se necessario e faz o download validado do .mp4!
   */
  async function baixarCardEscaneado({ novela, item, cardAlvo = null, chavesProibidas = [], outrosPrompts = [], renomear = true }) {
    const ctx = { novelaId: novela.id, itemId: item.id };
    await verificarCalibragem();
    await fecharOverlays();

    const proibidasSet = new Set((chavesProibidas || []).map(normalizarUrlMidia).filter(Boolean));
    const pref = novela?.qualidadeDownloadVideo || '1080p';
    const brutoGen = numeroResolucao(novela?.qualidadeGeracaoVideo || '720p') || 720;
    const precisaMenuQualidade = pref !== 'original' && (numeroResolucao(pref) || 0) > (brutoGen === 4000 ? 2160 : brutoGen);

    const tile = await localizarCardNaListaVirtual({
      chavesAlvo: cardAlvo?.chaves || [],
      scrollSugerido: cardAlvo?.scrollTop ?? null,
      item,
      outrosPrompts,
      chavesProibidas,
      exigirVideo: item.tipo === 'video',
    });

    // Se o card nao precisa de upscale pelo menu ⋮ E ja temos a videoUrlReal extraida na varredura, podemos inclusive usar como fallback imediato!
    if (!tile) {
      if (cardAlvo?.videoUrlReal && (!proibidasSet.size || !cardAlvo.chaves?.some((k) => proibidasSet.has(k)))) {
        logExt(`Baixando {${item.id}} direto pela URL de mídia extraída na varredura.`, 'info');
        const arqDireto = await baixarPelaUrlExtraida(cardAlvo.videoUrlReal, item, cardAlvo.chaves || []);
        return {
          ...arqDireto,
          nomeAtivo: null,
          midiaChave: cardAlvo.videoUrlBase || arqDireto.urlMidia || cardAlvo.chaves?.[0] || null,
          todasChaves: cardAlvo.chaves || [],
          projetoUrl: location.href,
        };
      }
      throw new Error(`Não consegui localizar o card correspondente a {${item.id}} na página do Google Flow.`);
    }

    tile.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    await dormir(350);
    const hid = await hidratarExtrairVideoDoTile(tile);
    const chavesAtuais = [...new Set([...(cardAlvo?.chaves || []), ...hid.chaves].map(normalizarUrlMidia).filter(Boolean))];
    if (proibidasSet.size && chavesAtuais.some((k) => proibidasSet.has(k))) {
      throw new Error(`O card localizado para {${item.id}} já pertence a outra cena salva anteriormente.`);
    }

    let renomeado = normal(tile.getAttribute('aria-label')) === normal(item.id);
    if (renomear && !renomeado) {
      const colisao = tiles().find((t) => t !== tile && normal(t.getAttribute('aria-label')) === normal(item.id));
      if (colisao) {
        try { await renomearAtivo(colisao, `${item.id}_antigo`, ctx); } catch {}
      }
      try { renomeado = await renomearAtivo(tile, item.id, ctx); } catch { await fecharOverlays(); }
    }

    let arquivo = null;
    if (!precisaMenuQualidade && (hid.videoUrlReal || cardAlvo?.videoUrlReal)) {
      try {
        progresso(ctx, `Baixando mídia original de {${item.id}}...`);
        arquivo = await baixarPelaUrlExtraida(hid.videoUrlReal || cardAlvo.videoUrlReal, item, chavesAtuais);
      } catch {}
    }

    if (!arquivo) {
      const tileParaBaixar = tile.isConnected
        ? tile
        : await localizarCardNaListaVirtual({ chavesAlvo: chavesAtuais, scrollSugerido: cardAlvo?.scrollTop ?? null, exigirVideo: item.tipo === 'video' });
      if (!tileParaBaixar && (hid.videoUrlReal || cardAlvo?.videoUrlReal)) {
        arquivo = await baixarPelaUrlExtraida(hid.videoUrlReal || cardAlvo.videoUrlReal, item, chavesAtuais);
      } else if (tileParaBaixar) {
        arquivo = await baixarArquivo(tileParaBaixar, item, novela, ctx);
      } else {
        throw new Error(`O card de {${item.id}} desmontou antes de concluir o download.`);
      }
    }

    await fecharOverlays();
    const todasChaves = [...new Set([...chavesAtuais, ...(arquivo.todasChaves || [])].map(normalizarUrlMidia).filter(Boolean))];
    return {
      ...arquivo,
      nomeAtivo: renomeado ? item.id : null,
      midiaChave: hid.videoUrlBase || cardAlvo?.videoUrlBase || todasChaves[0] || arquivo.urlMidia || null,
      todasChaves,
      projetoUrl: location.href,
    };
  }

  // =============================================================
  //  PROJETO
  // =============================================================
  async function aguardarPronto({ url } = {}) {
    await aguardar(() => document.readyState === 'complete', { timeout: 30000, descricao: 'a página carregar' });
    const padrao = obter('projeto.padraoUrlProjeto', false) || '/project/';
    const esperavaProjeto = url ? url.includes(padrao) : location.pathname.includes(padrao);
    if (esperavaProjeto) {
      await dormir(800);
      const fim = Date.now() + 22000;
      while (Date.now() < fim) {
        if (!location.pathname.includes(padrao)) {
          return { inacessivel: true, motivo: 'Redirecionado para fora do projeto (pertence a outra conta ou sem permissão)', url: location.href, pedido: url, conta: contaAtual() };
        }
        const erroProj = detectarProjetoInacessivel();
        if (erroProj) {
          return { inacessivel: true, motivo: erroProj, url: location.href, pedido: url, conta: contaAtual() };
        }
        if (localizar(obter('prompt.campo'))) {
          await dormir(600);
          return { inacessivel: false, url: location.href, pedido: url, conta: contaAtual() };
        }
        await dormir(400);
      }
      return {
        inacessivel: true,
        motivo: detectarProjetoInacessivel() || 'Projeto não encontrado ou sem acesso na conta Google atual',
        url: location.href,
        pedido: url,
        conta: contaAtual(),
      };
    }
    await dormir(800);
    return { inacessivel: false, url: location.href, pedido: url, conta: contaAtual() };
  }

  async function renomearProjeto(nome) {
    const inp = await aguardar(() => localizar(obter('projeto.inputNomeProjeto')), { timeout: 10000 }).catch(() => null);
    if (!inp || !nome) return false;
    await cliqueReal(inp);
    await digitarTexto(inp, nome);
    tecla(inp, 'Enter', 'Enter', 13);
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    inp.blur();
    inp.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    await dormir(800);
    return normal(inp.value) === normal(nome);
  }

  async function criarProjeto({ nome, conta } = {}) {
    await carregarSeletores();
    const padrao = obter('projeto.padraoUrlProjeto', false) || '/project/';
    const contaEsperada = conta ?? contaAtual();
    if (location.pathname.includes(padrao)) throw new Error('A aba não está na página inicial do Flow para criar um projeto novo.');
    let btn;
    try {
      btn = await aguardar(() => localizar(obter('projeto.botaoNovoProjeto')), { timeout: 20000, descricao: 'o botão "Novo projeto"' });
    } catch {
      throw new Error('Não encontrei o botão "Novo projeto" na página inicial do Flow. Grave 1 captura clicando nele (ver instruções).');
    }
    const antes = location.href;
    await cliqueReal(btn);
    await aguardar(() => location.href !== antes && location.pathname.includes(padrao), { timeout: 60000, descricao: 'o novo projeto abrir' });
    await aguardarPronto();
    let renomeado = false;
    try { renomeado = await renomearProjeto(nome); } catch {}
    if (contaEsperada != null && contaAtual() !== contaEsperada) {
      logExt(`Projeto abriu em /u/${contaAtual() ?? '-'}/ em vez de /u/${contaEsperada}/ — corrigindo.`, 'aviso');
    }
    return { url: aplicarConta(location.href, contaEsperada), contaEsperada, contaPagina: contaAtual(), renomeado };
  }

  // =============================================================
  //  ORQUESTRACAO DE UM ITEM
  // =============================================================
  const OBRIGATORIOS = ['prompt.campo', 'prompt.gerar', 'configuracoes.gatilho', 'configuracoes.painel', 'resultado.tile', 'ingredientes.botaoAdicionar', 'ativo.botaoMais'];

  async function verificarCalibragem() {
    await carregarSeletores();
    const faltando = OBRIGATORIOS.filter((c) => obter(c, false) == null);
    if (!SEL.calibrado || faltando.length) {
      throw new Error(`Automação não calibrada. Pendentes: ${faltando.join(', ') || 'calibrado=false'} (dados/flow-selectors.json).`);
    }
  }

  async function executarItem({ novela, item, refsInfo, chavesProibidas = [], outrosPrompts = [], quantidadeResultados = 1 }) {
    const ctx = { novelaId: novela.id, itemId: item.id };
    await verificarCalibragem();
    const erroProj = detectarProjetoInacessivel();
    if (erroProj) throw new ErroFatal(`[PROJETO_INACESSIVEL] ${erroProj}`);
    try {
      await aguardar(() => {
        const ep = detectarProjetoInacessivel();
        if (ep) throw new ErroFatal(`[PROJETO_INACESSIVEL] ${ep}`);
        const sc = detectarCreditosEsgotados();
        if (sc) throw new ErroFatal(`[CREDITOS_ESGOTADOS] ${sc}`);
        return localizar(obter('prompt.campo'));
      }, { timeout: 25000, descricao: 'a caixa de comando do Flow' });
    } catch (e) {
      if (e instanceof ErroFatal) throw e;
      if (!location.pathname.includes(obter('projeto.padraoUrlProjeto', false) || '/project/')) {
        throw new ErroFatal('[PROJETO_INACESSIVEL] A aba saiu do projeto do Google Flow.');
      }
      throw e;
    }
    const ehVideo = item.tipo === 'video';
    const qtdEfetiva = (!ehVideo && Number(quantidadeResultados || item?.quantidadeResultados) === 4) ? 4 : 1;
    const forcarElementos = ehVideo && (novela?.forcarElementos || novela?.modoGeracaoVideo === 'elementos' || item.submodo === 'elementos_video');
    const submodoEfetivo = ehVideo ? (forcarElementos ? 'elementos_video' : (item.submodo || 'frame_inicial')) : item.submodo;
    const timeoutGeracao = ehVideo ? 14 * 60 * 1000 : 5 * 60 * 1000;

    await fecharOverlays();
    await excluirCardsFalhosVisiveis();
    await configurar({
      ehVideo,
      submodo: submodoEfetivo,
      modelo: ehVideo ? novela.modeloVideo : novela.modeloImagem,
      duracao: item.duracao,
      qualidadeGeracao: novela.qualidadeGeracaoVideo,
      quantidadeResultados: qtdEfetiva,
    }, ctx);

    let resultadoRender = null;
    let ativosSubidos = [];
    try {
      progresso(ctx, 'Limpando referências anteriores');
      await limparIngredientes();
      const refs = item.refs || [];
      ativosSubidos = [];
      for (const [i, ref] of refs.entries()) {
        progresso(ctx, `Anexando referência ${i + 1}/${refs.length}: ${ref}`);
        await anexarReferencia(ref, submodoEfetivo === 'frame_inicial' && i === 0, ctx, refsInfo?.[ref] || null, ativosSubidos);
      }
      if (refs.length && contarIngredientes() < refs.length) {
        throw new Error(`Só ${contarIngredientes()} de ${refs.length} referência(s) apareceram na caixa de comando.`);
      }
      if (refs.length) {
        // BARREIRA: nunca colar o prompt / clicar em → antes de TODAS as imagens anexadas estarem 100% no Flow (+2,5s estabilizador)
        progresso(ctx, `Confirmando que as ${refs.length} imagem(ns) anexada(s) terminaram de subir...`);
        await aguardarUploadsConcluidos({ esperado: refs.length, ctx, rotulo: `${refs.length} anexo(s) de {${item.id}}` });
      }

      progresso(ctx, 'Colando prompt');
      await colarPrompt(item.prompt, ctx);
      if (refs.length) await aguardarUploadsConcluidos({ esperado: refs.length, ctx, estabilizadorMs: 0, timeoutMs: 30000 });
      const antes = await snapshotResultados(chavesProibidas);
      await enviar(antes, item.prompt, ctx);
      progresso(ctx, qtdEfetiva === 4 ? 'Enviado em Modo Burst 4x — aguardando pelo menos 1 das 4 imagens gerar' : 'Enviado — aguardando o Flow gerar');
      resultadoRender = await aguardarRenderizacao(
        antes,
        { item, ehVideo, outrosPrompts },
        timeoutGeracao,
        ctx
      );
    } finally {
      if (qtdEfetiva === 4) {
        await restaurarQuantidadePadrao1x(ctx);
      }
    }
    const { tile, midia, todasChaves: chavesRender } = resultadoRender;
    const midiaChave = chaveMidia(midia) || chavesRender?.[0] || null;
    const chavesCardNovo = [...new Set([midiaChave, ...(chavesRender || [])].filter(Boolean))];
    await dormir(2500);

    // JAMAIS usar fallback cego: localiza estritamente pelas chaves ineditas do card recem-gerado!
    const tileGerado = () => {
      if (tile.isConnected) return tile;
      if (chavesCardNovo.length) {
        const achado = tiles().find((t) => chavesMidiaDoTile(t).some((k) => chavesCardNovo.includes(k)));
        if (achado) return achado;
      }
      return null;
    };

    progresso(ctx, `Renomeando ativo para "${item.id}"`);
    // Regenerar: a versao ANTIGA ainda tem o nome {id} no Flow -> renomeia para "{id}_antigo" (evita nome duplicado)
    if (item.flowMidiaChave && item.flowMidiaChave !== midiaChave) {
      const chaveAntigaNorm = normalizarUrlMidia(item.flowMidiaChave);
      const velho = chaveAntigaNorm ? tiles().find((t) => chavesMidiaDoTile(t).includes(chaveAntigaNorm)) : null;
      if (velho && velho !== tileGerado() && normal(velho.getAttribute('aria-label')) === normal(item.id)) {
        progresso(ctx, `Renomeando a versão antiga para "${item.id}_antigo"`);
        try { await renomearAtivo(velho, `${item.id}_antigo`, ctx); } catch (e) { logExt(`Não renomeei a versão antiga de {${item.id}}: ${e.message}`, 'aviso'); }
      }
    }
    let renomeado = false;
    const cardRen = tileGerado();
    if (cardRen) {
      try { renomeado = await renomearAtivo(cardRen, item.id, ctx); }
      catch (e) { logExt(`Renomear {${item.id}} falhou: ${e.message}`, 'aviso'); await fecharOverlays(); }
    }
    if (renomeado) logExt(`Ativo renomeado e verificado no Flow: "${item.id}".`, 'ok');
    else logExt(`NÃO consegui gravar o nome "${item.id}" no Flow após 3 tentativas verificadas. Itens que usam [${item.id}] usarão o reparo/upload automático.`, 'aviso');

    progresso(ctx, 'Baixando em resolução máxima');
    let alvo = tileGerado();
    if (!alvo) {
      alvo = await localizarCardNaListaVirtual({ chavesAlvo: chavesCardNovo, item, outrosPrompts, chavesProibidas, exigirVideo: ehVideo });
    }
    if (!alvo) throw new Error(`O card recém-gerado de {${item.id}} saiu do DOM antes de concluir o download.`);
    const arquivo = await baixarArquivo(alvo, item, novela, ctx);
    await fecharOverlays();
    const todasChavesFinais = [...new Set([...chavesCardNovo, ...(arquivo.todasChaves || [])].map(normalizarUrlMidia).filter(Boolean))];
    return {
      ...arquivo,
      nomeAtivo: renomeado ? item.id : null,
      midiaChave: midiaChave || todasChavesFinais[0] || null,
      todasChaves: todasChavesFinais,
      ativosSubidos,
      projetoUrl: location.href,
    };
  }

  NS.automation = {
    NaoCalibradoError,
    HOSTS_FLOW,
    ehPaginaFlow,
    contaAtual,
    contaDaUrl,
    aplicarConta,
    urlHome,
    _ouvinteStorage: ouvinteStorage,
    carregarSeletores,
    helpers: { dormir, aguardar, localizar, localizarTodos, cliqueReal, hover, digitarTexto, tecla, fecharOverlays, substituir, normalizarUrlMidia, projectIdDaUrl, aguardarUploadsConcluidos },
    passos: {
      abrirConfiguracoes, fecharConfiguracoes, escolherRadio, selecionarModelo, definirDuracao, definirResolucaoMaxima, configurar,
      limparIngredientes, limparComposer, anexarReferencia, colarPrompt, enviar, snapshotResultados, aguardarRenderizacao,
      renomearAtivo, baixarMaxima, baixarArquivo, escolherOpcaoDownload, arquivoDeMidia, renomearProjeto,
    },
    executarItem,
    baixarItem,
    escanearVideosDoProjeto,
    baixarCardEscaneado,
    criarProjeto,
    limparComposer: async (p) => { await carregarSeletores(); return limparComposer(p); },
    renomearProjeto: async ({ nome }) => { await carregarSeletores(); return { renomeado: await renomearProjeto(nome) }; },
    aguardarPronto: async (p) => { await carregarSeletores(); return aguardarPronto(p); },
  };
  carregarSeletores();
})();
