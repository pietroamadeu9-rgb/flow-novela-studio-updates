// =============================================================
//  Flow Novela Studio - Content script (ponte aba <-> service worker)
// =============================================================
(function () {
  const NS = (window.FlowStudio = window.FlowStudio || {});
  // Pode ser injetado de novo (extensao recarregada / injecao automatica): remove o ouvinte antigo
  if (NS.ouvinteMensagens) {
    try { chrome.runtime.onMessage.removeListener(NS.ouvinteMensagens); } catch {}
  }
  NS.contentPronto = true;

  const ok = (data) => ({ ok: true, data });
  const falha = (e) => ({ ok: false, erro: e?.message || String(e) });

  NS.ouvinteMensagens = (msg, sender, responder) => {
    const acao = msg?.acao;
    if (!acao) return;
    (async () => {
      switch (acao) {
        case 'ping':
          return { pronto: true, url: location.href, conta: NS.automation.contaAtual() };
        case 'mapear':
          return NS.mapper.capturar(msg.payload || {});
        case 'gravar_cliques':
          return NS.mapper.gravarCliques(msg.payload?.ligado);
        case 'status_gravacao':
          return { gravando: NS.mapper.estaGravando() };
        case 'seletores_atualizados':
          await NS.automation.carregarSeletores();
          return { ok: true };
        case 'criar_projeto':
          return NS.automation.criarProjeto(msg.payload || {});
        case 'renomear_projeto':
          return NS.automation.renomearProjeto(msg.payload || {});
        case 'aguardar_pronto':
          return NS.automation.aguardarPronto(msg.payload || {});
        case 'limpar_composer':
          return NS.automation.limparComposer(msg.payload || {});
        case 'executar_item':
          return NS.automation.executarItem(msg.payload);
        case 'baixar_item':
          return NS.automation.baixarItem(msg.payload);
        case 'escanear_videos_projeto':
          return NS.automation.escanearVideosDoProjeto(msg.payload || {});
        case 'baixar_card_escaneado':
          return NS.automation.baixarCardEscaneado(msg.payload || {});
        default:
          throw new Error(`Ação desconhecida na página: ${acao}`);
      }
    })()
      .then((d) => responder(acao === 'status_gravacao' ? d : ok(d)))
      .catch((e) => responder(falha(e)));
    return true;
  };
  chrome.runtime.onMessage.addListener(NS.ouvinteMensagens);
})();
