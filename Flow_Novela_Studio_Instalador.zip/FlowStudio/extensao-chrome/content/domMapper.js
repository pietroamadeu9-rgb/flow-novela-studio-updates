// =============================================================
//  Flow Novela Studio - Mapeador DOM do Google Flow
//  Varre elementos interativos visiveis, menus abertos, cards de ativos,
//  textos visiveis e inputs de arquivo, IGNORANDO classes CSS aleatorias.
//  Gera seletores estaveis (aria-label, role+nome, placeholder, data-*, texto).
// =============================================================
(function () {
  const NS = (window.FlowStudio = window.FlowStudio || {});
  // reinjecao: desliga a gravacao de cliques da instancia anterior
  if (NS.mapper) { try { NS.mapper.gravarCliques(false); } catch {} }

  const VERSAO_MAPPER = '1.0.0';
  const SELETOR_INTERATIVO = [
    'button', 'a[href]', 'input', 'textarea', 'select', 'summary', 'label[for]', 'video', 'img[role]',
    '[contenteditable]:not([contenteditable="false"])', '[role]', '[aria-label]', '[aria-haspopup]',
    '[placeholder]', '[tabindex]:not([tabindex="-1"])', '[data-testid]', '[draggable="true"]', '[onclick]',
  ].join(',');
  const ROLES_CONTAINER = '[role="menu"],[role="listbox"],[role="dialog"],[role="alertdialog"],[role="tablist"],[role="radiogroup"],[role="toolbar"],[role="tooltip"],[role="menubar"],[role="tree"],[role="grid"],[aria-modal="true"],[popover],dialog[open]';
  const ROLES_FILHOS = '[role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],[role="tab"],[role="radio"],[role="checkbox"],[role="switch"],[role="treeitem"],[role="gridcell"],button,a[href],input,textarea,[contenteditable="true"]';
  const ROLES_IGNORADOS_GENERICOS = new Set(['presentation', 'none', 'generic']);

  // ---------- utilitarios ----------
  const limpar = (s, max = 160) => {
    if (s == null) return '';
    const t = String(s).replace(/\s+/g, ' ').trim();
    return t.length > max ? t.slice(0, max) + '…' : t;
  };
  const cssEsc = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/["\\]/g, '\\$&'));
  const attrEsc = (s) => String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"');

  /** Heuristica: id/valor gerado automaticamente (nao confiavel como seletor). */
  function pareceAleatorio(v) {
    if (!v) return true;
    const s = String(v);
    if (s.length > 40) return true;
    if (/^:r[0-9a-z]+:$/i.test(s) || /^radix-/i.test(s) || /^headlessui-/i.test(s)) return true;
    if (/\d{3,}/.test(s)) return true;
    if (/^[a-z0-9]{8,}$/i.test(s) && /\d/.test(s) && /[a-z]/i.test(s)) return true;
    if (/^(mat|mdc|cdk|ng|css|sc|jsx|emotion)-/i.test(s)) return true;
    if (/[A-Z].*[0-9]|[0-9].*[A-Z]/.test(s) && s.length >= 6 && !/[\s-_]/.test(s)) return true;
    return false;
  }

  /** querySelectorAll que atravessa shadow DOM aberto. */
  let raizesCache = null;
  function listarRaizes(raiz = document) {
    const raizes = [raiz];
    const visitar = (r) => r.querySelectorAll('*').forEach((e) => { if (e.shadowRoot) { raizes.push(e.shadowRoot); visitar(e.shadowRoot); } });
    visitar(raiz);
    return raizes;
  }
  function buscarProfundo(seletor, raiz = document) {
    const out = [];
    const raizes = raiz === document && raizesCache ? raizesCache : listarRaizes(raiz);
    for (const r of raizes) { try { r.querySelectorAll(seletor).forEach((e) => out.push(e)); } catch {} }
    return out;
  }

  function visivel(el) {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    if (typeof el.checkVisibility === 'function') {
      if (!el.checkVisibility({ opacityProperty: true, visibilityProperty: true, contentVisibilityAuto: true })) return false;
    } else {
      const cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) < 0.05) return false;
    }
    return true;
  }

  function noViewport(r) {
    return r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  }

  const ROLE_IMPLICITO = {
    BUTTON: 'button', A: 'link', TEXTAREA: 'textbox', SELECT: 'combobox', SUMMARY: 'button', DIALOG: 'dialog',
    IMG: 'img', VIDEO: 'video', NAV: 'navigation', MAIN: 'main', HEADER: 'banner', FOOTER: 'contentinfo', ASIDE: 'complementary', FORM: 'form',
    H1: 'heading', H2: 'heading', H3: 'heading', H4: 'heading', H5: 'heading', H6: 'heading', UL: 'list', OL: 'list', LI: 'listitem',
  };
  function roleDe(el) {
    const r = el.getAttribute('role');
    if (r) return r;
    if (el.tagName === 'INPUT') {
      const t = (el.type || 'text').toLowerCase();
      return { checkbox: 'checkbox', radio: 'radio', range: 'slider', button: 'button', submit: 'button', file: 'file', search: 'searchbox' }[t] || 'textbox';
    }
    if (el.isContentEditable) return 'textbox';
    return ROLE_IMPLICITO[el.tagName] || null;
  }

  /** Textos de icones (Material Symbols / Google Symbols usam ligaduras como "add", "arrow_forward"). */
  function textosIcones(el) {
    const out = [];
    const cands = [el, ...el.querySelectorAll('i, span, mat-icon, [aria-hidden="true"]')].slice(0, 40);
    for (const c of cands) {
      if (c.children.length) continue;
      const t = (c.textContent || '').trim();
      if (!t || t.length > 40 || !/^[a-z0-9_]+$/.test(t)) continue;
      const ff = getComputedStyle(c).fontFamily || '';
      if (/symbol|icon|material/i.test(ff)) out.push(t);
    }
    return [...new Set(out)];
  }

  function textoPorIds(ids) {
    if (!ids) return '';
    return ids.split(/\s+/).map((id) => document.getElementById(id)?.innerText || '').join(' ');
  }

  function nomeAcessivel(el) {
    const al = el.getAttribute('aria-label');
    if (al) return limpar(al);
    const lb = textoPorIds(el.getAttribute('aria-labelledby'));
    if (lb.trim()) return limpar(lb);
    if (el.id) {
      const lab = document.querySelector(`label[for="${attrEsc(el.id)}"]`);
      if (lab) return limpar(lab.innerText);
    }
    if (el.tagName === 'IMG') return limpar(el.alt);
    const icones = textosIcones(el);
    let txt = limpar(el.innerText || el.value || '', 120);
    icones.forEach((i) => { txt = txt.replace(new RegExp(`\\b${i}\\b`), '').trim(); });
    if (txt) return limpar(txt);
    return limpar(el.getAttribute('title') || el.getAttribute('placeholder') || '');
  }

  function dataAttrs(el) {
    const o = {};
    for (const a of el.attributes) {
      if (!a.name.startsWith('data-')) continue;
      if (/^data-(v-|reactid|react|emotion|styled|radix-collection)/.test(a.name)) continue;
      if (a.value.length > 80) continue;
      o[a.name] = a.value;
    }
    return Object.keys(o).length ? o : undefined;
  }

  let cacheContagem = new Map();
  function contar(seletor) {
    if (cacheContagem.has(seletor)) return cacheContagem.get(seletor);
    let n;
    try { n = buscarProfundo(seletor).filter(visivel).length; } catch { n = -1; }
    cacheContagem.set(seletor, n);
    return n;
  }

  /** Caminho estrutural sem classes: tag:nth-of-type desde o ancestral estavel mais proximo. */
  function caminhoEstrutural(el) {
    const partes = [];
    let cur = el;
    for (let i = 0; cur && cur.nodeType === 1 && i < 8; i++) {
      if (cur.id && !pareceAleatorio(cur.id)) { partes.unshift(`#${cssEsc(cur.id)}`); break; }
      const tag = cur.tagName.toLowerCase();
      const pai = cur.parentElement;
      if (!pai) { partes.unshift(tag); break; }
      const irmaos = [...pai.children].filter((c) => c.tagName === cur.tagName);
      partes.unshift(irmaos.length > 1 ? `${tag}:nth-of-type(${irmaos.indexOf(cur) + 1})` : tag);
      cur = pai;
    }
    return partes.join(' > ');
  }

  /** Contexto semantico: ancestrais com role/aria-label/landmark (ex.: dialog "Configurações" > menu). */
  function contexto(el) {
    const out = [];
    let cur = el.parentElement;
    while (cur && cur !== document.body && out.length < 6) {
      const role = cur.getAttribute('role');
      const al = cur.getAttribute('aria-label');
      const tag = cur.tagName;
      if ((role && !ROLES_IGNORADOS_GENERICOS.has(role)) || al || ['DIALOG', 'NAV', 'HEADER', 'MAIN', 'ASIDE', 'FORM', 'FOOTER'].includes(tag)) {
        out.unshift(`${role || tag.toLowerCase()}${al ? ` "${limpar(al, 50)}"` : ''}`);
      }
      cur = cur.parentElement || cur.getRootNode()?.host || null;
    }
    return out.join(' > ');
  }

  /** Gera seletores candidatos (do mais estavel ao menos), com contagem de correspondencias. */
  function seletoresCandidatos(el, info) {
    const tag = el.tagName.toLowerCase();
    const c = [];
    const add = (tipo, valor, css) => {
      const n = css ? contar(valor) : undefined;
      c.push({ tipo, valor, ...(css ? { correspondencias: n, unico: n === 1 } : {}) });
    };
    if (info.dataAttrs?.['data-testid']) add('css', `[data-testid="${attrEsc(info.dataAttrs['data-testid'])}"]`, true);
    if (el.id && !pareceAleatorio(el.id)) add('css', `#${cssEsc(el.id)}`, true);
    const al = el.getAttribute('aria-label');
    if (al) add('css', `${tag}[aria-label="${attrEsc(al)}"]`, true);
    const ph = el.getAttribute('placeholder');
    if (ph) add('css', `${tag}[placeholder="${attrEsc(ph)}"]`, true);
    const nm = el.getAttribute('name');
    if (nm && !pareceAleatorio(nm)) add('css', `${tag}[name="${attrEsc(nm)}"]`, true);
    if (info.dataAttrs) {
      for (const [k, v] of Object.entries(info.dataAttrs)) {
        if (k === 'data-testid' || pareceAleatorio(v) || !v) continue;
        add('css', `${tag}[${k}="${attrEsc(v)}"]`, true);
        if (c.length > 8) break;
      }
    }
    if (info.role && info.nome) add('role', { role: info.role, nome: info.nome });
    if (info.texto && info.texto.length <= 60) add('texto', { tag, texto: info.texto });
    if (info.icones?.length) add('icone', { tag, icone: info.icones[0] });
    add('estrutural', caminhoEstrutural(el), true);
    return c;
  }

  let contadorIdx = 0;
  /** Descricao completa e estavel de um elemento. */
  function descrever(el, { comSeletores = true } = {}) {
    const r = el.getBoundingClientRect();
    const tag = el.tagName.toLowerCase();
    const role = roleDe(el);
    const icones = textosIcones(el);
    const textoBruto = el.isContentEditable ? (el.innerText || '') : (el.innerText || '');
    const info = {
      idx: ++contadorIdx,
      tag,
      role: role || undefined,
      tipo: el.getAttribute('type') || undefined,
      nome: nomeAcessivel(el) || undefined,
      texto: limpar(textoBruto, 160) || undefined,
      icones: icones.length ? icones : undefined,
      ariaLabel: el.getAttribute('aria-label') || undefined,
      ariaLabelledby: limpar(textoPorIds(el.getAttribute('aria-labelledby'))) || undefined,
      ariaDescricao: limpar(textoPorIds(el.getAttribute('aria-describedby'))) || undefined,
      placeholder: el.getAttribute('placeholder') || el.getAttribute('aria-placeholder') || el.dataset?.placeholder || undefined,
      title: el.getAttribute('title') || undefined,
      alt: el.getAttribute('alt') || undefined,
      name: el.getAttribute('name') || undefined,
      href: tag === 'a' ? limpar(el.getAttribute('href'), 200) : undefined,
      idEstavel: el.id && !pareceAleatorio(el.id) ? el.id : undefined,
      dataAttrs: dataAttrs(el),
      contentEditable: el.isContentEditable || undefined,
      estado: {
        desabilitado: el.disabled || el.getAttribute('aria-disabled') === 'true' || undefined,
        expandido: el.getAttribute('aria-expanded') ?? undefined,
        selecionado: el.getAttribute('aria-selected') ?? undefined,
        marcado: el.getAttribute('aria-checked') ?? (el.type === 'checkbox' || el.type === 'radio' ? String(el.checked) : undefined),
        pressionado: el.getAttribute('aria-pressed') ?? undefined,
        atual: el.getAttribute('aria-current') ?? undefined,
        popup: el.getAttribute('aria-haspopup') ?? undefined,
        controla: el.getAttribute('aria-controls') ? limpar(el.getAttribute('aria-controls'), 60) : undefined,
        valor: (tag === 'input' && el.type !== 'password') || tag === 'textarea' || tag === 'select' ? limpar(el.value, 80) || undefined : undefined,
        aceita: el.getAttribute('accept') || undefined,
      },
      rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) },
      noViewport: noViewport(r),
      contexto: contexto(el) || undefined,
      emShadowDom: el.getRootNode() instanceof ShadowRoot || undefined,
    };
    Object.keys(info.estado).forEach((k) => info.estado[k] === undefined && delete info.estado[k]);
    if (!Object.keys(info.estado).length) delete info.estado;
    if (comSeletores) info.seletores = seletoresCandidatos(el, info);
    return info;
  }

  /** Elementos que sao apenas wrappers sem semantica (evita duplicar botao + span interno). */
  function relevante(el) {
    const role = el.getAttribute('role');
    if (role && ROLES_IGNORADOS_GENERICOS.has(role) && !el.getAttribute('aria-label')) return false;
    if (el.tagName === 'VIDEO') return true;
    if (el.getAttribute('tabindex') !== null && !role && !el.getAttribute('aria-label') && !(el.innerText || '').trim()) {
      return el.getBoundingClientRect().width > 20;
    }
    return true;
  }

  // ---------- coletas ----------
  function coletarElementos() {
    const vistos = new Set();
    const lista = [];
    for (const el of buscarProfundo(SELETOR_INTERATIVO)) {
      if (vistos.has(el) || !visivel(el) || !relevante(el)) continue;
      if (el.closest('#flow-studio-overlay')) continue;
      vistos.add(el);
      lista.push(el);
    }
    // elementos com cursor:pointer sem semantica (divs clicaveis)
    for (const el of buscarProfundo('div, span, li, img')) {
      if (vistos.has(el) || lista.length > 2500) continue;
      if (getComputedStyle(el).cursor !== 'pointer' || !visivel(el)) continue;
      if (el.parentElement && getComputedStyle(el.parentElement).cursor === 'pointer') continue; // so o mais externo
      if (el.closest('button, a, [role]') && el.closest('button, a, [role]') !== el) continue;
      vistos.add(el);
      lista.push(el);
    }
    return lista.slice(0, 2500).map((el) => {
      const d = descrever(el);
      if (!el.matches(SELETOR_INTERATIVO)) d.clicavelPorCursor = true;
      return d;
    });
  }

  function coletarMenus() {
    return buscarProfundo(ROLES_CONTAINER).filter(visivel).slice(0, 60).map((c) => ({
      role: c.getAttribute('role') || c.tagName.toLowerCase(),
      nome: nomeAcessivel(c) || limpar(c.getAttribute('aria-label')) || undefined,
      modal: c.getAttribute('aria-modal') === 'true' || c.tagName === 'DIALOG' || undefined,
      orientacao: c.getAttribute('aria-orientation') || undefined,
      rect: (() => { const r = c.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; })(),
      contexto: contexto(c) || undefined,
      seletores: seletoresCandidatos(c, { role: c.getAttribute('role'), nome: nomeAcessivel(c), dataAttrs: dataAttrs(c) }),
      itens: [...c.querySelectorAll(ROLES_FILHOS)].filter(visivel).slice(0, 80).map((i) => descrever(i)),
    }));
  }

  /** Cards de ativos: imagens/videos visiveis + container clicavel + textos proximos (nome do ativo). */
  function coletarAtivos() {
    const midias = buscarProfundo('img, video, canvas, [style*="background-image"]').filter((m) => {
      if (!visivel(m)) return false;
      const r = m.getBoundingClientRect();
      return r.width >= 40 && r.height >= 40;
    });
    return midias.slice(0, 300).map((m) => {
      let card = m.parentElement;
      for (let i = 0; i < 6 && card && card !== document.body; i++) {
        const role = card.getAttribute('role');
        if (role && !ROLES_IGNORADOS_GENERICOS.has(role)) break;
        if (card.getAttribute('aria-label') || card.getAttribute('draggable') === 'true' || card.tagName === 'BUTTON' || card.tagName === 'A' || card.hasAttribute('tabindex')) break;
        if (dataAttrs(card) && i >= 1) break;
        card = card.parentElement;
      }
      const r = m.getBoundingClientRect();
      const src = m.currentSrc || m.src || m.getAttribute('poster') || '';
      return {
        midia: m.tagName.toLowerCase(),
        src: src.startsWith('data:') ? src.slice(0, 40) + '…(data uri)' : limpar(src, 220),
        tipoSrc: src.startsWith('blob:') ? 'blob' : src.startsWith('data:') ? 'data' : src ? 'url' : 'nenhum',
        alt: m.getAttribute('alt') || undefined,
        tamanho: { w: Math.round(r.width), h: Math.round(r.height), naturalW: m.naturalWidth || m.videoWidth || undefined, naturalH: m.naturalHeight || m.videoHeight || undefined },
        proporcao: r.height ? +(r.width / r.height).toFixed(3) : undefined,
        card: card && card !== document.body ? descrever(card) : undefined,
        textosDoCard: card ? [...new Set((card.innerText || '').split('\n').map((t) => t.trim()).filter((t) => t && t.length < 80))].slice(0, 10) : [],
        botoesDoCard: card ? [...card.querySelectorAll('button,[role="button"],[aria-haspopup]')].slice(0, 10).map((b) => ({ nome: nomeAcessivel(b), icones: textosIcones(b), visivel: visivel(b) })) : [],
      };
    });
  }

  function coletarInputsArquivo() {
    return buscarProfundo('input[type="file"]').map((i) => ({
      accept: i.getAttribute('accept') || '',
      multiple: i.multiple,
      visivel: visivel(i),
      name: i.name || undefined,
      contexto: contexto(i) || undefined,
      seletorEstrutural: caminhoEstrutural(i),
      labelAssociado: nomeAcessivel(i) || undefined,
    }));
  }

  function coletarTextos() {
    const out = new Map();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.nodeValue.trim().length >= 2 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
    });
    let n;
    while ((n = walker.nextNode()) && out.size < 800) {
      const pai = n.parentElement;
      if (!pai || ['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(pai.tagName) || !visivel(pai)) continue;
      const t = limpar(n.nodeValue, 140);
      if (!out.has(t)) out.set(t, { texto: t, tag: pai.tagName.toLowerCase(), role: roleDe(pai) || undefined, contexto: contexto(pai) || undefined });
    }
    return [...out.values()];
  }

  function coletarTitulos() {
    return buscarProfundo('h1,h2,h3,h4,h5,h6,[role="heading"]').filter(visivel).map((h) => ({ nivel: h.getAttribute('aria-level') || h.tagName.replace('H', ''), texto: limpar(h.innerText) }));
  }

  // ---------- gravacao de cliques (para descobrir o caminho dos submenus) ----------
  const cliques = [];
  let gravando = false;
  function aoClicar(ev) {
    const alvo = ev.target.closest?.(SELETOR_INTERATIVO) || ev.target;
    if (!alvo || alvo.closest?.('#flow-studio-overlay')) return;
    const d = descrever(alvo);
    d.momento = new Date().toISOString();
    d.url = location.href;
    cliques.push(d);
    if (cliques.length > 300) cliques.shift();
    try {
      chrome.runtime.sendMessage({ tipo: 'clique_gravado', descricao: `${d.role || d.tag} "${d.nome || d.texto || d.icones?.[0] || '?'}"${d.contexto ? ' em ' + d.contexto : ''}` });
    } catch {}
  }
  function gravarCliques(ligado) {
    gravando = !!ligado;
    document.removeEventListener('click', aoClicar, true);
    if (gravando) document.addEventListener('click', aoClicar, true);
    mostrarIndicadorGravacao(false);
    return { gravando, cliquesPendentes: cliques.length };
  }
  function mostrarIndicadorGravacao() {
    // MODO FURTIVO 100% LIMPO: jamais injeta div, overlay, painel flutuante ou CSS no DOM do Google Flow!
    const antigo = document.getElementById('flow-studio-overlay');
    if (antigo) {
      try { antigo.remove(); } catch {}
    }
  }
  mostrarIndicadorGravacao();

  // ---------- captura principal ----------
  function capturar({ rotulo = '' } = {}) {
    const t0 = performance.now();
    contadorIdx = 0;
    raizesCache = listarRaizes(document);
    cacheContagem = new Map();
    try {
      return capturarInterno(rotulo, t0);
    } finally {
      raizesCache = null;
      cacheContagem = new Map();
    }
  }

  function capturarInterno(rotulo, t0) {
    const elementos = coletarElementos();
    const menusAbertos = coletarMenus();
    const ativos = coletarAtivos();
    const relatorio = {
      versaoMapper: VERSAO_MAPPER,
      capturadoEm: new Date().toISOString(),
      rotulo,
      url: location.href,
      titulo: document.title,
      idioma: document.documentElement.lang || navigator.language,
      viewport: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio },
      scroll: { x: Math.round(scrollX), y: Math.round(scrollY) },
      elementoFocado: document.activeElement && document.activeElement !== document.body ? descrever(document.activeElement, { comSeletores: false }) : null,
      contagens: {},
      elementos,
      menusAbertos,
      ativos,
      inputsArquivo: coletarInputsArquivo(),
      titulos: coletarTitulos(),
      textosVisiveis: coletarTextos(),
      iframes: [...document.querySelectorAll('iframe')].map((f) => ({ src: limpar(f.src, 200), titulo: f.title || undefined, visivel: visivel(f) })),
      cliquesGravados: cliques.splice(0, cliques.length),
    };
    relatorio.contagens = {
      elementos: elementos.length,
      botoes: elementos.filter((e) => e.tag === 'button' || e.role === 'button').length,
      camposTexto: elementos.filter((e) => e.tag === 'textarea' || e.contentEditable || e.role === 'textbox').length,
      menusAbertos: menusAbertos.length,
      ativos: ativos.length,
      cliquesGravados: relatorio.cliquesGravados.length,
      tempoMs: Math.round(performance.now() - t0),
    };
    return relatorio;
  }

  NS.mapper = { capturar, descrever, buscarProfundo, visivel, nomeAcessivel, textosIcones, gravarCliques, estaGravando: () => gravando };
})();
