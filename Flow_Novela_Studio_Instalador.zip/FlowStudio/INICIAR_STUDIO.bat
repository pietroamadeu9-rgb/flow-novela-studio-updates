@echo off
setlocal
cd /d "C:\FlowStudio" 2>nul || cd /d "%~dp0"
if exist "%CD%\INICIAR_APP.vbs" (
  start "" "%SystemRoot%\System32\wscript.exe" "%CD%\INICIAR_APP.vbs"
  exit /b 0
)
set "PATH=%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;%PATH%"
powershell -NoProfile -WindowStyle Hidden -Command "$conns = Get-NetTCPConnection -LocalPort 3456 -State Listen -ErrorAction SilentlyContinue; if (-not $conns) { Start-Process -FilePath 'node' -ArgumentList 'server\index.js' -WorkingDirectory $PWD -WindowStyle Hidden; Start-Sleep -Seconds 2 }; $cands = @((Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'), (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'), (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'), (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'), (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')); $nav = $cands | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1; if ($nav) { Start-Process $nav -ArgumentList '--app=http://localhost:3456', '--window-size=1500,920' } else { Start-Process 'http://localhost:3456' }"
endlocal
exit /b 0
