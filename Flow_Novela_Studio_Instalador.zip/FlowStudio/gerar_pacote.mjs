import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)));
const STAGE = path.join(os.tmpdir(), 'fns_pacote_amigo_stage');
const STAGE_INNER = path.join(STAGE, 'FlowStudio');
const ZIP_INSTALADOR = path.join(ROOT, 'Flow_Novela_Studio_Instalador.zip');
const ZIP_COMPAT = path.join(ROOT, 'FlowStudio_Para_Amigo.zip');

// =========================================================================
// 1) INSTALAR_TUDO.bat — Instalador Automatico de 1 Clique para Leigos
// =========================================================================
const instalarTudoBat = [
  '@echo off',
  'setlocal EnableDelayedExpansion',
  'title Flow Novela Studio - Instalador Automatico (1 Clique)',
  'color 0B',
  'cd /d "%~dp0"',
  '',
  'rem --- Se o usuario clicou no INSTALAR_TUDO.bat da raiz do ZIP e existe a subpasta FlowStudio ---',
  'if not exist "package.json" (',
  '  if exist "%~dp0FlowStudio\\package.json" (',
  '    cd /d "%~dp0FlowStudio"',
  '  )',
  ')',
  '',
  'set "ORIGEM_DIR=%CD%"',
  'set "DESTINO_DIR=C:\\FlowStudio"',
  '',
  'echo.',
  'echo  ==============================================================',
  'echo     FLOW NOVELA STUDIO - INSTALADOR AUTOMATICO DE 1 CLIQUE',
  'echo  ==============================================================',
  'echo.',
  '',
  'rem --- a) Copiar automaticamente para C:\\FlowStudio se extraido em outro lugar ---',
  'echo [1/6] Preparando a pasta oficial em C:\\FlowStudio...',
  'if /I not "%ORIGEM_DIR%"=="%DESTINO_DIR%" (',
  '  echo       Copiando arquivos de "%ORIGEM_DIR%" para "%DESTINO_DIR%"...',
  '  if not exist "%DESTINO_DIR%" mkdir "%DESTINO_DIR%"',
  '  robocopy "%ORIGEM_DIR%" "%DESTINO_DIR%" /E /NFL /NDL /NJH /NJS /NC /NS /XD node_modules .git >nul',
  '  echo       Arquivos copiados com sucesso para C:\\FlowStudio!',
  ') else (',
  '  echo       Pasta ja esta em C:\\FlowStudio.',
  ')',
  'cd /d "%DESTINO_DIR%"',
  'if not exist "dados" mkdir "dados"',
  'if not exist "dados\\novelas" mkdir "dados\\novelas"',
  'if not exist "Meus_Projetos_Flow" mkdir "Meus_Projetos_Flow"',
  '',
  'rem --- b) Verificar Node.js; se nao tiver, instalar via winget ou MSI oficial e atualizar PATH na mesma sessao ---',
  'echo.',
  'echo [2/6] Verificando o Node.js...',
  'set "PATH=%ProgramFiles%\\nodejs;%LOCALAPPDATA%\\Programs\\nodejs;%APPDATA%\\npm;%PATH%"',
  'for /f "tokens=2*" %%A in (\'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment" /v Path 2^>nul ^| findstr /i "Path"\') do set "PATH=%%B;%PATH%"',
  'for /f "tokens=2*" %%A in (\'reg query "HKCU\\Environment" /v Path 2^>nul ^| findstr /i "Path"\') do set "PATH=%%B;%PATH%"',
  '',
  'where node >nul 2>nul',
  'if errorlevel 1 (',
  '  echo       Node.js nao encontrado. Instalando automaticamente ^(aguarde 1 a 2 minutos^)...',
  '  where winget >nul 2>nul',
  '  if not errorlevel 1 (',
  '    echo       Instalando Node.js LTS via winget...',
  '    winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements --silent',
  '  )',
  '  set "PATH=%ProgramFiles%\\nodejs;%LOCALAPPDATA%\\Programs\\nodejs;%APPDATA%\\npm;%PATH%"',
  '  for /f "tokens=2*" %%A in (\'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment" /v Path 2^>nul ^| findstr /i "Path"\') do set "PATH=%%B;%PATH%"',
  '  for /f "tokens=2*" %%A in (\'reg query "HKCU\\Environment" /v Path 2^>nul ^| findstr /i "Path"\') do set "PATH=%%B;%PATH%"',
  '  where node >nul 2>nul',
  '  if errorlevel 1 (',
  '    echo       Baixando e instalando o instalador oficial (.msi) do Node.js LTS...',
  '    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference=\'Stop\'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $msi=Join-Path $env:TEMP \'node_lts_x64.msi\'; $url=\'https://nodejs.org/dist/v22.14.0/node-v22.14.0-x64.msi\'; try { $idx=Invoke-RestMethod -Uri \'https://nodejs.org/dist/index.json\' -TimeoutSec 15; $lts=$idx | Where-Object { $_.lts -and $_.files -contains \'win-x64-msi\' } | Select-Object -First 1; if ($lts) { $url=\'https://nodejs.org/dist/\' + $lts.version + \'/node-\' + $lts.version + \'-x64.msi\' } } catch {}; Write-Host (\'      Baixando \' + $url + \'...\'); Invoke-WebRequest -Uri $url -OutFile $msi -UseBasicParsing; Write-Host \'      Executando instalador do Node.js...\'; $p=Start-Process msiexec.exe -ArgumentList \'/i\', $msi, \'/passive\', \'/norestart\' -Wait -PassThru; Remove-Item $msi -Force -ErrorAction SilentlyContinue"',
  '  )',
  '  set "PATH=%ProgramFiles%\\nodejs;%LOCALAPPDATA%\\Programs\\nodejs;%APPDATA%\\npm;%PATH%"',
  '  for /f "tokens=2*" %%A in (\'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment" /v Path 2^>nul ^| findstr /i "Path"\') do set "PATH=%%B;%PATH%"',
  '  for /f "tokens=2*" %%A in (\'reg query "HKCU\\Environment" /v Path 2^>nul ^| findstr /i "Path"\') do set "PATH=%%B;%PATH%"',
  ')',
  '',
  'where node >nul 2>nul',
  'if errorlevel 1 (',
  '  echo [ERRO] Nao foi possivel instalar o Node.js automaticamente.',
  '  echo Verifique sua conexao com a internet e execute INSTALAR_TUDO.bat novamente.',
  '  pause',
  '  exit /b 1',
  ')',
  'for /f "delims=" %%v in (\'node -v\') do echo       Node.js pronto e ativo: %%v',
  '',
  'rem --- c) Rodar npm install do projeto automaticamente ---',
  'echo.',
  'echo [3/6] Instalando pacotes do Flow Novela Studio (npm install)...',
  'call npm.cmd install --omit=dev --no-audit --no-fund',
  'if not exist "node_modules\\express\\package.json" (',
  '  echo [ERRO] Falha ao instalar dependencias do projeto. Verifique sua internet e tente novamente.',
  '  pause',
  '  exit /b 1',
  ')',
  'echo       Pacotes do projeto instalados com sucesso!',
  '',
  'rem --- d) Instalar automaticamente o Claude Code e abrir o login na tela ---',
  'echo.',
  'echo [4/6] Instalando o Claude Code (@anthropic-ai/claude-code)...',
  'call npm.cmd install -g @anthropic-ai/claude-code --no-audit --no-fund',
  'set "PATH=%APPDATA%\\npm;%ProgramFiles%\\nodejs;%LOCALAPPDATA%\\Programs\\nodejs;%PATH%"',
  '',
  'if exist "%APPDATA%\\npm\\claude.cmd" (',
  '  call "%APPDATA%\\npm\\claude.cmd" auth status >nul 2>nul',
  '  if errorlevel 1 (',
  '    echo.',
  '    echo  ==============================================================',
  '    echo   LOGIN DO CLAUDE:',
  '    echo   Faca login na conta do Claude que abriu no navegador',
  '    echo   e depois volte aqui!',
  '    echo  ==============================================================',
  '    echo.',
  '    call "%APPDATA%\\npm\\claude.cmd" auth login',
  '  ) else (',
  '    echo       Conta do Claude ja esta conectada neste computador!',
  '  )',
  ') else (',
  '  where claude >nul 2>nul',
  '  if not errorlevel 1 (',
  '    echo.',
  '    echo  ==============================================================',
  '    echo   LOGIN DO CLAUDE:',
  '    echo   Faca login na conta do Claude que abriu no navegador',
  '    echo   e depois volte aqui!',
  '    echo  ==============================================================',
  '    echo.',
  '    call claude auth login',
  '  )',
  ')',
  '',
  'rem --- e) Criar atalho "Flow Novela Studio" direto na Area de Trabalho apontando para INICIAR_APP.vbs ---',
  'echo.',
  'echo [5/6] Criando atalho "Flow Novela Studio" na sua Area de Trabalho...',
  'powershell -NoProfile -ExecutionPolicy Bypass -Command "$root = \'C:\\FlowStudio\'; $desks = @([Environment]::GetFolderPath(\'Desktop\'), (Join-Path $env:USERPROFILE \'Desktop\')); if ($env:OneDrive) { $desks += (Join-Path $env:OneDrive \'Desktop\'); $desks += (Join-Path $env:OneDrive \'Area de Trabalho\') }; $ws = New-Object -ComObject WScript.Shell; $wscriptExe = Join-Path $env:SystemRoot \'System32\\wscript.exe\'; $vbs = Join-Path $root \'INICIAR_APP.vbs\'; foreach ($d in ($desks | Select-Object -Unique)) { if ($d -and (Test-Path $d)) { $lnk = Join-Path $d \'Flow Novela Studio.lnk\'; $s = $ws.CreateShortcut($lnk); $s.TargetPath = $wscriptExe; $s.Arguments = \'\"\' + $vbs + \'\"\'; $s.WorkingDirectory = $root; $ico = Join-Path $root \'flow-studio.ico\'; if (Test-Path $ico) { $s.IconLocation = $ico + \',0\' }; $s.WindowStyle = 1; $s.Description = \'Flow Novela Studio\'; $s.Save(); Write-Host (\'      Atalho criado em: \' + $lnk) } }"',
  '',
  'rem --- f) Abrir Google Chrome em chrome://extensions e abrir a pasta da extensao ao lado ---',
  'echo.',
  'echo [6/6] Abrindo o Google Chrome e a pasta da extensao ao lado...',
  'powershell -NoProfile -ExecutionPolicy Bypass -Command "$extDir = \'C:\\FlowStudio\\extensao-chrome\'; Start-Process explorer.exe -ArgumentList $extDir; try { Set-Clipboard -Value \'chrome://extensions\' } catch {}; $cands = @((Join-Path $env:ProgramFiles \'Google\\Chrome\\Application\\chrome.exe\'), (Join-Path ${env:ProgramFiles(x86)} \'Google\\Chrome\\Application\\chrome.exe\'), (Join-Path $env:LOCALAPPDATA \'Google\\Chrome\\Application\\chrome.exe\')); $chrome = $cands | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1; if ($chrome) { Start-Process $chrome -ArgumentList \'--new-window\', \'chrome://extensions\'; Start-Sleep -Milliseconds 1400; try { $ws = New-Object -ComObject WScript.Shell; if ($ws.AppActivate(\'Chrome\')) { Start-Sleep -Milliseconds 300; $ws.SendKeys(\'^l\'); Start-Sleep -Milliseconds 150; $ws.SendKeys(\'chrome://extensions{ENTER}\') } } catch {} } else { Start-Process \'msedge.exe\' -ArgumentList \'--new-window\', \'edge://extensions\' -ErrorAction SilentlyContinue }"',
  '',
  'echo.',
  'echo  ==============================================================',
  'echo     TUDO INSTALADO COM SUCESSO! FALTA SO ATIVAR A EXTENSAO:',
  'echo  ==============================================================',
  'echo.',
  'echo   O Google Chrome e a janelinha da pasta ja abriram na sua tela:',
  'echo.',
  'echo   1^) No canto superior direito do Chrome ^(em chrome://extensions^),',
  'echo      ligue a chavinha "Modo do desenvolvedor".',
  'echo.',
  'echo   2^) Clique no botao "Carregar sem compactacao" ^(canto superior',
  'echo      esquerdo^) e selecione a pasta que abriu ao lado:',
  'echo      C:\\FlowStudio\\extensao-chrome',
  'echo.',
  'echo   3^) Pronto! Depois e so dar 2 cliques no atalho',
  'echo      "Flow Novela Studio" que foi criado na sua Area de Trabalho!',
  'echo  ==============================================================',
  'echo.',
  'pause',
  'endlocal',
  'exit /b 0',
  '',
].join('\r\n');

// =========================================================================
// 2) INICIAR_STUDIO.bat / Iniciar_Flow_Studio.bat (Aciona INICIAR_APP.vbs sem deixar CMD aberto)
// =========================================================================
const iniciarBat = [
  '@echo off',
  'setlocal',
  'cd /d "C:\\FlowStudio" 2>nul || cd /d "%~dp0"',
  'if exist "%CD%\\INICIAR_APP.vbs" (',
  '  start "" "%SystemRoot%\\System32\\wscript.exe" "%CD%\\INICIAR_APP.vbs"',
  '  exit /b 0',
  ')',
  'set "PATH=%ProgramFiles%\\nodejs;%LOCALAPPDATA%\\Programs\\nodejs;%APPDATA%\\npm;%PATH%"',
  'powershell -NoProfile -WindowStyle Hidden -Command "$conns = Get-NetTCPConnection -LocalPort 3456 -State Listen -ErrorAction SilentlyContinue; if (-not $conns) { Start-Process -FilePath \'node\' -ArgumentList \'server\\index.js\' -WorkingDirectory $PWD -WindowStyle Hidden; Start-Sleep -Seconds 2 }; $cands = @((Join-Path $env:ProgramFiles \'Google\\Chrome\\Application\\chrome.exe\'), (Join-Path ${env:ProgramFiles(x86)} \'Google\\Chrome\\Application\\chrome.exe\'), (Join-Path $env:LOCALAPPDATA \'Google\\Chrome\\Application\\chrome.exe\'), (Join-Path ${env:ProgramFiles(x86)} \'Microsoft\\Edge\\Application\\msedge.exe\'), (Join-Path $env:ProgramFiles \'Microsoft\\Edge\\Application\\msedge.exe\')); $nav = $cands | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1; if ($nav) { Start-Process $nav -ArgumentList \'--app=http://localhost:3456\', \'--window-size=1500,920\' } else { Start-Process \'http://localhost:3456\' }"',
  'endlocal',
  'exit /b 0',
  '',
].join('\r\n');

// =========================================================================
// 3) Parar_Flow_Studio.bat
// =========================================================================
const pararBat = [
  '@echo off',
  'setlocal',
  'title Parar Flow Novela Studio',
  'echo.',
  'echo Encerrando o servidor do Flow Novela Studio (porta 3456)...',
  'powershell -NoProfile -Command "$conns = Get-NetTCPConnection -LocalPort 3456 -State Listen -ErrorAction SilentlyContinue; if (-not $conns) { Write-Host \'Nenhum servidor rodando na porta 3456.\'; exit 0 }; $pids = $conns | Select-Object -ExpandProperty OwningProcess -Unique; foreach ($id in $pids) { if ($id -gt 0) { $proc = Get-Process -Id $id -ErrorAction SilentlyContinue; if ($proc -and $proc.ProcessName -match \'^node\') { Stop-Process -Id $id -Force; Write-Host (\'Servidor encerrado com seguranca (PID \' + $id + \').\') } } }"',
  'timeout /t 2 >nul',
  'endlocal',
  'exit /b 0',
  '',
].join('\r\n');

// =========================================================================
// 4) GERAR_PACOTE_AMIGO.bat
// =========================================================================
const gerarPacoteBat = [
  '@echo off',
  'setlocal',
  'title Flow Novela Studio - Gerar Pacote para Amigo',
  'cd /d "%~dp0"',
  'set "PATH=%ProgramFiles%\\nodejs;%LOCALAPPDATA%\\Programs\\nodejs;%APPDATA%\\npm;%PATH%"',
  'echo.',
  'echo Compilando interface e gerando Flow_Novela_Studio_Instalador.zip...',
  'if exist "node_modules\\vite\\bin\\vite.js" (',
  '  call npm.cmd run build',
  ')',
  'node gerar_pacote.mjs',
  'echo.',
  'echo Pacote limpo gerado com sucesso na sua Area de Trabalho!',
  'pause',
  'endlocal',
  'exit /b 0',
  '',
].join('\r\n');

// =========================================================================
// 5) LEIA-ME_COMO_USAR.txt
// =========================================================================
const leiaMeTxt = [
  '====================================================================',
  '        FLOW NOVELA STUDIO - INSTALACAO EM 1 CLIQUE (LEIGOS)',
  '====================================================================',
  '',
  '1) Extraia este arquivo .zip em qualquer lugar e de 2 cliques em:',
  '   INSTALAR_TUDO.bat',
  '',
  '   O instalador faz tudo sozinho:',
  '   - Copia os arquivos automaticamente para C:\\FlowStudio',
  '   - Instala o Node.js automaticamente (se voce nao tiver)',
  '   - Instala os pacotes do projeto e o Claude Code',
  '   - Abre o login da sua conta Claude no navegador',
  '   - Cria o atalho "Flow Novela Studio" na sua Area de Trabalho',
  '   - Abre o Chrome em chrome://extensions e a pasta da extensao ao lado',
  '',
  '2) No Chrome que abriu, ligue a chave "Modo do desenvolvedor" e',
  '   clique em "Carregar sem compactacao" escolhendo a pasta:',
  '   C:\\FlowStudio\\extensao-chrome',
  '',
  '3) Pronto! Abra pelo atalho "Flow Novela Studio" na sua Area de Trabalho!',
  '====================================================================',
  '',
].join('\r\n');

fs.writeFileSync(path.join(ROOT, 'INSTALAR_TUDO.bat'), instalarTudoBat, 'ascii');
fs.writeFileSync(path.join(ROOT, 'INSTALAR.bat'), instalarTudoBat, 'ascii');
fs.writeFileSync(path.join(ROOT, '1_INSTALAR_PRIMEIRA_VEZ.bat'), instalarTudoBat, 'ascii');
fs.writeFileSync(path.join(ROOT, 'INICIAR_STUDIO.bat'), iniciarBat, 'ascii');
fs.writeFileSync(path.join(ROOT, 'Iniciar_Flow_Studio.bat'), iniciarBat, 'ascii');
fs.writeFileSync(path.join(ROOT, 'GERAR_PACOTE_AMIGO.bat'), gerarPacoteBat, 'ascii');
fs.writeFileSync(path.join(ROOT, 'Parar_Flow_Studio.bat'), pararBat, 'ascii');
fs.writeFileSync(path.join(ROOT, 'LEIA-ME_COMO_USAR.txt'), leiaMeTxt, 'utf8');
console.log('Arquivos .bat (INSTALAR_TUDO.bat, INICIAR_STUDIO.bat, GERAR_PACOTE_AMIGO.bat) atualizados.');

// 6) Descobrir a Area de Trabalho real do usuario e atualizar o atalho local (padrao + OneDrive) apontando para INICIAR_APP.vbs
const psShortcut = `
$root = '${ROOT.replace(/'/g, "''")}'
$deskPrincipal = [Environment]::GetFolderPath('Desktop')
$desks = @($deskPrincipal, (Join-Path $env:USERPROFILE 'Desktop'))
if ($env:OneDrive) {
  $odDesk = Join-Path $env:OneDrive 'Desktop'
  if (-not (Test-Path $odDesk)) { New-Item -ItemType Directory -Path $odDesk -Force | Out-Null }
  $desks += $odDesk
}
$ws = New-Object -ComObject WScript.Shell
$wscriptExe = Join-Path $env:SystemRoot 'System32\\wscript.exe'
$vbs = Join-Path $root 'INICIAR_APP.vbs'
foreach ($d in ($desks | Select-Object -Unique)) {
  if (-not $d -or -not (Test-Path $d)) { continue }
  $lnk = Join-Path $d 'Flow Novela Studio.lnk'
  $s = $ws.CreateShortcut($lnk)
  $s.TargetPath = $wscriptExe
  $s.Arguments = '"' + $vbs + '"'
  $s.WorkingDirectory = $root
  $ico = Join-Path $root 'flow-studio.ico'
  if (Test-Path $ico) { $s.IconLocation = $ico + ',0' }
  $s.WindowStyle = 1
  $s.Description = 'Flow Novela Studio'
  $s.Save()
}
Write-Output $deskPrincipal
`;
const deskDir = execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psShortcut], { encoding: 'utf8' }).trim();

// 7) Montar pasta limpa para o amigo e gerar Flow_Novela_Studio_Instalador.zip
fs.rmSync(STAGE, { recursive: true, force: true });
fs.mkdirSync(STAGE_INNER, { recursive: true });

function copiarLimpo(orig, dest) {
  if (!fs.existsSync(orig)) return;
  const st = fs.statSync(orig);
  if (st.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const nome of fs.readdirSync(orig)) {
      if (nome === 'node_modules' || nome === '.git' || nome === '.env' || nome === 'bin' || /\.(bak|tmp|log|zip)$/i.test(nome)) continue;
      copiarLimpo(path.join(orig, nome), path.join(dest, nome));
    }
  } else {
    const base = path.basename(orig);
    if (base === '.env' || /\.(bak|tmp|log|zip)$/i.test(orig)) return;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(orig, dest);
  }
}

const arquivosRaiz = [
  'INSTALAR_TUDO.bat',
  'INSTALAR.bat',
  'INICIAR_APP.vbs',
  'INICIAR_STUDIO.bat',
  'GERAR_PACOTE_AMIGO.bat',
  'PUBLICAR_ATUALIZACAO.bat',
  '1_INSTALAR_PRIMEIRA_VEZ.bat',
  'Iniciar_Flow_Studio.bat',
  'Iniciar_Invisivel.vbs',
  'Subir_Servidor_Oculto.bat',
  'Parar_Flow_Studio.bat',
  'Abrir_Estudio.bat',
  'LEIA-ME_COMO_USAR.txt',
  'LEIA-ME.md',
  '.env.example',
  'version.json',
  'launcher.mjs',
  'gerar_pacote.mjs',
  'publicar_update.mjs',
  'flow-studio.ico',
  'package.json',
  'package-lock.json',
];
for (const arq of arquivosRaiz) {
  copiarLimpo(path.join(ROOT, arq), path.join(STAGE_INNER, arq));
}
for (const pasta of ['server', 'extensao-chrome', 'web']) {
  copiarLimpo(path.join(ROOT, pasta), path.join(STAGE_INNER, pasta));
}
// Tambem coloca INSTALAR_TUDO.bat e LEIA-ME_COMO_USAR.txt no topo do ZIP (caso ele abra a pasta raiz antes de entrar em FlowStudio)
fs.copyFileSync(path.join(ROOT, 'INSTALAR_TUDO.bat'), path.join(STAGE, 'INSTALAR_TUDO.bat'));
fs.copyFileSync(path.join(ROOT, 'LEIA-ME_COMO_USAR.txt'), path.join(STAGE, 'LEIA-ME_COMO_USAR.txt'));

// dados: APENAS flow-selectors.json limpo + subpasta vazia novelas/
fs.mkdirSync(path.join(STAGE_INNER, 'dados', 'novelas'), { recursive: true });
if (fs.existsSync(path.join(ROOT, 'dados', 'flow-selectors.json'))) {
  fs.copyFileSync(path.join(ROOT, 'dados', 'flow-selectors.json'), path.join(STAGE_INNER, 'dados', 'flow-selectors.json'));
}
// Meus_Projetos_Flow vazia
fs.mkdirSync(path.join(STAGE_INNER, 'Meus_Projetos_Flow'), { recursive: true });

// Varredura de seguranca obrigatoria: garante ZERO .env, ZERO chaves/tokens e ZERO pastas de novelas/videos
function varrerSegurancaStage(dir) {
  for (const nome of fs.readdirSync(dir)) {
    const abs = path.join(dir, nome);
    const rel = path.relative(STAGE_INNER, abs).replace(/\\/g, '/');
    const st = fs.statSync(abs);
    if (nome.toLowerCase() === '.env' || /^gdrive_(token|credentials)\.json$/i.test(nome) || nome === 'whatsapp_auth') {
      throw new Error(`BLOQUEIO DE SEGURANÇA: arquivo/pasta sensível detectado no stage (${rel})`);
    }
    if (rel.startsWith('dados/novelas/') || rel.startsWith('Meus_Projetos_Flow/')) {
      throw new Error(`BLOQUEIO DE SEGURANÇA: novela ou mídia pessoal detectada no stage (${rel})`);
    }
    if (st.isDirectory()) varrerSegurancaStage(abs);
  }
}
varrerSegurancaStage(STAGE_INNER);

if (fs.existsSync(ZIP_INSTALADOR)) fs.unlinkSync(ZIP_INSTALADOR);

const psZip = `
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stage = (Resolve-Path -LiteralPath '${STAGE.replace(/'/g, "''")}').Path.TrimEnd('\\')
$zipPath = '${ZIP_INSTALADOR.replace(/'/g, "''")}'
$fs = [System.IO.File]::Open($zipPath, [System.IO.FileMode]::CreateNew)
$zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Create, $false)
try {
  $items = Get-ChildItem -LiteralPath $stage -Recurse -Force
  foreach ($item in $items) {
    $rel = $item.FullName.Substring($stage.Length + 1).Replace('\\', '/')
    if ($item.PSIsContainer) {
      if ((Get-ChildItem -LiteralPath $item.FullName -Force | Measure-Object).Count -eq 0) {
        [void]$zip.CreateEntry($rel + '/')
      }
    } else {
      [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $item.FullName, $rel, [System.IO.Compression.CompressionLevel]::Optimal)
    }
  }
} finally {
  if ($zip) { $zip.Dispose() }
  if ($fs) { $fs.Dispose() }
}
`;
execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psZip], { stdio: 'inherit' });
fs.copyFileSync(ZIP_INSTALADOR, ZIP_COMPAT);

const zipDesktop = path.join(deskDir, 'Flow_Novela_Studio_Instalador.zip');
fs.copyFileSync(ZIP_INSTALADOR, zipDesktop);
try {
  fs.copyFileSync(ZIP_INSTALADOR, path.join(deskDir, 'FlowStudio_Para_Amigo.zip'));
} catch {}
fs.rmSync(STAGE, { recursive: true, force: true });
const tamZip = fs.statSync(ZIP_INSTALADOR).size;
console.log(`ZIP_RAIZ=${ZIP_INSTALADOR}`);
console.log(`ZIP_DESKTOP=${zipDesktop}`);
console.log(`TAMANHO_KB=${(tamZip / 1024).toFixed(1)}`);
