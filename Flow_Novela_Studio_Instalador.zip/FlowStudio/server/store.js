// Banco de dados em arquivos JSON (sem dependencias nativas)
import fs from 'node:fs';
import path from 'node:path';
import { nomeArquivoSeguro, PASTAS } from './parser.js';

export function escreverJsonAtomico(arquivo, dados) {
  const tmp = arquivo + '.tmp';
  const conteudo = JSON.stringify(dados, null, 2);
  try {
    fs.writeFileSync(tmp, conteudo, 'utf8');
    fs.renameSync(tmp, arquivo);
  } catch {
    // Antivirus/indexador do Windows pode bloquear o rename; grava direto
    fs.writeFileSync(arquivo, conteudo, 'utf8');
    try { fs.unlinkSync(tmp); } catch {}
  }
}

export function lerJson(arquivo, padrao) {
  try { return JSON.parse(fs.readFileSync(arquivo, 'utf8')); } catch { return padrao; }
}

export class Store {
  constructor(dadosDir, projDir) {
    this.dadosDir = dadosDir;
    this.projDir = projDir;
    this.dir = path.join(dadosDir, 'novelas');
    fs.mkdirSync(this.dir, { recursive: true });
    fs.mkdirSync(projDir, { recursive: true });
    this.novelas = new Map();
    this.carregar();
  }

  carregar() {
    for (const f of fs.readdirSync(this.dir)) {
      if (!f.endsWith('.json')) continue;
      const n = lerJson(path.join(this.dir, f), null);
      if (!n || !n.id) continue;
      // Recuperacao apos queda: nada fica "gerando" ao reiniciar
      (n.itens || []).forEach((it) => {
        if (it.status === 'gerando' || it.status === 'na_fila') it.status = 'pendente';
      });
      this.garantirPastas(n);
      this.novelas.set(n.id, n);
    }
  }

  listar() {
    return [...this.novelas.values()].sort((a, b) => (a.ordem ?? 0) - (b.ordem ?? 0));
  }

  obter(id) { return this.novelas.get(id) || null; }

  pastaAbs(n) { return path.join(this.projDir, n.pasta); }

  garantirPastas(n) {
    const base = this.pastaAbs(n);
    Object.values(PASTAS).forEach((p) => fs.mkdirSync(path.join(base, p), { recursive: true }));
  }

  /** Le os padroes globais atuais salvos em `<dadosDir>/config.json` (fonte unica de verdade no disco). */
  lerPadroesDisco() {
    const cfg = lerJson(path.join(this.dadosDir, 'config.json'), null);
    return (cfg && typeof cfg.padroes === 'object' && cfg.padroes) ? { ...cfg.padroes } : {};
  }

  criar(nome, padroesExtra = null) {
    nome = String(nome || '').trim() || 'Nova Novela';
    let pastaBase = nomeArquivoSeguro(nome);
    let pasta = pastaBase, k = 2;
    const usadas = new Set(this.listar().map((n) => n.pasta.toLowerCase()));
    while (usadas.has(pasta.toLowerCase()) || fs.existsSync(path.join(this.projDir, pasta))) {
      pasta = `${pastaBase} (${k++})`;
    }
    const agora = new Date().toISOString();
    const ordens = this.listar().map((n) => n.ordem ?? 0);
    const pad = { ...this.lerPadroesDisco(), ...(padroesExtra && typeof padroesExtra === 'object' ? padroesExtra : {}) };
    const n = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      nome,
      pasta,
      ordem: ordens.length ? Math.max(...ordens) + 1 : 1,
      criadoEm: agora,
      atualizadoEm: agora,
      modeloImagem: pad.modeloImagem || 'Nano Banana 2.1',
      modeloVideo: pad.modeloVideo || 'Omni 1.2 Flash',
      forcarElementos: typeof pad.forcarElementos === 'boolean' ? pad.forcarElementos : false,
      ...(pad.qualidadeGeracaoVideo ? { qualidadeGeracaoVideo: pad.qualidadeGeracaoVideo } : {}),
      ...(pad.qualidadeDownloadVideo ? { qualidadeDownloadVideo: pad.qualidadeDownloadVideo } : {}),
      ...(pad.qualidadeDownloadImagem ? { qualidadeDownloadImagem: pad.qualidadeDownloadImagem } : {}),
      roteiro: '',
      itens: [],
      resumo: { referencias: 0, imagensBase: 0, videos: 0, total: 0, linhasIgnoradas: 0 },
      validacao: { ok: true, erros: [], avisos: [] },
      ignoradas: [],
      flowProjectUrl: null,
      status: 'rascunho',
      concluidaManualmente: false,
      statusManual: null,
    };
    this.garantirPastas(n);
    this.salvar(n);
    return n;
  }

  salvar(n) {
    n.atualizadoEm = new Date().toISOString();
    this.novelas.set(n.id, n);
    escreverJsonAtomico(path.join(this.dir, `${n.id}.json`), n);
    return n;
  }

  remover(id) {
    this.novelas.delete(id);
    try { fs.unlinkSync(path.join(this.dir, `${id}.json`)); } catch {}
  }
}
