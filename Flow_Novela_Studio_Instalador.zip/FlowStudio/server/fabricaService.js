// =============================================================
//  Fabrica Claude — integracao do Flow Novela Studio com C:\FabricaClaude
//  - le "prontos_para_flow" e "series"
//  - importa uma parte pronta para o estudio (1 clique), herdando referencias da Parte 1
//  - roda o Claude CLI (sempre Sonnet, cwd = Fabrica) para criar historias / partes
//  - agendamento viral (fontes do Facebook + Agendador de Tarefas do Windows)
// =============================================================
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { parseRoteiro, aplicarModoElementos } from './parser.js';
import { escreverJsonAtomico, lerJson } from './store.js';
import {
  FABRICA_DIR,
  PASTA_CLAUDE_VAZIA,
  obterPastaClaudeVazia,
  detectarClaudeCli,
  executarClaude,
  statusClaudeCompleto,
  abrirLoginClaude,
  matarArvore,
  atualizarUltimoRegistroUsoClaude,
  normalizarModeloClaude,
  ROTULO_MODELO_CLAUDE,
} from './claudeBridge.js';
import { FichasService, lerSecoesPrompt, preencherModelo, extrairJsonDaResposta } from './fichasService.js';

export const HASHTAGS_VALIDAS = ['#historia', '#novela', '#motivacional', '#filme'];

/** Calcula dinamicamente o total de cenas: Math.round((duracaoMin * 60) / tamanhoCenaSeg). Ex.: 3 min + 10s = 18 cenas; 3 min + 15s = 12 cenas. */
export function calcularNumeroCenas(duracaoMin = 3, tamanhoCenaSeg = 15) {
  const dur = Math.max(1, Number(duracaoMin) || 3);
  const seg = Number(tamanhoCenaSeg) === 10 ? 10 : 15;
  return Math.round((dur * 60) / seg);
}

/** Bloco de fidelidade total quando o usuario fornece seu proprio resumo ("Meu Resumo"). */
export function blocoFidelidadeResumo(resumoUsuario) {
  const r = String(resumoUsuario || '').trim();
  if (!r) return '';
  return [
    'OBRIGATÓRIO — FIDELIDADE TOTAL AO RESUMO DO USUÁRIO: Adapte EXATAMENTE esta história, personagens, conflito e reviravolta final fornecidos pelo usuário. É PROIBIDO inventar outra trama, trocar o tema para dívida/herança/terra ou usar esqueletos que descaracterizem o resumo abaixo:',
    `"""\n${r}\n"""`,
    'REGRAS INVIOLÁVEIS DE FIDELIDADE ESTRITA AO RESUMO:',
    '- FATOS INTOCÁVEIS: Todos os fatos, nomes/papéis, motivações, sacrifícios, valores, objetos centrais (ex.: camiseta, presente, documento...), situações, viradas e desfechos descritos no resumo do usuário são obrigatórios e invioláveis.',
    '- PROIBIDO INVENTAR OUTRO ENREDO: É TERMINANTEMENTE PROIBIDO substituir ou desviar o enredo por outra história inventada (ex.: proibido inventar cartão estourado, lanchonete, comprovante de banco, dívida de armazém ou personagens extras quando o resumo já define os fatos centrais).',
    '- ONDE ENTRA A CRIATIVIDADE: Toda a criatividade dramática deve ir para COMO os personagens falam, provocam, reagem, hesitam e sentem dentro dos fatos exatos do resumo — com fala natural de novela, subtexto, comparação/provocação quando couber e reação real de quem escuta (nunca deixar a outra parte muda/apática sem motivo).',
    '- CENAS MUDAS (ATÉ 2 POR HISTÓRIA): É permitido o uso estratégico de até 2 cenas visuais sem diálogo (0 falas + `Ação:` com ≥ 20 caracteres, fora da Cena 1, fora da cena final e sem colar Cena 2 e 3 mudas seguidas), apenas quando acrescentarem tensão/emoção dentro do enredo real do resumo.',
    '- AMBIENTE FIEL: Ajuste o campo `Universo:` do roteiro para o ambiente real do resumo (ex.: `urbano_simples` ou `classe_media` se for casa/apartamento/divórcio na cidade — NUNCA force `interior_humilde`, roça, sítio ou armazém se o resumo não for sobre isso!).',
  ].join('\n');
}

/**
 * Normaliza localmente a saida da Chamada A para extrair ou formatar `roteiro_humano.md`
 * (corrige contadores `(N palavras)` nas falas e garante delimitador `===FILE:roteiro_humano.md===` se o modelo escreveu o roteiro direto).
 */
export function normalizarSaidaRoteiroChamadaA(saidaA) {
  let texto = String(saidaA || '');
  if (!texto.trim()) return texto;

  // Se nao veio com ===FILE:roteiro_humano.md=== mas tem estrutura clara de roteiro (# Titulo + Universo:/Personagens: + ## CENA 01), envelopa
  const arqs = extrairArquivosDelimitados(texto);
  if (!arqs['roteiro_humano.md']) {
    const semBiblia = texto
      .replace(/===FILE:\s*biblia_serie\.json\s*===[\s\S]*?(?:===END_FILE===|$)/gi, '')
      .replace(/RESULTADO_JSON:\s*\{[^\n]*\}/gi, '')
      .trim();
    const mInicio = semBiblia.match(/(^#\s+[^\n]+[\s\S]*?^##\s*CENA\s*0*1\b[\s\S]*)/im);
    if (mInicio && /^Personagens\s*:/im.test(mInicio[1])) {
      const rotExtraido = limparRoteiroDeJson(mInicio[1]).trim();
      texto = `===FILE:roteiro_humano.md===\n${rotExtraido}\n===END_FILE===\n${texto}`;
    }
  }

  // Recalcula contadores `(N palavras)` nas falas do bloco roteiro_humano.md para evitar falso erro bobo de soma
  return texto.replace(
    /(===FILE:\s*roteiro_humano\.md\s*===\n)([\s\S]*?)(===END_FILE===)/i,
    (_, abre, corpo, fecha) => {
      const linhas = String(corpo).split(/\r?\n/).map((raw) => {
        const mFala = raw.match(/^(\s*[A-ZÀ-Ú][A-ZÀ-Ú0-9 .'-]*?\s*\[[^\]]*\]\s*:\s*["“])(.+?)(["”])(\s*(?:\(\d+\s*palavras?\))?\s*)$/u);
        if (!mFala) return raw;
        const [, pre, falaTxt, aspaFim] = mFala;
        const nPal = contarPalavrasFala(falaTxt);
        return `${pre}${falaTxt}${aspaFim} (${nPal} palavras)`;
      });
      return `${abre}${linhas.join('\n').trim()}\n${fecha}`;
    }
  );
}

/** Verifica se o texto do roteiro_humano.md possui todas as secoes estruturais obrigatorias. */
export function temEstruturaRoteiroCompleta(rotTxt) {
  const t = String(rotTxt || '');
  return (
    /^#\s+\S/m.test(t) &&
    /^Universo\s*:/im.test(t) &&
    /^Esqueleto\s*:/im.test(t) &&
    /^Rela[cç][aã]o exata\s*:/im.test(t) &&
    /^Conflito concreto\s*:/im.test(t) &&
    /^Teste da Dona Maria\s*:/im.test(t) &&
    /^Personagens\s*:/im.test(t) &&
    /^##\s*CENA\s*0*1\b/im.test(t) &&
    /^Novidade\s*:/im.test(t)
  );
}

/**
 * Extrai o texto limpo da semente gerada pelo Claude em `criarSementes` (Link Viral ou Sementes Anti-Clichê),
 * removendo logs técnicos do yt-dlp/whisper (`extrair_video.mjs`) e linhas `RESULTADO_JSON:`.
 */
export function extrairSementeLimpaDeSaida(saida, { transcricaoViral = '' } = {}) {
  const bruto = String(saida || '').replace(/\r\n?/g, '\n');
  const limpo = bruto
    .replace(/^Tentando download[^\n]*\n?/gim, '')
    .replace(/^Transcrevendo as falas com whisper[^\n]*\n?/gim, '')
    .replace(/^⚡\s*Transcri[cç][aã]o[^\n]*cache local[^\n]*\n?/gim, '')
    .replace(/^📄\s*Transcri[cç][aã]o carregada em mem[oó]ria[^\n]*\n?/gim, '')
    .replace(/^✅\s*Extra[cç][aã]o local conclu[ií]da[^\n]*\n?/gim, '')
    .replace(/^#\s*Extra[cç][aã]o\s*[—–-][^\n]*\n?/gim, '')
    .replace(/^-\s*(?:Pasta|V[ií]deo|Dura[cç][aã]o|Transcri[cç][aã]o|Frames)\s*:[^\n]*\n?/gim, '')
    .replace(/^Pr[oó]ximo passo:\s*ler transcricao\.txt[^\n]*\n?/gim, '')
    .replace(/^RESULTADO_JSON:\s*\{[^\n]*\}\s*$/gim, '')
    .replace(/\n---\s*$/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  if (limpo) return limpo;
  return String(transcricaoViral || '').trim();
}

export const TIMEOUT_PADRAO_CLAUDE_SEG = 270; // 270s (4m30s) — dentro da faixa prudente 240s–300s (nunca 1500s!)
export const TIMEOUT_MAX_CLAUDE_SEG = 300;

/**
 * Detecta idioma provavel de uma transcricao viral ('es' | 'en' | 'pt') para instruir traducao/adaptacao automatica.
 */
export function detectarIdiomaTranscricao(texto, idiomaHint = '') {
  const h = String(idiomaHint || '').toLowerCase().trim();
  if (h.startsWith('es')) return 'es';
  if (h.startsWith('en')) return 'en';
  if (h.startsWith('pt')) return 'pt';
  const t = ` ${String(texto || '').toLowerCase()} `;
  const esHits = (t.match(/\b(necesito|pastel|ahorita|ustedes|hermano|hermana|mamá|papá|nieta|anciano|dinero|celebrar|hablar|quiere|gracias|siempre|también|después|nosotros|pero|porque\s+le)\b/g) || []).length;
  const enHits = (t.match(/\b(the|you|that|with|have|this|from|they|would|about|there|their|what|when|your|daughter|mother|husband|wife|money)\b/g) || []).length;
  const ptHits = (t.match(/\b(você|vocês|não|então|porque|também|dinheiro|irmão|irmã|marido|esposa|mãe|pai|filha|agora|aqui|está|estou)\b/g) || []).length;
  if (esHits >= 3 && esHits > ptHits) return 'es';
  if (enHits >= 4 && enHits > ptHits) return 'en';
  return 'pt';
}

/**
 * Prepara, limpa e delimita o conteudo de `transcricao.txt` (ou `transcricao.json` / `info.json` / `RESUMO.md`)
 * para ser injetado DIRETAMENTE dentro do prompt enviado ao Claude (modo stateless `--tools ""`, zero leitura de disco pelo CLI).
 * Se o video for longo (> 180s ou > maxChars), resume/delimita preservando Inicio (Gancho) + Meio (Escalada) + Fim (Reviravolta).
 */
export function prepararTranscricaoViralParaPrompt({
  transcricaoTxt = '',
  transcricaoJson = null,
  infoJson = null,
  resumoMd = '',
  titulo = '',
  duracaoSegundos = null,
  maxChars = 4200,
} = {}) {
  let textoBase = String(transcricaoTxt || '').trim();
  if (!textoBase && transcricaoJson && Array.isArray(transcricaoJson.segmentos)) {
    textoBase = transcricaoJson.segmentos
      .map((s) => String(s?.texto || '').trim())
      .filter(Boolean)
      .join('\n');
  }
  if (!textoBase && infoJson) {
    textoBase = [infoJson.titulo, infoJson.descricao].filter(Boolean).join('\n');
  }
  if (!textoBase && resumoMd) {
    textoBase = String(resumoMd || '').trim();
  }

  // Infere duracao do video (em segundos)
  let durSeg = Number(duracaoSegundos || infoJson?.duracaoSegundos) || 0;
  if (!durSeg && resumoMd) {
    const mDur = String(resumoMd).match(/Dura[cç][aã]o:\s*([\d.]+)\s*s/i);
    if (mDur) durSeg = Number(mDur[1]) || 0;
  }
  if (!durSeg && textoBase) {
    const tss = [...textoBase.matchAll(/\[(\d{1,2}):(\d{2})\]/g)];
    if (tss.length) {
      const ult = tss[tss.length - 1];
      durSeg = Number(ult[1]) * 60 + Number(ult[2]) + 5;
    }
  }

  // Limpa titulo removendo hashtags e contadores de views de redes sociais
  const tituloBruto = String(titulo || infoJson?.titulo || (String(resumoMd).match(/^#\s*Extra[cç][aã]o\s*[—–-]\s*(.+)$/im) || [])[1] || '')
    .replace(/#\S+/g, '')
    .replace(/^\s*[\d.,]+[MKmk]?\s*views\s*·\s*[\d.,]+[MKmk]?\s*reactions\s*\|\s*/i, '')
    .replace(/\s*\|\s*[^|]{2,40}\s*$/, '')
    .replace(/\s+/g, ' ')
    .trim();

  const idioma = detectarIdiomaTranscricao(`${tituloBruto} ${textoBase}`, transcricaoJson?.idioma);

  // Remove timestamps repetitivos [MM:SS] e linhas vazias duplicadas para economizar tokens
  const linhasLimpas = textoBase
    .replace(/\r\n?/g, '\n')
    .split('\n')
    .map((l) => l.replace(/^\s*\[\d{1,2}:\d{2}(?:\.\d+)?\]\s*/, '').trim())
    .filter((l) => l && !/^(- Pasta:|- Vídeo:|- Duração:|- Transcrição:|- Frames:|Próximo passo:|# Extração)/i.test(l));

  const textoContinuo = linhasLimpas.join('\n').trim();
  const ehLongo = durSeg > 180 || textoContinuo.length > maxChars;

  let textoDelimitado = textoContinuo;
  if (textoContinuo.length > maxChars && linhasLimpas.length >= 6) {
    const terco = Math.max(400, Math.floor((maxChars - 180) / 3));
    const inicio = textoContinuo.slice(0, terco).trim();
    const meioPos = Math.floor(textoContinuo.length / 2) - Math.floor(terco / 2);
    const meio = textoContinuo.slice(Math.max(terco, meioPos), Math.max(terco, meioPos) + terco).trim();
    const fim = textoContinuo.slice(-terco).trim();
    textoDelimitado = [
      '[ATO 1 — ABERTURA E GANCHO INICIAL]:',
      inicio,
      '',
      '[ATO 2 — ESCALADA DO CONFLITO E SACRIFÍCIO]:',
      meio,
      '',
      '[ATO 3 — CLÍMAX, VIRADA E LIÇÃO FINAL]:',
      fim,
    ].join('\n');
  } else if (ehLongo && linhasLimpas.length >= 9) {
    // Video > 180s mas texto <= maxChars: estrutura em 3 atos claros para orientar a condensacao nas cenas alvo
    const n = linhasLimpas.length;
    const p1 = Math.floor(n * 0.35);
    const p2 = Math.floor(n * 0.70);
    textoDelimitado = [
      '[ATO 1 — ABERTURA E GANCHO INICIAL]:',
      linhasLimpas.slice(0, p1).join('\n'),
      '',
      '[ATO 2 — ESCALADA DO CONFLITO E SACRIFÍCIO]:',
      linhasLimpas.slice(p1, p2).join('\n'),
      '',
      '[ATO 3 — CLÍMAX, VIRADA E LIÇÃO FINAL]:',
      linhasLimpas.slice(p2).join('\n'),
    ].join('\n');
  }

  const notasAdaptacao = [];
  if (idioma !== 'pt') {
    const nomeIdioma = idioma === 'es' ? 'Espanhol' : 'Inglês/Estrangeiro';
    notasAdaptacao.push(`- IDIOMA ORIGINAL DETECTADO: ${nomeIdioma} -> TRADUZA E ADAPTE 100% PARA PORTUGUÊS DO BRASIL (nomes brasileiros naturais, relações familiares claras e fala popular brasileira do dia a dia).`);
  }
  if (ehLongo) {
    notasAdaptacao.push(`- VÍDEO LONGO (${durSeg ? `${Math.round(durSeg)}s` : `${textoContinuo.length} chars`}): condense o arco dramático (Gancho -> Escalada/Humilhação -> Virada/Justiça) de forma enxuta e direta para caber perfeitamente no número exato de cenas configurado, sem enrolação.`);
  }

  const blocoPrompt = [
    '=== TRANSCRIÇÃO DO VÍDEO VIRAL JÁ EXTRAÍDA E INJETADA NO PROMPT (ZERO LEITURA DE DISCO) ===',
    '⚠️ ATENÇÃO: Você está rodando com `--tools ""` (sem acesso a arquivos). NÃO tente abrir `transcricao.txt` nem olhar `frames/` no disco — todo o conteúdo falado do vídeo já está transcrito e delimitado abaixo:',
    tituloBruto ? `TÍTULO / PREMISSA ORIGINAL DO VÍDEO: "${tituloBruto}"` : '',
    durSeg ? `DURAÇÃO ORIGINAL DO VÍDEO: ${Math.round(durSeg)}s (${ehLongo ? 'vídeo longo — estruturado em 3 atos abaixo' : 'curto'})` : '',
    ...notasAdaptacao,
    'CONTEÚDO FALADO DO VÍDEO:',
    '"""',
    textoDelimitado || tituloBruto || '(sem fala detectada — use o título/premissa acima)',
    '"""',
  ].filter(Boolean).join('\n');

  return {
    titulo: tituloBruto,
    duracaoSegundos: durSeg || null,
    idioma,
    ehLongo,
    textoLimpo: textoContinuo,
    textoDelimitado,
    blocoPrompt,
  };
}

/** Extrai blocos `===FILE:<nome>=== ... ===END_FILE===` devolvidos no stdout do Claude stateless (1 turno, sem tools). */
export function extrairArquivosDelimitados(saida) {
  const texto = String(saida || '').replace(/\r\n?/g, '\n');
  const arquivos = {};
  const re = /===FILE:\s*([^\n=]+?)\s*===\n([\s\S]*?)(?:===END_FILE===|(?=\n===FILE:)|(?=\nRESULTADO_JSON:)|$)/g;
  for (const m of texto.matchAll(re)) {
    const bruto = m[1].trim().replace(/^[`"']+|[`"']+$/g, '');
    const base = path.posix.basename(bruto.replace(/\\/g, '/'));
    let corpo = m[2].replace(/^\s*```[a-z0-9_-]*\n/i, '').replace(/\n```\s*$/i, '').trim();
    if (base && corpo) arquivos[base] = corpo + '\n';
  }
  return arquivos;
}

/** Gera `continuidade_cenas.md` deterministicamente a partir do `roteiro_humano.md` (0 tokens, 100% sincronizado). */
export function gerarTabelaContinuidadeDeRoteiro(roteiroTxt) {
  const linhas = String(roteiroTxt || '').replace(/^\uFEFF/, '').split(/\r?\n/);
  const titulo = (linhas.find((l) => /^#\s+\S/.test(l.trim())) || '# Novela').replace(/^#\s+/, '').trim();
  const cenas = [];
  let atual = null;
  for (const raw of linhas) {
    const l = raw.trim();
    const h = l.match(/^#{1,4}\s*cena\s*0*(\d+)\b/i);
    if (h) {
      atual = { num: Number(h[1]), onde: '', quem: '', transicao: '' };
      cenas.push(atual);
      continue;
    }
    if (!atual) continue;
    let m;
    if ((m = l.match(/^Onde:\s*(.+)$/i))) atual.onde = m[1].trim();
    else if ((m = l.match(/^Em quadro:\s*(.+)$/i))) atual.quem = m[1].trim();
    else if ((m = l.match(/^Transi[cç][aã]o:\s*(.+)$/i))) atual.transicao = m[1].trim();
    else if (!atual.transicao && (m = l.match(/^Novidade:\s*(.+)$/i))) atual.transicao = m[1].trim();
  }
  if (!cenas.length) return '';
  const out = [
    `# Tabela de Continuidade — ${titulo}`,
    '',
    '| Cena | Onde fisicamente | Quem está em quadro | Transição |',
    '|---|---|---|---|',
  ];
  for (const c of cenas) {
    const num = String(c.num).padStart(2, '0');
    const tr = (c.transicao || (c.num === 1 ? 'abertura no pico de tensão (gancho)' : 'continuação direta')).replace(/\|/g, '/');
    out.push(`| ${num} | ${c.onde} | ${c.quem} | ${tr} |`);
  }
  return out.join('\n') + '\n';
}

export function slugDeTitulo(titulo) {
  const base = String(titulo || '')
    .replace(/^#\s+/, '')
    .replace(/\s*[—–-]+\s*Parte\s*\d+.*$/i, '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return base || `historia-${Date.now().toString(36)}`;
}

// ---------------- Legenda Facebook (2 a 3 hashtags exclusivas da lista salva HASHTAGS_VALIDAS) ----------------
/** Fisher-Yates com crypto.randomInt: embaralhamento real. Devolve 2 ou 3 hashtags EXCLUSIVAS de HASHTAGS_VALIDAS (nunca a lista toda). */
export function sortearHashtags(excluirIguaisA = null, qtdForcada = null) {
  const pool = [...HASHTAGS_VALIDAS];
  const maxPermitido = Math.max(2, Math.min(3, pool.length - 1)); // 2 ou 3 (nunca a lista inteira de 4)
  const chaveAnterior = Array.isArray(excluirIguaisA) && excluirIguaisA.length
    ? [...excluirIguaisA].map((x) => String(x || '').trim().toLowerCase()).filter(Boolean).sort().join(',')
    : '';

  for (let t = 0; t < 12; t++) {
    const qtd = (qtdForcada === 2 || qtdForcada === 3)
      ? Math.min(qtdForcada, maxPermitido)
      : crypto.randomInt(2, maxPermitido + 1); // 2 ou 3
    const a = [...pool];
    for (let i = a.length - 1; i > 0; i--) {
      const j = crypto.randomInt(0, i + 1);
      [a[i], a[j]] = [a[j], a[i]];
    }
    const escolhidas = a.slice(0, qtd);
    const chaveAtual = [...escolhidas].sort().join(',');
    if (!chaveAnterior || chaveAtual !== chaveAnterior) return escolhidas;
  }
  return pool.slice(0, 2);
}

export function lerLegenda(txt) {
  const partes = String(txt || '').replace(/\r\n?/g, '\n').trim().split(/\n[ \t]*\n/);
  const hashtags = (partes.length > 1 ? partes[partes.length - 1] : '').match(/#\w+/g) || [];
  const texto = partes.length > 1 ? partes.slice(0, -1).join('\n\n') : partes[0] || '';
  return { linhas: texto.split('\n').map((l) => l.trim()).filter(Boolean), hashtags };
}

export function validarLegenda(txt) {
  const erros = [];
  const partes = String(txt || '').replace(/\r\n?/g, '\n').replace(/\s+$/, '').split(/\n[ \t]*\n/);
  if (partes.length !== 2) return { ok: false, erros: ['precisa de exatamente 1 linha em branco entre o texto e as hashtags'] };
  const corpo = partes[0].split('\n').map((l) => l.trim()).filter(Boolean);
  if (corpo.length < 1 || corpo.length > 3) erros.push(`texto com ${corpo.length} linha(s) (esperado 1 a 3)`);
  const emojis = (partes[0].match(/\p{Extended_Pictographic}/gu) || []).length;
  if (emojis < 1 || emojis > 2) erros.push(`${emojis} emoji(s) (esperado 1 ou 2)`);
  const tags = partes[1].match(/#\w+/g) || [];
  if (tags.length < 2 || tags.length > 3) erros.push(`${tags.length} hashtag(s) (esperado 2 ou 3)`);
  if (new Set(tags).size !== tags.length) erros.push('hashtags repetidas');
  tags.forEach((t) => { if (!HASHTAGS_VALIDAS.includes(t)) erros.push(`hashtag inválida ${t}`); });
  return { ok: erros.length === 0, erros };
}

/** Mantem as linhas do texto e sorteia novas 2 ou 3 hashtags da lista salva. */
export function resortearLegenda(txt) {
  const { linhas, hashtags } = lerLegenda(txt);
  return `${linhas.join('\n')}\n\n${sortearHashtags(hashtags).join(' ')}\n`;
}

// ---------------- Tipo de final (escolha obrigatoria do usuario) ----------------
/** 'aberto' (final chocante, vai ter proxima parte) | 'fechado' (a historia se encerra aqui) | null */
export function normalizarTipoFinal(v) {
  const s = String(v || '').trim().toLowerCase();
  if (['aberto', 'finalaberto', 'final_aberto', 'cliffhanger', 'continua'].includes(s)) return 'aberto';
  if (['fechado', 'encerrar', 'encerraraqui', 'encerrar_aqui', 'final_fechado', 'fim'].includes(s)) return 'fechado';
  return null;
}

/**
 * Instrucao explicita enviada ao Claude CLI. O validar_novela.mjs decide cliffhanger x desfecho pelo titulo
 * "Parte N de M" (continua = N < M), entao o titulo e parte da instrucao.
 * Usa dinamicamente a ultima cena (Cena ${numCenas}) e penultima (Cena ${numCenas - 1}).
 */
export function instrucaoTipoFinal(tipo, { parte = 1, ehSerie = false, numCenas = 12 } = {}) {
  const t = normalizarTipoFinal(tipo);
  const totalCenas = Math.max(2, Number(numCenas) || 12);
  const penult = String(totalCenas - 1).padStart(2, '0');
  const ult = String(totalCenas).padStart(2, '0');
  if (t === 'aberto') {
    return [
      'TIPO DE FINAL ESCOLHIDO PELO USUÁRIO (OBRIGATÓRIO): 🔥 FINAL ABERTO CHOCANTE — esta história VAI TER PRÓXIMA PARTE.',
      `- Aplique a Lei 4 com rigor: na penúltima cena (Cena ${penult}) inclua a linha "Armadilha: ..." preparando a tensão; na última cena (Cena ${ult}) inclua "Choque: <revelação|flagrante|chegada|prova> — <o que o espectador descobre, dito com todas as letras numa fala>" com um choque CONCRETO que deixe gancho forte para a Parte ${parte + 1}.`,
      '- "Final-fisgada:" do cabeçalho deve começar com revelação, flagrante, chegada ou prova.',
      `- O título do roteiro_humano.md DEVE ser "# <Título> — Parte ${parte} de M" com M MAIOR que ${parte} (assim o validar_novela.mjs exige o cliffhanger). Inclua no cabeçalho a linha "Tipo-final: aberto" e grave "tipoFinal": "aberto" no metadata_flow.json.`,
      `- Trate como SÉRIE: totalPartes ≥ ${parte + 1}.`,
    ].join('\n');
  }
  if (t === 'fechado') {
    return [
      'TIPO DE FINAL ESCOLHIDO PELO USUÁRIO (OBRIGATÓRIO): ✅ A HISTÓRIA SE ENCERRA AQUI — FINAL FECHADO.',
      `- Resolva TODOS os conflitos até a última cena (Cena ${ult}): desfecho emocionante com justiça completa (quem errou recebe a consequência, a protagonista recupera/conquista o que perdeu), sem gancho de continuação e sem "Choque" pendente. Mantenha a fisgada emocional (olhar, frase ou promessa que dê catarse).`,
      parte > 1 || ehSerie
        ? `- Esta Parte ${parte} é a ÚLTIMA da série: título "# <Título> — Parte ${parte} de ${parte}" (o validar_novela.mjs aceita desfecho fechado) e totalPartes = ${parte} (marcando a série como encerrada).`
        : '- Título SEM numeração de parte (ou "Parte 1 de 1"): é uma história de parte única fechada — não crie Bíblia de série.',
      '- Inclua no cabeçalho a linha "Tipo-final: fechado" e grave "tipoFinal": "fechado" no metadata_flow.json.',
    ].join('\n');
  }
  return '';
}

/** Confere se o roteiro respeita o tipo de final pedido (titulo "Parte N de M" + Armadilha/Choque na ultima cena). */
export function verificarTipoFinalRoteiro(txt, tipo) {
  const t = normalizarTipoFinal(tipo);
  const texto = String(txt || '');
  const titulo = (texto.split(/\r?\n/).find((l) => /^#\s+\S/.test(l)) || '').trim();
  const m = titulo.match(/Parte\s*(\d+)\s*de\s*(\d+)/i);
  const parte = m ? Number(m[1]) : 1;
  const total = m ? Number(m[2]) : 1;
  if (!t) return { ok: true, parte, total, motivo: null };
  const temChoque = /^\s*Choque\s*:\s*\S/im.test(texto);
  if (t === 'aberto') {
    if (!(parte < total)) return { ok: false, parte, total, motivo: `Final aberto pedido, mas o título indica "Parte ${parte} de ${total}" (precisa ser "Parte ${parte} de M" com M > ${parte}).` };
    if (!temChoque) return { ok: false, parte, total, motivo: 'Final aberto pedido, mas a última cena não tem a linha "Choque: ...".' };
    return { ok: true, parte, total, motivo: null };
  }
  if (parte < total) return { ok: false, parte, total, motivo: `Final fechado pedido, mas o título indica "Parte ${parte} de ${total}" (deveria encerrar: "Parte ${parte} de ${parte}").` };
  return { ok: true, parte, total, motivo: null };
}

/** Conta palavras exatamente como validar_novela.mjs. */
export function contarPalavrasFala(t) {
  return (String(t || '').match(/[\p{L}\p{N}]+(?:['’-][\p{L}\p{N}]+)*/gu) || []).length;
}

/** Teste da Dona Maria: so as falas, cena a cena, a partir do roteiro_humano.md. */
export function extrairDialogosRoteiro(txt) {
  const cenas = [];
  let atual = null;
  const textoLimpo = String(txt || '').replace(/^\uFEFF/, '');
  const mCenasHeader = textoLimpo.match(/^Cenas\s*:\s*(\d+)\s*x\s*(10|15|30)\s*s/im);
  const tamanhoCenaSegundos = mCenasHeader ? Number(mCenasHeader[2]) : 15;
  for (const raw of textoLimpo.split(/\r?\n/)) {
    const l = raw.trim();
    const h = l.match(/^#{1,4}\s*cena\s*0*(\d+)\b[^—–-]*(?:[—–-]+\s*(.*))?$/i);
    if (h) {
      const mDur = l.match(/\((\d+)\s*s\)/i);
      atual = {
        cena: Number(h[1]),
        etapa: (h[2] || '').trim(),
        duracaoSegundos: mDur ? Number(mDur[1]) : tamanhoCenaSegundos,
        totalPalavras: 0,
        falas: [],
      };
      cenas.push(atual);
      continue;
    }
    if (!atual) continue;
    const f = l.match(/^([A-ZÀ-Ú][A-ZÀ-Ú0-9 .'-]*?)\s*\[([^\]]*)\]\s*:\s*["“](.+?)["”]/u);
    if (f) {
      const textoFala = f[3].trim();
      const palavras = contarPalavrasFala(textoFala);
      atual.falas.push({ quem: f[1].trim(), emocao: f[2].trim(), texto: textoFala, palavras });
      atual.totalPalavras += palavras;
    }
  }
  const titulo = (textoLimpo.split(/\r?\n/).find((l) => /^#\s+\S/.test(l)) || '').replace(/^#\s+/, '').trim();
  return { titulo, tamanhoCenaSegundos, cenas };
}

/**
 * Edita inline uma fala especifica (cena + falaIndex) diretamente no texto de `roteiro_humano.md`,
 * recalculando `(N palavras)` na linha e `[Total da cena: M palavras]` na cena (zero chamada ao Claude CLI).
 */
export function editarFalaEmRoteiroTexto(txt, { cena, falaIndex = 0, texto, emocao = null } = {}) {
  const cenaAlvo = Number(cena);
  const idxAlvo = Number(falaIndex);
  const novoTextoFala = String(texto || '').replace(/[\r\n"“”]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!cenaAlvo || !novoTextoFala) throw new Error('Cena e texto da fala são obrigatórios.');

  const linhas = String(txt || '').replace(/^\uFEFF/, '').split(/\r?\n/);
  let cenaAtual = null;
  let contadorFalaCena = -1;
  let editou = false;
  const indicesFalasDaCena = [];
  let indiceTotalCena = -1;

  for (let i = 0; i < linhas.length; i++) {
    const l = linhas[i].trim();
    const h = l.match(/^#{1,4}\s*cena\s*0*(\d+)\b/i);
    if (h) {
      cenaAtual = Number(h[1]);
      contadorFalaCena = -1;
      continue;
    }
    if (cenaAtual !== cenaAlvo) continue;

    if (/^\[Total da cena\s*:\s*\d+\s*palavras?\]/i.test(l)) {
      indiceTotalCena = i;
      continue;
    }

    const f = l.match(/^([A-ZÀ-Ú][A-ZÀ-Ú0-9 .'-]*?)\s*\[([^\]]*)\]\s*:\s*["“](.+?)["”](.*)$/u);
    if (f) {
      contadorFalaCena++;
      indicesFalasDaCena.push(i);
      if (contadorFalaCena === idxAlvo) {
        const quem = f[1].trim();
        const emoFinal = typeof emocao === 'string' && emocao.trim() ? emocao.trim() : f[2].trim();
        const sufixo = f[4] || '';
        const nPal = contarPalavrasFala(novoTextoFala);
        const temSufixoPalavras = /\(\d+\s*palavras?\)/i.test(sufixo);
        const novoSufixo = temSufixoPalavras
          ? sufixo.replace(/\(\d+\s*palavras?\)/i, `(${nPal} palavras)`)
          : ` (${nPal} palavras)`;
        linhas[i] = `${quem} [${emoFinal}]: "${novoTextoFala}"${novoSufixo}`;
        editou = true;
      }
    }
  }

  if (!editou) throw new Error(`Fala #${idxAlvo + 1} da Cena ${cenaAlvo} não encontrada no roteiro.`);

  // Recalcula o total de palavras da cena se houver a linha [Total da cena: X palavras]
  if (indiceTotalCena >= 0) {
    let soma = 0;
    for (const idxLinha of indicesFalasDaCena) {
      const m = linhas[idxLinha].trim().match(/^([A-ZÀ-Ú][A-ZÀ-Ú0-9 .'-]*?)\s*\[([^\]]*)\]\s*:\s*["“](.+?)["”]/u);
      if (m) soma += contarPalavrasFala(m[3]);
    }
    linhas[indiceTotalCena] = `[Total da cena: ${soma} palavras]`;
  }

  return linhas.join('\n');
}

// ---------------- Conversao do prompts_flow.txt para o formato do parser do estudio ----------------
/** "{id} -> (i) ..." (uma linha) vira "{id}" + linha "(i) ..." exigidas pelo parser. */
export function converterPromptsParaEstudio(txt, declaracoesExtras = []) {
  const saida = [];
  const declaradas = new Set();
  const usadas = new Set();
  let injetou = false;
  const extra = () => {
    for (const d of declaracoesExtras) { saida.push(`{${d.id}}`); saida.push(`(i) ${d.prompt}`); declaradas.add(d.id); }
    injetou = true;
  };
  for (const raw of String(txt || '').replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const l = raw.trim();
    if (!l) { saida.push(''); continue; }
    if (/^BLOCO\s*1\b/i.test(l)) { saida.push(l); if (declaracoesExtras.length && !injetou) extra(); continue; }
    const m = l.match(/^\{([^{}]+)\}\s*->\s*(.*)$/);
    if (m) {
      saida.push(`{${m[1].trim()}}`);
      saida.push(m[2].trim());
      declaradas.add(m[1].trim());
      for (const r of m[2].matchAll(/\[([^\[\]]+)\]/g)) usadas.add(r[1].trim());
      continue;
    }
    saida.push(l);
  }
  if (declaracoesExtras.length && !injetou) { const antes = saida.splice(0); extra(); saida.push(...antes); }
  return { texto: saida.join('\n'), declaradas: [...declaradas], usadas: [...usadas] };
}

const ITEM_RESETADO = {
  status: 'pendente', arquivo: null, geradoEm: null, erro: null, nomeAtivoFlow: null, flowMidiaChave: null,
  tamanhoBytes: null, formatoReal: null, resolucaoDownload: null, originalPrompt: null, promptAutoAjustado: null,
};

const lerTexto = (p) => { try { return fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, ''); } catch { return null; } };
const nomeParte = (n) => `parte_${String(n).padStart(2, '0')}`;

// ---------------- HERANCA FISICA DE 01_Referencias (Parte 2, 3... a partir da Parte 1) ----------------
/**
 * Copia fisicamente para a novela `n` as imagens {ref_xxx} de mesmo codigo ja geradas em partes anteriores
 * da mesma serie (da mais recente para a mais antiga) e marca-as como concluidas.
 * Nao copia nomeAtivoFlow/flowMidiaChave: o ativo ainda NAO esta no projeto novo do Google Flow,
 * entao o runner (uploadedAssetsByProjectUrl + arquivoUrl) sobe o arquivo do disco antes de gerar {imagem_01}.
 */
export function herdarReferenciasFisicas({ n, anteriores, pastaAbsDe }) {
  const herdadas = [];
  const faltando = [];
  const baseNova = pastaAbsDe(n);
  const ordenadas = [...anteriores].sort((a, b) => (b.numeroParte || 0) - (a.numeroParte || 0));
  for (const it of n.itens || []) {
    if (it.tipo !== 'referencia_imagem') continue;
    if (it.status === 'concluido' && it.arquivo && fs.existsSync(path.join(baseNova, it.arquivo))) { herdadas.push({ id: it.id, deParte: it.herdadoDe?.parte ?? null, jaTinha: true }); continue; }
    let achou = null;
    for (const ant of ordenadas) {
      const ai = (ant.itens || []).find((x) => x.id === it.id && x.tipo === 'referencia_imagem' && x.status === 'concluido' && x.arquivo);
      const origem = ai ? path.join(pastaAbsDe(ant), ai.arquivo) : null;
      if (origem && fs.existsSync(origem)) { achou = { ant, ai, origem }; break; }
    }
    if (!achou) { faltando.push(it.id); continue; }
    const nome = path.basename(achou.origem);
    const destinoRel = `${it.pasta || '01_Referencias'}/${nome}`;
    const destino = path.join(baseNova, destinoRel);
    fs.mkdirSync(path.dirname(destino), { recursive: true });
    fs.copyFileSync(achou.origem, destino);
    Object.assign(it, {
      arquivo: destinoRel, status: 'concluido', erro: null, geradoEm: achou.ai.geradoEm || new Date().toISOString(),
      tamanhoBytes: fs.statSync(destino).size, formatoReal: achou.ai.formatoReal || null, resolucaoDownload: achou.ai.resolucaoDownload || null,
      herdadoDe: { novelaId: achou.ant.id, parte: achou.ant.numeroParte ?? null, nome: achou.ant.nome },
      nomeAtivoFlow: null, flowMidiaChave: null,
    });
    herdadas.push({ id: it.id, deParte: achou.ant.numeroParte ?? null, arquivo: destinoRel });
  }
  return { herdadas, faltando };
}

// ---------------- Servico ----------------
// Nenhum valor de qualidade/resolucao/modelo e imposto aqui: tudo vem EXCLUSIVAMENTE dos "Padroes" globais do FlowStudio
// (index.js -> config().padroes, definidos pelo usuario). Sem Padroes disponiveis, a novela mantem os defaults do proprio Estudio.
const PADROES_BASE_ESTUDIO = {};

/**
 * Blindagem de CENAS MUDAS (ironia dramática visual) no prompts_flow.txt: para toda cena do roteiro com 0 falas,
 * garante no prompt de vídeo (inglês) a instrução que impede o Flow de inventar fala/lip-sync. Custo zero de Claude.
 */
export const FRASE_CENA_MUDA = 'No spoken dialogue in this scene; characters keep their lips closed throughout the entire clip, pure visual storytelling.';
export function garantirBlindagemCenasMudas(roteiroTxt, promptsTxt) {
  const mudas = extrairDialogosRoteiro(roteiroTxt).cenas.filter((c) => !c.falas.length).map((c) => c.cena);
  if (!mudas.length || !promptsTxt) return { texto: promptsTxt, corrigidas: [] };
  const corrigidas = [];
  const linhas = String(promptsTxt).split(/\r?\n/).map((l) => {
    const m = l.match(/^\{\s*(?:Cena\s*0*(\d+)|video_0*(\d+))\s*\}\s*->\s*\(v\)/i);
    if (!m) return l;
    const n = Number(m[1] || m[2]);
    if (!mudas.includes(n)) return l;
    if (/No spoken dialogue in this scene/i.test(l) && /lips closed throughout the entire clip/i.test(l) && /pure visual storytelling/i.test(l)) return l;
    corrigidas.push(n);
    const limpo = l.replace(/\s*No spoken dialogue in this scene[^.]*\.?/i, '');
    const i = limpo.search(/\s+No music,/i);
    return i >= 0 ? `${limpo.slice(0, i)} ${FRASE_CENA_MUDA}${limpo.slice(i)}` : `${limpo.trimEnd()} ${FRASE_CENA_MUDA}`;
  });
  return { texto: linhas.join('\n'), corrigidas };
}

/** Remove blocos de código/JSON que tenham vazado para dentro do roteiro_humano.md (a bíblia vive em biblia_serie.json). */
export function limparRoteiroDeJson(txt) {
  return String(txt || '')
    .replace(/```[a-z]*\n[\s\S]*?```/gi, '')
    .replace(/```[a-z]*\n[\s\S]*$/i, '') // cerca de abertura sem fechamento (o extrator pode ter comido a de fechamento)
    .replace(/===FILE:\s*biblia_serie\.json\s*===[\s\S]*?(?:===END_FILE===|$)/gi, '')
    .replace(/\n{3,}/g, '\n\n');
}

export class FabricaService {
  constructor({ store, log, emitirNovela, broadcastUI, runner = null, obterPadroes = null, aoImportarNovela = null, reprocessarNovela = null }) {
    this.store = store;
    this.log = log;
    this.emitirNovela = emitirNovela;
    this.broadcast = broadcastUI;
    this.runner = runner;
    this.obterPadroes = obterPadroes;
    this.aoImportarNovela = aoImportarNovela;
    this.reprocessarNovela = reprocessarNovela; // (novela, textoConvertido) -> mescla roteiro preservando itens ja gerados
    this.jobs = new Map();
    this.fichas = new FichasService({ log });
  }

  /** Padroes globais atuais definidos pelo usuario no proprio FlowStudio (modal "Padroes" + `<dadosDir>/config.json`). */
  padroesEstudio() {
    const arqCfg = this.store?.dadosDir ? path.join(this.store.dadosDir, 'config.json') : null;
    const cfgDisco = arqCfg ? lerJson(arqCfg, {}) : {};
    const doDisco = (cfgDisco && typeof cfgDisco.padroes === 'object' && cfgDisco.padroes) ? cfgDisco.padroes : {};
    const doCallback = typeof this.obterPadroes === 'function' ? (this.obterPadroes() || {}) : {};
    return { ...PADROES_BASE_ESTUDIO, ...doDisco, ...doCallback };
  }

  get dir() { return FABRICA_DIR; }
  get existe() { return fs.existsSync(this.dir); }
  exigirFabrica() { if (!this.existe) throw new Error(`Pasta da Fábrica não encontrada (${this.dir}). Esta função precisa do C:\\FabricaClaude.`); }
  get prontosDir() { return path.join(this.dir, 'prontos_para_flow'); }
  get seriesDir() { return path.join(this.dir, 'series'); }

  // ---------- status ----------
  status({ forcar = false } = {}) {
    const bin = path.join(this.dir, 'bin');
    const tem = (...p) => fs.existsSync(path.join(bin, ...p));
    return {
      fabricaExiste: this.existe,
      pasta: this.dir,
      claude: statusClaudeCompleto({ forcar }),
      ferramentas: { ytdlp: tem('yt-dlp.exe'), ffmpeg: tem('ffmpeg.exe'), whisper: tem('whisper', 'whisper-cli.exe') && tem('whisper', 'ggml-small.bin') },
      config: this.lerConfigFabrica(),
      jobsAtivos: [...this.jobs.values()].filter((j) => j.estado === 'rodando').length,
    };
  }
  abrirLogin() { return abrirLoginClaude(); }

  lerConfigFabrica() {
    const c = lerJson(path.join(this.dir, 'dados', 'config.json'), {});
    const tSeg = Number(c.timeoutClaudeSegundos);
    const timeoutClaudeSegundos = (Number.isFinite(tSeg) && tSeg >= 30)
      ? Math.min(TIMEOUT_MAX_CLAUDE_SEG, Math.round(tSeg))
      : TIMEOUT_PADRAO_CLAUDE_SEG;
    return {
      ...c,
      tamanhoCenaSegundos: Number(c.tamanhoCenaSegundos) === 10 ? 10 : 15,
      modoGeracaoVideo: c.modoGeracaoVideo === 'frame_inicial' ? 'frame_inicial' : 'elementos',
      modeloRoteirista: normalizarModeloClaude(c.modeloRoteirista, 'sonnet'),
      timeoutClaudeSegundos,
    };
  }

  /** Retorna o timeout prudente em ms (padrão 270s, teto 300s, ou o valor menor configurado em config.json). */
  obterTimeoutClaudeMs(config = null, padraoSeg = TIMEOUT_PADRAO_CLAUDE_SEG) {
    const cfg = config || (this.existe ? this.lerConfigFabrica() : {});
    const cfgSeg = Number(cfg?.timeoutClaudeSegundos);
    const baseSeg = (Number.isFinite(cfgSeg) && cfgSeg >= 30)
      ? Math.min(padraoSeg, cfgSeg)
      : padraoSeg;
    return Math.max(5000, Math.min(TIMEOUT_MAX_CLAUDE_SEG, baseSeg) * 1000);
  }

  /** Atualiza SO os campos narrativos/operacionais em C:\FabricaClaude\dados\config.json (sem impor qualidade/modelos do Flow). */
  salvarConfigFabrica(patch = {}) {
    this.exigirFabrica();
    const p = path.join(this.dir, 'dados', 'config.json');
    const c = lerJson(p, {});
    if (['aprovacao', 'automatico'].includes(patch.modoOperacao)) c.modoOperacao = patch.modoOperacao;
    const dur = Number(patch.duracaoTotalMinutos); if (Number.isInteger(dur) && dur >= 1 && dur <= 30) c.duracaoTotalMinutos = dur;
    // 15s (padrao) ou 10s. 30s nao e oferecido: so entrara se houver outra ferramenta de video no futuro.
    const tam = Number(patch.tamanhoCenaSegundos); if ([10, 15].includes(tam)) c.tamanhoCenaSegundos = tam;
    else if (![10, 15].includes(Number(c.tamanhoCenaSegundos))) c.tamanhoCenaSegundos = 15;
    if (['unica', 'serie'].includes(patch.formatoHistoria)) c.formatoHistoria = patch.formatoHistoria;
    const np = Number(patch.numeroPartesPadrao); if (Number.isInteger(np) && np >= 1 && np <= 12) c.numeroPartesPadrao = np;
    if (['elementos', 'frame_inicial'].includes(patch.modoGeracaoVideo)) {
      c.modoGeracaoVideo = patch.modoGeracaoVideo;
    } else if (!['elementos', 'frame_inicial'].includes(c.modoGeracaoVideo)) {
      c.modoGeracaoVideo = 'elementos';
    }
    // modelo da Chamada A do roteirista (Sonnet por padrão para economizar cota na janela de 5h; Opus continua disponível no seletor). A Chamada B é sempre Sonnet.
    const mr = String(patch.modeloRoteirista || '').toLowerCase();
    if (['opus', 'sonnet'].includes(mr)) c.modeloRoteirista = mr;
    else if (!['opus', 'sonnet'].includes(c.modeloRoteirista)) c.modeloRoteirista = 'sonnet';
    delete c.flowConfig;
    escreverJsonAtomico(p, c);
    return { ...c, modoGeracaoVideo: c.modoGeracaoVideo };
  }

  // ---------- leitura de prontos / series ----------
  novelasDaSerie(slug) { return this.store.listar().filter((n) => n.serieSlug === slug); }
  novelaImportada(slug, parte) { return this.store.listar().find((n) => n.serieSlug === slug && n.numeroParte === parte) || null; }

  listarProntos() {
    if (!fs.existsSync(this.prontosDir)) return [];
    const out = [];
    for (const slug of fs.readdirSync(this.prontosDir)) {
      const dSlug = path.join(this.prontosDir, slug);
      if (!fs.statSync(dSlug).isDirectory()) continue;
      const pastasParte = fs.readdirSync(dSlug).filter((pd) => /^parte_\d+$/i.test(pd) && fs.statSync(path.join(dSlug, pd)).isDirectory());
      const qtdPartesDisco = pastasParte.length;
      for (const pd of pastasParte) {
        const m = pd.match(/^parte_(\d+)$/i);
        const dParte = path.join(dSlug, pd);
        if (!m) continue;
        const parte = Number(m[1]);
        const meta = lerJson(path.join(dParte, 'metadata_flow.json'), {});
        const legenda = lerTexto(path.join(dParte, 'legenda_facebook.txt')) || meta.legendaFacebook || '';
        const imp = this.novelaImportada(slug, parte);
        const temPrompts = fs.existsSync(path.join(dParte, 'prompts_flow.txt'));
        const roteiroTxt = lerTexto(path.join(dParte, 'roteiro_humano.md')) || '';
        const statusFs = lerJson(path.join(dParte, 'status_flowstudio.json'), {});
        const pronta = temPrompts && fs.existsSync(path.join(dParte, 'metadata_flow.json'));
        const verifFinal = roteiroTxt ? verificarTipoFinalRoteiro(roteiroTxt, null) : null;
        const tipoFinal = normalizarTipoFinal(meta.tipoFinal || statusFs.tipoFinal)
          || (verifFinal ? (verifFinal.parte < verifFinal.total ? 'aberto' : 'fechado') : null);
        const tituloRot = roteiroTxt ? (roteiroTxt.split(/\r?\n/).find((l) => /^#\s+\S/.test(l.trim())) || '').replace(/^#\s+/, '').trim() : '';
        const mCenasRot = roteiroTxt ? roteiroTxt.match(/^Cenas\s*:\s*(\d+)\s*x\s*(10|15|30)\s*s/im) : null;
        const temRefsExistentes = fs.existsSync(path.join(this.seriesDir, slug, 'catalogo_refs.json'))
          || /\{ref_[a-z0-9_]+\}/i.test(lerTexto(path.join(dParte, 'prompts_flow.txt')) || '')
          || this.novelasDaSerie(slug).some((n) => (n.itens || []).some((i) => i.tipo === 'referencia_imagem' && i.status === 'concluido'));
        const ehUnica =
          meta.formato === 'unica' ||
          meta.formatoHistoria === 'unica' ||
          (parte === 1 && qtdPartesDisco <= 1 && (Number(meta.totalPartes) || 1) <= 1 && (!verifFinal || verifFinal.total <= 1) && tipoFinal !== 'aberto');
        const totalPartes = ehUnica ? 1 : Math.max(Number(meta.totalPartes) || 1, verifFinal?.total || 1, qtdPartesDisco, parte);
        const ehSerie = !ehUnica && Boolean(totalPartes > 1 || parte > 1 || qtdPartesDisco > 1 || tipoFinal === 'aberto' || meta.serie);
        out.push({
          slug, parte, titulo: meta.titulo || tituloRot || `${slug} — Parte ${parte}`,
          serie: ehSerie,
          formato: ehSerie ? 'serie' : 'unica',
          totalPartes,
          numeroCenas: meta.numeroCenas || (mCenasRot ? Number(mCenasRot[1]) : null),
          tamanhoCenaSegundos: meta.tamanhoCenaSegundos || (mCenasRot ? Number(mCenasRot[2]) : null),
          pasta: dParte, temPrompts, temRoteiro: !!roteiroTxt,
          pronta,
          rascunho: !pronta || statusFs.validacaoOk === false,
          motivoRascunho: !pronta
            ? (roteiroTxt
                ? (statusFs.validacaoOk ? 'Roteiro validado — aguardando gerar prompts' : 'Roteiro sem prompts/metadata (incompleto)')
                : 'Parte incompleta')
            : statusFs.validacaoOk === false ? 'Reprovada no validador' : null,
          tipoFinal, temRefsExistentes,
          // enquanto o Claude reescreve: o card mostra o indicador e bloqueia Ler Só Diálogos / Importar (vem do servidor, sobrevive a recarregar a página)
          regerando: (() => { const j = this.jobAtivoDaParte(slug, parte); return j ? { jobId: j.id, desde: j.iniciadoEm, etapa: j.etapa, tipo: j.tipo } : null; })(),
          falhaRegerar: this.ultimaFalhaDaParte(slug, parte),
          legendaFacebook: legenda, legendaValida: legenda ? validarLegenda(legenda).ok : false,
          referenciasHerdadasDaParte1: meta.referenciasHerdadasDaParte1 || [],
          referenciasNovas: meta.referenciasNovas || [],
          criadoEm: meta.criadoEm || null,
          importada: imp ? { novelaId: imp.id, nome: imp.nome, legendaEnviadaWhatsappEm: imp.legendaEnviadaWhatsappEm || null } : null,
        });
      }
    }
    return out.sort((a, b) => a.slug.localeCompare(b.slug) || a.parte - b.parte);
  }

  listarSeries() {
    if (!fs.existsSync(this.seriesDir)) return [];
    const prontos = this.listarProntos();
    const out = [];
    for (const slug of fs.readdirSync(this.seriesDir)) {
      const d = path.join(this.seriesDir, slug);
      if (!fs.statSync(d).isDirectory()) continue;
      const biblia = lerJson(path.join(d, 'biblia_serie.json'), {});
      const catalogo = lerJson(path.join(d, 'catalogo_refs.json'), {});
      const total = biblia.totalPartes || (biblia.partes || []).length || 1;
      const prontosDoSlug = prontos.filter((x) => x.slug === slug);
      // Historias de parte unica (totalPartes === 1 e sem multi-partes) nao sao listadas como serie
      if (total <= 1 && prontosDoSlug.length <= 1 && prontosDoSlug.every((x) => !x.serie)) continue;
      const partes = [];
      for (let p = 1; p <= total; p++) {
        const pronto = prontos.find((x) => x.slug === slug && x.parte === p) || null;
        const resumoMd = lerTexto(path.join(d, 'resumos', `${nomeParte(p)}.md`)) || '';
        const bp = (biblia.partes || []).find((x) => x.parte === p) || {};
        partes.push({
          parte: p, status: pronto ? 'pronta' : (bp.status || (resumoMd ? 'apenas_resumo' : 'sem_resumo')),
          arco: bp.arco || '', ganchoDeFim: bp.ganchoDeFim || '', resumo: resumoMd,
          pronto: pronto ? { legendaFacebook: pronto.legendaFacebook, importada: pronto.importada, pasta: pronto.pasta } : null,
        });
      }
      const prontas = partes.filter((x) => x.status === 'pronta').map((x) => x.parte);
      const proxima = partes.find((x) => x.status !== 'pronta' && (x.parte === 1 || prontas.includes(x.parte - 1)));
      out.push({
        slug, titulo: biblia.titulo || slug, totalPartes: total, premissa: biblia.premissa || '',
        universoSocial: biblia.universoSocial || '', partes, proximaParte: proxima ? proxima.parte : null,
        refs: { personagens: Object.keys(catalogo.personagens || {}).length, cenarios: Object.keys(catalogo.cenarios || {}).length },
        refsCriadasNaParte: catalogo.refsCriadasNaParte || {},
      });
    }
    return out;
  }

  // ---------- importacao 1 clique ----------
  descricaoRef(slug, id) {
    const cat = lerJson(path.join(this.seriesDir, slug, 'catalogo_refs.json'), {});
    const d = (cat.personagens || {})[id] || (cat.cenarios || {})[id];
    return d || null;
  }

  /** Descobre refs herdadas e monta declaracoes (Bloco 1) para o parser do estudio validar as [ref_xxx]. */
  declaracoesHerdadas(slug, parte, usadasSemDecl, meta) {
    const ids = new Set([...(meta.referenciasHerdadasDaParte1 || []), ...usadasSemDecl].filter((x) => /^ref_/.test(x)));
    const anteriores = this.novelasDaSerie(slug).filter((n) => (n.numeroParte || 0) < parte);
    const decls = [];
    for (const id of ids) {
      let prompt = null;
      for (const a of [...anteriores].sort((x, y) => (y.numeroParte || 0) - (x.numeroParte || 0))) {
        const it = (a.itens || []).find((i) => i.id === id && i.tipo === 'referencia_imagem');
        if (it?.prompt) { prompt = it.prompt; break; }
      }
      if (!prompt) {
        const desc = this.descricaoRef(slug, id);
        prompt = desc
          ? `vertical 9:16, reference image of: ${desc}. Plain white background for characters, empty space for scenery, sharp, natural realism, no text.`
          : null;
      }
      if (prompt) decls.push({ id, prompt });
    }
    return decls;
  }

  importar({ slug, parte = 1, substituir = false, ignorarLockProprio = false, ignorarJobId = null } = {}) {
    this.exigirFabrica();
    if (!ignorarLockProprio && this.jobAtivoDaParte(slug, parte, { ignorarJobId })) {
      throw new Error('Esta parte está sendo reescrita pelo Claude agora. Espere terminar para importar.');
    }
    const pasta = path.join(this.prontosDir, slug, nomeParte(parte));
    const promptsTxt = lerTexto(path.join(pasta, 'prompts_flow.txt'));
    if (!promptsTxt) throw new Error(`Não achei prompts_flow.txt em ${pasta}`);
    const meta = lerJson(path.join(pasta, 'metadata_flow.json'), {});
    const existente = this.novelaImportada(slug, parte);
    if (existente && !substituir) throw new Error(`Esta parte já foi importada ("${existente.nome}"). Abra a novela no Estúdio.`);

    // 1) declara refs herdadas (para o parser aceitar [ref_xxx] que o Bloco 1 da Parte 2+ nao redeclara)
    let conv = converterPromptsParaEstudio(promptsTxt);
    const declaradas = new Set(conv.declaradas);
    const semDecl = conv.usadas.filter((u) => /^ref_/.test(u) && !declaradas.has(u));
    const extras = this.declaracoesHerdadas(slug, parte, semDecl, meta).filter((d) => !declaradas.has(d.id));
    if (extras.length) conv = converterPromptsParaEstudio(promptsTxt, extras);

    // 2) cria a novela herdando 100% dos Padroes globais do FlowStudio + modoGeracaoVideo da Fabrica ("elementos" por padrao)
    const padroes = this.padroesEstudio();
    const cfgFab = this.lerConfigFabrica();
    const modoGeracaoVideo = cfgFab.modoGeracaoVideo === 'frame_inicial' ? 'frame_inicial' : 'elementos';
    const forcarElementos = modoGeracaoVideo !== 'frame_inicial';

    const n = this.store.criar(meta.titulo || `${slug} — Parte ${parte}`, padroes);
    const r = parseRoteiro(conv.texto, { forcarElementos });
    n.itens = aplicarModoElementos(r.itens.map((it) => ({ ...it, ...ITEM_RESETADO })), forcarElementos);
    n.roteiro = conv.texto; n.resumo = r.resumo; n.validacao = r.validacao; n.ignoradas = r.ignoradas;
    n.processadoEm = new Date().toISOString();

    const totalPartes = Number(meta.totalPartes) || 1;
    const ehSerie = Boolean(meta.formato !== 'unica' && (totalPartes > 1 || parte > 1 || (meta.serie && totalPartes > 1) || meta.tipoFinal === 'aberto'));

    // 3) vinculos da Fabrica + Padroes globais configurados pelo usuario no FlowStudio
    Object.assign(n, {
      serieSlug: slug,
      numeroParte: parte,
      totalPartes,
      serie: ehSerie,
      formatoHistoria: ehSerie ? 'serie' : 'unica',
      fabricaPasta: pasta,
      legendaFacebook: (lerTexto(path.join(pasta, 'legenda_facebook.txt')) || meta.legendaFacebook || '').trim(),
      legendaEnviadaWhatsappEm: null,
      origemFabrica: true,
      roteiroHumano: lerTexto(path.join(pasta, 'roteiro_humano.md')) || '',
      modeloImagem: padroes.modeloImagem || n.modeloImagem,
      modeloVideo: padroes.modeloVideo || n.modeloVideo,
      forcarElementos,
      modoGeracaoVideo,
      qualidadeGeracaoVideo: padroes.qualidadeGeracaoVideo ?? n.qualidadeGeracaoVideo,
      qualidadeDownloadVideo: padroes.qualidadeDownloadVideo ?? n.qualidadeDownloadVideo,
      qualidadeDownloadImagem: padroes.qualidadeDownloadImagem ?? n.qualidadeDownloadImagem,
    });

    // 4) heranca fisica de 01_Referencias (Parte 1 -> Parte N)
    let heranca = { herdadas: [], faltando: [] };
    if (parte > 1) heranca = this.herdarReferencias(n, { salvar: false });
    this.store.salvar(n);
    this.emitirNovela(n);
    this.aoImportarNovela?.(n);
    if (existente && substituir) this.log(`Fábrica: "${existente.nome}" mantida; nova cópia criada com os dados atuais.`, 'aviso');
    this.log(`Fábrica Claude: "${n.nome}" importada (${r.resumo.referencias} refs, ${r.resumo.imagensBase} imagens-base, ${r.resumo.videos} vídeos · modo ${forcarElementos ? 'Elementos' : 'Frame Inicial'} · Padrões do Estúdio).` +
      (heranca.herdadas.length ? ` ${heranca.herdadas.length} referência(s) herdada(s) da Parte anterior.` : ''), 'ok');
    return { novela: n, validacao: r.validacao, heranca };
  }

  /** Aplica a heranca fisica numa novela ja existente (usado no import e antes de rodar a fila). */
  herdarReferencias(n, { salvar = true } = {}) {
    if (!n.serieSlug || !(n.numeroParte > 1)) return { herdadas: [], faltando: [] };
    const anteriores = this.novelasDaSerie(n.serieSlug).filter((x) => x.id !== n.id && (x.numeroParte || 0) < n.numeroParte);
    const r = herdarReferenciasFisicas({ n, anteriores, pastaAbsDe: (x) => this.store.pastaAbs(x) });
    const novas = r.herdadas.filter((h) => !h.jaTinha).length;
    if (salvar && novas) { this.store.salvar(n); this.emitirNovela(n); this.log(`Fábrica: ${novas} referência(s) herdada(s) copiadas fisicamente para "${n.nome}".`, 'ok'); }
    return r;
  }

  /** Texto de contexto da historia para o auto-conserto (skill conserto-contextual). */
  contextoHistoria(n, item) {
    try {
      const txt = n.roteiroHumano || (n.fabricaPasta ? lerTexto(path.join(n.fabricaPasta, 'roteiro_humano.md')) : '');
      if (!txt) return '';
      const mc = String(item?.id || '').match(/Cena\s*0*(\d+)/i);
      let trecho = '';
      if (mc) {
        const re = new RegExp(`^##\\s*CENA\\s*0*${mc[1]}\\b[\\s\\S]*?(?=^##\\s*CENA|$(?![\\s\\S]))`, 'im');
        trecho = (txt.match(re) || [''])[0].trim();
      }
      const cab = txt.split(/^##\s*CENA/im)[0].trim();
      return [cab.slice(0, 1800), trecho ? `\nCENA DO ITEM:\n${trecho.slice(0, 1500)}` : ''].join('\n').trim();
    } catch { return ''; }
  }

  // ---------- legenda (Facebook Mobile 3 a 4 linhas: 95 a 160 chars, teto 170 chars + Português real do dia a dia + 2 a 3 hashtags da lista salva) ----------
  static PERFIS_FOLEGO_LEGENDA = [
    {
      id: 'mobile_curta',
      rotulo: 'Curta Facebook Mobile (3 linhas no celular · 95 a 140 chars)',
      minChars: 95,
      maxChars: 140,
    },
    {
      id: 'mobile_padrao',
      rotulo: 'Padrão Facebook Mobile (3 a 4 linhas no celular · 115 a 160 chars)',
      minChars: 115,
      maxChars: 160,
    },
  ];

  sortearPerfilFolegoLegenda(n = null, forcarId = null) {
    const perfis = FabricaService.PERFIS_FOLEGO_LEGENDA;
    if (forcarId) {
      const achou = perfis.find((p) => p.id === forcarId);
      if (achou) {
        this._ultimoPerfilLegendaId = achou.id;
        if (n) n.ultimoPerfilLegenda = achou.id;
        return achou;
      }
    }
    const ultimoGlobal = this._ultimoPerfilLegendaId || null;
    const ultimoNovela = n?.ultimoPerfilLegenda || null;
    let candidatos = perfis.filter((p) => p.id !== ultimoGlobal && p.id !== ultimoNovela);
    if (!candidatos.length) candidatos = perfis.filter((p) => p.id !== ultimoGlobal);
    if (!candidatos.length) candidatos = perfis;
    const escolhido = candidatos[crypto.randomInt(0, candidatos.length)];
    this._ultimoPerfilLegendaId = escolhido.id;
    if (n) n.ultimoPerfilLegenda = escolhido.id;
    return escolhido;
  }

  /**
   * Extrai o contexto real e completo da novela específica:
   * - Todas as falas em português (trechos entre aspas) do BLOCO 3 — PROMPTS DE VÍDEO
   * - Resumo enxuto das ações das cenas (do BLOCO 3 e/ou do roteiro_humano.md da pasta da novela, se existir)
   * Nunca gera legenda usando apenas título, ID da pasta ou texto truncado.
   */
  extrairResumoDialogosNovela(n) {
    const blocos = [`Título da novela: "${n?.nome || 'Novela'}"`];

    // 1) Localiza roteiro_humano.md (na novela em memória, na pasta da novela no Estúdio, na Fábrica ou em prontos_para_flow)
    let roteiroHumanoTxt = String(n?.roteiroHumano || '').trim();
    if (!roteiroHumanoTxt && this.store && n) {
      try {
        const pastaEstudio = this.store.pastaAbs(n);
        roteiroHumanoTxt = lerTexto(path.join(pastaEstudio, 'roteiro_humano.md')) || '';
      } catch {}
    }
    if (!roteiroHumanoTxt && n?.fabricaPasta) {
      roteiroHumanoTxt = lerTexto(path.join(n.fabricaPasta, 'roteiro_humano.md')) || '';
    }
    if (!roteiroHumanoTxt && n?.serieSlug && this.existe) {
      roteiroHumanoTxt =
        lerTexto(path.join(this.prontosDir, n.serieSlug, nomeParte(n.numeroParte || 1), 'roteiro_humano.md')) || '';
    }

    // Mapa opcional de Ação/Novidade por cena vindo do roteiro_humano.md
    const acoesRoteiroPorCena = new Map();
    if (roteiroHumanoTxt) {
      let cenaNum = null;
      for (const raw of roteiroHumanoTxt.split(/\r?\n/)) {
        const l = raw.trim();
        const mCena = l.match(/^#{1,4}\s*cena\s*0*(\d+)\b/i);
        if (mCena) {
          cenaNum = Number(mCena[1]);
          if (!acoesRoteiroPorCena.has(cenaNum)) acoesRoteiroPorCena.set(cenaNum, []);
          continue;
        }
        if (cenaNum !== null && /^(A[cç][aã]o|Novidade|Choque|Fisgada)\s*:/i.test(l)) {
          acoesRoteiroPorCena.get(cenaNum).push(l);
        }
      }
    }

    // 2) Extrai TODAS as falas em português (entre aspas) + resumo enxuto das ações de cada cena do BLOCO 3 — PROMPTS DE VÍDEO
    const itens =
      Array.isArray(n?.itens) && n.itens.length
        ? n.itens
        : parseRoteiro(n?.roteiro || '', { forcarElementos: !!n?.forcarElementos }).itens || [];
    const videos = itens.filter((i) => i.tipo === 'video');

    if (videos.length) {
      const linhasCena = videos.map((v, idx) => {
        const p = String(v.prompt || '').trim();
        const mNum = String(v.id || '').match(/(\d+)/);
        const numCena = mNum ? Number(mNum[1]) : idx + 1;
        const falas = [...p.matchAll(/[""“]([^""”]{2,400})[""”]/g)]
          .map((m) => `"${m[1].trim()}"`)
          .filter(Boolean);

        // Extrai resumo enxuto da ação visual do prompt do Bloco 3 (removendo instruções técnicas fixas do Veo)
        const acaoPromptLimpa = p
          .replace(/[""“][^""”]{2,400}[""”]/g, '')
          .replace(/^Exactly\s+\d+\s+seconds\s+vertical\s+9:16[^.]*\./i, '')
          .replace(/Fixed cameras and hard cuts only[^.]*\./gi, '')
          .replace(/Natural Brazilian Portuguese with accurate lip sync[^.]*\./gi, '')
          .replace(/Paced naturally across the full \d+ seconds[^.]*\./gi, '')
          .replace(/No music,\s*narration,\s*captions[^.]*\./gi, '')
          .replace(/Nobody looks into the lens\.?/gi, '')
          .replace(/\s+/g, ' ')
          .trim()
          .slice(0, 280);

        const acoesRot = (acoesRoteiroPorCena.get(numCena) || []).join(' | ');
        const resumoAcao = acoesRot || acaoPromptLimpa;
        const blocoFalas = falas.length ? `Falas em PT-BR: ${falas.join(' → ')}` : '(Cena visual / sem fala)';
        return `- ${v.id}: ${blocoFalas}${resumoAcao ? ` | Ação da cena: ${resumoAcao}` : ''}`;
      });
      blocos.push(`FALAS EM PORTUGUÊS E AÇÕES CENA A CENA (BLOCO 3 — PROMPTS DE VÍDEO):\n${linhasCena.join('\n')}`);
    } else if (n?.roteiro) {
      // Fallback: extrai diretamente todas as linhas de vídeo e falas entre aspas do texto bruto do roteiro
      const falasBrutas = [...String(n.roteiro).matchAll(/[""“]([^""”]{3,400})[""”]/g)].map((m) => `"${m[1].trim()}"`);
      if (falasBrutas.length) {
        blocos.push(`FALAS EM PORTUGUÊS EXTRAÍDAS DO ROTEIRO:\n${falasBrutas.join('\n')}`);
      }
      blocos.push(`ROTEIRO BRUTO:\n${String(n.roteiro).slice(0, 6000)}`);
    }

    // 3) Se existir roteiro_humano.md, anexa também o cabeçalho dramático e o roteiro humano completo
    if (roteiroHumanoTxt) {
      blocos.push(`ROTEIRO HUMANO COMPLETO (roteiro_humano.md):\n${roteiroHumanoTxt.slice(0, 7500)}`);
    }

    return blocos.join('\n\n');
  }

  sortearEmojisVariados(qtd = 2, contexto = '') {
    const ctx = String(contexto || '').toLowerCase();
    let pool = ['💔', '🥀', '😢', '🥹', '💭', '🙏', '🔥', '😤', '✨', '⚡', '👏', '😮'];
    if (/casamento|marido|esposa|div[oó]rcio|trai[cç]|ex\b|alian[cç]a/.test(ctx)) {
      pool = ['💔', '🥀', '🥹', '💭', '😢', '🙏', '🔥', '😤'];
    } else if (/m[aã]e|pai|filh[oa]|hospital|cirurgia|sacrif[ií]cio|rel[oó]gio|rem[eé]dio/.test(ctx)) {
      pool = ['🥹', '💔', '🙏', '😢', '🥀', '✨', '💭'];
    } else if (/humilh|desprez|roupa|apar[eê]ncia|pobre|patr[aã]o|gerente|restaurante|bolo/.test(ctx)) {
      pool = ['😤', '🔥', '👏', '💭', '🥀', '⚡', '🥹'];
    }
    const copia = [...pool];
    for (let i = copia.length - 1; i > 0; i--) {
      const j = crypto.randomInt(0, i + 1);
      [copia[i], copia[j]] = [copia[j], copia[i]];
    }
    return copia.slice(0, Math.max(1, Math.min(2, qtd)));
  }

  /**
   * Sorteia APENAS 2 ou 3 hashtags tiradas EXCLUSIVAMENTE da lista salva HASHTAGS_VALIDAS.
   * Nunca usa hashtags inventadas pela IA e nunca despeja a lista inteira.
   */
  selecionarHashtagsTematicas({ excluirIguaisA = null } = {}) {
    return sortearHashtags(excluirIguaisA);
  }

  /**
   * Pós-processamento garantido no backend para a legenda da novela/WhatsApp/Facebook Mobile:
   * - Remove qualquer '#hashtag' que tenha vindo do texto da IA
   * - Remove travessões/hífens soltos ('—', '–', ' - ') e frases robóticas da lista negra de IA
   * - Remove qualquer '?' e aberturas descritivas ("Nesse vídeo...", "O filho fez...")
   * - Garante corpo curto de Facebook Mobile: entre 95 e 160 caracteres (teto estrito 170 chars antes dos emojis)
   * - Encerra a frase com 1 a 2 emojis + '\n\n' + 2 ou 3 hashtags sorteadas EXCLUSIVAMENTE de HASHTAGS_VALIDAS
   */
  formatarLegendaWhatsapp(
    textoBruto,
    {
      hashtagsAtuais = null,
      contexto = '',
    } = {}
  ) {
    const limpo = String(textoBruto || '')
      .replace(/\r\n?/g, '\n')
      .replace(/===FILE:[^=]+===/gi, '')
      .replace(/===END_FILE===/gi, '')
      .replace(/^RESULTADO_JSON:.*$/gim, '')
      .replace(/```[a-z]*\n?/gi, '')
      .replace(/```/g, '')
      .trim();

    // 1) Filtra linhas do corpo removendo TODAS as #hashtags vindas da IA, cabeçalhos e rótulos
    const RE_LINHA_META = /^(legenda|op[cç][aã]o|sugest[aã]o|perfil|tamanho|corpo|hashtags?|frase)\s*[:—–-]/i;
    const partesValidas = limpo
      .split('\n')
      .map((l) =>
        l
          .replace(/^[-*•\d.)\s]+/, '')
          .replace(/#[a-zA-ZÀ-ÿ0-9_]+/g, '')
          .replace(/^["“”']+|[”"']+$/g, '')
          .trim()
      )
      .filter((l) => l.length >= 3 && !RE_LINHA_META.test(l));

    // Une tudo em um único parágrafo contínuo sem quebras de linha internas
    let paragrafoUnico = partesValidas.join(' ').replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();

    // 2) Lista Negra Anti-IA: remove travessões/hífens soltos, aberturas descritivas e clichês robóticos
    paragrafoUnico = paragrafoUnico
      .replace(/\s*[—–]\s*/g, ', ')
      .replace(/\s+-\s+/g, ', ')
      .replace(/^(nesse v[ií]deo|neste v[ií]deo|nessa hist[oó]ria|nesta hist[oó]ria|veja a hist[oó]ria de|conhe[cç]a a hist[oó]ria de|acompanhe a hist[oó]ria de|isso mostra que|uma li[cç][aã]o de vida[,:\s]*)[,\s:-]*/i, '')
      .replace(/\bn[aã]o [eé] sobre [^,.!]+,\s*[eé] sobre\s+/gi, 'O que mais machuca é ')
      .replace(/\b([eé] um n[ií]vel de|poucos entendem que|poucos entendem|no sil[êe]ncio|a verdadeira for[cç]a|li[cç][aã]o de vida|isso mostra que)\b[,\s]*/gi, '')
      .replace(/\b(concorda|o que voc[eê] faria|voc[eê] perdoaria|j[aá] passou por isso)\s*\?*/gi, '')
      .replace(/,\s*,+/g, ',')
      .replace(/\s+,/g, ',')
      .replace(/^[,\s:;.-]+/, '')
      .trim();

    // 3) Remove qualquer '?' convertendo para ponto final limpo
    paragrafoUnico = paragrafoUnico
      .replace(/\?+/g, '.')
      .replace(/\.{2,}/g, '.')
      .replace(/\s+\./g, '.')
      .replace(/\.\s*\./g, '.')
      .trim();

    // 4) Extrai emojis existentes no corpo e limpa o texto puro
    const emojisNoTexto = paragrafoUnico.match(/\p{Extended_Pictographic}/gu) || [];
    let corpoSemEmoji = paragrafoUnico
      .replace(/\p{Extended_Pictographic}/gu, '')
      .replace(/\uFE0F/g, '')
      .replace(/#[a-zA-ZÀ-ÿ0-9_]+/g, '')
      .replace(/\s*[—–]\s*/g, ', ')
      .replace(/\s+-\s+/g, ', ')
      .replace(/\s{2,}/g, ' ')
      .replace(/\s+([.,!])/g, '$1')
      .trim();

    if (corpoSemEmoji) {
      corpoSemEmoji = corpoSemEmoji[0].toUpperCase() + corpoSemEmoji.slice(1);
    }

    // Fallback natural brasileiro (entre 105 e 155 caracteres) caso o texto bruto venha vazio ou inválido
    const escolherFallbackNatural = () => {
      const ctx = String(contexto || '').toLowerCase();
      if (/filh[oa]|m[aã]e|pai|tempo|visita|idoso|velh/.test(ctx)) {
        return 'Dói no peito ver quem deu a vida pelos filhos ser tratado como peso, mas a gente só dá valor de verdade quando perde.';
      }
      if (/humilh|desprez|apar[eê]ncia|roupa|gar[cç]om|restaurante|patr[aã]o|pobre|rico/.test(ctx)) {
        return 'Quem muito pisa nos outros por causa de aparência esquece que o mundo dá voltas e a vida cobra onde mais dói.';
      }
      if (/casamento|marido|esposa|div[oó]rcio|trai[cç]|interesse/.test(ctx)) {
        return 'Às vezes a pessoa joga fora quem sempre esteve do lado na fase difícil só pra descobrir tarde demais o valor de quem era fiel.';
      }
      return 'Às vezes a gente faz tudo por quem ama e ainda leva desprezo em troca, mas o mundo dá voltas e ninguém foge do que planta.';
    };

    if (!corpoSemEmoji || corpoSemEmoji.length < 30) {
      corpoSemEmoji = escolherFallbackNatural();
    }

    // Garante pontuação final limpa antes dos emojis
    if (!/[.!]$/.test(corpoSemEmoji)) {
      corpoSemEmoji = corpoSemEmoji.replace(/[,;:-]+$/, '').trim() + '.';
    }

    // 5) Teto estrito de Facebook Mobile: máximo 170 caracteres antes dos emojis (meta 95 a 160 chars = 3 a 4 linhas no celular)
    if (corpoSemEmoji.length > 170) {
      const recorte = corpoSemEmoji.slice(0, 166);
      // Tenta cortar num ponto final ou vírgula natural entre 95 e 165 chars
      const ultPonto = Math.max(recorte.lastIndexOf('. '), recorte.lastIndexOf('! '));
      const ultVirgula = Math.max(recorte.lastIndexOf(', '), recorte.lastIndexOf('; '));
      if (ultPonto >= 92) {
        corpoSemEmoji = recorte.slice(0, ultPonto + 1).trim();
      } else if (ultVirgula >= 95) {
        corpoSemEmoji = recorte.slice(0, ultVirgula).replace(/[,;:-]+$/, '').trim() + '.';
      } else {
        const ultEspaco = recorte.lastIndexOf(' ');
        corpoSemEmoji = (ultEspaco > 90 ? recorte.slice(0, ultEspaco) : recorte).replace(/[,;:-]+$/, '').trim() + '.';
      }
    }

    // Se depois do corte ficou curto demais (< 85 chars) ou ainda tinha lixo, garante frase natural na faixa 95–160 chars
    if (corpoSemEmoji.length < 75) {
      corpoSemEmoji = escolherFallbackNatural();
    }

    // Garante zero '?', zero travessão e zero '\n' no corpo
    corpoSemEmoji = corpoSemEmoji
      .replace(/\?+/g, '.')
      .replace(/\s*[—–]\s*/g, ', ')
      .replace(/\s+-\s+/g, ', ')
      .replace(/[\r\n]+/g, ' ')
      .replace(/\s{2,}/g, ' ')
      .trim();

    // 6) Emojis (1 a 2) no final da frase
    const emojisUnicos = [...new Set(emojisNoTexto)];
    const emojisFinais =
      emojisUnicos.length >= 1
        ? emojisUnicos.slice(0, 2)
        : this.sortearEmojisVariados(crypto.randomInt(1, 3), `${contexto} ${corpoSemEmoji}`);

    // 7) Apenas 2 ou 3 hashtags sorteadas EXCLUSIVAMENTE da lista salva HASHTAGS_VALIDAS, separadas por \n\n
    const hashtagsFinais = sortearHashtags(hashtagsAtuais);

    return `${corpoSemEmoji} ${emojisFinais.join('')}\n\n${hashtagsFinais.join(' ')}`;
  }

  formatarLegendaLinhaUnica(textoBruto, opcoes = {}) {
    return this.formatarLegendaWhatsapp(textoBruto, opcoes);
  }

  normalizarLinhasLegenda(textoBruto, n = null) {
    const formatada = this.formatarLegendaWhatsapp(textoBruto, {
      contexto: n ? this.extrairResumoDialogosNovela(n) : '',
    });
    return [formatada];
  }

  gravarLegendaEmDiscoENovela(n, legendaCompleta, { hashtagsAtuais = null } = {}) {
    // Passa pelo pós-processador garantindo 95-160 chars (teto 170) + 1-2 emojis + \n\n + 2 ou 3 #hashtags de HASHTAGS_VALIDAS
    const legendaNormalizada = this.formatarLegendaWhatsapp(legendaCompleta, {
      hashtagsAtuais,
      contexto: n ? this.extrairResumoDialogosNovela(n) : '',
    });
    n.legendaFacebook = legendaNormalizada;
    n.legendaEnviadaWhatsappEm = null;
    this.store.salvar(n);
    this.emitirNovela(n);
    try {
      const pastaNovela = this.store.pastaAbs(n);
      fs.mkdirSync(pastaNovela, { recursive: true });
      fs.writeFileSync(path.join(pastaNovela, 'legenda_facebook.txt'), n.legendaFacebook + '\n', 'utf8');
    } catch {}
    if (n.fabricaPasta && fs.existsSync(n.fabricaPasta)) {
      try {
        fs.writeFileSync(path.join(n.fabricaPasta, 'legenda_facebook.txt'), n.legendaFacebook + '\n', 'utf8');
        const mp = path.join(n.fabricaPasta, 'metadata_flow.json');
        const meta = lerJson(mp, null);
        if (meta) {
          meta.legendaFacebook = n.legendaFacebook;
          meta.legendaEnviadaWhatsappEm = null;
          escreverJsonAtomico(mp, meta);
        }
      } catch {}
    }
    return n.legendaFacebook;
  }

  async gerarLegendaClaudeParaNovela(n, { perfilId = null } = {}) {
    if (!n) throw new Error('Novela não encontrada.');
    const contexto = this.extrairResumoDialogosNovela(n);
    const perfil = this.sortearPerfilFolegoLegenda(n, perfilId);
    const hashtagsAnteriores = n.legendaFacebook ? n.legendaFacebook.match(/#[a-zA-ZÀ-ÿ0-9_]+/g) || [] : [];

    const prompt = [
      'TAREFA: Escreva UMA ÚNICA FRASE curta de legenda para Facebook Mobile sobre o sentimento real da história abaixo (1 turno stateless, sem tools).',
      '',
      '1. COMO DEVE SOAR (PORTUGUÊS REAL DE BRASILEIRO NO DIA A DIA):',
      '   - Leia as falas do BLOCO 3 / roteiro abaixo para entender o assunto verdadeiro da história (ingratidão, desprezo, interesse, traição, humildade, abandono).',
      '   - Escreva 100% como uma pessoa comum falando na vida real, usando palavras simples que qualquer brasileiro fala conversando (ex.: "a gente", "pra", "às vezes", "só dá valor quando perde", "quem muito pisa", "dói no peito", "o mundo dá voltas", "tarde demais").',
      '',
      '2. TAMANHO CURTO DE FACEBOOK MOBILE (3 LINHAS NO CELULAR, NO MÁXIMO 4):',
      '   - A frase deve ter OBRIGATORIAMENTE entre 95 e 155 caracteres (TETO MÁXIMO ESTRITO: 165 caracteres antes dos emojis).',
      '   - Direto ao ponto, em uma única frase corrida, para aparecer inteira em 3 linhas no celular sem cortar no "Ver mais" do Facebook.',
      '',
      '3. LISTA NEGRA PROIBIDA (ZERO CARA DE IA):',
      '   - PROIBIDO escrever hashtags (NÃO escreva nenhuma #hashtag; o sistema adiciona depois).',
      '   - PROIBIDO usar travessão ou hífen solto ("—", "–" ou " - "). Use apenas vírgula normal.',
      '   - PROIBIDO usar frase de efeito robótica/poética de IA: NUNCA escreva "Não é sobre X, é sobre Y", "é um nível de", "poucos entendem", "no silêncio", "a verdadeira força", "lição de vida", "isso mostra que".',
      '   - PROIBIDO narrar ou descrever a cena (NUNCA escreva "Nesse vídeo", "O filho fez", "Ele fingiu ser garçom", nem cite nomes dos personagens).',
      '   - PROIBIDO fazer perguntas (ZERO "?").',
      '',
      '4. FORMATO EXATO DA SUA RESPOSTA:',
      '   - Devolva APENAS a frase corrida simples e humana (95 a 155 caracteres) com 1 ou 2 emojis no final. Nada mais, sem aspas e sem hashtags.',
      '   - Exemplo de tom e tamanho ideal (124 chars):',
      '     Dói no peito ver quem sempre ajudou ser desprezado por aparência, mas o mundo dá voltas e a gente só dá valor quando perde. 💔🙏',
      '',
      '=== FALAS E CONTEXTO DA HISTÓRIA (BLOCO 3 / ROTEIRO) ===',
      contexto,
    ].join('\n');

    let textoBruto = '';
    const cli = detectarClaudeCli();
    if (cli.disponivel) {
      try {
        this.log(`✨ Gerando legenda curta de Facebook Mobile via Claude para "${n.nome}"...`, 'info');
        const res = await executarClaude({
          prompt,
          comando: cli.comando,
          extraArgs: ['--max-turns', '1', '--tools', ''],
          cwd: obterPastaClaudeVazia(),
          timeoutMs: 90 * 1000,
          modelo: 'sonnet',
          meta: {
            tipo: 'legenda_whatsapp',
            novelaSlug: n.pasta || n.id,
            novelaTitulo: n.nome,
          },
        });
        const saidaClaude = typeof res === 'string' ? res : (res?.saida || '');
        if (saidaClaude && saidaClaude.trim()) {
          textoBruto = saidaClaude.trim();
        }
      } catch (e) {
        this.log(`Aviso ao consultar Claude para legenda (${e.message}) — aplicando frase natural conectada ao contexto local.`, 'aviso');
      }
    }

    return this.gravarLegendaEmDiscoENovela(n, textoBruto, {
      hashtagsAtuais: hashtagsAnteriores,
    });
  }

  salvarLegendaManualNovela(n, texto) {
    const bruto = String(texto || '').trim();
    if (!bruto) throw new Error('Digite o texto da legenda.');
    return this.gravarLegendaEmDiscoENovela(n, bruto);
  }

  sortearLegendaNovela(n) {
    const atual = String(n.legendaFacebook || '').trim();
    const hashtagsAtuais = atual ? atual.match(/#[a-zA-ZÀ-ÿ0-9_]+/g) || null : null;
    const semTags = atual.replace(/#[a-zA-ZÀ-ÿ0-9_]+/g, '').trim();
    return this.gravarLegendaEmDiscoENovela(n, semTags, {
      hashtagsAtuais,
    });
  }

  // ---------- jobs do Claude ----------
  novoJob(tipo, titulo, extra = {}) {
    const job = { id: Date.now().toString(36) + crypto.randomBytes(2).toString('hex'), tipo, titulo, estado: 'rodando', iniciadoEm: new Date().toISOString(), fimEm: null, saida: '', erro: null, resultado: null, validacao: null, importacao: null, etapa: 'iniciando', ...extra };
    this.jobs.set(job.id, job);
    this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
    return job;
  }
  jobPublico(j) { const { _proc, ...resto } = j; return { ...resto, saida: j.saida.slice(-60000) }; }
  listarJobs() { return [...this.jobs.values()].sort((a, b) => b.iniciadoEm.localeCompare(a.iniciadoEm)).slice(0, 20).map((j) => this.jobPublico(j)); }
  obterJob(id) { const j = this.jobs.get(id); return j ? this.jobPublico(j) : null; }
  cancelarJob(id) {
    const j = this.jobs.get(id); if (!j) throw new Error('Tarefa não encontrada.');
    const estavaRodando = j.estado === 'rodando';
    matarArvore(j._proc?.child);
    if (estavaRodando) {
      j.estado = 'cancelado'; j.fimEm = new Date().toISOString(); j.etapa = 'cancelado';
      try { j.restaurar?.('cancelado pelo usuário'); } catch {}
      this.broadcast({ type: 'fabrica_job', job: this.jobPublico(j) });
    }
    return this.jobPublico(j);
  }

  /** Tarefa do Claude ainda rodando para esta parte (regerar / gerar parte / prompts). Ignora o proprio job ou jobs cujo lock de escrita ja foi liberado. */
  jobAtivoDaParte(slug, parte, { ignorarJobId = null } = {}) {
    return [...this.jobs.values()].find((j) => j.estado === 'rodando' && !j.lockLiberado && j.id !== ignorarJobId && j.slugAlvo === slug && Number(j.parteAlvo) === Number(parte)) || null;
  }
  /** Ultima tarefa que FALHOU/foi cancelada para esta parte (para o alerta vermelho no card). */
  ultimaFalhaDaParte(slug, parte) {
    const l = [...this.jobs.values()].filter((j) => j.slugAlvo === slug && Number(j.parteAlvo) === Number(parte)).sort((a, b) => b.iniciadoEm.localeCompare(a.iniciadoEm))[0];
    return l && (l.estado === 'erro' || l.estado === 'cancelado') ? { jobId: l.id, estado: l.estado, erro: l.erro || 'cancelado', restaurado: !!l.restaurado, em: l.fimEm } : null;
  }

  /** Guia compacto (~1.100 tokens) embutido direto no prompt para chamada stateless de 1 turno (<3% da cota de 5h). */
  guiaCompactoInline({ modoGeracaoVideo = 'elementos', tamanhoCena = 15, duracaoMin = 3, numCenas = null } = {}) {
    const modo = modoGeracaoVideo === 'frame_inicial' ? 'frame_inicial' : 'elementos';
    const seg = Number(tamanhoCena) === 10 ? 10 : 15;
    const totalCenas = Number(numCenas) || calcularNumeroCenas(duracaoMin, seg);
    const penult = String(Math.max(1, totalCenas - 1)).padStart(2, '0');
    const ult = String(totalCenas).padStart(2, '0');
    const reguaAtiva = seg === 10
      ? `- CENA DE 10s (ATIVA — ${totalCenas} cenas): 1 a 3 falas (NUNCA > 3). Total da cena: **14 a 25 palavras** (META EXPLÍCITA: **18 a 21 palavras** em cada cena para preencher os 10s sem vazio de áudio) · **máximo 20 palavras** quando dividida em 3 falas (mínimo cai 15% se [chorando/sussurrando/voz embargada]). OBRIGATÓRIO: pelo menos **85% das cenas FALADAS de 10s DEVEM ter 2 falas (troca A -> B com corte)** (~9–10 palavras cada fala). Máx. 14 palavras por fala e máx. 11 palavras por frase. Nos prompts de vídeo de 10s inclua atuação cadenciada ao longo dos 10s completos: \`paced naturally across the full 10 seconds, with a brief natural beat before the clean cut to the second speaker\`.`
      : `- CENA DE 15s (ATIVA — ${totalCenas} cenas): 1 a 3 falas (NUNCA > 3). Total da cena: **23 a 30 palavras** (com 1 ou 2 falas) · **máximo 27 palavras** quando dividida em 3 falas (mínimo cai 15% se [chorando/sussurrando/voz embargada]). Máx. 16 palavras por fala e máx. 12 palavras por frase. Prompts de vídeo começam com \`Exactly 15 seconds vertical 9:16...\`.`;
    return [
      'MODO STATELESS DE 1 ÚNICO TURNO (ZERO TOOLS): você está rodando sem ferramentas de disco. Devolva os arquivos pedidos DIRETAMENTE no stdout usando os blocos delimitados `===FILE:<nome>===` ... `===END_FILE===`.',
      'PROIBIDO usar Read/Glob/Grep para abrir `.claude/skills/` ou `CLAUDE.md` — tudo já está neste prompt.',
      '',
      '=== GUIA COMPACTO OFICIAL DA FÁBRICA ===',
      '1) RÉGUA DE PALAVRAS NO VEO (ERRO BLOQUEANTE):',
      reguaAtiva,
      '- Referência das duas réguas: 10s = **14 a 25 palavras** (meta **18 a 21**, máx. **20** em 3 falas, mín. **85% das cenas com 2 falas A -> B**) · 15s = **23 a 30 palavras** (máx. **27** em 3 falas).',
      '- NUNCA termine fala truncada ("... e", "... de"). NUNCA narre ação física na fala (proibido "vou pegar/abrir", "estou assinando", imperativos "assina/pega/entrega/rasga/abre/guarda", "aqui está"): ação física vai em `Ação:` e no prompt visual em inglês; a fala traz acusação, decisão, subtexto ou emoção.',
      `  Configuração ativa: ${totalCenas} cenas de ${seg}s · modo de vídeo: ${modo}.`,
      '- CENAS MUDAS (ironia dramática visual): até **2 por história** (nunca a Cena 1, nunca a última cena e sem colar Cena 2 e Cena 3 mudas seguidas): sem nenhuma fala no roteiro, com `Novidade:` e `Ação:` (≥20 chars) descrevendo gesto e expressão dentro do enredo real do resumo. No prompt de vídeo (BLOCO 3) escreva SEMPRE: `No spoken dialogue in this scene; characters keep their lips closed throughout the entire clip, pure visual storytelling.` A regra de 85% de cenas com 2 falas conta só as cenas FALADAS.',
      '- DIÁLOGO VIVO DE NOVELA (AÇÃO → REAÇÃO): quem escuta uma acusação, provocação ou revelação NUNCA fica mudo ou apático sem motivo — reage na hora com fala viva, subtexto ou reação física intensa na `Ação:`.',
      '',
      '2) AS 5 LEIS DA DONA MARIA + VACINA ANTI-ROBÔ NOS DIÁLOGOS:',
      '- Lei 1 (Contexto Cenas 1–2): cabeçalho com `Relação exata:` (≥20 chars) e `Conflito concreto:` (≥20 chars). Nas Cenas 1–2 deixe claro o vínculo e o conflito concreto (divórcio, separação, camiseta, presente, dívida, dinheiro, casa, mentira, traição...) de forma HUMANA e ORGÂNICA.',
      '- VACINA ANTI-ROBÔ (OBRIGATÓRIO NOS DIÁLOGOS):',
      '  * PROIBIDO usar vocativos artificiais de cargo ou parentesco na fala para explicar quem é quem (ex.: NUNCA escrever "Meu marido,", "Minha esposa,", "Meu esposo,", "Minha mulher,", "Camila, irmã do Lucas,", "João, meu patrão,").',
      '  * Entre casal, use formas humanas ("Amor,", "Vida,", ou o próprio nome como "Lucas, me arruma cinquenta reais?"), deixando claro que são casados pelo contexto natural da conversa.',
      '  * Entre parentes/amigos, revele a relação de forma orgânica na frase (ex.: em vez de "Camila, irmã do Lucas. Como ele tá?", use "Camila, pelo amor de Deus, me dá notícia do seu irmão! Como o Lucas tá?").',
      '- Lei 2 (Escada): 1 única informação nova por cena em `Novidade: ...` e `Transição: ...` da Cena 2 em diante.',
      '- Lei 3 (Português de rua): frases curtas do cotidiano; ZERO metáfora/parábola/ditado/rebuscado (proibido: destino, cobra o preço, máscara, sombras do passado, ferida na alma, a vida cobra, o tempo cura, universo, quem semeia... colhe, mesóclise, todavia/outrora).',
      `- Lei 4 (Última cena — Cena ${ult}): se final ABERTO (\`Parte N de M\` com N < M), \`Armadilha: ...\` (≥20 chars) na penúltima cena (Cena ${penult}) + \`Choque: <revelação|flagrante|chegada|prova> — <fato concreto dito na fala>\` (≥40 chars) na última cena (Cena ${ult}) + \`Final-fisgada:\` iniciando por revelação/flagrante/chegada/prova. Se final FECHADO (\`Parte N de N\` ou parte única), resolva tudo com justiça completa na última cena (Cena ${ult}) + \`Fisgada: ...\` emocional (≥20 chars), sem \`Choque:\`.`,
      '- Lei 5 (Dona Maria): cabeçalho `Teste da Dona Maria: APROVADO — <em 1 frase, o que uma senhora de 65 anos entende só ouvindo os diálogos do início ao fim>` (≥40 chars).',
      '',
      '3) FORMATO EXATO DOS BLOCOS DE SAÍDA:',
      'a) `===FILE:roteiro_humano.md===`',
      '   # <Título> — Parte N de M   (ou sem "Parte" em história única fechada)',
      '   Universo: <ex.: urbano_simples | classe_media | interior_humilde | classe_alta>',
      `   Cenas: ${totalCenas} x ${seg}s`,
      '   Tipo-final: aberto|fechado',
      '   Esqueleto: <A-G> — <justificativa com ≥20 letras>',
      '   Relação exata: <quem são os dois das Cenas 1–2 e o vínculo>',
      '   Conflito concreto: <o que está em jogo agora>',
      '   Ponte (Cenas 1–3):',
      '   - Quem é quem: <≥15 chars>',
      '   - Por que agora: <≥15 chars>',
      '   - Regra/acordo em jogo: <≥15 chars>',
      '   Final-fisgada: <tipo> — <descrição ≥20 chars>',
      '   Teste da Dona Maria: APROVADO — <1 frase ≥40 chars>',
      '   Personagens:   (OBRIGATÓRIO: toda linha DEVE ter exatamente 3 barras `|` e o prefixo `Voz:`, sem `**`: `- NOME | papel | ref_codigo | Voz: descrição`)',
      '   - NOME | protagonista | ref_nome | Voz: <vocabulário e ritmo ≥15 chars>',
      `   ## CENA 01 (${seg}s) — Gancho`,
      '   Onde: ref_cenario_xxx (INTERIOR|EXTERIOR)',
      '   Em quadro: NOME, NOME   (máx. 3; todo falante da cena DEVE estar em Em quadro)',
      '   Transição: <da Cena 02 em diante: causa e efeito>',
      '   Novidade: <a única informação nova desta cena>',
      '   Ação: <o que se vê fisicamente>',
      '   NOME [emoção, tom]: "Fala em português." (N palavras)',
      `   ... (gere todas as ${totalCenas} cenas: CENA 01 até CENA ${ult})`,
      `   Fisgada: <obrigatória na última cena (Cena ${ult}), ≥20 chars>`,
      '   ===END_FILE===',
      '',
      'b) `===FILE:continuidade_cenas.md===` (batendo 100% com `Onde:` e `Em quadro:` do roteiro):',
      '   | Cena | Onde fisicamente | Quem está em quadro | Transição |',
      '   |---|---|---|---|',
      '   | 01 | ref_cenario_xxx (INTERIOR) | NOME, NOME | abertura no pico |',
      '   ===END_FILE===',
      '',
      'c) `===FILE:prompts_flow.txt===` (3 blocos, SEM linhas começando com `=`):',
      '   BLOCO 1 — REFERÊNCIAS',
      '   {ref_nome} -> (i) vertical 9:16, individual close-up from upper chest up on a uniform plain white background, 85mm lens, neutral expression, large centered face, sharp eyes, natural skin pores, wearing exactly <roupa fixa>. No other people, hand-held objects or text.',
      '   {ref_cenario_xxx} -> (i) vertical 9:16, empty <ambiente interior ou exterior> with no people, clear balanced natural lighting, realism, no signs or text.',
      `   BLOCO 2 — IMAGENS-BASE   (1-para-1 com vídeos: ${totalCenas} imagens para ${totalCenas} vídeos; máx. 3 anexos \`[...]\`; ZERO nomes próprios!)`,
      '   {imagem_01} -> (i) [ref_cenario_xxx] [ref_a] [ref_b] vertical 9:16, <ambiente>, <idade/tipo + roupa on the left>, <idade/tipo + roupa on the right>, 85mm vertical framing, large sharp faces, nobody looking at the lens.   (se 3 personagens em quadro, encadeie `[imagem_JJ] [ref_terceiro]` do mesmo cenário)',
      `   BLOCO 3 — PROMPTS DE VÍDEO   (${modo === 'frame_inicial' ? '1 anexo `[imagem_NN]`' : 'modo ELEMENTOS: 2 a 3 anexos `[imagem_NN] [ref_a] [ref_b]` pertencentes à imagem_NN'})`,
      `   {Cena 01} -> (v) [imagem_01]${modo === 'frame_inicial' ? '' : ' [ref_a] [ref_b]'} Exactly ${seg} seconds vertical 9:16, cinematic contemporary drama, natural dramatic realism. Setting: <interior/exterior + ambiente>. Characters: <idade/tipo + wearing roupa + on the left/right/center>. Fixed cameras and hard cuts only; no camera movement, zoom, slow motion or fades. Natural Brazilian Portuguese with accurate lip sync, one speaker at a time; listeners keep their lips still.${seg === 10 ? ' Paced naturally across the full 10 seconds, with a brief natural beat before the clean cut to the second speaker.' : ''} Opening shot: ... The <young/older/middle-aged man/woman> wearing the <roupa> standing on the <left/right/center> of the frame speaks in Portuguese with accurate lip sync, while <ouvinte> listens silently with lips closed: "<FALA 100% IDÊNTICA AO ROTEIRO>". Hard cut to close-up... No music, narration, captions, added dialogue, readable text, logos or watermarks. Nobody looks into the lens.`,
      '   REGRA CRÍTICA BLOCO 3: NUNCA escreva nome próprio fora das aspas; nos ~200 chars antes de cada `speaks` inclua SEMPRE idade/tipo + peça de roupa + posição (left/right/center) + `speaks`.',
      '   ===END_FILE===',
      '',
      'd) `===FILE:metadata_flow.json===`: JSON narrativo (`titulo, slug, serie, parte, totalPartes, tipoFinal, universoSocial, esqueleto, duracaoTotalMinutos, tamanhoCenaSegundos, numeroCenas, modoGeracaoVideo, totalImagens, totalVideos, referenciasNovas, referenciasHerdadasDaParte1`) — SEM qualidade/resolução/modelos do Flow.',
      '   ===END_FILE===',
      'e) `===FILE:legenda_linhas.txt===`: 1 frase corrida simples e humana de Facebook Mobile (entre 95 e 155 caracteres antes dos emojis, 3 linhas no celular), em português real do dia a dia ("a gente", "pra", "às vezes", "só dá valor quando perde", "o mundo dá voltas") ligada ao sentimento da história, com 1 a 2 emojis no final (PROIBIDO hashtags, PROIBIDO travessão "—", PROIBIDO clichê robótico "Não é sobre...", PROIBIDO narrar a cena e PROIBIDO perguntas "?").',
      '   ===END_FILE===',
    ].join('\n');
  }

  /** Extrai apenas dialogos limpos da Parte 1 (e parte anterior) + Bloco 1 de referencias para evitar que o Claude varra pastas antigas. */
  montarContextoParte1Enxuto(slug, parte = 2, { reaproveitarRefs = true, bl1Inline = '' } = {}) {
    const blocos = [
      'PROIBIDO varrer pastas antigas, `parte_01/`, `series/` ou `_versoes/` com Read/Glob/Grep — todo o contexto necessário da Parte anterior e o BLOCO 1 de referências já estão colados abaixo.',
    ];
    const biblia = lerJson(path.join(this.seriesDir, slug, 'biblia_serie.json'), null);
    if (biblia?.premissa) {
      const pInfo = (biblia.partes || []).find((x) => Number(x.parte) === Number(parte));
      blocos.push(`RESUMO DA SÉRIE "${biblia.titulo || slug}" (universo: ${biblia.universoSocial || 'interior_humilde'}): ${biblia.premissa}${pInfo?.arco ? `\nArco previsto da Parte ${parte}: ${pInfo.arco}` : ''}`);
    }
    if (parte > 1) {
      const partAnt = parte - 1;
      const rotAnt = lerTexto(path.join(this.prontosDir, slug, nomeParte(partAnt), 'roteiro_humano.md'))
        || lerTexto(path.join(this.prontosDir, slug, 'parte_01', 'roteiro_humano.md')) || '';
      if (rotAnt) {
        const d = extrairDialogosRoteiro(rotAnt);
        const linhasDiag = d.cenas.map((c) => `CENA ${String(c.cena).padStart(2, '0')}: ` + c.falas.map((f) => `${f.quem}: "${f.texto}"`).join(' | ')).join('\n');
        if (linhasDiag) blocos.push(`DIÁLOGOS LIMPOS DA PARTE ${partAnt} (para continuidade direta):\n${linhasDiag}`);
      }
    }
    if (reaproveitarRefs) {
      let bl1 = String(bl1Inline || '').trim();
      if (!bl1) {
        const prm1 = lerTexto(path.join(this.prontosDir, slug, 'parte_01', 'prompts_flow.txt')) || '';
        const m = prm1.match(/BLOCO\s*1[^\n]*\n([\s\S]*?)(?=\n\s*BLOCO\s*2)/i);
        bl1 = (m ? m[1] : '').trim();
      }
      if (!bl1) {
        const cat = lerJson(path.join(this.seriesDir, slug, 'catalogo_refs.json'), {});
        const linhasCat = [
          ...Object.entries(cat.personagens || {}).map(([k, v]) => `{${k}} -> ${v}`),
          ...Object.entries(cat.cenarios || {}).map(([k, v]) => `{${k}} -> ${v}`),
        ];
        bl1 = linhasCat.join('\n');
      }
      if (bl1) {
        blocos.push(`BLOCO 1 DE REFERÊNCIAS FIXAS DA PARTE 1 (mantenha EXATAMENTE os mesmos IDs {ref_xxx}):\n${bl1}`);
      }
    }
    return blocos.join('\n\n');
  }

  /** Cabecalho comum: guia compacto completo + chamada stateless de 1 turno sem tools. */
  cabecalho({ incluirGuia = true, incluirResultadoJson = true, config = null } = {}) {
    const cfg = config || (this.existe ? this.lerConfigFabrica() : { modoGeracaoVideo: 'elementos', tamanhoCenaSegundos: 15, duracaoTotalMinutos: 3 });
    const seg = Number(cfg.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const dur = Number(cfg.duracaoTotalMinutos) || 3;
    const numCenas = calcularNumeroCenas(dur, seg);
    return [
      incluirResultadoJson
        ? 'MODO BACKEND STATELESS (1 único turno, sem tools): NÃO mostre menu inicial e NÃO faça perguntas ao usuário. Responda SOMENTE com os blocos `===FILE:<nome>=== ... ===END_FILE===` solicitados e a linha final `RESULTADO_JSON:`.'
        : 'MODO BACKEND STATELESS (1 único turno, sem tools): NÃO mostre menu inicial, NÃO faça perguntas ao usuário e NÃO escreva `RESULTADO_JSON:`. Responda direto com o texto da semente em português.',
      incluirGuia ? this.guiaCompactoInline({ modoGeracaoVideo: cfg.modoGeracaoVideo, tamanhoCena: seg, duracaoMin: dur, numCenas }) : 'PROIBIDO usar Read/Glob/Grep para abrir `.claude/skills/` ou `CLAUDE.md`.',
      incluirResultadoJson ? 'Ao terminar, escreva como ÚLTIMA linha exatamente: RESULTADO_JSON: {"slug":"<slug>","parte":<numero>}  (quando aplicável).' : '',
    ].filter(Boolean).join('\n\n');
  }

  /** Chamada stateless de 1 unico turno de texto puro: `--max-turns 1 --tools ""` (custo <3% da cota de 5h). */
  montarExtraArgsClaude() {
    return ['--max-turns', '1', '--tools', ''];
  }

  async rodarClaude(job, prompt, { timeoutMs = null, tipo = null, modelo = null, etapaRotulo = null } = {}) {
    const modeloUsado = normalizarModeloClaude(modelo || job.modeloUnico);
    const cli = detectarClaudeCli();
    if (!cli.disponivel) throw new Error('Claude Code CLI não encontrado neste PC.');
    const extra = this.montarExtraArgsClaude();
    const cwdVazio = obterPastaClaudeVazia();
    const limiteMs = (Number.isFinite(Number(timeoutMs)) && Number(timeoutMs) > 0)
      ? Math.min(Number(timeoutMs), TIMEOUT_MAX_CLAUDE_SEG * 1000)
      : this.obterTimeoutClaudeMs(job?.configUsada, TIMEOUT_PADRAO_CLAUDE_SEG);
    const rotuloAtivo = etapaRotulo || job?.titulo || `Claude (${ROTULO_MODELO_CLAUDE[modeloUsado]} · 1 turno sem tools)`;
    job.etapaAtualRotulo = rotuloAtivo;
    job._proc = { cwd: cwdVazio, extraArgs: extra };
    const t0 = Date.now();
    const batimento = setInterval(() => {
      if (job.estado !== 'rodando') return;
      const s = Math.round((Date.now() - t0) / 1000);
      job.etapa = `${rotuloAtivo} — ${Math.floor(s / 60)}min ${String(s % 60).padStart(2, '0')}s (limite ${Math.round(limiteMs / 1000)}s)`;
      this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
    }, 5000);
    try {
      return await executarClaude({
        prompt,
        comando: cli.comando,
        extraArgs: extra,
        cwd: cwdVazio,
        timeoutMs: limiteMs,
        processoRef: job._proc,
        modelo: modeloUsado,
        meta: {
          tipo: tipo || job.tipo || 'fabrica',
          novelaSlug: job.slugAlvo || job.resultado?.slug || null,
          novelaTitulo: job.titulo || null,
        },
        onData: (t) => { job.saida += t; this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) }); },
      });
    } catch (err) {
      const decorridoSeg = Math.max(1, Math.round((Date.now() - t0) / 1000));
      job.tempoDecorridoErroSeg = decorridoSeg;
      job.etapaFalha = rotuloAtivo;
      const msgBase = String(err?.message || err || 'erro desconhecido');
      if (!msgBase.includes('Falha em "')) {
        throw new Error(`Falha em "${rotuloAtivo}" após ${decorridoSeg}s: ${msgBase}`);
      }
      throw err;
    } finally { clearInterval(batimento); }
  }

  extrairResultado(saida) {
    const m = [...String(saida).matchAll(/RESULTADO_JSON:\s*(\{[^\n]*\})/g)].pop();
    if (!m) return null;
    try { return JSON.parse(m[1]); } catch { return null; }
  }

  /** Infere { slug, parte } a partir de RESULTADO_JSON, metadata_flow.json, job.slugAlvo ou # Titulo do roteiro. */
  inferirSlugEParte(saida, arquivos = {}, fallback = {}) {
    const res = this.extrairResultado(saida);
    let slug = res?.slug || fallback.slug || null;
    let parte = Number(res?.parte || fallback.parte) || null;
    if (arquivos['metadata_flow.json']) {
      try {
        const meta = JSON.parse(arquivos['metadata_flow.json']);
        if (!slug && meta.slug) slug = String(meta.slug).trim();
        if (!parte && meta.parte) parte = Number(meta.parte);
      } catch {}
    }
    if (arquivos['roteiro_humano.md']) {
      const titulo = (arquivos['roteiro_humano.md'].split(/\r?\n/).find((l) => /^#\s+\S/.test(l.trim())) || '').trim();
      if (!slug && titulo) slug = slugDeTitulo(titulo);
      if (!parte) {
        const mp = titulo.match(/Parte\s*(\d+)\s*de\s*(\d+)/i);
        parte = mp ? Number(mp[1]) : 1;
      }
    }
    slug = slug ? slugDeTitulo(slug) : null;
    return { slug, parte: parte || 1 };
  }

  /** Gera/atualiza legenda_facebook.txt localmente usando o pós-processador de Facebook Mobile (custo ZERO de Claude). */
  gerarLegendaLocal(pastaParte, textoCandidato = '', tituloFallback = 'Esta história') {
    const rotTxt = lerTexto(path.join(pastaParte, 'roteiro_humano.md')) || '';
    const prmTxt = lerTexto(path.join(pastaParte, 'prompts_flow.txt')) || '';
    const legFormatada = this.formatarLegendaWhatsapp(textoCandidato, {
      contexto: `${tituloFallback}\n${rotTxt}\n${prmTxt}`,
    });
    const arqLeg = path.join(pastaParte, 'legenda_facebook.txt');
    fs.writeFileSync(arqLeg, legFormatada + '\n', 'utf8');
    return lerTexto(arqLeg) || '';
  }

  /** Sincroniza series/<slug>/ (biblia_serie.json, catalogo_refs.json e resumos/parte_NN.md) localmente em Node a partir do roteiro/prompts. */
  sincronizarSerieLocal({ slug, parte, roteiroTxt = '', promptsTxt = '', tipoFinal = 'fechado', cfg = {} }) {
    if (!slug || !roteiroTxt) return;
    const ver = verificarTipoFinalRoteiro(roteiroTxt, null);
    const ehUnicaFechada = parte === 1 && tipoFinal === 'fechado' && (!ver || ver.total <= 1);
    const ehSerie = !ehUnicaFechada && (cfg.formatoHistoria === 'serie' || tipoFinal === 'aberto' || parte > 1 || ver.total > 1);
    if (!ehSerie) return;
    const pastaSerie = path.join(this.seriesDir, slug);
    const pastaResumos = path.join(pastaSerie, 'resumos');
    fs.mkdirSync(pastaResumos, { recursive: true });
    const tituloBase = ((roteiroTxt.split(/\r?\n/).find((l) => /^#\s+\S/.test(l.trim())) || `# ${slug}`).replace(/^#\s+/, '').replace(/\s*[—–-]+\s*Parte\s*\d+.*$/i, '').trim()) || slug;
    const totalPartes = tipoFinal === 'fechado' ? parte : Math.max(ver.total || 2, parte + 1, Number(cfg.numeroPartesPadrao) || 2);
    const bibliaP = path.join(pastaSerie, 'biblia_serie.json');
    const biblia = lerJson(bibliaP, { titulo: tituloBase, slug, totalPartes, partes: [] });
    biblia.titulo = biblia.titulo || tituloBase;
    biblia.slug = slug;
    biblia.totalPartes = totalPartes;
    const relM = roteiroTxt.match(/^Relação exata:\s*(.+)$/im);
    const confM = roteiroTxt.match(/^Conflito concreto:\s*(.+)$/im);
    if (!biblia.premissa && (relM || confM)) biblia.premissa = [relM?.[1], confM?.[1]].filter(Boolean).join(' — ');
    if (!Array.isArray(biblia.partes)) biblia.partes = [];
    for (let p = 1; p <= totalPartes; p++) {
      let item = biblia.partes.find((x) => Number(x.parte) === p);
      if (!item) { item = { parte: p, status: p === parte ? 'pronta' : 'apenas_resumo', arco: '' }; biblia.partes.push(item); }
      if (p === parte) { item.status = 'pronta'; item.tipoFinal = tipoFinal; }
    }
    escreverJsonAtomico(bibliaP, biblia);

    // Resumo da parte
    const d = extrairDialogosRoteiro(roteiroTxt);
    const resumoLinhas = [
      `# Resumo — ${tituloBase} — Parte ${parte} de ${totalPartes}`,
      ...d.cenas.map((c) => `${c.cena}. **${c.etapa || `Cena ${c.cena}`}:** ` + c.falas.map((f) => `${f.quem}: "${f.texto}"`).join(' ')),
    ];
    fs.writeFileSync(path.join(pastaResumos, `${nomeParte(parte)}.md`), resumoLinhas.join('\n') + '\n', 'utf8');

    // Catalogo de refs
    const catP = path.join(pastaSerie, 'catalogo_refs.json');
    const cat = lerJson(catP, { serie: slug, personagens: {}, cenarios: {} });
    cat.personagens = cat.personagens || {};
    cat.cenarios = cat.cenarios || {};
    for (const raw of roteiroTxt.split(/\r?\n/)) {
      const m = raw.trim().match(/^[-*]\s*([^|]+)\|\s*([^|]+)\|\s*(ref_[a-z0-9_]+)\s*\|\s*(.+)$/i);
      if (m && !cat.personagens[m[3].trim()]) cat.personagens[m[3].trim()] = `${m[1].trim()} (${m[2].trim()}) — ${m[4].trim()}`;
      const mo = raw.trim().match(/^Onde:\s*(ref_[a-z0-9_]+)\s*\((INTERIOR|EXTERIOR)\)/i);
      if (mo && !cat.cenarios[mo[1].trim()]) cat.cenarios[mo[1].trim()] = `${mo[2].toUpperCase()} — ${mo[1].trim()}`;
    }
    if (promptsTxt) {
      for (const raw of promptsTxt.split(/\r?\n/)) {
        const m = raw.trim().match(/^\{(ref_[a-z0-9_]+)\}\s*->\s*\(i\)\s*(.+)$/i);
        if (m) {
          if (/^ref_cenario_/i.test(m[1])) cat.cenarios[m[1]] = m[2];
          else cat.personagens[m[1]] = m[2];
        }
      }
    }
    escreverJsonAtomico(catP, cat);
  }

  /**
   * Parseia os blocos `===FILE:<nome>===` devolvidos no stdout do Claude e grava os arquivos no disco (Node.js),
   * gerando tambem continuidade_cenas.md, metadata_flow.json e legenda_facebook.txt localmente (custo ZERO de Claude).
   */
  gravarArquivosExtraidosNoDisco(job, saida) {
    const arquivos = extrairArquivosDelimitados(saida);
    const { slug, parte } = this.inferirSlugEParte(saida, arquivos, { slug: job.slugAlvo, parte: job.parteAlvo });
    if (!slug) return { slug: null, parte: 1, arquivosGravados: [] };
    job.slugAlvo = slug;
    job.parteAlvo = parte;
    const pastaParte = job.pastaParte || path.join(this.prontosDir, slug, nomeParte(parte));
    job.pastaParte = pastaParte;
    fs.mkdirSync(pastaParte, { recursive: true });

    const cfg = job.configUsada || this.lerConfigFabrica();
    const seg = Number(job.tamanhoCenaSegundos || cfg.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const dur = Number(cfg.duracaoTotalMinutos) || 3;
    const numCenas = calcularNumeroCenas(dur, seg);
    const gravados = [];

    if (arquivos['roteiro_humano.md']) {
      fs.writeFileSync(path.join(pastaParte, 'roteiro_humano.md'), limparRoteiroDeJson(arquivos['roteiro_humano.md']), 'utf8');
      gravados.push('roteiro_humano.md');
    }
    const roteiroNoDisco = lerTexto(path.join(pastaParte, 'roteiro_humano.md')) || '';

    // Sempre sincroniza continuidade_cenas.md com o roteiro_humano.md para evitar qualquer divergencia de tabela
    if (roteiroNoDisco) {
      const tabAuto = gerarTabelaContinuidadeDeRoteiro(roteiroNoDisco);
      if (tabAuto) {
        fs.writeFileSync(path.join(pastaParte, 'continuidade_cenas.md'), tabAuto, 'utf8');
        gravados.push('continuidade_cenas.md');
      } else if (arquivos['continuidade_cenas.md']) {
        fs.writeFileSync(path.join(pastaParte, 'continuidade_cenas.md'), arquivos['continuidade_cenas.md'], 'utf8');
        gravados.push('continuidade_cenas.md');
      }
    }

    if (arquivos['prompts_flow.txt']) {
      fs.writeFileSync(path.join(pastaParte, 'prompts_flow.txt'), arquivos['prompts_flow.txt'], 'utf8');
      gravados.push('prompts_flow.txt');
      try { // cenas MUDAS: garante a instrução anti-fala no prompt de vídeo (custo zero)
        const bl = garantirBlindagemCenasMudas(roteiroNoDisco, arquivos['prompts_flow.txt']);
        if (bl.corrigidas.length) { fs.writeFileSync(path.join(pastaParte, 'prompts_flow.txt'), bl.texto, 'utf8'); this.log(`Fábrica: instrução "No spoken dialogue in this scene" adicionada nas cenas mudas ${bl.corrigidas.join(', ')}.`, 'info'); }
      } catch {}
    }

    const temPromptsAgora = fs.existsSync(path.join(pastaParte, 'prompts_flow.txt'));
    if (temPromptsAgora || arquivos['metadata_flow.json'] || arquivos['legenda_linhas.txt'] || arquivos['legenda_facebook.txt']) {
      const ver = verificarTipoFinalRoteiro(roteiroNoDisco, null);
      const tituloRot = (roteiroNoDisco.split(/\r?\n/).find((l) => /^#\s+\S/.test(l.trim())) || `# ${slug} — Parte ${parte}`).replace(/^#\s+/, '').trim();
      let meta = lerJson(path.join(pastaParte, 'metadata_flow.json'), {});
      if (arquivos['metadata_flow.json']) {
        try { meta = { ...meta, ...JSON.parse(arquivos['metadata_flow.json']) }; } catch {}
      }
      delete meta.flowConfig;
      delete meta.qualidadeGeracaoVideo;
      delete meta.qualidadeDownloadVideo;
      delete meta.qualidadeDownloadImagem;
      delete meta.modeloImagem;
      delete meta.modeloVideo;
      delete meta.travaSem4K;
      const d = extrairDialogosRoteiro(roteiroNoDisco);
      const totalCenasReal = d.cenas.length || numCenas;
      const tipoFinalCalc = job.tipoFinal || normalizarTipoFinal(meta.tipoFinal) || (ver.parte < ver.total ? 'aberto' : 'fechado');
      const ehUnicaFechada = parte === 1 && tipoFinalCalc === 'fechado' && (!ver || ver.total <= 1);
      const totalPartesCalc = tipoFinalCalc === 'fechado' ? parte : Math.max(Number(meta.totalPartes) || 1, ver.total || 1, parte);
      const ehSerieCalc = !ehUnicaFechada && Boolean(totalPartesCalc > 1 || parte > 1 || tipoFinalCalc === 'aberto' || (cfg.formatoHistoria === 'serie' && totalPartesCalc > 1));
      Object.assign(meta, {
        titulo: meta.titulo || tituloRot,
        slug,
        serie: ehSerieCalc,
        formato: ehSerieCalc ? 'serie' : 'unica',
        parte,
        totalPartes: totalPartesCalc,
        tipoFinal: tipoFinalCalc,
        tamanhoCenaSegundos: seg,
        duracaoTotalMinutos: dur,
        numeroCenas: totalCenasReal,
        modoGeracaoVideo: cfg.modoGeracaoVideo === 'frame_inicial' ? 'frame_inicial' : 'elementos',
        totalImagens: totalCenasReal,
        totalVideos: totalCenasReal,
        criadoEm: meta.criadoEm || new Date().toISOString(),
      });
      if (parte > 1 && (!Array.isArray(meta.referenciasHerdadasDaParte1) || !meta.referenciasHerdadasDaParte1.length)) {
        const cat = lerJson(path.join(this.seriesDir, slug, 'catalogo_refs.json'), {});
        meta.referenciasHerdadasDaParte1 = [...Object.keys(cat.personagens || {}), ...Object.keys(cat.cenarios || {})];
      }
      escreverJsonAtomico(path.join(pastaParte, 'metadata_flow.json'), meta);
      gravados.push('metadata_flow.json');

      const txtLeg = arquivos['legenda_linhas.txt'] || arquivos['legenda_facebook.txt'] || meta.legendaFacebook || '';
      const legFinal = this.gerarLegendaLocal(pastaParte, txtLeg, meta.titulo);
      meta.legendaFacebook = legFinal.trim();
      escreverJsonAtomico(path.join(pastaParte, 'metadata_flow.json'), meta);
      gravados.push('legenda_facebook.txt');
    }

    if (roteiroNoDisco) {
      const tituloExtraido = (roteiroNoDisco.split(/\r?\n/).find((l) => /^#\s+\S/.test(l.trim())) || '').replace(/^#\s+/, '').trim();
      atualizarUltimoRegistroUsoClaude({ novelaSlug: slug, novelaTitulo: tituloExtraido || slug });
      this.sincronizarSerieLocal({
        slug, parte, roteiroTxt: roteiroNoDisco,
        promptsTxt: lerTexto(path.join(pastaParte, 'prompts_flow.txt')) || '',
        tipoFinal: job.tipoFinal || 'fechado', cfg,
      });
    }

    if (job.resumoOriginalUsuario && String(job.resumoOriginalUsuario).trim()) {
      try {
        const resTxt = String(job.resumoOriginalUsuario).trim() + '\n';
        fs.writeFileSync(path.join(pastaParte, 'resumo_original.txt'), resTxt, 'utf8');
        fs.writeFileSync(path.join(this.prontosDir, slug, 'resumo_original.txt'), resTxt, 'utf8');
      } catch {}
    }

    try { this.gravarBibliaRica(job, slug, parte, pastaParte); } catch (e) { this.log(`Fábrica: não consegui salvar a bíblia rica (${e.message}).`, 'aviso'); }

    if (!this.extrairResultado(job.saida)) {
      job.saida = `${job.saida ? job.saida.trimEnd() + '\n' : ''}RESULTADO_JSON: ${JSON.stringify({ slug, parte })}`;
    }
    return { slug, parte, arquivosGravados: gravados };
  }

  /**
   * Auto-reparo cirurgico economico (MAXIMO 1 retry curto stateless):
   * Se validar_novela.mjs apontar ERRO bloqueante no roteiro_humano.md ou prompts_flow.txt,
   * faz NO MAXIMO 1 chamada extra enviando APENAS o arquivo com erro + as linhas exatas do erro do validador.
   */
  async autoRepararUmaVezSeNecessario(job, { slug, parte }) {
    if (!slug || !parte || job.estado === 'cancelado') return;
    const pastaParte = job.pastaParte || path.join(this.prontosDir, slug, nomeParte(parte));
    const apenasRoteiro = Boolean(job.apenasRoteiro || job.tipo === 'roteiro');
    const seg = Number(job.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const val = this.validarParte(slug, parte, { apenasRoteiro, seg });
    const rotTxt = lerTexto(path.join(pastaParte, 'roteiro_humano.md')) || '';
    const verifFinal = job.tipoFinal && rotTxt ? verificarTipoFinalRoteiro(rotTxt, job.tipoFinal) : { ok: true };
    if (val.ok && verifFinal.ok) return;

    const linhasErro = (val.saida || '')
      .split(/\r?\n/)
      .filter((l) => /^\s*✗/.test(l))
      .join('\n');
    const erroTipoFinal = !verifFinal.ok ? `  ✗ roteiro_humano.md:1 — ${verifFinal.motivo}` : '';
    const todosErros = [linhasErro, erroTipoFinal].filter(Boolean).join('\n');
    if (!todosErros) return;

    const erroEmRoteiro = /roteiro_humano\.md/i.test(todosErros) || apenasRoteiro;
    const erroEmPrompts = !apenasRoteiro && /prompts_flow\.txt/i.test(todosErros);
    if (!erroEmRoteiro && !erroEmPrompts) return;

    job.etapa = 'Auto-reparo cirúrgico (1 retry curto)';
    job.tentativasReparo = (job.tentativasReparo || 0) + 1;
    this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });

    const prmTxt = lerTexto(path.join(pastaParte, 'prompts_flow.txt')) || '';
    const blocosEnviar = [];
    const blocosPedir = [];
    if (erroEmRoteiro && rotTxt) {
      blocosEnviar.push(`ARQUIVO COM ERRO (roteiro_humano.md):\n===FILE:roteiro_humano.md===\n${rotTxt.trim()}\n===END_FILE===`);
      blocosPedir.push('`===FILE:roteiro_humano.md=== ... ===END_FILE===`');
    }
    if (erroEmPrompts && prmTxt) {
      if (!erroEmRoteiro && rotTxt) {
        const d = extrairDialogosRoteiro(rotTxt);
        blocosEnviar.push(`FALA EXATA DE CADA CENA DO ROTEIRO (para sincronizar BLOCO 3):\n` +
          d.cenas.map((c) => `Cena ${String(c.cena).padStart(2, '0')}: ` + c.falas.map((f) => `"${f.texto}"`).join(' | ')).join('\n'));
      }
      blocosEnviar.push(`ARQUIVO COM ERRO (prompts_flow.txt):\n===FILE:prompts_flow.txt===\n${prmTxt.trim()}\n===END_FILE===`);
      blocosPedir.push('`===FILE:prompts_flow.txt=== ... ===END_FILE===`');
    }
    if (!blocosEnviar.length) return;

    const promptReparo = [
      'MODO AUTO-REPARO CIRÚRGICO (1 ÚNICO TURNO STATELESS, ZERO TOOLS):',
      `Corrija APENAS os erros apontados abaixo pelo validador (cenas de ${seg}s: ${seg === 10 ? '14–25 palavras, meta 18–21, máx. 20 em 3 falas, mín. 85% das cenas com 2 falas A->B' : '23–30 palavras, máx. 27 em 3 falas'}) e devolva SOMENTE ${blocosPedir.join(' e ')} corrigido(s) + a linha final RESULTADO_JSON: {"slug":"${slug}","parte":${parte}}.`,
      '',
      'ERROS EXATOS DO VALIDADOR PARA CORRIGIR:',
      todosErros,
      '',
      ...blocosEnviar,
    ].join('\n');

    const saidaReparo = await this.rodarClaude(job, promptReparo);
    if (saidaReparo) {
      this.gravarArquivosExtraidosNoDisco(job, saidaReparo);
    }
  }

  pastaMaisRecente() {
    if (!fs.existsSync(this.prontosDir)) return null;
    let melhor = null;
    for (const slug of fs.readdirSync(this.prontosDir)) {
      const dSlug = path.join(this.prontosDir, slug);
      if (!fs.statSync(dSlug).isDirectory()) continue;
      for (const pd of fs.readdirSync(dSlug)) {
        const m = pd.match(/^parte_(\d+)$/i); if (!m) continue;
        const arqP = path.join(dSlug, pd, 'prompts_flow.txt');
        const arqR = path.join(dSlug, pd, 'roteiro_humano.md');
        const arq = fs.existsSync(arqP) ? arqP : fs.existsSync(arqR) ? arqR : null;
        if (!arq) continue;
        const t = fs.statSync(arq).mtimeMs;
        if (!melhor || t > melhor.t) melhor = { slug, parte: Number(m[1]), t };
      }
    }
    return melhor;
  }

  /** Roda validar_novela.mjs (local, sem tokens) em roteiro (modo --apenas-roteiro) ou em roteiro + prompts + legenda da parte. */
  validarParte(slug, parte, { apenasRoteiro = false, seg = null } = {}) {
    const pasta = path.join('prontos_para_flow', slug, nomeParte(parte));
    const nomes = apenasRoteiro ? ['roteiro_humano.md'] : ['roteiro_humano.md', 'prompts_flow.txt', 'legenda_facebook.txt'];
    const arquivos = nomes.map((f) => path.join(pasta, f)).filter((f) => fs.existsSync(path.join(this.dir, f)));
    if (!arquivos.length) return { ok: false, saida: 'Nenhum arquivo para validar.', apenasRoteiro, faltaLegenda: !apenasRoteiro };
    const args = [path.join('scripts', 'validar_novela.mjs'), ...arquivos];
    if (apenasRoteiro) args.push('--apenas-roteiro');
    if (seg === 10 || seg === 15) args.push(`--seg=${seg}`);
    const r = spawnSync(process.execPath, args, { cwd: this.dir, encoding: 'utf8', windowsHide: true });
    const faltaLegenda = apenasRoteiro ? false : !fs.existsSync(path.join(this.dir, pasta, 'legenda_facebook.txt'));
    return { ok: r.status === 0, saida: (r.stdout || '') + (r.stderr || ''), apenasRoteiro, faltaLegenda };
  }

  /** Cache persistente de transcricoes de videos virais (evita re-baixar com yt-dlp e re-rodar whisper no mesmo link). */
  arqCacheTranscricoesVirais() {
    return path.join(this.dir, 'dados', 'cache_transcricoes_virais.json');
  }

  lerCacheTranscricaoViral(link) {
    const url = String(link || '').trim();
    if (!url) return null;
    const db = lerJson(this.arqCacheTranscricoesVirais(), { itens: {} });
    const hit = db?.itens?.[url];
    if (hit && typeof hit.transcricao === 'string' && hit.transcricao.trim().length >= 20) return hit;
    return null;
  }

  salvarCacheTranscricaoViral(link, { transcricao = '', resumo = '', titulo = '', duracaoSegundos = null, idioma = 'pt', info = null } = {}) {
    const url = String(link || '').trim();
    const tr = String(transcricao || '').trim();
    if (!url || tr.length < 15) return null;
    try {
      const p = this.arqCacheTranscricoesVirais();
      const db = lerJson(p, { itens: {} });
      db.itens = db.itens || {};
      const entrada = {
        url,
        titulo: String(titulo || '').trim(),
        transcricao: tr.slice(0, 25000),
        resumo: String(resumo || '').trim().slice(0, 12000),
        duracaoSegundos: Number(duracaoSegundos) || null,
        idioma: idioma || 'pt',
        info: info || null,
        extraidoEm: new Date().toISOString(),
      };
      db.itens[url] = entrada;
      if (info?.url && String(info.url).trim() && info.url !== url) {
        db.itens[String(info.url).trim()] = entrada;
      }
      escreverJsonAtomico(p, db);
      return entrada;
    } catch {
      return null;
    }
  }

  /** Remove com seguranca a pasta temporaria `temp_midia/ext_*` do job (e quaisquer pastas orfas antigas). */
  limparPastaMidiaJob(job = null) {
    if (job?.pastaMidia) {
      try { fs.rmSync(job.pastaMidia, { recursive: true, force: true }); } catch {}
      job.pastaMidiaLimpa = true;
    }
    try {
      const tempRoot = path.join(this.dir, 'temp_midia');
      if (!fs.existsSync(tempRoot)) return;
      const temOutroJobExtraindo = [...this.jobs.values()].some((j) => j.estado === 'rodando' && j.id !== job?.id && j.pastaMidia);
      if (temOutroJobExtraindo) return;
      for (const item of fs.readdirSync(tempRoot)) {
        if (!/^ext_/i.test(item)) continue;
        const abs = path.join(tempRoot, item);
        try { fs.rmSync(abs, { recursive: true, force: true }); } catch {}
      }
    } catch {}
  }

  async obterOuExtrairTranscricaoViral(link, job, { forcar = false } = {}) {
    const url = String(link || '').trim();
    if (!forcar) {
      const cache = this.lerCacheTranscricaoViral(url);
      if (cache) {
        const prep = prepararTranscricaoViralParaPrompt({
          transcricaoTxt: cache.transcricao,
          infoJson: cache.info,
          resumoMd: cache.resumo,
          titulo: cache.titulo,
          duracaoSegundos: cache.duracaoSegundos,
        });
        job.transcricaoViral = prep.textoLimpo || cache.transcricao;
        job.transcricaoPromptPronta = prep.blocoPrompt;
        job.duracaoViralSegundos = prep.duracaoSegundos;
        job.idiomaViral = prep.idioma;
        job.resumoViral = cache.resumo || '';
        job.tituloViral = prep.titulo || cache.titulo || '';
        job.transcricaoDoCache = true;
        const msgCache = `⚡ Transcrição do vídeo viral recuperada do cache local (0s · ${job.transcricaoViral.length} chars${prep.duracaoSegundos ? ` · ${Math.round(prep.duracaoSegundos)}s` : ''} · idioma: ${prep.idioma}) e injetada direto no prompt.\n`;
        job.saida = (job.saida || '') + msgCache;
        this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
        return { ...cache, ...prep };
      }
    }
    try {
      job.pastaMidia = await this.extrairVideoLocal(url, job);
      const trTxt = lerTexto(path.join(job.pastaMidia, 'transcricao.txt')) || '';
      const trJson = lerJson(path.join(job.pastaMidia, 'transcricao.json'), null);
      const infoJson = lerJson(path.join(job.pastaMidia, 'info.json'), null);
      const resMd = lerTexto(path.join(job.pastaMidia, 'RESUMO.md')) || '';
      const mTit = String(job.saida || resMd).match(/^#\s*Extra[cç][aã]o\s*[—–-]\s*(.+)$/im);
      const tituloBruto = infoJson?.titulo || (mTit ? mTit[1].trim() : '');
      const prep = prepararTranscricaoViralParaPrompt({
        transcricaoTxt: trTxt,
        transcricaoJson: trJson,
        infoJson,
        resumoMd: resMd,
        titulo: tituloBruto,
      });
      job.transcricaoViral = prep.textoLimpo || trTxt || resMd;
      job.transcricaoPromptPronta = prep.blocoPrompt;
      job.duracaoViralSegundos = prep.duracaoSegundos;
      job.idiomaViral = prep.idioma;
      job.resumoViral = resMd;
      job.tituloViral = prep.titulo || tituloBruto;
      this.salvarCacheTranscricaoViral(url, {
        transcricao: trTxt || prep.textoLimpo || resMd,
        resumo: resMd,
        titulo: job.tituloViral,
        duracaoSegundos: prep.duracaoSegundos,
        idioma: prep.idioma,
        info: infoJson,
      });
      job.saida = `${(job.saida || '').replace(/Próximo passo:\s*ler transcricao\.txt[^\n]*/gi, '').trimEnd()}\n📄 Transcrição lida do disco e injetada diretamente no prompt (${job.transcricaoViral.length} chars${prep.duracaoSegundos ? ` · ${Math.round(prep.duracaoSegundos)}s` : ''} · idioma: ${prep.idioma}).\n`;
      this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
      return { url, titulo: job.tituloViral, transcricao: job.transcricaoViral, resumo: resMd, ...prep };
    } finally {
      // Limpa IMEDIATAMENTE a pasta temp_midia/ext_* apos ler a transcricao para memoria/cache (mesmo se falhar depois!)
      this.limparPastaMidiaJob(job);
    }
  }

  /** Extracao local do video (zero tokens): roda scripts/extrair_video.mjs e devolve a pasta temp_midia criada. */
  extrairVideoLocal(link, job) {
    this.exigirFabrica();
    if (!/^https?:\/\//i.test(String(link || '').trim())) return Promise.reject(new Error('Cole um link válido (começando com https://).'));
    job.etapa = 'extraindo vídeo (local, sem gastar tokens)';
    this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
    return new Promise((resolve, reject) => {
      const child = spawn(process.execPath, [path.join('scripts', 'extrair_video.mjs'), String(link).trim()], { cwd: this.dir, windowsHide: true });
      job._proc = { child };
      let out = '';
      const quando = (d) => { const t = d.toString('utf8'); out += t; job.saida += t; this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) }); };
      child.stdout.on('data', quando); child.stderr.on('data', quando);
      const timer = setTimeout(() => { try { child.kill(); } catch {} }, 25 * 60 * 1000);
      child.on('error', (e) => { clearTimeout(timer); reject(e); });
      child.on('close', (code) => {
        clearTimeout(timer);
        const m = out.match(/- Pasta:\s*(.+)/);
        if (code !== 0 || !m) return reject(new Error('Não consegui baixar/analisar o vídeo. Veja o log da tarefa (Stories/vídeos privados: dados\\COMO_ATIVAR_STORIES.txt na Fábrica).'));
        resolve(m[1].trim());
      });
    });
  }

  finalizarJob(job, estado, erro = null) {
    job.estado = estado;
    job.erro = erro;
    job.fimEm = new Date().toISOString();
    if (estado !== 'ok' && Array.isArray(job.etapas)) {
      for (const et of job.etapas) {
        if (et.estado === 'rodando') et.estado = 'erro';
      }
    }
    const durTotalSeg = job.iniciadoEm ? Math.max(1, Math.round((Date.now() - new Date(job.iniciadoEm).getTime()) / 1000)) : null;
    job.etapa = estado === 'ok'
      ? 'concluído'
      : (job.etapaFalha ? `falhou em ${job.etapaFalha}${durTotalSeg ? ` (${durTotalSeg}s)` : ''}` : estado);
    this.limparPastaMidiaJob(job);
    try {
      const pEst = this.arqEstadoCriador();
      if (pEst && fs.existsSync(pEst)) {
        const est = lerJson(pEst, {});
        if (est?.wiz?.jobId === job.id && estado !== 'ok') {
          est.wiz.rodando = false;
          est.wiz.estado = estado;
          est.wiz.erro = erro || estado;
          escreverJsonAtomico(pEst, est);
        }
      }
    } catch {}
    this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
    this.log(`Fábrica Claude — ${job.titulo}: ${estado === 'ok' ? 'concluído' : (erro || estado)}`, estado === 'ok' ? 'ok' : 'erro');
  }

  /** Depois que o Claude terminou: libera o lock da parte, valida, (opcional) importa e inicia a fila. */
  async posProcessar(job, { importar = false, iniciarFila = false } = {}) {
    // Libera imediatamente o lock de escrita da parte antes de validar/importar para que o proprio job NUNCA bloqueie a si mesmo!
    job.lockLiberado = true;
    // Etapas de semente ou ficha viral ainda NAO geram roteiro_humano.md em prontos_para_flow — jamais rodar validarParte nelas!
    if (job.tipo === 'sementes' || job.tipo === 'ficha') return;
    let res = this.extrairResultado(job.saida);
    if (!res?.slug && job.slugAlvo) res = { slug: job.slugAlvo, parte: job.parteAlvo || 1 };
    if (!res?.slug) { const m = this.pastaMaisRecente(); if (m && new Date(m.t) > new Date(job.iniciadoEm)) res = { slug: m.slug, parte: m.parte }; }
    if (!res?.slug) return;
    res.parte = Number(res.parte) || 1;
    job.resultado = res;
    job.etapa = 'validando (local)';
    const apenasRoteiro = Boolean(job.apenasRoteiro || job.tipo === 'roteiro');
    job.validacao = this.validarParte(res.slug, res.parte, { apenasRoteiro, seg: job.tamanhoCenaSegundos });
    if (!apenasRoteiro && job.validacao.faltaLegenda) job.validacao.ok = false;

    // tipo de final escolhido pelo usuario x o que o Claude entregou (titulo "Parte N de M" + Choque)
    const pastaParte = path.join(this.prontosDir, res.slug, nomeParte(res.parte));
    const roteiroTxt = lerTexto(path.join(pastaParte, 'roteiro_humano.md')) || '';
    if (roteiroTxt) {
      job.dialogos = extrairDialogosRoteiro(roteiroTxt);
      if (apenasRoteiro) {
        job.resultado = { ...res, apenasRoteiro: true, roteiro: roteiroTxt };
      }
    }
    if (job.tipoFinal && roteiroTxt) {
      const verif = verificarTipoFinalRoteiro(roteiroTxt, job.tipoFinal);
      job.validacao.tipoFinal = { pedido: job.tipoFinal, ...verif };
      if (!verif.ok) { job.validacao.ok = false; job.validacao.saida = `${job.validacao.saida || ''}\n❌ Tipo de final: ${verif.motivo}`; }
      try {
        const mp = path.join(pastaParte, 'metadata_flow.json');
        const meta = lerJson(mp, null);
        if (meta && meta.tipoFinal !== job.tipoFinal) { meta.tipoFinal = job.tipoFinal; escreverJsonAtomico(mp, meta); }
      } catch {}
    }
    try {
      if (fs.existsSync(pastaParte)) {
        escreverJsonAtomico(path.join(pastaParte, 'status_flowstudio.json'), {
          validacaoOk: !!job.validacao.ok, apenasRoteiro, tipoFinal: job.tipoFinal || null, em: new Date().toISOString(), job: job.tipo,
        });
      }
    } catch {}
    this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });

    if (importar && job.validacao.ok) {
      try {
        const existente = this.novelaImportada(res.slug, res.parte);
        if (existente && job.atualizarExistente) {
          // "Gerar Novamente" de uma parte ja importada: atualiza a MESMA novela preservando refs/imagens ja geradas (0 creditos no Bloco 1)
          job.etapa = 'atualizando a novela existente no Estúdio';
          const at = this.atualizarNovelaImportada(existente, res.slug, res.parte);
          job.importacao = { novelaId: existente.id, nome: existente.nome, atualizada: true, preservados: at.preservados, pendentes: at.pendentes };
          return;
        }
        if (existente) {
          job.importacao = { novelaId: existente.id, nome: existente.nome, jaImportada: true };
          return;
        }
        job.etapa = 'importando para o Estúdio';
        const imp = this.importar({ slug: res.slug, parte: res.parte, ignorarLockProprio: true, ignorarJobId: job.id });
        job.importacao = { novelaId: imp.novela.id, nome: imp.novela.nome, herdadas: imp.heranca.herdadas.length, faltando: imp.heranca.faltando, errosParser: imp.validacao.erros.length };
        if (iniciarFila && imp.validacao.ok && this.runner) {
          job.etapa = 'iniciando fila no Google Flow';
          this.runner.enfileirar([{ novelaId: imp.novela.id }]);
          job.importacao.filaIniciada = true;
        }
      } catch (eImp) {
        // Se apenas a importacao pos-validacao falhar, NUNCA invalida nem faz rollback dos arquivos prontos e aprovados na parte_XX!
        job.importacao = { erro: eImp.message };
        this.log(`⚠️ Fábrica: os arquivos de ${res.slug}/${nomeParte(res.parte)} foram APROVADOS e mantidos, mas a auto-importação avisou: ${eImp.message}`, 'aviso');
      }
    }
  }

  /** Preserva em `_versoes/parcial_<TIMESTAMP>/` qualquer arquivo gerado/alterado antes de restaurar versao anterior (NUNCA destroi trabalho pago com cota). */
  arquivarParciaisDaPasta(pastaParte, desdeMs = 0) {
    if (!pastaParte || !fs.existsSync(pastaParte)) return null;
    const candidatos = fs.readdirSync(pastaParte).filter((f) => {
      if (f === '_versoes' || f === 'bloco1_refs_backup.txt') return false;
      try {
        const st = fs.statSync(path.join(pastaParte, f));
        return st.isFile() && st.mtimeMs >= desdeMs;
      } catch { return false; }
    });
    if (!candidatos.length) return null;
    const destinoParcial = path.join(pastaParte, '_versoes', `parcial_${new Date().toISOString().replace(/[:.]/g, '-')}`);
    fs.mkdirSync(destinoParcial, { recursive: true });
    for (const f of candidatos) {
      const orig = path.join(pastaParte, f);
      const dest = path.join(destinoParcial, f);
      fs.copyFileSync(orig, dest);
      try { fs.unlinkSync(orig); } catch {}
    }
    return { pasta: destinoParcial, arquivos: candidatos };
  }

  /**
   * Quando o Claude CLI encerra por limite de cota ("hit your limit"), timeout, --max-turns ou codigo != 0:
   *  a) Se `roteiro_humano.md` e `prompts_flow.txt` novos ja foram gravados, roda o validador neles primeiro:
   *     se passarem na validacao (+ tipo de final), APROVA E MANTÉM OS ARQUIVOS NOVOS (zero rollback!).
   *  b) Se estiverem incompletos ou invalidos, salva todos os arquivos parciais em `_versoes/parcial_TIMESTAMP/`
   *     antes de qualquer restauracao da versao anterior.
   */
  async tentarResgatarOuArquivarParciais(job, erroCli, { importar = false, iniciarFila = false } = {}) {
    job.lockLiberado = true;
    const desdeMs = new Date(job.iniciadoEm).getTime() - 1000;
    let slug = job.slugAlvo || null;
    let parte = Number(job.parteAlvo) || null;
    if (!slug) {
      const ext = this.extrairResultado(job.saida);
      if (ext?.slug) { slug = ext.slug; parte = Number(ext.parte) || 1; }
      else {
        const m = this.pastaMaisRecente();
        if (m && m.t >= desdeMs) { slug = m.slug; parte = m.parte; }
      }
    }
    const pastaParte = job.pastaParte || (slug && parte ? path.join(this.prontosDir, slug, nomeParte(parte)) : null);
    if (!pastaParte || !fs.existsSync(pastaParte) || !slug || !parte) return { resgatado: false, parcial: null };

    const rotP = path.join(pastaParte, 'roteiro_humano.md');
    const prmP = path.join(pastaParte, 'prompts_flow.txt');
    const legP = path.join(pastaParte, 'legenda_facebook.txt');
    const metaP = path.join(pastaParte, 'metadata_flow.json');
    const apenasRoteiro = Boolean(job.apenasRoteiro || job.tipo === 'roteiro');
    // Na etapa "prompts" o roteiro_humano.md ja existia da Etapa 1; em apenasRoteiro (modo Com Aprovacao) basta roteiro_humano.md novo e valido
    const temNovos = apenasRoteiro
      ? (fs.existsSync(rotP) && fs.statSync(rotP).mtimeMs >= desdeMs)
      : (fs.existsSync(rotP) && fs.existsSync(prmP) && (fs.statSync(rotP).mtimeMs >= desdeMs || fs.statSync(prmP).mtimeMs >= desdeMs));

    if (temNovos || job.validacao?.ok) {
      if (!apenasRoteiro) {
        // Se o CLI bateu limite/max-turns no ultimo segundo logo apos validar roteiro+prompts mas antes de gerar legenda/metadata, completa localmente so se roteiro+prompts ja forem 100% validos
        if (!fs.existsSync(legP)) {
          const pastaRel = path.join('prontos_para_flow', slug, nomeParte(parte));
          const rPre = spawnSync(process.execPath, [path.join('scripts', 'validar_novela.mjs'), path.join(pastaRel, 'roteiro_humano.md'), path.join(pastaRel, 'prompts_flow.txt')], { cwd: this.dir, encoding: 'utf8', windowsHide: true });
          if (rPre.status === 0) {
            const rotTxt = lerTexto(rotP) || '';
            const tituloRot = (rotTxt.split(/\r?\n/).find((l) => /^#\s+\S/.test(l)) || `# ${slug} — Parte ${parte}`).replace(/^#\s+/, '').trim();
            this.gerarLegendaLocal(pastaParte, '', tituloRot);
          }
        }
        if (!fs.existsSync(metaP)) {
          const rotTxt = lerTexto(rotP) || '';
          const ver = verificarTipoFinalRoteiro(rotTxt, null);
          escreverJsonAtomico(metaP, {
            titulo: (rotTxt.split(/\r?\n/).find((l) => /^#\s+\S/.test(l)) || `# ${slug}`).replace(/^#\s+/, '').trim(),
            slug, serie: ver.total > 1 || parte > 1, parte, totalPartes: ver.total || parte,
            tipoFinal: job.tipoFinal || (ver.parte < ver.total ? 'aberto' : 'fechado'),
            modoGeracaoVideo: this.lerConfigFabrica().modoGeracaoVideo,
            criadoEm: new Date().toISOString(),
            legendaFacebook: (lerTexto(legP) || '').trim(),
          });
        }
      }

      const val = this.validarParte(slug, parte, { apenasRoteiro, seg: job.tamanhoCenaSegundos });
      const verifFinal = job.tipoFinal ? verificarTipoFinalRoteiro(lerTexto(rotP) || '', job.tipoFinal) : { ok: true };
      if (val.ok && (apenasRoteiro || !val.faltaLegenda) && verifFinal.ok) {
        try { fs.rmSync(path.join(pastaParte, 'bloco1_refs_backup.txt'), { force: true }); } catch {}
        if (!this.extrairResultado(job.saida)) {
          job.saida = `${job.saida ? job.saida + '\n' : ''}RESULTADO_JSON: ${JSON.stringify({ slug, parte })}`;
        }
        job.resgatadoDeErroCli = erroCli;
        await this.posProcessar(job, { importar, iniciarFila });
        this.log(`✅ Fábrica: o Claude CLI encerrou com aviso (${erroCli}), mas os arquivos novos de ${slug}/${nomeParte(parte)} já estavam gravados e APROVADOS no validador — mantidos sem rollback!`, 'ok');
        this.finalizarJob(job, 'ok');
        return { resgatado: true, parcial: null };
      }
    }

    // Incompleto ou reprovado no validador: preserva os arquivos gerados em _versoes/parcial_TIMESTAMP/ antes do rollback
    const parcial = this.arquivarParciaisDaPasta(pastaParte, job.tipo === 'regerar' ? 0 : desdeMs);
    if (parcial) {
      job.parcialSalvoEm = parcial.pasta;
      job.arquivosParciais = parcial.arquivos;
      this.log(`⚠️ Fábrica: arquivos parciais/inválidos de ${slug}/${nomeParte(parte)} preservados em _versoes/${path.basename(parcial.pasta)} (${parcial.arquivos.join(', ')}).`, 'aviso');
    }
    return { resgatado: false, parcial };
  }

  iniciarJob({ tipo, titulo, prompt, escrita = true, importar = false, iniciarFila = false, preparo = null, posClaude = null, extra = {}, dupla = null }) {
    this.exigirFabrica();
    const job = this.novoJob(tipo, titulo, extra);
    (async () => {
      try {
        if (preparo) await preparo(job);
        let saida;
        if (dupla) {
          saida = await this.rodarDupla(job, dupla); // Etapa 1/2 (opus|sonnet) -> Etapa 2/2 (sonnet)
        } else {
          job.etapa = `Claude (${ROTULO_MODELO_CLAUDE[normalizarModeloClaude(job.modeloUnico)]} · 1 turno sem tools) trabalhando`;
          this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
          saida = await this.rodarClaude(job, typeof prompt === 'function' ? prompt(job) : prompt);
        }
        if (job.estado === 'cancelado') return;
        if (saida && !job.saida.includes(saida)) job.saida += saida;
        if (tipo !== 'sementes' && tipo !== 'ficha') {
          const grav = this.gravarArquivosExtraidosNoDisco(job, job.saida);
          if (grav.slug) await this.autoRepararUmaVezSeNecessario(job, grav);
        }
        if (typeof posClaude === 'function') await posClaude(job, saida);
        if (typeof job.verificar === 'function') await job.verificar(job);
        job.lockLiberado = true;
        if (tipo !== 'sementes' && tipo !== 'ficha') {
          await this.posProcessar(job, { importar, iniciarFila });
        }
        this.finalizarJob(job, 'ok');
      } catch (e) {
        job.lockLiberado = true;
        if (job.estado === 'cancelado') return;
        let msg = e.message;
        try {
          if (tipo !== 'sementes' && tipo !== 'ficha' && job.saida) {
            this.gravarArquivosExtraidosNoDisco(job, job.saida);
          }
          if (tipo !== 'sementes' && tipo !== 'ficha') {
            const resgate = await this.tentarResgatarOuArquivarParciais(job, msg, { importar, iniciarFila });
            if (resgate.resgatado) return;
            if (resgate.parcial) msg = `${msg} · tentativa parcial salva em _versoes/${path.basename(resgate.parcial.pasta)}`;
          }
        } catch {}
        // falha fatal (arquivos ausentes/invalidos ja arquivados em _versoes/parcial_*): restaura a versao anterior
        if (typeof job.restaurar === 'function') {
          try { job.restaurar(msg); msg = `${msg} — a versão anterior foi RESTAURADA (nada foi perdido).`; } catch (e2) { msg = `${msg} — ATENÇÃO: não consegui restaurar a versão anterior (${e2.message}); ela está em ${job.backup}.`; }
        }
        this.finalizarJob(job, 'erro', msg);
      }
    })();
    return this.jobPublico(job);
  }

  // =====================================================================
  //  PROMPT MESTRE DO ROTEIRISTA — arquitetura em 2 chamadas
  //  Chamada A (opus por padrão | sonnet): escaleta dramática + roteiro com falas vivas + bíblia (JSON)
  //  Chamada B (sonnet): só FORMATA no padrão do parser/validador mexendo o mínimo possível nas falas
  // =====================================================================
  get arquivoPromptMestre() { return path.join(this.dir, 'prompts', 'prompt_mestre_roteirista.md'); }

  /** Modelo da Chamada A (seletor Sonnet por padrão para economizar cota na janela de 5h | Opus opcional). A Chamada B é SEMPRE Sonnet. */
  modeloRoteirista(config = null, override = null) {
    const cfg = config || (this.existe ? this.lerConfigFabrica() : {});
    return normalizarModeloClaude(override || cfg.modeloRoteirista, 'sonnet');
  }

  reguaPalavrasTexto(seg) {
    return Number(seg) === 10
      ? 'CENA DE 10s: 1 a 3 falas (nunca mais de 3); total de **14 a 25 palavras** (referência natural **18 a 21** para preencher os 10s sem silêncio longo no final); máx. 20 palavras com 3 falas; máx. 14 por fala e 11 por frase; ao menos 85% das cenas FALADAS com 2 falas (troca A→B).'
      : 'CENA DE 15s: 1 a 3 falas (nunca mais de 3); total de **23 a 30 palavras** (máx. 27 com 3 falas); máx. 16 por fala e 12 por frase.';
  }

  /** Contexto da CONTINUAÇÃO (Parte 2+): bíblia rica + gancho anterior explícito + últimas cenas LITERAIS + refs fixas do catálogo. */
  montarContextoContinuacao(slug, parte) {
    const partAnt = Math.max(1, parte - 1);
    const biblia = lerJson(path.join(this.seriesDir, slug, 'biblia_serie.json'), null)
      || lerJson(path.join(this.prontosDir, slug, nomeParte(partAnt), 'biblia_rica.json'), null)
      || lerJson(path.join(this.prontosDir, slug, 'parte_01', 'biblia_rica.json'), null);
    const bibliaTxt = biblia ? JSON.stringify(biblia.bibliaRica || biblia, null, 1).slice(0, 9000) : '(sem bíblia salva — use o roteiro anterior como memória)';
    const rotAnt = lerTexto(path.join(this.prontosDir, slug, nomeParte(partAnt), 'roteiro_humano.md')) || '';
    const blocos = rotAnt.split(/^(?=#{2,4}\s*CENA\s*\d+)/im).filter((b) => /^#{2,4}\s*CENA/i.test(b.trim()));
    const ganchoHeader = (rotAnt.match(/^Final-fisgada[^:]*:\s*(.+)$/im) || [])[1] || '';
    const choqueFinal = (rotAnt.match(/^Choque\s*:\s*(.+)$/im) || [])[1] || '';
    const fisgadaFinal = ([...rotAnt.matchAll(/^Fisgada\s*:\s*(.+)$/gim)].pop() || [])[1] || '';
    const dAnt = rotAnt ? extrairDialogosRoteiro(rotAnt) : { cenas: [] };
    const resumoFalasAnt = dAnt.cenas.map((c) => `Cena ${String(c.cena).padStart(2, '0')}: ` + c.falas.map((f) => `${f.quem}: "${f.texto}"`).join(' | ')).join('\n');
    const ultimas = [
      (ganchoHeader || choqueFinal || fisgadaFinal)
        ? `GANCHO/CHOQUE EXATO COM QUE A PARTE ${partAnt} TERMINOU (A CENA 01 DA PARTE ${parte} DEVE PARTIR DIRETAMENTE DAQUI):\n- Final-fisgada: ${ganchoHeader}\n- Choque/Fisgada final: ${choqueFinal || fisgadaFinal}`
        : '',
      blocos.length ? `ÚLTIMAS 3 CENAS COMPLETAS DA PARTE ${partAnt}:\n${blocos.slice(-3).map((b) => b.trim()).join('\n\n')}` : '(roteiro anterior não encontrado)',
      resumoFalasAnt ? `RESUMO DE TODOS OS DIÁLOGOS DA PARTE ${partAnt} (para não repetir discussão nem contradizer fatos):\n${resumoFalasAnt}` : '',
    ].filter(Boolean).join('\n\n');
    const cat = lerJson(path.join(this.seriesDir, slug, 'catalogo_refs.json'), {});
    let refs = [
      ...Object.entries(cat.personagens || {}).map(([k, v]) => `{${k}} -> ${v}`),
      ...Object.entries(cat.cenarios || {}).map(([k, v]) => `{${k}} -> ${v}`),
    ].join('\n');
    if (!refs) {
      const prm1 = lerTexto(path.join(this.prontosDir, slug, 'parte_01', 'prompts_flow.txt')) || '';
      const m = prm1.match(/BLOCO\s*1[^\n]*\n([\s\S]*?)(?=\n\s*BLOCO\s*2)/i);
      refs = (m ? m[1] : '').trim() || '(catálogo vazio)';
    }
    return { biblia: bibliaTxt, ultimasCenas: ultimas, refs };
  }

  /** CHAMADA A: criação (Parte 1 / história única) ou continuação (Parte 2+). Exportado para teste (sem chamar o Claude). */
  montarPromptChamadaA({ continuacao = false, entrada = '', resumoUsuario = '', config = {}, tipoFinal, parte = 1, slug = '', titulo = '', totalPartes = 2, observacao = '', ajustes = '', job = null } = {}) {
    const secoes = lerSecoesPrompt(this.arquivoPromptMestre);
    const modelo = continuacao ? secoes.chamada_a_continuacao : secoes.chamada_a_criacao;
    if (!modelo) throw new Error(`prompt_mestre_roteirista.md não encontrado (ou sem a seção da Chamada A) em ${this.arquivoPromptMestre}`);
    const seg = Number(config.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const dur = Number(config.duracaoTotalMinutos) || 3;
    const numCenas = calcularNumeroCenas(dur, seg);
    const tf = this.exigirTipoFinal(tipoFinal ?? config.tipoFinal);
    const temResumo = Boolean(String(resumoUsuario || '').trim());
    const textoBusca = [entrada, resumoUsuario, observacao, ajustes, slug, titulo].join(' ');
    const sel = this.fichas.selecionarParaPrompt({ tipoConflito: config.tipoConflito, texto: textoBusca });
    if (job) job.fichasUsadas = sel.fichas.map((f) => ({ id: f.id, titulo: f.titulo, tipoConflito: f.tipoConflito, propria: !!f.propria }));
    const ctx = continuacao ? this.montarContextoContinuacao(slug, parte) : { biblia: '', ultimasCenas: '', refs: '' };
    const preenchido = preencherModelo(modelo, {
      NUM_CENAS: numCenas,
      REGUA: this.reguaPalavrasTexto(seg),
      INSTRUCAO_FINAL: instrucaoTipoFinal(tf, { parte, ehSerie: continuacao || config.formatoHistoria === 'serie' || tf === 'aberto', numCenas }),
      LEIS: secoes.leis_resumo || '',
      FICHAS: this.fichas.blocoParaPrompt(sel, { temResumoUsuario: temResumo }),
      FIDELIDADE: temResumo ? blocoFidelidadeResumo(resumoUsuario) : '',
      ENTRADA: `${String(entrada || '').trim()}${ajustes ? `\n\nAJUSTES PEDIDOS PELO USUÁRIO:\n"""\n${ajustes}\n"""` : ''}`,
      TITULO: titulo || slug, PARTE: parte, TOTAL_PARTES: totalPartes,
      BIBLIA: ctx.biblia, ULTIMAS_CENAS: ctx.ultimasCenas, REFS: ctx.refs,
      OBSERVACAO: observacao ? `OBSERVAÇÃO DO USUÁRIO PARA ESTA PARTE:\n"""\n${observacao}\n"""` : '',
    });
    return [
      'MODO BACKEND STATELESS (1 único turno, sem tools): NÃO faça perguntas nem mostre menu. Entregue direto o material pedido abaixo (`===FILE:roteiro_humano.md=== ... ===END_FILE===` + `===FILE:biblia_serie.json=== ... ===END_FILE===` + `RESULTADO_JSON:`).',
      temResumo ? blocoFidelidadeResumo(resumoUsuario) : '',
      this.descreverConfig({ ...config, tamanhoCenaSegundos: seg, duracaoTotalMinutos: dur }),
      preenchido,
    ].filter(Boolean).join('\n\n');
  }

  /** CHAMADA B (sonnet): formata o material da Chamada A no padrão exato do parser/validador. */
  montarPromptChamadaB({ saidaA = '', config = {}, tipoFinal, parte = 1, slug = '', completo = true, ctxRefs = '' } = {}) {
    const secoes = lerSecoesPrompt(this.arquivoPromptMestre);
    const modelo = secoes.chamada_b_formatacao;
    if (!modelo) throw new Error(`prompt_mestre_roteirista.md sem a seção da Chamada B em ${this.arquivoPromptMestre}`);
    const seg = Number(config.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const numCenas = calcularNumeroCenas(Number(config.duracaoTotalMinutos) || 3, seg);
    const tf = this.exigirTipoFinal(tipoFinal ?? config.tipoFinal);
    // o JSON da bíblia NUNCA vai para dentro do roteiro: sai do texto que a Chamada B recebe
    const semBiblia = String(saidaA).replace(/===FILE:\s*biblia_serie\.json\s*===[\s\S]*?(?:===END_FILE===|$)/i, '').trim();
    const arquivos = completo
      ? 'Devolva TODOS os blocos: `===FILE:roteiro_humano.md===`, `===FILE:continuidade_cenas.md===`, `===FILE:prompts_flow.txt===`, `===FILE:metadata_flow.json===` e `===FILE:legenda_linhas.txt===`. Em cena MUDA, o prompt de vídeo (BLOCO 3) deve conter: `No spoken dialogue in this scene; characters keep their lips closed throughout the entire clip, pure visual storytelling.`'
      : 'Devolva APENAS o bloco `===FILE:roteiro_humano.md===` (NÃO gere prompts_flow.txt agora).';
    return [
      this.cabecalho({ config: { ...config, tamanhoCenaSegundos: seg } }),
      instrucaoTipoFinal(tf, { parte, ehSerie: parte > 1 || tf === 'aberto', numCenas }),
      preencherModelo(modelo, { ARQUIVOS: arquivos, SAIDA_A: semBiblia }),
      ctxRefs,
      `Termine com a última linha exata: RESULTADO_JSON: {"slug":"${slug || '<slug-em-kebab-case>'}","parte":${parte}}`,
    ].filter(Boolean).join('\n\n');
  }

  /**
   * Executa Chamada A (modelo escolhido, padrão sonnet) e tenta normalizar/validar localmente o roteiro + bíblia.
   * Quando `completo === false` (modo Com Aprovação) e o parser local já aprova o roteiro sem erro de validação,
   * NÃO dispara a Chamada B (Etapa 2/2), economizando cota e tempo!
   */
  async rodarDupla(job, { promptA, promptB, modeloA = 'sonnet', completo = false, timeoutA = null, timeoutB = null }) {
    const mA = normalizarModeloClaude(modeloA, 'sonnet');
    const rA = ROTULO_MODELO_CLAUDE[mA];
    const limiteA = (Number.isFinite(Number(timeoutA)) && Number(timeoutA) > 0)
      ? Math.min(Number(timeoutA), TIMEOUT_MAX_CLAUDE_SEG * 1000)
      : this.obterTimeoutClaudeMs(job?.configUsada, TIMEOUT_PADRAO_CLAUDE_SEG);
    const limiteB = (Number.isFinite(Number(timeoutB)) && Number(timeoutB) > 0)
      ? Math.min(Number(timeoutB), TIMEOUT_MAX_CLAUDE_SEG * 1000)
      : this.obterTimeoutClaudeMs(job?.configUsada, 240);
    job.modeloA = mA; job.modeloB = 'sonnet';
    job.etapas = [
      { n: 1, rotulo: 'Escaleta e dramaturgia', modelo: mA, estado: 'rodando' },
      { n: 2, rotulo: completo ? 'Prompts do Flow e formatação' : 'Validação local / ajuste fino', modelo: 'sonnet', estado: 'aguardando' },
    ];
    job.etapa = `Etapa 1/2: Escaleta e dramaturgia (${rA})...`;
    this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
    const textoA = typeof promptA === 'function' ? promptA(job) : promptA;
    const saidaABruta = await this.rodarClaude(job, textoA, { modelo: mA, tipo: `${job.tipo}_ideacao`, etapaRotulo: `Etapa 1/2: Escaleta e dramaturgia (${rA})`, timeoutMs: limiteA });
    if (job.estado === 'cancelado') return '';
    const saidaA = normalizarSaidaRoteiroChamadaA(saidaABruta);
    job.saidaA = saidaA;
    job.etapas[0].estado = 'ok';
    const arqsA = extrairArquivosDelimitados(saidaA);
    if (arqsA['biblia_serie.json']) job.bibliaRicaTxt = arqsA['biblia_serie.json'];

    // Corte de chamada extra desnecessária (Etapa 2/2): se o parser local já extraiu e validou roteiro_humano.md sem erro
    const temRoteiroCompletoA = Boolean(arqsA['roteiro_humano.md'] && temEstruturaRoteiroCompleta(arqsA['roteiro_humano.md']));
    const temPromptsA = Boolean(arqsA['prompts_flow.txt']);
    if (temRoteiroCompletoA && (!completo || temPromptsA)) {
      try {
        const gravA = this.gravarArquivosExtraidosNoDisco(job, saidaA);
        if (gravA.slug) {
          const apenasRoteiro = !completo;
          const seg = Number(job.tamanhoCenaSegundos) === 10 ? 10 : 15;
          const valA = this.validarParte(gravA.slug, gravA.parte, { apenasRoteiro, seg });
          const pastaParte = job.pastaParte || path.join(this.prontosDir, gravA.slug, nomeParte(gravA.parte));
          const rotDisco = lerTexto(path.join(pastaParte, 'roteiro_humano.md')) || '';
          const verifFinal = job.tipoFinal && rotDisco ? verificarTipoFinalRoteiro(rotDisco, job.tipoFinal) : { ok: true };
          if (valA.ok && (apenasRoteiro || !valA.faltaLegenda) && verifFinal.ok) {
            job.etapas[1].estado = 'ok';
            job.etapas[1].rotulo = 'Formatação validada pelo parser local (0 tokens extras)';
            job.etapas[1].modelo = null;
            job.etapa = 'Roteiro validado localmente na 1ª chamada (Etapa 2/2 poupada)';
            this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
            return saidaA;
          }
        }
      } catch {}
    }

    job.etapas[1].estado = 'rodando';
    job.etapa = 'Etapa 2/2: Formatação e ajuste fino (Sonnet)...';
    job.saida = `${job.saida.trimEnd()}\n\n==================== ETAPA 2/2 · FORMATAÇÃO E AJUSTE FINO (Sonnet) ====================\n`;
    this.broadcast({ type: 'fabrica_job', job: this.jobPublico(job) });
    const textoB = typeof promptB === 'function' ? promptB(saidaA, job) : promptB;
    const saidaB = await this.rodarClaude(job, textoB, { modelo: 'sonnet', tipo: job.tipo, etapaRotulo: 'Etapa 2/2: Formatação e ajuste fino (Sonnet)', timeoutMs: limiteB });
    job.etapas[1].estado = 'ok';
    return saidaB;
  }

  /** Guarda a bíblia rica da Chamada A em series/<slug>/biblia_serie.json (campo bibliaRica) e uma cópia na pasta da parte. NUNCA dentro do roteiro. */
  gravarBibliaRica(job, slug, parte, pastaParte) {
    const txtJson = job.bibliaRicaTxt;
    if (!txtJson) return false;
    const rica = extrairJsonDaResposta(txtJson);
    if (!rica) { this.log('Fábrica: a bíblia (JSON) da Chamada A veio inválida — ignorada (o roteiro não foi afetado).', 'aviso'); return false; }
    try { fs.writeFileSync(path.join(pastaParte, 'biblia_rica.json'), JSON.stringify(rica, null, 2), 'utf8'); } catch {}
    const pastaSerie = path.join(this.seriesDir, slug);
    if (fs.existsSync(path.join(pastaSerie, 'biblia_serie.json')) || job.tipoFinal === 'aberto' || parte > 1) {
      fs.mkdirSync(pastaSerie, { recursive: true });
      const bp = path.join(pastaSerie, 'biblia_serie.json');
      const b = lerJson(bp, { titulo: rica.titulo || slug, slug, partes: [] });
      b.bibliaRica = rica;
      if (!b.premissa && rica.premissa) b.premissa = rica.premissa;
      if (!b.universoSocial && rica.universo) b.universoSocial = rica.universo;
      escreverJsonAtomico(bp, b);
    }
    return true;
  }

  // =====================================================================
  //  FICHAS VIRAIS
  // =====================================================================
  /** Cadastra ficha por LINK viral (yt-dlp + whisper locais) ou por TRANSCRIÇÃO colada, com 1 chamada sonnet curta. */
  extrairFicha({ link = '', transcricao = '', contexto = '', tipoConflito = null, views = 0, retencao3s = 0, retencao30s = 0, propria = false } = {}) {
    this.exigirFabrica();
    const url = String(link || '').trim();
    const texto = String(transcricao || '').trim();
    if (!url && texto.length < 40) throw new Error('Cole um link viral (Facebook, Instagram, TikTok, YouTube) ou a transcrição do vídeo (mín. 40 caracteres).');
    return this.iniciarJob({
      tipo: 'ficha', titulo: url ? 'Ficha viral (link)' : 'Ficha viral (transcrição)', escrita: false, extra: { modeloUnico: 'sonnet' },
      preparo: async (job) => {
        if (url) {
          job.pastaMidia = await this.extrairVideoLocal(url, job);
          job.transcricaoViral = lerTexto(path.join(job.pastaMidia, 'transcricao.txt')) || lerTexto(path.join(job.pastaMidia, 'RESUMO.md')) || '';
        } else job.transcricaoViral = texto;
        if (String(job.transcricaoViral).trim().length < 40) throw new Error('Não consegui obter a transcrição desse vídeo (sem fala ou sem legenda).');
      },
      prompt: (job) => this.fichas.montarPromptExtracao({ transcricao: job.transcricaoViral, contexto }),
      posClaude: async (job) => {
        const f = this.fichas.fichaDaResposta(job.saida, { origem: url ? 'link' : 'transcricao', url, propria, views, retencao3s, retencao30s, tipoConflito });
        job.fichaCriada = { id: f.id, titulo: f.titulo, tipoConflito: f.tipoConflito };
        if (job.pastaMidia) { try { fs.rmSync(job.pastaMidia, { recursive: true, force: true }); } catch {} }
        this.log(`🎯 Ficha viral criada: "${f.titulo}" (${f.tipoConflito}).`, 'ok');
      },
    });
  }

  /** Promove uma novela PRÓPRIA campeã (do Estúdio ou da Fábrica) a ficha de referência — 0 tokens. */
  promoverNovelaEmFicha({ novelaId = null, slug = '', parte = 1, views = 0, retencao3s = 0, retencao30s = 0, tipoConflito = null } = {}) {
    this.exigirFabrica();
    let s = String(slug || ''); let p = Number(parte) || 1; let titulo = '';
    const n = novelaId ? this.store.obter(novelaId) : null;
    if (novelaId && !n) throw new Error('Novela não encontrada.');
    if (n) { s = n.serieSlug || s; p = n.numeroParte || p; titulo = n.nome || ''; }
    if (!/^[a-z0-9][a-z0-9_-]*$/i.test(s)) throw new Error('Esta novela não veio da Fábrica (sem roteiro_humano.md): escolha uma parte pronta.');
    const rot = (n?.roteiroHumano) || lerTexto(path.join(this.prontosDir, s, nomeParte(p), 'roteiro_humano.md'));
    if (!rot) throw new Error('Não achei o roteiro_humano.md desta novela.');
    const existente = this.fichas.listar().find((f) => f.novelaRef && f.novelaRef.slug === s && Number(f.novelaRef.parte) === p);
    const dados = this.fichas.fichaDeRoteiro(rot, { views, retencao3s, retencao30s, tipoConflito, slug: s, parte: p, titulo: titulo && !/—\s*Parte/i.test(titulo) ? titulo : '' });
    if (existente) return this.fichas.atualizar(existente.id, { ...dados, id: existente.id, views, retencao3s, retencao30s, tipoConflito: tipoConflito || existente.tipoConflito });
    return this.fichas.criar(dados);
  }

  descreverConfig(c) {
    const seg = Number(c.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const dur = Number(c.duracaoTotalMinutos) || 3;
    const numCenas = calcularNumeroCenas(dur, seg);
    return `Configuração narrativa obrigatória: duração total ${dur} min, exatamente ${numCenas} cenas de ${seg}s (${numCenas} x ${seg}s), formato ${c.formatoHistoria === 'serie' ? `série de ${c.numeroPartesPadrao} partes (roteiro cena a cena SÓ da Parte 1)` : 'história única'}.`;
  }

  // ---------- Estado persistente do fluxo "Com Aprovação" ----------
  arqEstadoCriador() {
    return this.store?.dadosDir ? path.join(this.store.dadosDir, 'fabrica_criador_estado.json') : null;
  }
  roteiroPendenteMaisRecente() {
    if (!fs.existsSync(this.prontosDir)) return null;
    let melhor = null;
    for (const slug of fs.readdirSync(this.prontosDir)) {
      const dSlug = path.join(this.prontosDir, slug);
      if (!fs.statSync(dSlug).isDirectory()) continue;
      for (const pd of fs.readdirSync(dSlug)) {
        const m = pd.match(/^parte_(\d+)$/i); if (!m) continue;
        const arqR = path.join(dSlug, pd, 'roteiro_humano.md');
        const arqP = path.join(dSlug, pd, 'prompts_flow.txt');
        if (!fs.existsSync(arqR) || fs.existsSync(arqP)) continue;
        const t = fs.statSync(arqR).mtimeMs;
        if (!melhor || t > melhor.t) melhor = { slug, parte: Number(m[1]), t, arqR };
      }
    }
    return melhor;
  }
  obterEstadoCriador() {
    const p = this.arqEstadoCriador();
    if (!p) return {};
    const est = lerJson(p, {});
    let alterou = false;
    if (est?.wiz?.jobId && !this.jobs.has(est.wiz.jobId)) {
      // O servidor reiniciou: limpa o jobId antigo em memoria e recupera o roteiro do disco (ou limpa wiz se nao houver)
      if (est.wiz.etapa === 'roteiro') {
        const slug = est.wiz.resultado?.slug || this.roteiroPendenteMaisRecente()?.slug || null;
        const parte = Number(est.wiz.resultado?.parte || this.roteiroPendenteMaisRecente()?.parte) || 1;
        const rotTxt = slug ? lerTexto(path.join(this.prontosDir, slug, nomeParte(parte), 'roteiro_humano.md')) : null;
        if (slug && rotTxt) {
          est.wiz = {
            ...est.wiz,
            jobId: null,
            rodando: false,
            estado: 'ok',
            resultado: { slug, parte },
            dialogos: extrairDialogosRoteiro(rotTxt),
          };
        } else {
          est.wiz = null;
        }
      } else if (est.wiz.etapa === 'sementes' && (est.wiz.saida || est.wiz.sementeGerada)) {
        est.wiz = { ...est.wiz, jobId: null, rodando: false, estado: 'ok', validacao: null };
      } else if (est.wiz.estado === 'erro' && (est.wiz.transcricaoViral || est.wiz.erro)) {
        est.wiz = { ...est.wiz, jobId: null, rodando: false, estado: 'erro' };
      } else {
        est.wiz = null;
      }
      alterou = true;
    }
    // Se estiver na etapa de sementes e a caixa `semente` estiver vazia mas houver saida valida em wiz, preenche automaticamente!
    if (est?.wiz?.etapa === 'sementes') {
      if (est.wiz.validacao) {
        delete est.wiz.validacao;
        alterou = true;
      }
      const semLimpa = extrairSementeLimpaDeSaida(
        est.wiz.sementeGerada || est.wiz.resultado?.semente || est.wiz.saida || '',
        { transcricaoViral: est.wiz.transcricaoViral || est.transcricaoViral || '' }
      );
      if (semLimpa && (!est.semente || !String(est.semente).trim())) {
        est.semente = semLimpa;
        est.wiz.sementeGerada = semLimpa;
        alterou = true;
      }
    }
    if (alterou) escreverJsonAtomico(p, est);
    return est;
  }
  salvarEstadoCriador(patch = {}) {
    const p = this.arqEstadoCriador();
    if (!p) return {};
    const atual = lerJson(p, {});
    const novo = patch && patch.__limpar ? {} : { ...atual, ...patch, atualizadoEm: new Date().toISOString() };
    if (novo?.wiz?.jobId && !this.jobs.has(novo.wiz.jobId)) {
      novo.wiz = { ...novo.wiz, jobId: null, rodando: false };
    }
    if (novo?.wiz?.etapa === 'sementes') {
      if (novo.wiz.validacao) delete novo.wiz.validacao;
      const semLimpa = extrairSementeLimpaDeSaida(
        novo.wiz.sementeGerada || novo.wiz.resultado?.semente || novo.wiz.saida || '',
        { transcricaoViral: novo.wiz.transcricaoViral || novo.transcricaoViral || '' }
      );
      if (semLimpa && (!novo.semente || !String(novo.semente).trim())) {
        novo.semente = semLimpa;
        novo.wiz.sementeGerada = semLimpa;
      }
    }
    escreverJsonAtomico(p, novo);
    return novo;
  }

  // Etapa 1 (aprovacao): 5 sementes (ou semente adaptada de link)
  criarSementes({ origem, texto = '', link = '', config = {}, forcarReextracao = false }) {
    const c = this.salvarConfigFabrica(config);
    return this.iniciarJob({
      tipo: 'sementes', titulo: origem === 'link' ? 'Adaptar vídeo viral (semente)' : 'Sementes anti-clichê', escrita: false,
      preparo: async (job) => {
        if (origem === 'link') {
          await this.obterOuExtrairTranscricaoViral(link, job, { forcar: !!forcarReextracao });
        }
      },
      posClaude: async (job, saidaClaude) => {
        const sementeGerada = extrairSementeLimpaDeSaida(saidaClaude || job.saida, { transcricaoViral: job.transcricaoViral });
        job.sementeGerada = sementeGerada;
        job.validacao = null;
        job.resultado = {
          semente: sementeGerada,
          transcricaoViral: job.transcricaoViral || null,
          tituloViral: job.tituloViral || null,
          link: link || null,
          origem: origem || 'sementes',
        };
        // Persiste imediatamente a semente gerada no estado do Criador para nunca abrir em branco
        try {
          const pEst = this.arqEstadoCriador();
          if (pEst && fs.existsSync(pEst)) {
            const est = lerJson(pEst, {});
            if (sementeGerada) est.semente = sementeGerada;
            if (job.transcricaoViral) est.transcricaoViral = job.transcricaoViral;
            if (est.wiz) {
              est.wiz.sementeGerada = sementeGerada;
              est.wiz.transcricaoViral = job.transcricaoViral || null;
              est.wiz.validacao = null;
              est.wiz.resultado = job.resultado;
            }
            escreverJsonAtomico(pEst, est);
          }
        } catch {}
        if (origem === 'link' && job.pastaMidia) {
          try { fs.rmSync(job.pastaMidia, { recursive: true, force: true }); } catch {}
          try {
            const hp = path.join(this.dir, 'dados', 'historico_virais.json');
            const h = lerJson(hp, { adaptados: [] });
            h.adaptados = [...(h.adaptados || []), { url: link, titulo: job.tituloViral || null, em: new Date().toISOString() }];
            escreverJsonAtomico(hp, h);
          } catch {}
        }
      },
      prompt: (job) => [
        this.cabecalho({ incluirGuia: false, incluirResultadoJson: false, config: c }), this.descreverConfig(c), '',
        origem === 'resumo' ? blocoFidelidadeResumo(texto) : '',
        'TRÍADE ANTI-CLICHÊ: toda semente exige (1) objeto físico concreto em disputa, (2) vínculo familiar/social claro e (3) ironia plantada que vira contra quem humilhou.',
        origem === 'link'
          ? `ETAPA: adapte o vídeo viral cuja transcrição já está injetada abaixo em UMA semente dramática completa e inédita em PORTUGUÊS DO BRASIL com Tríade Concreta (1. Objeto físico em disputa + 2. Vínculo familiar/social + 3. Ironia plantada e reviravolta final). NÃO escreva o roteiro cena a cena ainda e NÃO escreva RESULTADO_JSON:\n\n${job.transcricaoPromptPronta || `CONTEÚDO TRANSCRITO:\n"""\n${(job.transcricaoViral || '').slice(0, 4200)}\n"""`}`
          : origem === 'resumo'
            ? `ETAPA: estruture o resumo acima mantendo 100% da história, personagens e reviravolta do usuário. NÃO escreva roteiro ainda.`
            : `ETAPA: gere 5 sementes originais numeradas com Tríade Concreta${texto ? ` sobre o tema/pedido: "${texto}"` : ''}. NÃO escreva roteiro ainda.`,
        'Apresente o resultado em português simples e direto, pronto para aprovação.',
      ].filter(Boolean).join('\n'),
    });
  }

  /** Escolha obrigatoria do rumo do final (lanca erro amigavel se ausente). */
  exigirTipoFinal(v) {
    const t = normalizarTipoFinal(v);
    if (!t) throw new Error('Escolha o tipo de final: "🔥 Final Aberto Chocante" ou "✅ A História se Encerra Aqui".');
    return t;
  }

  /** Monta o prompt de criacao de roteiro (exportado para testes locais sem chamar o Claude). */
  montarPromptRoteiro({ semente = '', resumoUsuario = '', origem = '', ajustes = '', config = {}, tipoFinal }) {
    const tf = this.exigirTipoFinal(tipoFinal ?? config.tipoFinal);
    const seg = Number(config.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const dur = Number(config.duracaoTotalMinutos) || 3;
    const numCenas = calcularNumeroCenas(dur, seg);
    const textoBase = String(resumoUsuario || semente || '').trim();
    const temResumoUsuario = Boolean(String(resumoUsuario || '').trim() || origem === 'resumo');
    return [
      temResumoUsuario ? blocoFidelidadeResumo(textoBase) : '',
      this.cabecalho({ config: { ...config, tamanhoCenaSegundos: seg, duracaoTotalMinutos: dur } }),
      this.descreverConfig({ ...config, tamanhoCenaSegundos: seg, duracaoTotalMinutos: dur }),
      instrucaoTipoFinal(tf, { parte: 1, ehSerie: config.formatoHistoria === 'serie', numCenas }),
      `ETAPA: escreva o roteiro cena a cena da Parte 1 com EXATAMENTE ${numCenas} cenas de ${seg}s (CENA 01 até CENA ${String(numCenas).padStart(2, '0')}) e devolva o bloco \`===FILE:roteiro_humano.md=== ... ===END_FILE===\`. NÃO gere prompts_flow.txt ainda.`,
      temResumoUsuario
        ? `RESUMO OBRIGATÓRIO DO USUÁRIO (siga 100% esta história, personagens e reviravolta):\n"""\n${textoBase}\n"""`
        : `SEMENTE APROVADA:\n"""\n${textoBase}\n"""`,
      ajustes ? `AJUSTES PEDIDOS PELO USUÁRIO:\n"""\n${ajustes}\n"""` : '',
      'Termine com a última linha exata: RESULTADO_JSON: {"slug":"<slug-em-kebab-case>","parte":1}',
    ].filter(Boolean).join('\n\n');
  }

  // Etapa 2 (aprovacao): roteiro + Biblia (em "Meu Resumo" entra direto aqui, pulando sementes com custo zero!)
  criarRoteiro({ semente = '', resumoUsuario = '', origem = '', ajustes = '', config = {}, tipoFinal, modeloRoteirista = null }) {
    const textoBase = String(resumoUsuario || semente || '').trim();
    if (!textoBase) throw new Error('Cole/escreva o resumo ou a semente aprovada.');
    const tf = this.exigirTipoFinal(tipoFinal ?? config.tipoFinal);
    const c = this.salvarConfigFabrica(config);
    const seg = Number(c.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const numCenas = calcularNumeroCenas(c.duracaoTotalMinutos, seg);
    const resumoEfetivo = origem === 'resumo' ? textoBase : String(resumoUsuario || '').trim();
    return this.iniciarJob({
      tipo: 'roteiro',
      titulo: `Roteiro (${numCenas} cenas de ${seg}s · ${tf === 'aberto' ? 'final aberto' : 'final fechado'})`,
      escrita: true,
      extra: {
        tipoFinal: tf,
        apenasRoteiro: true,
        resumoOriginalUsuario: resumoEfetivo || textoBase,
        tamanhoCenaSegundos: seg,
        numeroCenas: numCenas,
        configUsada: c,
      },
      dupla: {
        completo: false,
        modeloA: this.modeloRoteirista(c, modeloRoteirista),
        promptA: (job) => this.montarPromptChamadaA({ continuacao: false, entrada: textoBase, resumoUsuario: resumoEfetivo, config: c, tipoFinal: tf, ajustes, job }),
        promptB: (saidaA) => this.montarPromptChamadaB({ saidaA, config: c, tipoFinal: tf, parte: 1, completo: false }),
      },
    });
  }

  // Etapa 3 (aprovacao): prompts + legenda (+ importar)
  criarPrompts({ slug, parte = 1, ajustes = '', importar = true, iniciarFila = false, tipoFinal = null }) {
    this.exigirFabrica();
    const pastaAbs = path.join(this.prontosDir, slug, nomeParte(parte));
    const metaAtual = lerJson(path.join(pastaAbs, 'metadata_flow.json'), {});
    const cfg = this.lerConfigFabrica();
    const tf = normalizarTipoFinal(tipoFinal) || normalizarTipoFinal(metaAtual.tipoFinal);
    const rotAtual = lerTexto(path.join(pastaAbs, 'roteiro_humano.md')) || '';
    const mCenas = rotAtual.match(/^Cenas\s*:\s*(\d+)\s*x\s*(10|15)\s*s/im);
    const seg = mCenas ? Number(mCenas[2]) : (Number(metaAtual.tamanhoCenaSegundos) || cfg.tamanhoCenaSegundos || 15);
    const numCenas = mCenas ? Number(mCenas[1]) : (extrairDialogosRoteiro(rotAtual).cenas.length || calcularNumeroCenas(cfg.duracaoTotalMinutos, seg));
    const ctxRefs = parte > 1 ? this.montarContextoParte1Enxuto(slug, parte, { reaproveitarRefs: true }) : '';
    return this.iniciarJob({
      tipo: 'prompts', titulo: `Prompts + legenda — ${slug} P${parte} (${numCenas}x${seg}s)`, escrita: true, importar, iniciarFila,
      extra: { tipoFinal: tf, slugAlvo: slug, parteAlvo: parte, pastaParte: pastaAbs, tamanhoCenaSegundos: seg, numeroCenas: numCenas, configUsada: { ...cfg, tamanhoCenaSegundos: seg } },
      prompt: [
        this.cabecalho({ config: { ...cfg, tamanhoCenaSegundos: seg } }), '',
        `ETAPA: converta o roteiro aprovado abaixo em \`===FILE:continuidade_cenas.md===\`, \`===FILE:prompts_flow.txt===\` (${numCenas} imagens-base no BLOCO 2 e ${numCenas} vídeos de \`Exactly ${seg} seconds\` no BLOCO 3), \`===FILE:metadata_flow.json===\` e \`===FILE:legenda_linhas.txt===\` (2 a 3 linhas humanas com 1 ou 2 emojis).`,
        rotAtual ? `ROTEIRO APROVADO:\n===FILE:roteiro_humano.md===\n${rotAtual.trim()}\n===END_FILE===` : '',
        ctxRefs,
        tf ? `Grave "tipoFinal": "${tf}" no metadata_flow.json.` : '',
        ajustes ? `AJUSTES: ${ajustes}` : '',
        `A última linha deve ser: RESULTADO_JSON: {"slug":"${slug}","parte":${parte}}`,
      ].filter(Boolean).join('\n\n'),
    });
  }

  // Modo 100% automatico
  criarAutomatico({ origem, texto = '', link = '', config = {}, importar = true, iniciarFila = false, tipoFinal, modeloRoteirista = null }) {
    const tf = this.exigirTipoFinal(tipoFinal ?? config.tipoFinal);
    const c = this.salvarConfigFabrica({ ...config, modoOperacao: 'automatico' });
    const seg = Number(c.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const numCenas = calcularNumeroCenas(c.duracaoTotalMinutos, seg);
    return this.iniciarJob({
      tipo: 'automatico', titulo: origem === 'link' ? 'Automático: adaptar vídeo viral' : `Automático: história nova (${numCenas}x${seg}s)`, escrita: true, importar, iniciarFila,
      extra: { tipoFinal: tf, tamanhoCenaSegundos: seg, numeroCenas: numCenas, configUsada: c },
      preparo: async (job) => {
        if (origem === 'link') {
          await this.obterOuExtrairTranscricaoViral(link, job);
        }
      },
      posClaude: async (job) => {
        this.limparPastaMidiaJob(job);
      },
      dupla: {
        completo: true,
        modeloA: this.modeloRoteirista(c, modeloRoteirista),
        promptA: (job) => this.montarPromptChamadaA({
          continuacao: false,
          entrada: origem === 'link'
            ? `ADAPTAÇÃO DE VÍDEO VIRAL PARA PORTUGUÊS DO BRASIL (use a estrutura dramática, o conflito central e a reviravolta da transcrição injetada abaixo, adaptando para nomes e ambiente brasileiros em ${numCenas} cenas de ${seg}s):\n\n${job.transcricaoPromptPronta || `TRANSCRIÇÃO INJETADA:\n"""\n${(job.transcricaoViral || '').slice(0, 4200)}\n"""`}`
            : origem === 'resumo'
              ? `RESUMO OBRIGATÓRIO DO USUÁRIO:\n"""\n${texto}\n"""`
              : `Crie uma semente anti-clichê forte (objeto concreto + vínculo claro + ironia plantada)${texto ? ` sobre: "${texto}"` : ''} e desenvolva a história completa.`,
          resumoUsuario: origem === 'resumo' ? texto : (origem === 'link' ? (job.transcricaoPromptPronta || job.transcricaoViral || '') : ''),
          config: c, tipoFinal: tf, job,
        }),
        promptB: (saidaA) => this.montarPromptChamadaB({ saidaA, config: c, tipoFinal: tf, parte: 1, completo: true }),
      },
    });
  }

  // Continuar serie
  gerarParte(slug, { parte = null, importar = true, iniciarFila = false, tipoFinal, observacao = '', modeloRoteirista = null } = {}) {
    this.exigirFabrica();
    const tf = this.exigirTipoFinal(tipoFinal);
    const serie = this.listarSeries().find((s) => s.slug === slug);
    if (!serie) throw new Error('Série não encontrada.');
    const alvo = parte || serie.proximaParte || (serie.totalPartes + 1);
    if (alvo > 1 && !serie.partes.find((p) => p.parte === alvo - 1 && p.status === 'pronta')) throw new Error(`A Parte ${alvo - 1} ainda não está pronta.`);
    if (serie.partes.find((p) => p.parte === alvo && p.status === 'pronta')) throw new Error(`A Parte ${alvo} já está pronta — use "🔄 Gerar Novamente" no card dela.`);
    const pastaAlvo = path.join(this.prontosDir, slug, nomeParte(alvo));
    const cfg = this.lerConfigFabrica();
    const seg = Number(cfg.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const numCenas = calcularNumeroCenas(cfg.duracaoTotalMinutos, seg);
    const ctxEnxuto = this.montarContextoParte1Enxuto(slug, alvo, { reaproveitarRefs: true });
    return this.iniciarJob({
      tipo: 'serie', titulo: `Gerar Parte ${alvo} — ${serie.titulo} (${tf === 'aberto' ? 'final aberto' : 'encerra aqui'})`, escrita: true, importar, iniciarFila,
      extra: { tipoFinal: tf, slugAlvo: slug, parteAlvo: alvo, pastaParte: pastaAlvo, tamanhoCenaSegundos: seg, numeroCenas: numCenas, configUsada: cfg },
      dupla: {
        modeloA: this.modeloRoteirista(cfg, modeloRoteirista),
        promptA: (job) => this.montarPromptChamadaA({
          continuacao: true, config: cfg, tipoFinal: tf, parte: alvo, slug, titulo: serie.titulo,
          totalPartes: Math.max(serie.totalPartes || alvo, alvo), observacao, job,
        }),
        promptB: (saidaA) => this.montarPromptChamadaB({ saidaA, config: cfg, tipoFinal: tf, parte: alvo, slug, completo: true, ctxRefs: ctxEnxuto }),
      },
    });
  }

  /** Prompt do "🔄 Gerar Novamente" (exportado para teste, sem chamar o Claude). */
  montarPromptRegerar({ slug, parte, tipoFinal, observacao = '', reaproveitarRefs = true, temPrompts = false, ehSerie = false, bl1Inline = '', config = null }) {
    const pasta = `prontos_para_flow/${slug}/${nomeParte(parte)}`;
    const cfg = config || (this.existe ? this.lerConfigFabrica() : { modoGeracaoVideo: 'elementos', tamanhoCenaSegundos: 15, duracaoTotalMinutos: 3 });
    const seg = Number(cfg.tamanhoCenaSegundos) === 10 ? 10 : 15;
    const numCenas = calcularNumeroCenas(cfg.duracaoTotalMinutos, seg);
    const ctxEnxuto = (parte > 1 || reaproveitarRefs || ehSerie)
      ? this.montarContextoParte1Enxuto(slug, parte, { reaproveitarRefs, bl1Inline })
      : 'PROIBIDO varrer pastas antigas ou `_versoes/` com Read/Glob/Grep.';
    return [
      this.cabecalho({ config: cfg }), '',
      instrucaoTipoFinal(tipoFinal, { parte, ehSerie: ehSerie || parte > 1, numCenas }), '',
      `ETAPA: REESCREVER do zero a ${parte > 1 ? `PARTE ${parte} da série "${slug}"` : `história "${slug}"`} (${numCenas} cenas de ${seg}s). A pasta ${pasta}/ foi ESVAZIADA de propósito: a versão anterior foi movida para ${pasta}/_versoes/ e é PROIBIDO ler ou copiar qualquer arquivo de _versoes/ ou de pastas antigas.`,
      `Devolva em 1 único turno os blocos \`===FILE:roteiro_humano.md===\`, \`===FILE:continuidade_cenas.md===\`, \`===FILE:prompts_flow.txt===\`, \`===FILE:metadata_flow.json===\` e \`===FILE:legenda_linhas.txt===\`, respeitando a régua de ${seg === 10 ? '14–25 palavras (meta 18–21, máx. 20 em 3 falas, ≥85% das cenas com 2 falas A->B)' : '23–30 palavras (máx. 27 em 3 falas)'} e as 5 leis acima.`,
      parte > 1 ? `Mantenha continuidade direta com os diálogos da Parte 1 colados abaixo.` : '',
      reaproveitarRefs
        ? `REAPROVEITAR PERSONAGENS/CENÁRIOS (obrigatório): mantenha EXATAMENTE os mesmos IDs {ref_xxx}${temPrompts ? ' e copie LITERALMENTE as linhas do BLOCO 1 coladas abaixo' : ''} para reaproveitar no Estúdio com 0 créditos. Só crie ref NOVO se a observação do usuário exigir personagem/cenário inédito.`
        : 'Você pode criar novos personagens/cenários (refs novos) se melhorar a história.',
      ctxEnxuto,
      String(observacao || '').trim() ? `OBSERVAÇÃO RÁPIDA DO USUÁRIO:\n"""${String(observacao).trim()}"""` : '',
      `A última linha deve ser: RESULTADO_JSON: {"slug":"${slug}","parte":${parte}}`,
    ].filter(Boolean).join('\n');
  }

  /** "🔄 Gerar Novamente": reescreve um rascunho ou parte pronta (com backup da versao anterior e zero perda de arquivos parciais). */
  regerarParte({ slug, parte = 1, tipoFinal, observacao = '', reaproveitarRefs = true, importar = true, iniciarFila = false, modeloRoteirista = null, apenasRoteiro = undefined } = {}) {
    this.exigirFabrica();
    const tf = this.exigirTipoFinal(tipoFinal);
    if (!/^[a-z0-9][a-z0-9_-]*$/i.test(String(slug || ''))) throw new Error('Slug inválido.');
    const p = Number(parte) || 1;
    const pasta = path.join(this.prontosDir, slug, nomeParte(p));
    if (!fs.existsSync(pasta)) throw new Error(`Não achei a pasta ${slug}/${nomeParte(p)} em prontos_para_flow.`);
    const existente = this.novelaImportada(slug, p);
    if (existente && this.runner?.rodando && this.runner.novelaAtual === existente.id) throw new Error('Esta parte está rodando na fila do Flow. Pause antes de reescrever.');
    if (this.jobAtivoDaParte(slug, p)) throw new Error('Esta parte JÁ está sendo reescrita pelo Claude. Espere terminar (ou cancele a tarefa).');
    const temPrompts = fs.existsSync(path.join(pasta, 'prompts_flow.txt'));
    const cfgAtual = this.lerConfigFabrica();
    // Respeito estrito ao modo "Com Aprovação": para na revisão do roteiro e NÃO avança sozinho para gerar prompts_flow.txt sem aprovação explícita
    const modoApenasRoteiro = Boolean(apenasRoteiro) || (
      apenasRoteiro !== false &&
      cfgAtual.modoOperacao === 'aprovacao' &&
      (!importar || !temPrompts || !existente)
    );
    const importarEfetivo = modoApenasRoteiro ? false : Boolean(importar);
    const ARQUIVOS = ['roteiro_humano.md', 'continuidade_cenas.md', 'prompts_flow.txt', 'metadata_flow.json', 'legenda_facebook.txt', 'status_flowstudio.json'];
    return this.iniciarJob({
      tipo: 'regerar', titulo: `🔄 Gerar Novamente — ${slug} P${p} (${tf === 'aberto' ? 'final aberto' : 'encerra aqui'})`, escrita: true, maxTurns: 8,
      importar: importarEfetivo, iniciarFila: importarEfetivo && iniciarFila && !existente,
      extra: {
        tipoFinal: tf,
        apenasRoteiro: modoApenasRoteiro,
        tamanhoCenaSegundos: Number(cfgAtual.tamanhoCenaSegundos) === 10 ? 10 : 15,
        atualizarExistente: !!existente,
        slugAlvo: slug,
        parteAlvo: p,
        pastaParte: pasta,
      },
      preparo: async (job) => {
        const destino = path.join(pasta, '_versoes', `v_${new Date().toISOString().replace(/[:.]/g, '-')}`);
        fs.mkdirSync(destino, { recursive: true });
        const movidos = [];
        for (const f of ARQUIVOS) {
          const o = path.join(pasta, f);
          if (!fs.existsSync(o)) continue;
          try { fs.renameSync(o, path.join(destino, f)); } catch { fs.copyFileSync(o, path.join(destino, f)); fs.unlinkSync(o); }
          movidos.push(f);
        }
        const bk = path.join(pasta, 'bloco1_refs_backup.txt');
        if (reaproveitarRefs) {
          const antigo = lerTexto(path.join(destino, 'prompts_flow.txt')) || '';
          const m = antigo.match(/BLOCO\s*1[^\n]*\n([\s\S]*?)(?=\n\s*BLOCO\s*2)/i);
          const metaAnt = lerJson(path.join(destino, 'metadata_flow.json'), {});
          const bl1Txt = (m ? m[1] : '').trim();
          job.bloco1Texto = bl1Txt;
          if (bl1Txt) fs.writeFileSync(bk, `${bl1Txt}\n`);
          job.refsBackup = { linhas: bl1Txt ? bl1Txt.split('\n').filter((l) => l.trim()).length : 0, referenciasNovas: metaAnt.referenciasNovas || [], referenciasHerdadasDaParte1: metaAnt.referenciasHerdadasDaParte1 || [] };
        }
        job.backup = destino;
        job.movidos = movidos;
        this.log(`Fábrica: versão anterior de ${slug}/${nomeParte(p)} MOVIDA para _versoes/${path.basename(destino)} (${movidos.join(', ') || 'nada'}).`, 'aviso');
        job.restaurar = (motivo) => {
          // NUNCA sobrescreve/destroi arquivos gerados na tentativa atual: se ainda houver parciais na pasta, arquiva primeiro em _versoes/parcial_*
          if (!job.parcialSalvoEm) {
            const parcial = this.arquivarParciaisDaPasta(pasta, 0);
            if (parcial) { job.parcialSalvoEm = parcial.pasta; job.arquivosParciais = parcial.arquivos; }
          }
          for (const f of movidos) {
            const o = path.join(destino, f); const d = path.join(pasta, f);
            if (fs.existsSync(o)) fs.copyFileSync(o, d);
          }
          try { fs.rmSync(bk, { force: true }); } catch {}
          job.restaurado = true;
          this.log(`🔴 Gerar Novamente FALHOU em ${slug}/${nomeParte(p)}: ${motivo}. A versão anterior foi restaurada.`, 'erro');
        };
        job.verificar = () => {
          const rot = path.join(pasta, 'roteiro_humano.md');
          if (!fs.existsSync(rot)) throw new Error('O Claude terminou SEM escrever o novo roteiro_humano.md');
          if (fs.statSync(rot).mtimeMs < new Date(job.iniciadoEm).getTime() - 1000) throw new Error('O roteiro_humano.md não foi reescrito');
          if (!modoApenasRoteiro && !fs.existsSync(path.join(pasta, 'prompts_flow.txt'))) {
            throw new Error('O Claude escreveu o roteiro mas não gerou o prompts_flow.txt');
          }
          try { fs.rmSync(bk, { force: true }); } catch {}
        };
      },
      dupla: {
        completo: !modoApenasRoteiro,
        modeloA: this.modeloRoteirista(null, modeloRoteirista),
        promptA: (job) => {
          const cfg0 = this.lerConfigFabrica();
          const biblia0 = lerJson(path.join(this.seriesDir, slug, 'biblia_serie.json'), null)
            || lerJson(path.join(job.backup || '', 'biblia_rica.json'), null);
          const antigo = lerTexto(path.join(job.backup || '', 'roteiro_humano.md')) || '';
          const pega = (re) => (antigo.match(re) || [])[1] || '';

          // Recupera o resumo original do usuario (de resumo_original.txt, do estado do Criador ou do enredo completo do roteiro anterior)
          let resumoOriginal = lerTexto(path.join(pasta, 'resumo_original.txt'))
            || lerTexto(path.join(this.prontosDir, slug, 'resumo_original.txt'))
            || lerTexto(path.join(job.backup || '', 'resumo_original.txt'))
            || '';
          if (!resumoOriginal.trim()) {
            const estCriador = this.obterEstadoCriador();
            if (estCriador?.texto && (estCriador?.wiz?.resultado?.slug === slug || slugDeTitulo(estCriador.texto) === slug || estCriador.origem === 'resumo')) {
              resumoOriginal = String(estCriador.texto).trim();
            }
          }

          // Extrai tambem todos os fatos estruturais e escada de novidades da versao anterior para NUNCA perder o enredo
          const novidadesAntigas = [...antigo.matchAll(/^##\s*CENA\s*0*(\d+)[^\n]*\n[\s\S]*?^Novidade:\s*(.+)$/gim)]
            .map((m) => `Cena ${String(m[1]).padStart(2, '0')}: ${m[2].trim()}`)
            .join('\n');
          const persAntigos = [...antigo.matchAll(/^-\s*([A-ZÀ-Ú0-9 .'-]+\s*\|[^\n]+)$/gim)]
            .map((m) => `- ${m[1].trim()}`)
            .join('\n');

          const premissa = [
            pega(/^#\s+(.+)$/m) ? `Título anterior: ${pega(/^#\s+(.+)$/m)}` : '',
            pega(/^Universo:\s*(.+)$/im) ? `Universo: ${pega(/^Universo:\s*(.+)$/im)}` : '',
            pega(/^Rela[cç][aã]o exata:\s*(.+)$/im) ? `Relação exata: ${pega(/^Rela[cç][aã]o exata:\s*(.+)$/im)}` : '',
            pega(/^Conflito concreto:\s*(.+)$/im) ? `Conflito concreto: ${pega(/^Conflito concreto:\s*(.+)$/im)}` : '',
            pega(/^-?\s*Quem [eé] quem:\s*(.+)$/im) ? `Quem é quem: ${pega(/^-?\s*Quem [eé] quem:\s*(.+)$/im)}` : '',
            pega(/^-?\s*Por que agora:\s*(.+)$/im) ? `Por que agora: ${pega(/^-?\s*Por que agora:\s*(.+)$/im)}` : '',
            pega(/^-?\s*Regra\/acordo em jogo:\s*(.+)$/im) ? `Regra/acordo em jogo: ${pega(/^-?\s*Regra\/acordo em jogo:\s*(.+)$/im)}` : '',
            pega(/^Final-fisgada[^:]*:\s*(.+)$/im) ? `Final-fisgada: ${pega(/^Final-fisgada[^:]*:\s*(.+)$/im)}` : '',
            pega(/^Teste da Dona Maria:\s*(.+)$/im) ? `Resumo Dona Maria: ${pega(/^Teste da Dona Maria:\s*(.+)$/im)}` : '',
            persAntigos ? `Personagens e refs:\n${persAntigos}` : '',
            novidadesAntigas ? `Fatos cena a cena da história:\n${novidadesAntigas}` : '',
            biblia0?.premissa || biblia0?.logline ? `Premissa da série: ${biblia0.premissa || biblia0.logline}` : '',
          ].filter(Boolean).join('\n');

          const resumoParaFidelidade = resumoOriginal.trim() || premissa;
          const entrada = `REESCREVA ${p > 1 ? `a PARTE ${p} da série` : 'a história'} "${slug}" mantendo 100% FIELMENTE todos os fatos, personagens, objetos, motivações, sacrifícios e reviravolta do resumo original (é PROIBIDO inventar outro enredo, cartão estourado, lanchonete ou subtrama estranha!), mas elevando a dramaturgia, a naturalidade das falas e a reação viva de quem escuta.\n${premissa || '(use fielmente o resumo do usuário)'}`;
          return this.montarPromptChamadaA({
            continuacao: p > 1,
            entrada,
            resumoUsuario: resumoParaFidelidade,
            config: cfg0,
            tipoFinal: tf,
            parte: p,
            slug,
            titulo: biblia0?.titulo || slug,
            totalPartes: Math.max(biblia0?.totalPartes || p, p),
            observacao,
            job,
          });
        },
        promptB: (saidaA, job) => this.montarPromptChamadaB({
          saidaA,
          config: this.lerConfigFabrica(),
          tipoFinal: tf,
          parte: p,
          slug,
          completo: !modoApenasRoteiro,
          ctxRefs: (reaproveitarRefs || p > 1) ? this.montarContextoParte1Enxuto(slug, p, { reaproveitarRefs: !!reaproveitarRefs, bl1Inline: job.bloco1Texto || '' }) : '',
        }),
      },
    });
  }

  /** Atualiza a novela ja importada com os novos prompts, preservando itens identicos (refs ja geradas = 0 creditos). */
  atualizarNovelaImportada(n, slug, parte) {
    const pasta = path.join(this.prontosDir, slug, nomeParte(parte));
    const promptsTxt = lerTexto(path.join(pasta, 'prompts_flow.txt'));
    if (!promptsTxt) throw new Error('prompts_flow.txt novo não encontrado.');
    const meta = lerJson(path.join(pasta, 'metadata_flow.json'), {});
    let conv = converterPromptsParaEstudio(promptsTxt);
    const declaradas = new Set(conv.declaradas);
    const semDecl = conv.usadas.filter((u) => /^ref_/.test(u) && !declaradas.has(u));
    const extras = this.declaracoesHerdadas(slug, parte, semDecl, meta).filter((d) => !declaradas.has(d.id));
    if (extras.length) conv = converterPromptsParaEstudio(promptsTxt, extras);
    if (typeof this.reprocessarNovela !== 'function') throw new Error('Reprocessamento indisponível.');
    this.reprocessarNovela(n, conv.texto);
    const atual = this.store.obter(n.id) || n;
    if (parte > 1) this.herdarReferencias(atual, { salvar: false });
    const padroes = this.padroesEstudio();
    if (!atual.qualidadeCustomizadaManualmente) {
      if (padroes.modeloImagem) atual.modeloImagem = padroes.modeloImagem;
      if (padroes.modeloVideo) atual.modeloVideo = padroes.modeloVideo;
      if (padroes.qualidadeGeracaoVideo) atual.qualidadeGeracaoVideo = padroes.qualidadeGeracaoVideo;
      if (padroes.qualidadeDownloadVideo) atual.qualidadeDownloadVideo = padroes.qualidadeDownloadVideo;
      if (padroes.qualidadeDownloadImagem) atual.qualidadeDownloadImagem = padroes.qualidadeDownloadImagem;
    }
    atual.legendaFacebook = (lerTexto(path.join(pasta, 'legenda_facebook.txt')) || meta.legendaFacebook || atual.legendaFacebook || '').trim();
    atual.legendaEnviadaWhatsappEm = null;
    atual.roteiroHumano = lerTexto(path.join(pasta, 'roteiro_humano.md')) || atual.roteiroHumano || '';
    if (meta.titulo) atual.nome = meta.titulo;
    atual.totalPartes = meta.totalPartes || atual.totalPartes;
    const ehSerie = Boolean(meta.formato !== 'unica' && ((atual.totalPartes || 1) > 1 || parte > 1 || (meta.serie && (atual.totalPartes || 1) > 1) || meta.tipoFinal === 'aberto'));
    atual.serie = ehSerie;
    atual.formatoHistoria = ehSerie ? 'serie' : 'unica';
    this.store.salvar(atual);
    this.emitirNovela(atual);
    const preservados = (atual.itens || []).filter((i) => i.status === 'concluido').length;
    const pendentes = (atual.itens || []).filter((i) => i.status !== 'concluido').length;
    this.log(`Fábrica: "${atual.nome}" reescrita e atualizada no Estúdio — ${preservados} item(ns) reaproveitado(s), ${pendentes} para gerar.`, 'ok');
    return { preservados, pendentes };
  }

  /** "👁️ Ler Só Diálogos": falas das cenas do roteiro_humano.md. */
  dialogos(slug, parte = 1) {
    this.exigirFabrica();
    if (!/^[a-z0-9][a-z0-9_-]*$/i.test(String(slug || ''))) throw new Error('Slug inválido.');
    const pasta = path.join(this.prontosDir, slug, nomeParte(Number(parte) || 1));
    if (this.jobAtivoDaParte(slug, Number(parte) || 1)) throw new Error('⏳ O Claude está reescrevendo esta parte agora. Espere terminar para ler os diálogos novos (o roteiro antigo já foi guardado em _versoes).');
    const txt = lerTexto(path.join(pasta, 'roteiro_humano.md'));
    if (!txt) throw new Error('Esta parte ainda não tem roteiro_humano.md.');
    const meta = lerJson(path.join(pasta, 'metadata_flow.json'), {});
    const d = extrairDialogosRoteiro(txt);
    const verif = verificarTipoFinalRoteiro(txt, null);
    return { slug, parte: Number(parte) || 1, roteiroAtualizadoEm: fs.statSync(path.join(pasta, 'roteiro_humano.md')).mtime.toISOString(), ...d, tipoFinal: normalizarTipoFinal(meta.tipoFinal) || (verif.parte < verif.total ? 'aberto' : 'fechado') };
  }

  /**
   * Edicao inline de uma fala no `roteiro_humano.md` (zero chamada ao Claude CLI).
   * Salva o arquivo atualizado e ressincroniza `continuidade_cenas.md`.
   */
  editarFalaRoteiro({ slug, parte = 1, cena, falaIndex = 0, texto, emocao = null } = {}) {
    this.exigirFabrica();
    if (!/^[a-z0-9][a-z0-9_-]*$/i.test(String(slug || ''))) throw new Error('Slug inválido.');
    const p = Number(parte) || 1;
    if (this.jobAtivoDaParte(slug, p)) throw new Error('⏳ O Claude está reescrevendo esta parte agora.');
    const pasta = path.join(this.prontosDir, slug, nomeParte(p));
    const arqRoteiro = path.join(pasta, 'roteiro_humano.md');
    const txtAtual = lerTexto(arqRoteiro);
    if (!txtAtual) throw new Error('Esta parte ainda não tem roteiro_humano.md.');

    const novoTxt = editarFalaEmRoteiroTexto(txtAtual, { cena, falaIndex, texto, emocao });
    fs.writeFileSync(arqRoteiro, novoTxt, 'utf8');

    const tabAuto = gerarTabelaContinuidadeDeRoteiro(novoTxt);
    if (tabAuto) {
      fs.writeFileSync(path.join(pasta, 'continuidade_cenas.md'), tabAuto, 'utf8');
    }

    const d = this.dialogos(slug, p);
    // Atualiza tambem o estado salvo do Criador se pertencer a este mesmo slug/parte
    try {
      const est = this.lerEstadoCriador();
      if (est?.wiz?.resultado?.slug === slug && (Number(est?.wiz?.resultado?.parte) || 1) === p) {
        est.wiz.dialogos = d;
        this.salvarEstadoCriador(est);
      }
    } catch {}

    this.log(`Fábrica: fala #${Number(falaIndex) + 1} da Cena ${String(cena).padStart(2, '0')} (${slug}) atualizada inline sem gastar cota do Claude.`, 'ok');
    return d;
  }

  // ---------- agendamento viral ----------
  agendamento() {
    this.exigirFabrica();
    const fontes = lerJson(path.join(this.dir, 'dados', 'fontes_facebook.json'), { paginas: [] });
    const cfg = this.lerConfigFabrica();
    let tarefa = 'Nenhum agendamento ativo.';
    try {
      const r = spawnSync(process.execPath, [path.join('scripts', 'agendar_windows.mjs'), 'status'], { cwd: this.dir, encoding: 'utf8', windowsHide: true, timeout: 15000 });
      tarefa = (r.stdout || '').trim() || tarefa;
    } catch {}
    const hist = lerJson(path.join(this.dir, 'dados', 'historico_virais.json'), { adaptados: [] });
    const logTxt = lerTexto(path.join(this.dir, 'dados', 'cacador.log')) || '';
    return { paginas: fontes.paginas || [], horario: cfg.agendamento?.horario || '08:00', ativo: !!cfg.agendamento?.ativo, tarefa, adaptados: (hist.adaptados || []).slice(-10).reverse(), logRecente: logTxt.split('\n').slice(-12).join('\n') };
  }

  salvarAgendamento({ paginas, horario, ativo }) {
    this.exigirFabrica();
    if (Array.isArray(paginas)) {
      const limpas = [...new Set(paginas.map((p) => String(p).trim()).filter(Boolean))];
      const ruins = limpas.filter((p) => !/^https?:\/\//i.test(p));
      if (ruins.length) throw new Error(`Link inválido (precisa começar com https://): ${ruins[0]}`);
      const fp = path.join(this.dir, 'dados', 'fontes_facebook.json');
      const f = lerJson(fp, {}); f.paginas = limpas; escreverJsonAtomico(fp, f);
    }
    const rodar = (...a) => spawnSync(process.execPath, [path.join('scripts', 'agendar_windows.mjs'), ...a], { cwd: this.dir, encoding: 'utf8', windowsHide: true, timeout: 20000 });
    let msg = '';
    if (ativo === true) {
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(horario || '')) throw new Error('Horário inválido. Use HH:MM (ex.: 08:00).');
      msg = (rodar('criar', horario).stdout || '').trim();
    } else if (ativo === false) msg = (rodar('remover').stdout || '').trim();
    return { ...this.agendamento(), mensagem: msg };
  }

  buscarAgora() {
    this.exigirFabrica();
    const r = spawnSync(process.execPath, [path.join('scripts', 'cacador_virais_fb.mjs'), '--so-buscar'], { cwd: this.dir, encoding: 'utf8', windowsHide: true, timeout: 5 * 60 * 1000 });
    return { ok: r.status === 0, saida: ((r.stdout || '') + (r.stderr || '')).slice(-4000) };
  }
}
