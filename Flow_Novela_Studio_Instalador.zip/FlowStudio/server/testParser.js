// Teste rapido do parser:  npm run test:parser
import { parseRoteiro } from './parser.js';

const exemplo = `BLOCO 1 — REFERÊNCIAS
{ref_bia}
(i) Retrato vertical de Bia, 25 anos, cabelos cacheados castanhos, vestido floral simples, fundo neutro.
{ref_larissa}
(i) Retrato vertical de Larissa, 30 anos, loira, elegante, blusa de seda branca, fundo neutro.
{ref_cozinha_fazenda}
(i) Cozinha rústica de fazenda, fogão a lenha, luz da manhã entrando pela janela.

BLOCO 2 — IMAGENS-BASE
Imagem-base: imagem_01 — Bia e Larissa na cozinha
{imagem_01}
(i) [ref_bia] [ref_larissa] [ref_cozinha_fazenda] Fotografia cinematográfica vertical, Bia e Larissa discutindo na cozinha.
{imagem_02}
(i) [imagem_01] Derive os mesmos personagens e cenário, agora em close no rosto de Larissa.

BLOCO 3 — PROMPTS DE VÍDEO
Parte 1
{Cena 01}
(v) [imagem_01] Exactly 10 seconds, vertical 9:16, Bia vira de costas e sai da cozinha.
{Cena 02}
(v) [imagem_02] [ref_bia] Exactly 15 seconds, vertical 9:16, Larissa chora em silêncio.
{Cena 03}
(v) [ref_inexistente] Exactly 10 seconds, teste de validação.
`;

const r = parseRoteiro(exemplo);
console.log('Resumo:', r.resumo);
console.table(r.itens.map((i) => ({ id: i.id, tipo: i.tipo, submodo: i.submodo, dur: i.duracao, refs: i.refs.join(','), arquivo: i.caminhoRelativo, prompt: i.prompt.slice(0, 40) })));
console.log('Erros:', r.validacao.erros.map((e) => e.msg));
console.log('Avisos:', r.validacao.avisos.map((e) => e.msg));
console.log('Ignoradas:', r.ignoradas.length);

const forc = parseRoteiro(exemplo, { forcarElementos: true });
console.log('Forçar elementos -> Cena 01:', forc.itens.find((i) => i.id === 'Cena 01').submodo);
