// =============================================================
//  WhatsApp leve (Baileys via WebSocket, sem navegador) — envia a legenda para o proprio numero.
//  - Remove sufixo ":device" de sock.user.id
//  - Resolve JID brasileiro na rede com sock.onWhatsApp testando com e sem o 9o digito apos o DDD (55 + DDD)
//  Sessao persistente em dados/whatsapp_auth/ (NUNCA entra no pacote ZIP).
// =============================================================
import fs from 'node:fs';
import path from 'node:path';

/** "5511 99999-9999" ou "5511999999999:12@s.whatsapp.net" -> "5511999999999@s.whatsapp.net" (sem ":device"). */
export function normalizarJid(entrada, paisPadrao = '55') {
  let s = String(entrada || '').trim();
  if (!s) return null;
  if (/@(s\.whatsapp\.net|lid)$/.test(s)) return s.replace(/:\d+@/, '@');
  s = s.replace(/@.*$/, '').replace(/:\d+$/, '').replace(/\D/g, '');
  if (!s) return null;
  if (s.length <= 11) s = paisPadrao + s; // DDD + numero sem codigo do pais
  return `${s}@s.whatsapp.net`;
}

/**
 * Gera as variantes brasileiras (55 + DDD) com e sem o 9o digito para consulta em sock.onWhatsApp(...).
 * Ex.: "5511913321436" -> ["5511913321436", "551113321436"]
 *      "551113321436"  -> ["551113321436", "5511913321436"]
 */
export function variantesNumeroBrasil(entrada, paisPadrao = '55') {
  let d = String(entrada || '').trim().replace(/@.*$/, '').replace(/:\d+$/, '').replace(/\D/g, '');
  if (!d) return [];
  if (d.length === 10 || d.length === 11) d = paisPadrao + d;
  const out = [d];
  if (d.startsWith('55') && d.length === 13 && d[4] === '9') {
    const sem9 = `55${d.slice(2, 4)}${d.slice(5)}`;
    if (!out.includes(sem9)) out.push(sem9);
  } else if (d.startsWith('55') && d.length === 12) {
    const com9 = `55${d.slice(2, 4)}9${d.slice(4)}`;
    if (!out.includes(com9)) out.push(com9);
  }
  return out;
}

export class WhatsappService {
  constructor({ dadosDir, log, aoMudar = () => {} }) {
    this.authDir = path.join(dadosDir, 'whatsapp_auth');
    this.log = log;
    this.aoMudar = aoMudar;
    this.sock = null;
    this.estado = 'desconectado'; // desconectado | iniciando | aguardando_qr | conectado
    this.qrDataUrl = null;
    this.numero = null;
    this.selfJid = null;
    this.selfLid = null;
    this.ultimoErro = null;
    this.logsEnvio = [];
    this.parando = false;
    this.tentativas = 0;
    this.timerReconexao = null;
  }

  registrarLogEnvio(msg, ok = true) {
    const item = { t: new Date().toISOString(), ok, msg };
    this.logsEnvio = [item, ...this.logsEnvio].slice(0, 25);
    this.aoMudar(this.status());
  }

  temSessaoSalva() { try { return fs.existsSync(path.join(this.authDir, 'creds.json')); } catch { return false; } }

  status() {
    return {
      estado: this.estado,
      conectado: this.estado === 'conectado',
      numero: this.numero,
      selfJid: this.selfJid,
      qr: this.qrDataUrl,
      temSessaoSalva: this.temSessaoSalva(),
      ultimoErro: this.ultimoErro,
      logsEnvio: this.logsEnvio,
    };
  }

  /** Reconecta sozinho na inicializacao se ja existe sessao salva. */
  async iniciarSeTiverSessao() { if (this.temSessaoSalva()) await this.conectar().catch((e) => { this.ultimoErro = e.message; }); }

  async conectar() {
    if (['iniciando', 'aguardando_qr', 'conectado'].includes(this.estado) && this.sock) return this.status();
    this.parando = false;
    this.estado = 'iniciando'; this.ultimoErro = null; this.qrDataUrl = null;
    this.aoMudar(this.status());
    const baileys = await import('@whiskeysockets/baileys');
    const makeWASocket = baileys.default || baileys.makeWASocket;
    const { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = baileys;
    const QR = await import('qrcode');
    const toDataURL = (QR.default || QR).toDataURL;
    fs.mkdirSync(this.authDir, { recursive: true });
    const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
    let version;
    try { version = (await fetchLatestBaileysVersion()).version; } catch {}
    const silencioso = { level: 'silent', trace() {}, debug() {}, info() {}, warn() {}, error() {}, fatal() {}, child() { return silencioso; } };
    const sock = makeWASocket({ auth: state, version, logger: silencioso, printQRInTerminal: false, browser: ['Flow Novela Studio', 'Desktop', '1.0'], markOnlineOnConnect: false, syncFullHistory: false });
    this.sock = sock;
    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', async (u) => {
      if (sock !== this.sock) return;
      const { connection, lastDisconnect, qr } = u;
      if (qr) {
        try { this.qrDataUrl = await toDataURL(qr, { margin: 1, width: 280 }); } catch {}
        this.estado = 'aguardando_qr';
        this.aoMudar(this.status());
      }
      if (connection === 'open') {
        this.tentativas = 0; this.qrDataUrl = null; this.estado = 'conectado';
        // Remove obrigatoriamente qualquer sufixo ":device" do sock.user.id
        this.selfJid = normalizarJid(sock.user?.id);
        this.selfLid = sock.user?.lid ? String(sock.user.lid).replace(/:\d+@/, '@') : null;
        this.numero = this.selfJid ? this.selfJid.split('@')[0] : null;
        this.log(`WhatsApp conectado ao número ${this.numero || '?'} (JID base: ${this.selfJid || '?'}).`, 'ok');
        this.aoMudar(this.status());
      }
      if (connection === 'close') {
        const codigo = lastDisconnect?.error?.output?.statusCode;
        this.sock = null; this.qrDataUrl = null;
        const deslogou = codigo === DisconnectReason.loggedOut;
        if (this.parando) { this.estado = 'desconectado'; this.aoMudar(this.status()); return; }
        if (deslogou) {
          this.estado = 'desconectado'; this.numero = null; this.selfJid = null; this.selfLid = null;
          try { fs.rmSync(this.authDir, { recursive: true, force: true }); } catch {}
          this.log('WhatsApp foi desconectado pelo celular. Gere um novo QR Code para reconectar.', 'aviso');
          this.aoMudar(this.status()); return;
        }
        this.estado = 'iniciando';
        this.ultimoErro = lastDisconnect?.error?.message || null;
        this.aoMudar(this.status());
        const espera = Math.min(30000, 2000 * 2 ** Math.min(this.tentativas++, 4));
        clearTimeout(this.timerReconexao);
        this.timerReconexao = setTimeout(() => { this.estado = 'desconectado'; this.conectar().catch((e) => { this.ultimoErro = e.message; }); }, espera);
      }
    });
    return this.status();
  }

  async desconectar({ apagarSessao = true } = {}) {
    this.parando = true;
    clearTimeout(this.timerReconexao);
    const s = this.sock;
    this.sock = null;
    try { if (s && apagarSessao) await s.logout(); } catch {}
    try { s?.end?.(undefined); } catch {}
    if (apagarSessao) { try { fs.rmSync(this.authDir, { recursive: true, force: true }); } catch {} }
    this.estado = 'desconectado'; this.qrDataUrl = null; this.numero = null; this.selfJid = null; this.selfLid = null;
    this.aoMudar(this.status());
    return this.status();
  }

  /**
   * Resolve o JID real registrado na rede do WhatsApp (com e sem o 9o digito apos 55 + DDD).
   * Remove sempre qualquer sufixo ":device".
   */
  async resolverJidReal(numeroDestino = '') {
    const selfLimpo = normalizarJid(this.sock?.user?.id) || this.selfJid;
    const destinoLimpo = String(numeroDestino || '').trim();
    const paraSiMesmo = !destinoLimpo || normalizarJid(destinoLimpo) === selfLimpo;
    const baseConsulta = destinoLimpo || selfLimpo || this.numero || '';
    const candidatos = variantesNumeroBrasil(baseConsulta);

    if (typeof this.sock?.onWhatsApp === 'function' && candidatos.length) {
      try {
        const resp = await this.sock.onWhatsApp(...candidatos);
        if (Array.isArray(resp) && resp.length) {
          const valido = resp.find((r) => r?.exists && r?.jid);
          if (valido?.jid) {
            const jidRede = normalizarJid(valido.jid);
            return { jid: jidRede, candidatos, resolvidoVia: 'onWhatsApp', paraSiMesmo };
          }
          if (!paraSiMesmo) {
            throw new Error(`Número não encontrado no WhatsApp (testados: ${candidatos.join(' e ')}). Verifique DDD e dígitos.`);
          }
        }
      } catch (e) {
        if (/não encontrado no WhatsApp/i.test(e.message || '')) throw e;
        this.log(`WhatsApp: aviso ao consultar onWhatsApp (${e.message}) — usando JID direto.`, 'aviso');
      }
    }

    const fallback = paraSiMesmo ? selfLimpo : normalizarJid(destinoLimpo);
    if (!fallback) throw new Error('Número de destino inválido.');
    return { jid: fallback, candidatos, resolvidoVia: paraSiMesmo ? 'selfJid-sem-device' : 'normalizado', paraSiMesmo };
  }

  /** Envia texto. Sem `numeroDestino`, envia para o PROPRIO numero conectado ("mensagem para você mesmo"). */
  async enviarTexto(texto, numeroDestino = '') {
    if (this.estado !== 'conectado' || !this.sock) {
      const msg = 'WhatsApp não está conectado. Escaneie o QR Code na aba "CapCut & WhatsApp".';
      this.registrarLogEnvio(`❌ ${msg}`, false);
      throw new Error(msg);
    }
    let infoJid = null;
    try {
      infoJid = await this.resolverJidReal(numeroDestino);
      const res = await this.sock.sendMessage(infoJid.jid, { text: String(texto) });
      const msgId = res?.key?.id || 'ok';
      const resumo = `Enviado para ${infoJid.jid} (${infoJid.resolvidoVia}${infoJid.candidatos?.length > 1 ? ` · testou ${infoJid.candidatos.join('/')}` : ''}) [id: ${msgId}]`;
      this.ultimoErro = null;
      this.registrarLogEnvio(`✅ ${resumo}`, true);
      this.log(`📲 WhatsApp: ${resumo}`, 'ok');
      return { ok: true, para: infoJid.jid.split('@')[0], jid: infoJid.jid, resolvidoVia: infoJid.resolvidoVia, msgId };
    } catch (e) {
      const alvo = infoJid?.jid || numeroDestino || this.selfJid || '?';
      const msgErro = `Falha ao enviar para ${alvo}: ${e.message}`;
      this.ultimoErro = msgErro;
      this.registrarLogEnvio(`❌ ${msgErro}`, false);
      this.log(`❌ WhatsApp: ${msgErro}`, 'erro');
      throw e;
    }
  }
}
