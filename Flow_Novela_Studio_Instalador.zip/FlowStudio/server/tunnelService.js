// =============================================================
//  TunnelService — Túnel HTTPS Direto (Cloudflare Quick Tunnel via cloudflared)
//  - Zero uso de VPN no PC e no iPhone (seguro para contas Meta/Facebook/Instagram)
//  - Baixa automaticamente o binario oficial cloudflared.exe em C:\FlowStudio\bin\ (ignorado no zip/git)
//  - Gerencia o processo `cloudflared tunnel --url http://127.0.0.1:3456 --no-autoupdate`
//  - Captura automaticamente a URL `https://xxxx.trycloudflare.com` e gera o QR Code
// =============================================================
import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import QRCode from 'qrcode';
import { escreverJsonAtomico, lerJson } from './store.js';

const URL_CLOUDFLARED_WIN64 =
  'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe';
const RE_TRYCLOUDFLARE = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i;

export class TunnelService {
  constructor({ rootDir, dadosDir, porta = 3456, log = () => {}, aoMudar = () => {} }) {
    this.rootDir = rootDir;
    this.dadosDir = dadosDir;
    this.porta = porta;
    this.log = log;
    this.aoMudar = aoMudar;

    this.binDir = path.join(rootDir, 'bin');
    this.binLocal = path.join(this.binDir, process.platform === 'win32' ? 'cloudflared.exe' : 'cloudflared');
    this.arqConfig = path.join(dadosDir, 'tunel_config.json');
    this.cfg = { autoIniciar: false, ...(lerJson(this.arqConfig, {}) || {}) };

    this.proc = null;
    this.estado = 'parado'; // 'parado' | 'baixando' | 'conectando' | 'online' | 'erro'
    this.url = null;
    this.qrDataUrl = null;
    this.erro = null;
    this.iniciadoEm = null;
    this._promessaIniciando = null;
  }

  estadoPublico() {
    return {
      estado: this.estado,
      ativo: this.estado === 'online' || this.estado === 'conectando' || this.estado === 'baixando',
      online: this.estado === 'online',
      url: this.url,
      qrDataUrl: this.qrDataUrl,
      erro: this.erro,
      iniciadoEm: this.iniciadoEm,
      autoIniciar: Boolean(this.cfg.autoIniciar),
      binarioPronto: Boolean(this.localizarBinarioExistente()),
    };
  }

  notificar() {
    try { this.aoMudar(this.estadoPublico()); } catch {}
  }

  salvarConfig(patch = {}) {
    if (typeof patch.autoIniciar === 'boolean') {
      this.cfg.autoIniciar = patch.autoIniciar;
    }
    escreverJsonAtomico(this.arqConfig, this.cfg);
    this.notificar();
    return this.estadoPublico();
  }

  localizarBinarioExistente() {
    if (fs.existsSync(this.binLocal)) {
      try {
        if (fs.statSync(this.binLocal).size > 1_000_000) return this.binLocal;
      } catch {}
    }
    const candidatos = process.platform === 'win32'
      ? [
          'C:\\Program Files (x86)\\cloudflared\\cloudflared.exe',
          'C:\\Program Files\\cloudflared\\cloudflared.exe',
        ]
      : ['/usr/local/bin/cloudflared', '/usr/bin/cloudflared'];
    for (const c of candidatos) {
      if (fs.existsSync(c)) return c;
    }
    try {
      const cmd = process.platform === 'win32' ? 'where.exe' : 'which';
      const r = spawnSync(cmd, ['cloudflared'], { encoding: 'utf8', timeout: 2000, windowsHide: true });
      const achado = String(r.stdout || '').split(/\r?\n/)[0]?.trim();
      if (achado && fs.existsSync(achado)) return achado;
    } catch {}
    return null;
  }

  async garantirBinario() {
    const existente = this.localizarBinarioExistente();
    if (existente) return existente;

    if (process.platform !== 'win32') {
      throw new Error('Binário cloudflared não encontrado no sistema. Instale cloudflared para usar o túnel HTTPS.');
    }

    fs.mkdirSync(this.binDir, { recursive: true });
    this.estado = 'baixando';
    this.erro = null;
    this.notificar();
    this.log('⬇️ Baixando binário oficial do Cloudflare Tunnel (cloudflared.exe) pela primeira vez...', 'info');

    const tmp = `${this.binLocal}.download`;
    try {
      const resp = await fetch(URL_CLOUDFLARED_WIN64, { redirect: 'follow' });
      if (!resp.ok) throw new Error(`Download do cloudflared retornou HTTP ${resp.status}`);
      const ab = await resp.arrayBuffer();
      const buf = Buffer.from(ab);
      if (buf.length < 5_000_000) {
        throw new Error(`Arquivo cloudflared baixado parece incompleto (${buf.length} bytes).`);
      }
      fs.writeFileSync(tmp, buf);
      try {
        if (fs.existsSync(this.binLocal)) fs.unlinkSync(this.binLocal);
        fs.renameSync(tmp, this.binLocal);
      } catch {
        fs.copyFileSync(tmp, this.binLocal);
        try { fs.unlinkSync(tmp); } catch {}
      }
      this.log(`✅ Binário cloudflared.exe instalado automaticamente em bin/cloudflared.exe (${(buf.length / (1024 * 1024)).toFixed(1)} MB).`, 'ok');
      return this.binLocal;
    } catch (e) {
      try { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); } catch {}
      this.estado = 'erro';
      this.erro = `Falha ao baixar cloudflared.exe: ${e.message}`;
      this.notificar();
      throw e;
    }
  }

  async iniciar() {
    if (this.estado === 'online' && this.proc && this.url) {
      return this.estadoPublico();
    }
    if (this._promessaIniciando) {
      return this._promessaIniciando;
    }

    this._promessaIniciando = (async () => {
      try {
        await this.parar({ silencioso: true });
        const bin = await this.garantirBinario();
        this.estado = 'conectando';
        this.url = null;
        this.qrDataUrl = null;
        this.erro = null;
        this.notificar();
        this.log(`🌍 Iniciando Túnel HTTPS Direto (Cloudflare Quick Tunnel → http://127.0.0.1:${this.porta})...`, 'info');

        return await new Promise((resolve, reject) => {
          let resolvido = false;
          let bufferLog = '';
          const child = spawn(
            bin,
            ['tunnel', '--url', `http://127.0.0.1:${this.porta}`, '--no-autoupdate'],
            {
              cwd: this.rootDir,
              stdio: ['ignore', 'pipe', 'pipe'],
              windowsHide: true,
            }
          );
          this.proc = child;

          const timeout = setTimeout(() => {
            if (resolvido) return;
            resolvido = true;
            this.estado = 'erro';
            this.erro = 'Tempo limite (25s) aguardando URL pública do Cloudflare Tunnel.';
            this.notificar();
            this.parar({ silencioso: true });
            reject(new Error(this.erro));
          }, 25000);

          const processarSaida = async (chunk) => {
            const txt = chunk.toString('utf8');
            bufferLog = (bufferLog + txt).slice(-8000);
            const m = bufferLog.match(RE_TRYCLOUDFLARE);
            if (m && !this.url) {
              const urlCapturada = m[0].toLowerCase();
              this.url = urlCapturada;
              this.qrDataUrl = await QRCode.toDataURL(urlCapturada, { margin: 1, width: 240 }).catch(() => null);
              this.estado = 'online';
              this.erro = null;
              this.iniciadoEm = new Date().toISOString();
              this.notificar();
              this.log(`🌍 Túnel HTTPS Cloudflare ativo (sem VPN): ${urlCapturada}`, 'ok');
              if (!resolvido) {
                resolvido = true;
                clearTimeout(timeout);
                resolve(this.estadoPublico());
              }
            }
          };

          child.stdout?.on('data', (d) => { processarSaida(d); });
          child.stderr?.on('data', (d) => { processarSaida(d); });

          child.on('error', (err) => {
            clearTimeout(timeout);
            if (this.proc === child) this.proc = null;
            this.estado = 'erro';
            this.erro = `Falha ao executar cloudflared: ${err.message}`;
            this.url = null;
            this.qrDataUrl = null;
            this.notificar();
            if (!resolvido) {
              resolvido = true;
              reject(new Error(this.erro));
            }
          });

          child.on('exit', (code) => {
            clearTimeout(timeout);
            const eraAtual = this.proc === child;
            if (eraAtual) {
              this.proc = null;
              const estavaOnline = this.estado === 'online';
              this.url = null;
              this.qrDataUrl = null;
              if (this.estado !== 'parado') {
                this.estado = 'parado';
                if (estavaOnline) {
                  this.log('Túnel HTTPS Cloudflare encerrado.', 'aviso');
                }
              }
              this.notificar();
            }
            if (!resolvido) {
              resolvido = true;
              const msg = `cloudflared encerrou inesperadamente (código ${code ?? '?'}).`;
              this.estado = 'erro';
              this.erro = msg;
              this.notificar();
              reject(new Error(msg));
            }
          });
        });
      } finally {
        this._promessaIniciando = null;
      }
    })();

    return this._promessaIniciando;
  }

  async parar({ silencioso = false } = {}) {
    const p = this.proc;
    this.proc = null;
    this.estado = 'parado';
    this.url = null;
    this.qrDataUrl = null;
    this.erro = null;
    this.iniciadoEm = null;
    if (p) {
      try {
        if (process.platform === 'win32' && p.pid) {
          spawnSync('taskkill', ['/PID', String(p.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
        } else {
          p.kill('SIGTERM');
        }
      } catch {}
      if (!silencioso) {
        this.log('🛑 Túnel HTTPS Cloudflare desligado.', 'info');
      }
    }
    this.notificar();
    return this.estadoPublico();
  }
}
