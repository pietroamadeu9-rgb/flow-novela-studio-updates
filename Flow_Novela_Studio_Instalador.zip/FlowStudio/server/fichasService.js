// =============================================================
//  Banco curado de FICHAS VIRAIS — C:\FabricaClaude\fichas_virais\fichas.json
//  Ficha = resumo dramático enxuto (gancho 3s, conflito, ironia, estrutura cena a cena, melhores falas, virada)
//  usado SÓ como referência de estrutura/ritmo/tom na Chamada A do roteirista (nunca para copiar história ou falas).
// =============================================================
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { FABRICA_DIR } from './claudeBridge.js';

export const TIPOS_CONFLITO = [
  ['traicao_ciume', 'Traição / ciúme'],
  ['dinheiro_divida', 'Dinheiro / dívida'],
  ['heranca_terra', 'Herança / terra / casa'],
  ['humilhacao_trabalho', 'Humilhação no trabalho (patroa, empregada...)'],
  ['familia_sogra_nora', 'Família (sogra, nora, cunhado...)'],
  ['segredo_mentira', 'Segredo / mentira'],
  ['injustica_familiar', 'Injustiça familiar'],
  ['vinganca', 'Vingança'],
  ['outro', 'Outro'],
];
const IDS_TIPOS = new Set(TIPOS_CONFLITO.map((t) => t[0]));

const PALAVRAS_TIPO = {
  traicao_ciume: /(trai[cç][aã]o|traiu|amante|ci[uú]me|escondid|celular|outra pessoa|marido|esposa|casamento|namorad|presente)/i,
  dinheiro_divida: /(d[ií]vida|dinheiro|empr[eé]stimo|cobran[cç]a|caderno|fiado|pagar|banco|agiota|conta)/i,
  heranca_terra: /(heran[cç]a|terra|s[ií]tio|casa|testamento|escritura|matr[ií]cula|inventário|documento)/i,
  humilhacao_trabalho: /(patroa|patr[aã]o|diarista|empregad|demiss|trabalh|loja|chefe|sal[aá]rio)/i,
  familia_sogra_nora: /(sogra|nora|genro|cunhad|enteada|madrasta|irm[aã]|tio|tia|fam[ií]lia)/i,
  segredo_mentira: /(segredo|mentira|mentiu|escondeu|verdade|revela)/i,
  injustica_familiar: /(injusti|culpa|acusa|expuls|despej|botar pra fora|humilh)/i,
  vinganca: /(vingan|desforra|plano|armadilha|me paga)/i,
};

export function inferirTipoConflito(texto) {
  const t = String(texto || '');
  let melhor = null;
  let pontos = 0;
  for (const [tipo, re] of Object.entries(PALAVRAS_TIPO)) {
    const m = t.match(new RegExp(re.source, 'gi'));
    if (m && m.length > pontos) { pontos = m.length; melhor = tipo; }
  }
  return melhor || 'outro';
}

const num = (v, min = 0, max = 1e12) => { const n = Number(v); return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : 0; };
const txt = (v, max = 600) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const lista = (v, maxItens, maxChars) => (Array.isArray(v) ? v : String(v || '').split(/\r?\n/)).map((x) => txt(x, maxChars)).filter(Boolean).slice(0, maxItens);

/** Normaliza e valida uma ficha (aceita edição manual, extração do Claude ou promoção de novela). */
export function normalizarFicha(raw = {}, base = {}) {
  const f = { ...base, ...raw };
  const tipo = IDS_TIPOS.has(f.tipoConflito) ? f.tipoConflito : inferirTipoConflito(`${f.conflitoConcreto || ''} ${f.titulo || ''} ${f.gancho3s || ''}`);
  return {
    id: f.id || `ficha_${Date.now().toString(36)}${crypto.randomBytes(2).toString('hex')}`,
    titulo: txt(f.titulo, 120) || 'Ficha sem título',
    origem: ['link', 'transcricao', 'novela', 'manual', 'exemplo'].includes(f.origem) ? f.origem : 'manual',
    url: txt(f.url, 400),
    propria: !!f.propria, // da PRÓPRIA página (prioridade na seleção)
    ativa: f.ativa !== false,
    tipoConflito: tipo,
    views: Math.round(num(f.views)),
    retencao3s: Math.round(num(f.retencao3s, 0, 100) * 10) / 10,
    retencao30s: Math.round(num(f.retencao30s, 0, 100) * 10) / 10,
    gancho3s: txt(f.gancho3s, 400),
    conflitoConcreto: txt(f.conflitoConcreto, 400),
    ironiaDramatica: txt(f.ironiaDramatica, 500),
    estrutura: lista(f.estrutura, 14, 260),
    melhoresFalas: lista(f.melhoresFalas, 4, 200),
    virada: txt(f.virada, 500),
    finalFisgada: txt(f.finalFisgada, 400),
    ritmo: txt(f.ritmo, 300),
    tom: txt(f.tom, 300),
    novelaRef: f.novelaRef ? { slug: txt(f.novelaRef.slug, 80), parte: Number(f.novelaRef.parte) || 1 } : null,
    criadoEm: f.criadoEm || new Date().toISOString(),
    atualizadoEm: new Date().toISOString(),
  };
}

/** Extrai o JSON que o Claude devolveu (tolera cerca de markdown e texto em volta). */
export function extrairJsonDaResposta(saida) {
  const t = String(saida || '').replace(/```(?:json)?/gi, '');
  const i = t.indexOf('{');
  const j = t.lastIndexOf('}');
  if (i < 0 || j <= i) return null;
  try { return JSON.parse(t.slice(i, j + 1)); } catch { return null; }
}

/** Seções do arquivo prompts/*.md marcadas com <!-- SECAO: nome -->. */
export function lerSecoesPrompt(arquivo) {
  let txt0 = '';
  try { txt0 = fs.readFileSync(arquivo, 'utf8').replace(/^\uFEFF/, ''); } catch { return {}; }
  const partes = txt0.split(/<!--\s*(?:SECAO|SECTION):\s*([a-z0-9_]+)\s*-->/i);
  const out = {};
  for (let k = 1; k < partes.length; k += 2) out[partes[k].toLowerCase()] = partes[k + 1].trim();
  return out;
}
export function preencherModelo(modelo, vars = {}) {
  return String(modelo || '').replace(/\{\{\s*([A-Z0-9_]+)\s*\}\}/g, (_, k) => (vars[k] == null ? '' : String(vars[k])));
}

export class FichasService {
  constructor({ dir = FABRICA_DIR, log = () => {} } = {}) {
    this.dir = dir;
    this.log = log;
  }
  get pasta() { return path.join(this.dir, 'fichas_virais'); }
  get arquivo() { return path.join(this.pasta, 'fichas.json'); }
  get promptExtrator() { return path.join(this.dir, 'prompts', 'prompt_extrator_ficha.md'); }

  ler() {
    try {
      const j = JSON.parse(fs.readFileSync(this.arquivo, 'utf8').replace(/^\uFEFF/, ''));
      return { versao: 1, ...j, fichas: Array.isArray(j.fichas) ? j.fichas : [] };
    } catch { return { versao: 1, fichas: [] }; }
  }
  gravar(db) {
    fs.mkdirSync(this.pasta, { recursive: true });
    const tmp = `${this.arquivo}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
    try { fs.renameSync(tmp, this.arquivo); } catch { fs.writeFileSync(this.arquivo, JSON.stringify(db, null, 2), 'utf8'); try { fs.unlinkSync(tmp); } catch {} }
  }

  listar() {
    return this.ler().fichas.sort((a, b) => (b.propria - a.propria) || (b.retencao30s - a.retencao30s) || (b.views - a.views));
  }
  obter(id) { return this.ler().fichas.find((f) => f.id === id) || null; }

  criar(dados = {}) {
    const db = this.ler();
    const f = normalizarFicha(dados);
    db.fichas.push(f);
    this.gravar(db);
    return f;
  }
  atualizar(id, patch = {}) {
    const db = this.ler();
    const i = db.fichas.findIndex((f) => f.id === id);
    if (i < 0) throw new Error('Ficha não encontrada.');
    db.fichas[i] = normalizarFicha({ ...patch, id, criadoEm: db.fichas[i].criadoEm }, db.fichas[i]);
    this.gravar(db);
    return db.fichas[i];
  }
  excluir(id) {
    const db = this.ler();
    const antes = db.fichas.length;
    db.fichas = db.fichas.filter((f) => f.id !== id);
    if (db.fichas.length === antes) throw new Error('Ficha não encontrada.');
    this.gravar(db);
    return { ok: true };
  }

  /** Prompt (sonnet) que transforma a transcrição bruta em ficha curta. */
  montarPromptExtracao({ transcricao, contexto = '' }) {
    const modelo = lerSecoesPrompt(this.promptExtrator).extrator
      || 'Transforme a transcrição numa ficha JSON com: titulo, tipoConflito, gancho3s, conflitoConcreto, ironiaDramatica, estrutura[], melhoresFalas[], virada, finalFisgada, ritmo, tom. Responda só com JSON.\n\n{{CONTEXTO}}\n\nTRANSCRIÇÃO:\n"""\n{{TRANSCRICAO}}\n"""';
    return preencherModelo(modelo, { TRANSCRICAO: String(transcricao || '').slice(0, 9000), CONTEXTO: contexto ? `CONTEXTO DO USUÁRIO: ${contexto}` : '' });
  }

  /** Cria a ficha a partir da resposta do Claude (sonnet). */
  fichaDaResposta(saida, meta = {}) {
    const j = extrairJsonDaResposta(saida);
    if (!j) throw new Error('O Claude não devolveu uma ficha em JSON válido. Tente de novo.');
    return this.criar({ ...j, origem: meta.origem || 'link', url: meta.url || '', propria: !!meta.propria, views: meta.views, retencao3s: meta.retencao3s, retencao30s: meta.retencao30s, tipoConflito: meta.tipoConflito || j.tipoConflito });
  }

  /**
   * Promove uma novela PRÓPRIA campeã a ficha de referência (determinístico, 0 tokens):
   * gancho = 1ª fala, estrutura = linhas "Novidade:", melhores falas = as mais fortes, virada/final = Choque/Fisgada.
   */
  fichaDeRoteiro(roteiroTxt, { views = 0, retencao3s = 0, retencao30s = 0, tipoConflito = null, slug = '', parte = 1, titulo = '' } = {}) {
    const linhas = String(roteiroTxt || '').replace(/^\uFEFF/, '').split(/\r?\n/);
    const cab = { tituloRot: (linhas.find((l) => /^#\s+\S/.test(l.trim())) || '').replace(/^#\s+/, '').trim() };
    const pega = (re) => { const m = String(roteiroTxt).match(re); return m ? m[1].trim() : ''; };
    const conflito = pega(/^Conflito concreto:\s*(.+)$/im);
    const relacao = pega(/^Rela[cç][aã]o exata:\s*(.+)$/im);
    const final = pega(/^Final-fisgada:\s*(.+)$/im);
    const ironia = pega(/Regra\/acordo em jogo:\s*(.+)$/im) || pega(/^Ponte[^\n]*\n[\s\S]*?Por que agora:\s*(.+)$/im);
    const cenas = [];
    let cur = null;
    for (const raw of linhas) {
      const l = raw.trim();
      const h = l.match(/^#{1,4}\s*cena\s*0*(\d+)\b/i);
      if (h) { cur = { n: Number(h[1]), etapa: '', novidade: '', falas: [], choque: '', fisgada: '' }; cenas.push(cur); const e = l.match(/[—–-]+\s*(.+)$/); cur.etapa = e ? e[1] : ''; continue; }
      if (!cur) continue;
      let m;
      if ((m = l.match(/^Novidade:\s*(.+)$/i))) cur.novidade = m[1].trim();
      else if ((m = l.match(/^Choque:\s*(.+)$/i))) cur.choque = m[1].trim();
      else if ((m = l.match(/^Fisgada:\s*(.+)$/i))) cur.fisgada = m[1].trim();
      else if ((m = l.match(/^([A-ZÀ-Ú][A-ZÀ-Ú0-9 .'-]*?)\s*\[([^\]]*)\]\s*:\s*["“](.+?)["”]/u))) cur.falas.push({ quem: m[1].trim(), emocao: m[2].trim(), texto: m[3].trim() });
    }
    const todas = cenas.flatMap((c) => c.falas.map((f) => ({ ...f, cena: c.n })));
    const pontuar = (f) => (f.texto.match(/[?!]/g) || []).length * 2 + (/(mentir|dinheiro|d[ií]vida|nunca|jamais|vergonha|culpa|verdade)/i.test(f.texto) ? 2 : 0) + Math.min(f.texto.split(/\s+/).length, 14) / 7;
    const escolhidas = [];
    if (todas[0]) escolhidas.push(todas[0]);
    for (const f of [...todas].sort((a, b) => pontuar(b) - pontuar(a))) { if (escolhidas.length >= 4) break; if (!escolhidas.includes(f)) escolhidas.push(f); }
    const ult = cenas[cenas.length - 1] || {};
    const mediaFalas = cenas.length ? (todas.length / cenas.length).toFixed(1) : '0';
    const mudas = cenas.filter((c) => !c.falas.length).length;
    const emocoes = {};
    for (const f of todas) for (const e of f.emocao.split(/[,;]/)) { const k = e.trim().toLowerCase(); if (k) emocoes[k] = (emocoes[k] || 0) + 1; }
    const tom = Object.entries(emocoes).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k]) => k).join(', ');
    const tipo = IDS_TIPOS.has(tipoConflito) ? tipoConflito : inferirTipoConflito(`${conflito} ${relacao} ${roteiroTxt.slice(0, 1500)}`);
    return normalizarFicha({
      titulo: titulo || (cab.tituloRot || slug).replace(/\s*[—–-]+\s*Parte\s*\d+.*$/i, ''),
      origem: 'novela', propria: true, ativa: true, tipoConflito: tipo, views, retencao3s, retencao30s,
      gancho3s: todas[0] ? `${todas[0].quem}: "${todas[0].texto}"` : '',
      conflitoConcreto: [relacao, conflito].filter(Boolean).join(' — '),
      ironiaDramatica: ironia,
      estrutura: cenas.map((c) => `${String(c.n).padStart(2, '0')} ${c.etapa ? `(${c.etapa}) ` : ''}${c.novidade || (c.falas.length ? 'troca de falas' : 'cena muda')}`),
      melhoresFalas: escolhidas.map((f) => f.texto),
      virada: ult.choque || ult.fisgada || final,
      finalFisgada: final || ult.fisgada || '',
      ritmo: `${mediaFalas} falas por cena em média${mudas ? `, ${mudas} cena(s) muda(s) de ironia visual` : ''}.`,
      tom: tom ? `emoções mais usadas: ${tom}` : '',
      novelaRef: { slug, parte },
    });
  }

  /**
   * Escolhe 2 a 3 fichas ATIVAS do mesmo tipo de conflito (prioridade: da própria página, maior retenção 30s, mais views).
   * Se houver menos de 2 do mesmo tipo, completa com as melhores de outros tipos (marcadas como "só ritmo").
   */
  selecionarParaPrompt({ tipoConflito = null, texto = '', max = 3 } = {}) {
    const tipo = IDS_TIPOS.has(tipoConflito) ? tipoConflito : inferirTipoConflito(texto);
    const ativas = this.listar().filter((f) => f.ativa);
    const mesmo = ativas.filter((f) => f.tipoConflito === tipo);
    const outros = ativas.filter((f) => f.tipoConflito !== tipo);
    let esc = mesmo.slice(0, Math.min(3, max));
    let completouComOutros = false;
    if (esc.length < 2) { esc = [...esc, ...outros.slice(0, 2 - esc.length)]; completouComOutros = esc.some((f) => f.tipoConflito !== tipo); }
    return { tipo, fichas: esc, completouComOutros };
  }

  /** Bloco de texto injetado na Chamada A. Vazio se não houver fichas ativas. Quando há resumo do usuário, omite enredos externos para blindar 100% os fatos do resumo. */
  blocoParaPrompt(sel, { temResumoUsuario = false } = {}) {
    if (!sel?.fichas?.length) return '';
    if (temResumoUsuario) {
      const itensRitmo = sel.fichas.slice(0, 2).map((f, i) => [
        `CADÊNCIA ${i + 1} (${f.tipoConflito} · retenção 3s ${f.retencao3s}% · 30s ${f.retencao30s}%):`,
        f.ritmo || f.tom ? `  • Ritmo e emoção das trocas A→B: ${[f.ritmo, f.tom].filter(Boolean).join(' · ')}` : '',
        f.melhoresFalas.length ? `  • Exemplo apenas de tamanho/impacto de frase falada (JAMAIS copie o assunto): ${f.melhoresFalas.slice(0, 2).map((x) => `"${x}"`).join(' · ')}` : '',
      ].filter(Boolean).join('\n')).join('\n');
      return `REFERÊNCIA APENAS DE CADÊNCIA E RITMO DE FALA (⚠️ O USUÁRIO FORNECEU UM RESUMO PRÓPRIO — É TERMINANTEMENTE PROIBIDO USAR QUALQUER ENREDO, PERSONAGEM, OBJETO, CARTÃO, LANCHONETE OU SITUAÇÃO DE FORA DO RESUMO DO USUÁRIO!):\n${itensRitmo}`;
    }
    const itens = sel.fichas.map((f, i) => [
      `FICHA ${i + 1} — ${f.titulo} [${f.tipoConflito}${f.propria ? ' · da própria página' : ''}${f.tipoConflito !== sel.tipo ? ' · tipo diferente: use só o RITMO' : ''}] (views ${f.views.toLocaleString('pt-BR')} · retenção 3s ${f.retencao3s}% · 30s ${f.retencao30s}%)`,
      f.gancho3s ? `  • Gancho dos 3s: ${f.gancho3s}` : '',
      f.conflitoConcreto ? `  • Conflito: ${f.conflitoConcreto}` : '',
      f.ironiaDramatica ? `  • Ironia dramática: ${f.ironiaDramatica}` : '',
      f.estrutura.length ? `  • Estrutura: ${f.estrutura.join(' | ')}` : '',
      f.melhoresFalas.length ? `  • Tipo de golpe nas falas (NÃO copiar): ${f.melhoresFalas.map((x) => `"${x}"`).join(' · ')}` : '',
      f.virada ? `  • Virada: ${f.virada}` : '',
      f.ritmo || f.tom ? `  • Ritmo/tom: ${[f.ritmo, f.tom].filter(Boolean).join(' · ')}` : '',
    ].filter(Boolean).join('\n')).join('\n\n');
    return `FICHAS DE REFERÊNCIA (histórias que já funcionaram; use APENAS como referência de estrutura, ritmo e tom natural de fala). É PROIBIDO copiar a história, os personagens, os objetos ou as falas delas — a sua história é outra, com outros nomes, objetos e reviravolta:\n${itens}`;
  }
}
