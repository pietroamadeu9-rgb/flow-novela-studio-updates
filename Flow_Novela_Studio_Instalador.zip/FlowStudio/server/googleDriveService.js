// =============================================================
//  Google Drive Service (OAuth2 Desktop / REST API v3 oficial, zero deps pesadas)
//  - Credenciais OAuth em dados/gdrive_credentials.json (NUNCA entra no ZIP)
//  - Tokens OAuth + preferencias em dados/gdrive_auth.json (NUNCA entra no ZIP)
//  - Cria/reutiliza automaticamente a pasta "FlowStudio_Videos_Prontos"
//  - Upload resumable em streaming (baixo uso de RAM mesmo p/ videos grandes)
//  - Permissao "anyone with link (reader)" + webViewLink + link direto uc?export=download (iPhone)
// =============================================================
import fs from 'node:fs';
import https from 'node:https';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { escreverJsonAtomico, lerJson } from './store.js';

export const PASTA_DRIVE_PADRAO = 'FlowStudio_Videos_Prontos';
export const REDIRECT_PATH = '/api/gdrive/callback';

const SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/userinfo.email',
].join(' ');

function base64Url(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

/** Extrai { clientId, clientSecret } tanto de campos diretos quanto de um JSON baixado do Google Cloud (installed / web). */
export function extrairCredenciaisOAuth(entrada = {}) {
  if (typeof entrada.jsonBruto === 'string' && entrada.jsonBruto.trim()) {
    let parsed;
    try {
      parsed = JSON.parse(entrada.jsonBruto.trim());
    } catch {
      throw new Error('O conteúdo JSON colado não é válido. Cole o conteúdo completo do arquivo client_secret_*.json ou preencha Client ID e Client Secret.');
    }
    const bloco = parsed.installed || parsed.web || parsed;
    const cid = String(bloco.client_id || bloco.clientId || '').trim();
    const sec = String(bloco.client_secret || bloco.clientSecret || '').trim();
    if (!cid || !sec) throw new Error('Não encontrei client_id e client_secret dentro do JSON informado.');
    return { clientId: cid, clientSecret: sec };
  }
  const clientId = String(entrada.clientId || '').trim();
  const clientSecret = String(entrada.clientSecret || '').trim();
  if (!clientId || !clientSecret) throw new Error('Informe o Client ID e o Client Secret do Google Cloud (OAuth Desktop App).');
  return { clientId, clientSecret };
}

/** Monta os links publicos para iPhone / navegador a partir do fileId do Google Drive. */
export function montarLinksDrive(fileId, webViewLinkApi = '') {
  if (!fileId) throw new Error('fileId ausente ao montar links do Google Drive.');
  return {
    fileId,
    webViewLink: webViewLinkApi || `https://drive.google.com/file/d/${fileId}/view?usp=drivesdk`,
    downloadLink: `https://drive.google.com/uc?export=download&id=${fileId}`,
  };
}

/** Monta o texto da Mensagem 2 enviada no WhatsApp (separada da legenda limpa). */
export function formatarMensagemWhatsappDrive({ webViewLink, downloadLink }) {
  return [
    '🎬 Vídeo pronto no Google Drive (qualidade original):',
    `🔗 Abrir: ${webViewLink}`,
    `📲 Salvar no iPhone: ${downloadLink}`,
  ].join('\n');
}

export class GoogleDriveService {
  constructor({ dadosDir, porta = 3456, log = () => {}, aoMudar = () => {} }) {
    this.dadosDir = dadosDir;
    this.porta = porta;
    this.log = log;
    this.aoMudar = aoMudar;
    this.arqCreds = path.join(dadosDir, 'gdrive_credentials.json');
    this.arqAuth = path.join(dadosDir, 'gdrive_auth.json');
    this.pkcePendente = null; // { state, verifier, criadoEm }
    this.uploadAtual = null;  // { nome, bytesEnviados, totalBytes, pct }
    this.ultimoErro = null;
  }

  get redirectUri() {
    return `http://127.0.0.1:${this.porta}${REDIRECT_PATH}`;
  }

  lerCredenciais() {
    const c = lerJson(this.arqCreds, null);
    if (c?.clientId && c?.clientSecret) return c;
    if (process.env.GDRIVE_CLIENT_ID && process.env.GDRIVE_CLIENT_SECRET) {
      return { clientId: process.env.GDRIVE_CLIENT_ID, clientSecret: process.env.GDRIVE_CLIENT_SECRET };
    }
    return null;
  }

  lerAuth() {
    return lerJson(this.arqAuth, {});
  }

  salvarAuth(patch = {}) {
    const atual = { autoUploadCapcut: true, ...this.lerAuth(), ...patch };
    escreverJsonAtomico(this.arqAuth, atual);
    this.aoMudar(this.status());
    return atual;
  }

  conectado() {
    const a = this.lerAuth();
    return Boolean((a.refresh_token || a.access_token) && this.lerCredenciais());
  }

  deveSubirAutomatico() {
    const a = this.lerAuth();
    return this.conectado() && a.autoUploadCapcut !== false;
  }

  status() {
    const creds = this.lerCredenciais();
    const auth = this.lerAuth();
    const isCon = Boolean((auth.refresh_token || auth.access_token) && creds);
    return {
      conectado: isCon,
      temCredenciais: !!creds,
      clientIdParcial: creds?.clientId ? `${creds.clientId.slice(0, 14)}…` : null,
      email: auth.email || null,
      pastaNome: PASTA_DRIVE_PADRAO,
      pastaId: auth.pastaId || null,
      autoUploadCapcut: auth.autoUploadCapcut !== false,
      ultimoUpload: auth.ultimoUpload || null,
      uploadAtual: this.uploadAtual,
      ultimoErro: this.ultimoErro,
      redirectUri: this.redirectUri,
    };
  }

  salvarCredenciais(entrada = {}) {
    const { clientId, clientSecret } = extrairCredenciaisOAuth(entrada);
    escreverJsonAtomico(this.arqCreds, { clientId, clientSecret, salvoEm: new Date().toISOString() });
    this.ultimoErro = null;
    this.aoMudar(this.status());
    return this.status();
  }

  atualizarPreferencias(patch = {}) {
    const novo = {};
    if (typeof patch.autoUploadCapcut === 'boolean') novo.autoUploadCapcut = patch.autoUploadCapcut;
    this.salvarAuth(novo);
    return this.status();
  }

  /** Gera a URL OAuth2 oficial do Google e opcionalmente abre o navegador padrao do Windows. */
  iniciarLoginOAuth({ entradaCredenciais = null, abrirNavegador = true } = {}) {
    if (entradaCredenciais && (entradaCredenciais.clientId || entradaCredenciais.jsonBruto)) {
      this.salvarCredenciais(entradaCredenciais);
    }
    const creds = this.lerCredenciais();
    if (!creds) {
      throw new Error('Salve primeiro o Client ID e Client Secret (ou cole o JSON do Google Cloud Desktop App).');
    }
    const verifier = base64Url(crypto.randomBytes(32));
    const challenge = base64Url(crypto.createHash('sha256').update(verifier).digest());
    const state = base64Url(crypto.randomBytes(16));
    this.pkcePendente = { state, verifier, criadoEm: Date.now() };

    const params = new URLSearchParams({
      client_id: creds.clientId,
      redirect_uri: this.redirectUri,
      response_type: 'code',
      scope: SCOPES,
      access_type: 'offline',
      prompt: 'consent',
      state,
      code_challenge: challenge,
      code_challenge_method: 'S256',
    });
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;

    if (abrirNavegador && process.platform === 'win32') {
      try {
        spawn('cmd.exe', ['/d', '/s', '/c', `start "" "${authUrl.replace(/&/g, '^&')}"`], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
      } catch {}
    }
    return { ok: true, authUrl, redirectUri: this.redirectUri };
  }

  /** Conclui o callback http://127.0.0.1:3456/api/gdrive/callback trocando `code` por tokens persistentes. */
  async concluirCallback({ code, state, error }) {
    if (error) throw new Error(`Autorização recusada no Google: ${error}`);
    if (!code) throw new Error('Código OAuth ausente no callback.');
    const creds = this.lerCredenciais();
    if (!creds) throw new Error('Credenciais OAuth não configuradas.');
    if (this.pkcePendente && state && state !== this.pkcePendente.state) {
      throw new Error('Parâmetro state inválido no retorno OAuth.');
    }

    const body = new URLSearchParams({
      code: String(code),
      client_id: creds.clientId,
      client_secret: creds.clientSecret,
      redirect_uri: this.redirectUri,
      grant_type: 'authorization_code',
      ...(this.pkcePendente?.verifier ? { code_verifier: this.pkcePendente.verifier } : {}),
    });
    const r = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });
    const dados = await r.json().catch(() => ({}));
    if (!r.ok || !dados.access_token) {
      throw new Error(dados.error_description || dados.error || `Falha ao obter token OAuth (${r.status}).`);
    }

    this.pkcePendente = null;
    const anterior = this.lerAuth();
    const auth = this.salvarAuth({
      access_token: dados.access_token,
      refresh_token: dados.refresh_token || anterior.refresh_token || null,
      token_type: dados.token_type || 'Bearer',
      scope: dados.scope || SCOPES,
      expiry_date: Date.now() + Number(dados.expires_in || 3500) * 1000,
      conectadoEm: new Date().toISOString(),
    });

    // Descobre o e-mail da conta Google conectada e garante a pasta FlowStudio_Videos_Prontos
    try {
      const u = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${auth.access_token}` },
      }).then((x) => (x.ok ? x.json() : null));
      if (u?.email) this.salvarAuth({ email: u.email });
    } catch {}

    try {
      await this.garantirPastaDrive();
    } catch (e) {
      this.log(`Google Drive conectado, mas aviso ao verificar pasta inicial: ${e.message}`, 'aviso');
    }

    this.ultimoErro = null;
    this.log(`☁️ Google Drive conectado com sucesso${this.lerAuth().email ? ` (${this.lerAuth().email})` : ''}! Pasta "${PASTA_DRIVE_PADRAO}" pronta.`, 'ok');
    this.aoMudar(this.status());
    return this.status();
  }

  desconectar({ apagarCredenciais = false } = {}) {
    const auth = this.lerAuth();
    try { fs.unlinkSync(this.arqAuth); } catch {}
    if (!apagarCredenciais) {
      // Preserva apenas a preferencia autoUploadCapcut sem tokens
      escreverJsonAtomico(this.arqAuth, { autoUploadCapcut: auth.autoUploadCapcut !== false });
    } else {
      try { fs.unlinkSync(this.arqCreds); } catch {}
    }
    this.ultimoErro = null;
    this.log('Google Drive desconectado.', 'aviso');
    this.aoMudar(this.status());
    return this.status();
  }

  /** Devolve um access_token valido (renovando automaticamente via refresh_token se necessario). */
  async obterAccessToken() {
    const creds = this.lerCredenciais();
    const auth = this.lerAuth();
    if (!creds || (!auth.access_token && !auth.refresh_token)) {
      throw new Error('Google Drive não está conectado.');
    }
    if (auth.access_token && auth.expiry_date && Date.now() < auth.expiry_date - 120_000) {
      return auth.access_token;
    }
    if (!auth.refresh_token) {
      throw new Error('Sessão do Google Drive expirou (sem refresh_token). Clique em "Conectar Google Drive" novamente.');
    }
    const body = new URLSearchParams({
      client_id: creds.clientId,
      client_secret: creds.clientSecret,
      refresh_token: auth.refresh_token,
      grant_type: 'refresh_token',
    });
    const r = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });
    const dados = await r.json().catch(() => ({}));
    if (!r.ok || !dados.access_token) {
      throw new Error(`Falha ao renovar token do Google Drive: ${dados.error_description || dados.error || r.status}`);
    }
    this.salvarAuth({
      access_token: dados.access_token,
      expiry_date: Date.now() + Number(dados.expires_in || 3500) * 1000,
    });
    return dados.access_token;
  }

  /** Localiza ou cria automaticamente a pasta `FlowStudio_Videos_Prontos` no Google Drive. */
  async garantirPastaDrive() {
    const token = await this.obterAccessToken();
    const auth = this.lerAuth();

    if (auth.pastaId) {
      const check = await fetch(
        `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(auth.pastaId)}?fields=id,name,trashed`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (check.ok) {
        const meta = await check.json().catch(() => null);
        if (meta?.id && !meta.trashed) return meta.id;
      }
    }

    const q = `name='${PASTA_DRIVE_PADRAO}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
    const busca = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)&pageSize=5`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (busca.ok) {
      const jb = await busca.json().catch(() => ({}));
      if (jb.files?.[0]?.id) {
        this.salvarAuth({ pastaId: jb.files[0].id });
        return jb.files[0].id;
      }
    }

    const criar = await fetch('https://www.googleapis.com/drive/v3/files?fields=id,name', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: PASTA_DRIVE_PADRAO,
        mimeType: 'application/vnd.google-apps.folder',
      }),
    });
    const jc = await criar.json().catch(() => ({}));
    if (!criar.ok || !jc.id) {
      throw new Error(`Não consegui criar a pasta "${PASTA_DRIVE_PADRAO}" no Drive: ${jc.error?.message || criar.status}`);
    }
    this.salvarAuth({ pastaId: jc.id });
    return jc.id;
  }

  /** Envia um stream de arquivo para a sessao resumable do Google Drive com progresso em tempo real. */
  _enviarStreamResumable(uploadUrl, arquivoAbs, tamanhoBytes, mimeType) {
    return new Promise((resolve, reject) => {
      const u = new URL(uploadUrl);
      const req = https.request(
        {
          protocol: u.protocol,
          hostname: u.hostname,
          port: u.port || 443,
          path: u.pathname + u.search,
          method: 'PUT',
          headers: {
            'Content-Length': tamanhoBytes,
            'Content-Type': mimeType,
          },
        },
        (res) => {
          let raw = '';
          res.on('data', (d) => { raw += d.toString('utf8'); });
          res.on('end', () => {
            let json = {};
            try { json = JSON.parse(raw); } catch {}
            if (res.statusCode >= 200 && res.statusCode < 300 && json.id) {
              resolve(json);
            } else {
              reject(new Error(json.error?.message || `Upload Drive HTTP ${res.statusCode}: ${raw.slice(0, 200)}`));
            }
          });
        }
      );

      req.on('error', reject);

      let enviados = 0;
      let ultimoEmit = 0;
      const stream = fs.createReadStream(arquivoAbs, { highWaterMark: 512 * 1024 });
      stream.on('data', (chunk) => {
        enviados += chunk.length;
        const agora = Date.now();
        if (agora - ultimoEmit > 600 || enviados === tamanhoBytes) {
          ultimoEmit = agora;
          this.uploadAtual = {
            nome: path.basename(arquivoAbs),
            bytesEnviados: enviados,
            totalBytes: tamanhoBytes,
            pct: Math.min(100, Math.round((enviados / Math.max(1, tamanhoBytes)) * 100)),
          };
          this.aoMudar(this.status());
        }
      });
      stream.on('error', (err) => { req.destroy(err); reject(err); });
      stream.pipe(req);
    });
  }

  /**
   * Faz upload do `.mp4`/`.mov` para `FlowStudio_Videos_Prontos`, aplica `anyone with link (reader)`
   * e retorna `{ fileId, nome, webViewLink, downloadLink, permissaoPublica, tamanhoBytes }`.
   */
  async subirVideo(arquivoAbs, { nomeExibicao = null } = {}) {
    if (!arquivoAbs || !fs.existsSync(arquivoAbs)) {
      throw new Error(`Arquivo de vídeo não encontrado para upload: ${arquivoAbs}`);
    }
    const st = fs.statSync(arquivoAbs);
    const nome = nomeExibicao || path.basename(arquivoAbs);
    const mimeType = /\.mov$/i.test(nome) ? 'video/quicktime' : 'video/mp4';

    this.ultimoErro = null;
    this.uploadAtual = { nome, bytesEnviados: 0, totalBytes: st.size, pct: 0 };
    this.aoMudar(this.status());

    try {
      const token = await this.obterAccessToken();
      const pastaId = await this.garantirPastaDrive();

      // 1) Inicia sessao resumable
      const ini = await fetch(
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,size,webViewLink,webContentLink',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json; charset=UTF-8',
            'X-Upload-Content-Type': mimeType,
            'X-Upload-Content-Length': String(st.size),
          },
          body: JSON.stringify({
            name: nome,
            parents: [pastaId],
          }),
        }
      );
      if (!ini.ok) {
        const txt = await ini.text().catch(() => '');
        throw new Error(`Falha ao iniciar upload no Google Drive (${ini.status}): ${txt.slice(0, 200)}`);
      }
      const uploadUrl = ini.headers.get('location');
      if (!uploadUrl) throw new Error('Google Drive não retornou a URL de sessão resumable.');

      this.log(`☁️ Google Drive: enviando "${nome}" (${(st.size / (1024 * 1024)).toFixed(1)} MB) para ${PASTA_DRIVE_PADRAO}...`, 'info');
      const arqCriado = await this._enviarStreamResumable(uploadUrl, arquivoAbs, st.size, mimeType);

      // 2) Permissao "qualquer pessoa com o link pode visualizar/baixar" (facilita abrir/salvar no iPhone)
      let permissaoPublica = false;
      try {
        const perm = await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(arqCriado.id)}/permissions`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ role: 'reader', type: 'anyone' }),
        });
        permissaoPublica = perm.ok;
      } catch {}

      const links = montarLinksDrive(arqCriado.id, arqCriado.webViewLink);
      const infoUpload = {
        ...links,
        nome,
        arquivoLocal: arquivoAbs,
        tamanhoBytes: st.size,
        permissaoPublica,
        enviadoEm: new Date().toISOString(),
      };
      this.uploadAtual = null;
      this.salvarAuth({ ultimoUpload: infoUpload });
      this.log(`☁️ Vídeo "${nome}" salvo no Google Drive! Link: ${links.webViewLink}`, 'ok');
      return infoUpload;
    } catch (e) {
      this.uploadAtual = null;
      this.ultimoErro = e.message;
      this.aoMudar(this.status());
      this.log(`❌ Google Drive: falha no upload de "${nome}" — ${e.message}`, 'erro');
      throw e;
    }
  }
}
