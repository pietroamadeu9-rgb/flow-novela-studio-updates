// =============================================================
//  Flow Novela Studio - Parser de Roteiros
//  Regras:
//   {id}                 -> nome exato do arquivo do proximo item
//   (i) texto            -> referencia_imagem / texto_puro / 9:16   -> 01_Referencias/<id>.png
//   (i) [a] [b] texto    -> imagem_base / ingredientes_imagem        -> 02_Imagens_Base/<id>.png
//   (v) [a] texto        -> video / frame_inicial (1 ref)            -> 03_Videos/<id>.mp4
//   (v) [a] [b] texto    -> video / elementos_video (2+ refs ou forcado)
//   Demais linhas (BLOCO x, Imagem-base:, Parte x...) sao ignoradas.
// =============================================================

export const PASTAS = {
  referencia_imagem: '01_Referencias',
  imagem_base: '02_Imagens_Base',
  video: '03_Videos',
};

const EXTENSOES = { referencia_imagem: 'png', imagem_base: 'png', video: 'mp4' };
const BLOCOS = { referencia_imagem: 1, imagem_base: 2, video: 3 };

/** Remove caracteres proibidos em nomes de arquivo do Windows. */
export function nomeArquivoSeguro(id) {
  let s = String(id)
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[. ]+$/, '');
  if (/^(con|prn|aux|nul|com\d|lpt\d)$/i.test(s)) s = '_' + s;
  return s || 'item';
}

/** Zero a esquerda para numero final de 1 digito: "Cena 1" -> "Cena 01", "imagem_2" -> "imagem_02". */
export function nomeComZero(nome) {
  return String(nome).replace(/^(.*\D)(\d)$/, '$10$2');
}

/** Ordenacao numerica natural ("Cena 2" antes de "Cena 10"). */
export const compararNumerico = (a, b) => String(a).localeCompare(String(b), 'pt-BR', { numeric: true, sensitivity: 'base' });

/** Normaliza uma linha: remove marcadores markdown comuns (**, __, `, > , - , * ). */
function normalizarLinha(raw) {
  let l = String(raw).replace(/\u00A0/g, ' ').replace(/\uFEFF/g, '').trim();
  // remove negrito/italico/codigo envolvendo a linha inteira
  for (let k = 0; k < 3; k++) {
    const m = l.match(/^(\*\*|__|\*|_|`)(.*)\1$/);
    if (m) l = m[2].trim();
  }
  // remove bullets / citacao no inicio
  l = l.replace(/^(?:>\s*|[-*•]\s+)/, '').trim();
  return l;
}

/** Detecta a duracao do video lendo "10 seconds" / "15 seconds" (tambem "15s", "15 segundos"). */
export function detectarDuracao(texto) {
  const re = /\b(\d{1,2})\s*-?\s*(?:seconds?|secs?|segundos?|s)\b/gi;
  let m;
  while ((m = re.exec(texto))) {
    const n = Number(m[1]);
    if (n === 15) return { duracao: 15, detectada: true };
    if (n === 10) return { duracao: 10, detectada: true };
  }
  return { duracao: 10, detectada: false };
}

/** Define o submodo de video conforme numero de refs e a opcao "Forcar Modo Elementos". */
export function submodoVideo(qtdRefs, forcarElementos) {
  if (forcarElementos) return 'elementos_video';
  if (qtdRefs >= 2) return 'elementos_video';
  if (qtdRefs === 1) return 'frame_inicial';
  return 'texto_video';
}

/** Recalcula os submodos dos videos de uma lista de itens (quando a chave do projeto muda). */
export function aplicarModoElementos(itens, forcarElementos) {
  return itens.map((it) =>
    it.tipo === 'video' ? { ...it, submodo: submodoVideo(it.refs.length, forcarElementos) } : it
  );
}

const RE_CABECALHO = [
  /^BLOCO\b/i,
  /^Imagem[\s-]*base\s*:/i,
  /^Parte\s*\d+/i,
  /^Cena\s*\d+\s*[:—–-]/i,
  /^#{1,6}\s/,
  /^[=\-—–_*]{3,}$/,
];

/**
 * Faz o parse completo de um roteiro.
 * @param {string} texto
 * @param {{forcarElementos?: boolean}} opts
 */
export function parseRoteiro(texto, opts = {}) {
  const forcar = !!opts.forcarElementos;
  const linhas = String(texto || '').replace(/\r\n?/g, '\n').split('\n');

  const itens = [];
  const erros = [];
  const avisos = [];
  const ignoradas = [];
  const declarados = new Map(); // id -> {ordem, tipo, linha}

  let idPendente = null;
  let linhaIdPendente = 0;
  let blocoAtual = null;
  let autoN = 0;

  linhas.forEach((raw, idx) => {
    const n = idx + 1;
    const linha = normalizarLinha(raw);
    if (!linha) return;

    // 1) Cabecalho "BLOCO N"
    const bm = linha.match(/^BLOCO\s*(\d+)/i);
    if (bm) {
      blocoAtual = Number(bm[1]);
      ignoradas.push({ linha: n, texto: linha, motivo: 'cabeçalho de bloco' });
      return;
    }

    // 2) Linha {id}
    const im = linha.match(/^\{\s*([^{}]+?)\s*\}$/);
    if (im) {
      if (idPendente) {
        avisos.push({
          linha: linhaIdPendente,
          msg: `O identificador {${idPendente}} não foi seguido por nenhuma linha (i)/(v) e foi descartado.`,
        });
      }
      idPendente = im[1];
      linhaIdPendente = n;
      return;
    }

    // 2b) Linha combinada "{id} -> (i)/(v) ..." ou "{id} (i)/(v) ..."
    let linhaPrompt = linha;
    const imInline = linha.match(/^\{\s*([^{}]+?)\s*\}\s*(?:->|→|[:—–-])?\s*(\(\s*[iIvV]\s*\)[\s\S]*)$/);
    if (imInline) {
      if (idPendente) {
        avisos.push({
          linha: linhaIdPendente,
          msg: `O identificador {${idPendente}} não foi seguido por nenhuma linha (i)/(v) e foi descartado.`,
        });
      }
      idPendente = imInline[1];
      linhaIdPendente = n;
      linhaPrompt = imInline[2].trim();
    }

    // 3) Linha (i) / (v)
    const pm = linhaPrompt.match(/^\(\s*([iIvV])\s*\)\s*/);
    if (!pm) {
      const motivo = RE_CABECALHO.some((r) => r.test(linha)) ? 'cabeçalho/título' : 'texto livre';
      ignoradas.push({ linha: n, texto: linha.slice(0, 160), motivo });
      return;
    }

    const marcador = pm[1].toLowerCase();
    const resto = linhaPrompt.slice(pm[0].length);
    const refs = [...resto.matchAll(/\[\s*([^\[\]]+?)\s*\]/g)].map((m) => m[1]).filter(Boolean);
    const prompt = resto
      .replace(/\[[^\[\]]*\]/g, ' ')
      .replace(/\s{2,}/g, ' ')
      .replace(/^[\s:—–-]+/, '')
      .trim();

    let tipo, submodo, duracao = null;
    if (marcador === 'i') {
      if (refs.length === 0) { tipo = 'referencia_imagem'; submodo = 'texto_puro'; }
      else { tipo = 'imagem_base'; submodo = 'ingredientes_imagem'; }
    } else {
      tipo = 'video';
      submodo = submodoVideo(refs.length, forcar);
      const d = detectarDuracao(resto);
      duracao = d.duracao;
      if (!d.detectada) avisos.push({ linha: n, msg: 'Duração não encontrada no texto ("10 seconds"/"15 seconds"). Usando padrão de 10s.' });
      if (refs.length === 0) avisos.push({ linha: n, msg: 'Vídeo (v) sem nenhuma [referência]. Será gerado apenas por texto.' });
    }

    let id = idPendente;
    if (!id) {
      autoN += 1;
      id = `sem_id_${String(autoN).padStart(2, '0')}`;
      avisos.push({ linha: n, msg: `Linha (${marcador}) sem {identificador} antes dela. Nome automático "${id}" atribuído.` });
    }
    idPendente = null;

    if (!prompt) erros.push({ linha: n, id, msg: `O item {${id}} está sem texto de prompt.` });

    if (declarados.has(id)) {
      erros.push({ linha: n, id, msg: `Identificador duplicado {${id}} (já declarado na linha ${declarados.get(id).linha}).` });
    }

    // Validacao das referencias (devem ser declaradas ANTES)
    const refsFaltando = [];
    refs.forEach((r) => {
      const dec = declarados.get(r);
      if (!dec) {
        refsFaltando.push(r);
        const existeDepois = linhas.slice(idx + 1).some((l) => normalizarLinha(l).match(new RegExp('^\\{\\s*' + r.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*\\}$')));
        erros.push({
          linha: n, id, ref: r,
          msg: existeDepois
            ? `[${r}] usada em {${id}} só é declarada DEPOIS. Mova a declaração {${r}} para antes.`
            : `[${r}] usada em {${id}} não existe — falta declarar {${r}} antes neste roteiro.`,
        });
      } else if (dec.tipo === 'video') {
        avisos.push({ linha: n, msg: `[${r}] em {${id}} aponta para um vídeo; o Flow normalmente só aceita imagens como ingrediente.` });
      }
    });

    if (blocoAtual && blocoAtual !== BLOCOS[tipo]) {
      avisos.push({ linha: n, msg: `{${id}} é do tipo ${tipo} mas está dentro do BLOCO ${blocoAtual}.` });
    }

    const arquivoNome = `${tipo === 'referencia_imagem' ? nomeArquivoSeguro(id) : nomeComZero(nomeArquivoSeguro(id))}.${EXTENSOES[tipo]}`;
    const item = {
      id,
      ordem: itens.length + 1,
      bloco: BLOCOS[tipo],
      tipo,
      submodo,
      proporcao: '9:16',
      duracao,
      refs,
      refsFaltando,
      prompt,
      linhaOrigem: n,
      pasta: PASTAS[tipo],
      arquivoNome,
      caminhoRelativo: `${PASTAS[tipo]}/${arquivoNome}`,
    };
    itens.push(item);
    declarados.set(id, { ordem: item.ordem, tipo, linha: n });
  });

  if (idPendente) {
    avisos.push({ linha: linhaIdPendente, msg: `O identificador {${idPendente}} no final do texto não tem prompt e foi descartado.` });
  }

  // Nomes de arquivo que colidem apos sanitizacao
  const vistos = new Map();
  itens.forEach((it) => {
    const k = it.caminhoRelativo.toLowerCase();
    if (vistos.has(k) && vistos.get(k) !== it.id) {
      erros.push({ linha: it.linhaOrigem, id: it.id, msg: `{${it.id}} gera o mesmo arquivo que {${vistos.get(k)}} (${it.caminhoRelativo}).` });
    }
    vistos.set(k, it.id);
  });

  const resumo = {
    referencias: itens.filter((i) => i.tipo === 'referencia_imagem').length,
    imagensBase: itens.filter((i) => i.tipo === 'imagem_base').length,
    videos: itens.filter((i) => i.tipo === 'video').length,
    total: itens.length,
    linhasIgnoradas: ignoradas.length,
  };

  return { itens, resumo, validacao: { ok: erros.length === 0, erros, avisos }, ignoradas };
}
