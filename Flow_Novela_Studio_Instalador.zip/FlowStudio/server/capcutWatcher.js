// =============================================================
//  Vigia de exportacao do CapCut PC -> envia a legenda do Facebook pelo WhatsApp
//  - Detecta pasta real de exportacao nos configs do CapCut PC + monitora Videos e Desktop quando sem pasta customizada
//  - Vincula automaticamente a novela mais recente com legendaFacebook pendente quando novelaAguardandoCapcutId estiver vazio
//  - Regra anti-envio prematuro: > 1 MB, tamanho identico por 5 s e destravado para escrita
// =============================================================
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { escreverJsonAtomico, lerJson } from './store.js';
import { formatarMensagemWhatsappDrive } from './googleDriveService.js';

export const MIN_BYTES = 1024 * 1024;
export const ESTAVEL_MS = 5000;
const EXT_VIDEO = /\.(mp4|mov)$/i;
const TEMP = /\.(tmp|part|crdownload)$/i;

/**
 * Detector de estabilizacao (funcao pura, testavel): recebe o estado anterior do arquivo e a leitura atual.
 * Estavel = tamanho > 1 MB, identico por >= 5 s seguidos e arquivo destravado para escrita.
 */
export function avaliarEstabilidade(estado, { tamanho, agora, travado }) {
  const e = estado && estado.tamanho === tamanho ? { ...estado } : { tamanho, desde: agora };
  const idade = agora - e.desde;
  const estavel = tamanho > MIN_BYTES && idade >= ESTAVEL_MS && !travado;
  return { estado: e, estavel, motivo: estavel ? 'ok' : tamanho <= MIN_BYTES ? 'pequeno' : idade < ESTAVEL_MS ? 'tamanho_mudando' : 'travado' };
}

/** Tenta abrir em r+ (falha enquanto o CapCut ainda escreve/trava o arquivo). */
export function arquivoTravado(abs) {
  try { const fd = fs.openSync(abs, 'r+'); fs.closeSync(fd); return false; } catch { return true; }
}

const normalizar = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const chavePasta = (p) => path.resolve(String(p || '')).replace(/[\\/]+$/, '').toLowerCase();

/** Casa o nome do arquivo com uma novela (titulo ou slug). */
export function novelaPeloNomeDoArquivo(nomeArquivo, novelas) {
  const nf = normalizar(path.basename(nomeArquivo, path.extname(nomeArquivo)));
  if (!nf) return null;
  let melhor = null;
  for (const n of novelas) {
    const alvos = [n.nome, n.serieSlug, n.pasta].filter(Boolean).map(normalizar);
    for (const a of alvos) {
      if (!a) continue;
      const palavras = a.split(' ').filter((p) => p.length >= 4 && !/^(parte|part)$/.test(p));
      const ok = nf.includes(a) || (palavras.length >= 2 && palavras.every((p) => nf.includes(p)));
      if (ok && (!melhor || a.length > melhor.tam)) melhor = { n, tam: a.length };
    }
  }
  return melhor?.n || null;
}

/** Tenta descobrir a ultima pasta real de exportacao nos arquivos locais de config do CapCut PC. */
export function detectarPastaExportacaoCapcutConfig() {
  const home = os.homedir() || process.env.USERPROFILE || '';
  const local = process.env.LOCALAPPDATA || (home ? path.join(home, 'AppData', 'Local') : '');
  if (!local) return [];
  const dirsConfig = [path.join(local, 'CapCut', 'User Data', 'Config')];
  try {
    const pkgs = path.join(local, 'Packages');
    if (fs.existsSync(pkgs)) {
      for (const pkg of fs.readdirSync(pkgs).filter((n) => /capcut/i.test(n))) {
        dirsConfig.push(path.join(pkgs, pkg, 'LocalCache', 'Local', 'CapCut', 'User Data', 'Config'));
      }
    }
  } catch {}

  const achadas = [];
  const RE_CHAVE = /^\s*"?(?:export|save|output|last_?export|video_?export|custom_?export)[a-z0-9_.-]*(?:path|dir|folder|location)"?\s*[:=]\s*"?([^"\r\n]+)"?/gim;
  const RE_IGNORAR = /VideoRecord|agencycache|prerender|com\.lveditor\.draft|Cloud files|Presets|Cache/i;

  for (const dir of dirsConfig) {
    if (!fs.existsSync(dir)) continue;
    let arqs = [];
    try { arqs = fs.readdirSync(dir); } catch { continue; }
    for (const nome of arqs) {
      const full = path.join(dir, nome);
      try {
        const st = fs.statSync(full);
        if (!st.isFile() || st.size > 600_000) continue;
        const txt = fs.readFileSync(full, 'utf8');
        let m;
        RE_CHAVE.lastIndex = 0;
        while ((m = RE_CHAVE.exec(txt))) {
          const cand = m[1].trim().replace(/\\\\/g, '\\').replace(/\//g, path.sep);
          if (!cand || RE_IGNORAR.test(cand) || !/^[A-Za-z]:\\/.test(cand)) continue;
          if (fs.existsSync(cand) && fs.statSync(cand).isDirectory()) achadas.push(cand);
        }
      } catch {}
    }
  }
  return [...new Set(achadas)];
}

export function candidatosPastaCapcut() {
  const home = os.homedir() || process.env.USERPROFILE || '';
  const local = process.env.LOCALAPPDATA || (home ? path.join(home, 'AppData', 'Local') : '');
  const oneDrive = process.env.OneDrive || process.env.OneDriveConsumer || (home ? path.join(home, 'OneDrive') : '');
  const brutas = [
    ...detectarPastaExportacaoCapcutConfig(),
    path.join(local, 'CapCut', 'Videos'),
    path.join(home, 'Videos', 'CapCut'),
    path.join(home, 'Videos'),
    path.join(home, 'Desktop'),
    ...(oneDrive ? [path.join(oneDrive, 'Videos'), path.join(oneDrive, 'Desktop'), path.join(oneDrive, 'Área de Trabalho')] : []),
    path.join(home, 'Movies', 'CapCut'),
  ];
  const vistas = new Set();
  const unicas = [];
  for (const p of brutas) {
    if (!p || !fs.existsSync(p)) continue;
    const k = chavePasta(p);
    if (vistas.has(k)) continue;
    vistas.add(k);
    unicas.push(p);
  }
  return unicas;
}

export class CapcutWatcher {
  constructor({ dadosDir, store, whatsapp, gdrive = null, log, aoMudar = () => {}, emitirNovela = () => {}, intervaloMs = 1000 }) {
    this.arq = path.join(dadosDir, 'capcut_config.json');
    this.store = store;
    this.whatsapp = whatsapp;
    this.gdrive = gdrive;
    this.log = log;
    this.aoMudar = aoMudar;
    this.emitirNovela = emitirNovela;
    this.intervaloMs = intervaloMs;
    this.timer = null;
    this.baseline = new Map(); // arquivo -> mtime (ms) de quando o monitor ligou; export que SOBRESCREVE um antigo (mtime novo) conta como novo
    this.estados = new Map(); // arquivo -> estado de estabilidade
    this.processados = new Set(); // "arquivo|mtime" ja tratados nesta sessao
    this.driveProcessados = new Set(); // "arquivo|mtime" ja enviados ao Google Drive nesta sessao
    this.pendentesWhatsapp = new Set(); // exports prontos esperando o WhatsApp conectar
    this._ultimoUploadPromise = null;
    this.cfg = this.carregar();
    this.vincularNovelaPendenteSeVazio({ salvar: false });
  }

  carregar() {
    const salvo = lerJson(this.arq, {});
    const padraoCapcutVideos = path.join(process.env.LOCALAPPDATA || '', 'CapCut', 'Videos');
    // Se nao havia flag explicita pastaCustomizada e o caminho era apenas o default antigo CapCut\Videos,
    // mantem pastaCustomizada = false para vigiar tambem Videos e Desktop automaticamente!
    const customSalva = typeof salvo.pastaCustomizada === 'boolean'
      ? salvo.pastaCustomizada
      : Boolean(salvo.pastaExportacaoCapcut && chavePasta(salvo.pastaExportacaoCapcut) !== chavePasta(padraoCapcutVideos));

    const c = {
      pastaExportacaoCapcut: salvo.pastaExportacaoCapcut || '',
      pastaCustomizada: customSalva,
      monitorAtivo: true,
      novelaAguardandoCapcutId: null,
      historico: [],
      destinoWhatsapp: '',
      ultimoVideoExportado: null,
      ...salvo,
    };
    c.pastaCustomizada = customSalva;
    if (c.pastaExportacaoCapcut && !fs.existsSync(c.pastaExportacaoCapcut)) {
      c.pastaExportacaoCapcut = '';
      c.pastaCustomizada = false;
    }
    return c;
  }

  salvar() { escreverJsonAtomico(this.arq, this.cfg); this.aoMudar(this.estadoPublico()); }

  /**
   * Lista todas as pastas efetivamente vigiadas:
   * - Se o usuario escolheu uma pasta customizada (ou um teste definiu pastaExportacaoCapcut): vigia ela + pasta detectada no config do CapCut PC.
   * - Se nenhum caminho customizado foi escolhido: vigia config do CapCut PC + CapCut\Videos + %USERPROFILE%\Videos + %USERPROFILE%\Desktop.
   */
  pastasVigiadasDetalhadas() {
    const lista = [];
    const vistas = new Set();
    const add = (pasta, origem, varrerSubpastas = true) => {
      if (!pasta || !fs.existsSync(pasta)) return;
      const k = chavePasta(pasta);
      if (vistas.has(k)) return;
      vistas.add(k);
      lista.push({ pasta, origem, varrerSubpastas });
    };

    const padraoCapcutVideos = path.join(process.env.LOCALAPPDATA || '', 'CapCut', 'Videos');
    const temPastaExplicita = Boolean(
      this.cfg.pastaExportacaoCapcut &&
      fs.existsSync(this.cfg.pastaExportacaoCapcut) &&
      (this.cfg.pastaCustomizada || chavePasta(this.cfg.pastaExportacaoCapcut) !== chavePasta(padraoCapcutVideos))
    );

    if (temPastaExplicita) {
      add(this.cfg.pastaExportacaoCapcut, 'configurada manualmente', true);
      for (const p of detectarPastaExportacaoCapcutConfig()) add(p, 'config local do CapCut PC', true);
      return lista;
    }

    // Sem pasta customizada: monitora automaticamente config do CapCut + Videos + Desktop!
    for (const p of detectarPastaExportacaoCapcutConfig()) add(p, 'config local do CapCut PC', true);
    const local = process.env.LOCALAPPDATA || '';
    const home = process.env.USERPROFILE || '';
    const oneDrive = process.env.OneDrive || process.env.OneDriveConsumer || '';
    if (local) add(path.join(local, 'CapCut', 'Videos'), 'padrão CapCut Videos', true);
    if (home) {
      add(path.join(home, 'Videos', 'CapCut'), 'Vídeos\\CapCut', true);
      add(path.join(home, 'Videos'), 'pasta Vídeos do Windows', true);
      add(path.join(home, 'Desktop'), 'Área de Trabalho', false);
    }
    if (oneDrive) {
      add(path.join(oneDrive, 'Videos'), 'OneDrive Vídeos', true);
      add(path.join(oneDrive, 'Desktop'), 'OneDrive Área de Trabalho', false);
      add(path.join(oneDrive, 'Área de Trabalho'), 'OneDrive Área de Trabalho', false);
    }
    return lista;
  }

  /** Retorna a novela mais recente que possui legendaFacebook ainda nao enviada ao WhatsApp. */
  novelaPendenteMaisRecente() {
    if (!this.store) return null;
    const pendentes = this.store.listar().filter((n) => n.legendaFacebook && !n.legendaEnviadaWhatsappEm);
    if (!pendentes.length) return null;
    const chaveData = (n) => String(n.concluidaEm || n.capcut?.enviadoEm || n.processadoEm || n.atualizadoEm || n.criadoEm || '');
    return pendentes.sort((a, b) => chaveData(b).localeCompare(chaveData(a)))[0] || null;
  }

  /** Se `novelaAguardandoCapcutId` estiver vazio (ou apontar para novela removida), vincula automaticamente a pendente mais recente. */
  vincularNovelaPendenteSeVazio({ salvar = true } = {}) {
    const atual = this.cfg.novelaAguardandoCapcutId ? this.store?.obter(this.cfg.novelaAguardandoCapcutId) : null;
    if (atual?.legendaFacebook) return atual;
    const pendente = this.novelaPendenteMaisRecente();
    if (pendente) {
      this.cfg.novelaAguardandoCapcutId = pendente.id;
      if (salvar) this.salvar();
      return pendente;
    }
    if (this.cfg.novelaAguardandoCapcutId && !atual) {
      this.cfg.novelaAguardandoCapcutId = null;
      if (salvar) this.salvar();
    }
    return null;
  }

  /** Localiza o ultimo video exportado (> 1 MB) para o botao manual do Google Drive. */
  acharUltimoVideoLocal() {
    const salvo = this.cfg.ultimoVideoExportado;
    if (salvo?.abs && fs.existsSync(salvo.abs)) {
      try {
        const st = fs.statSync(salvo.abs);
        if (st.isFile() && st.size > MIN_BYTES) {
          return { abs: salvo.abs, nome: path.basename(salvo.abs), tamanho: st.size, mtime: st.mtimeMs };
        }
      } catch {}
    }
    const candidatos = this.listarVideos()
      .filter((v) => v.tamanho > MIN_BYTES)
      .sort((a, b) => b.mtime - a.mtime);
    if (!candidatos.length) return null;
    const v = candidatos[0];
    return { abs: v.abs, nome: path.basename(v.abs), tamanho: v.tamanho, mtime: v.mtime };
  }

  estadoPublico() {
    this.vincularNovelaPendenteSeVazio({ salvar: false });
    const vigiadas = this.pastasVigiadasDetalhadas();
    const ultimo = this.acharUltimoVideoLocal();
    return {
      ...this.cfg,
      candidatas: candidatosPastaCapcut(),
      pastasVigiadas: vigiadas,
      monitorRodando: !!this.timer,
      pastaExiste: vigiadas.length > 0,
      observando: [...this.estados.keys()].map((a) => path.basename(a)),
      pendentesWhatsapp: [...this.pendentesWhatsapp],
      ultimoVideoDetectado: ultimo ? { nome: ultimo.nome, abs: ultimo.abs, tamanho: ultimo.tamanho } : null,
    };
  }

  atualizar(patch = {}) {
    if (patch.modoAutomaticoPastas === true) {
      this.cfg.pastaExportacaoCapcut = '';
      this.cfg.pastaCustomizada = false;
      this.reiniciar();
    } else if (typeof patch.pastaExportacaoCapcut === 'string') {
      const p = patch.pastaExportacaoCapcut.trim();
      if (p && !fs.existsSync(p)) throw new Error('Essa pasta não existe.');
      const mudou = p !== this.cfg.pastaExportacaoCapcut || Boolean(p) !== Boolean(this.cfg.pastaCustomizada);
      this.cfg.pastaExportacaoCapcut = p;
      this.cfg.pastaCustomizada = Boolean(p);
      if (mudou) this.reiniciar();
    }
    if (typeof patch.monitorAtivo === 'boolean') { this.cfg.monitorAtivo = patch.monitorAtivo; }
    if ('novelaAguardandoCapcutId' in patch) {
      this.cfg.novelaAguardandoCapcutId = patch.novelaAguardandoCapcutId || null;
      if (!this.cfg.novelaAguardandoCapcutId) this.vincularNovelaPendenteSeVazio({ salvar: false });
    }
    if (typeof patch.destinoWhatsapp === 'string') this.cfg.destinoWhatsapp = patch.destinoWhatsapp.replace(/[^\d+]/g, '');
    this.salvar();
    if (this.cfg.monitorAtivo) this.iniciar(); else this.parar();
    return this.estadoPublico();
  }

  /** Abre o seletor nativo de pastas do Windows (FolderBrowserDialog) e devolve a pasta escolhida. */
  escolherPasta() {
    return new Promise((resolve, reject) => {
      if (process.platform !== 'win32') return reject(new Error('Seletor de pastas disponível só no Windows.'));
      const inicial = (this.cfg.pastaExportacaoCapcut || process.env.USERPROFILE || '').replace(/'/g, "''");
      const script = [
        'Add-Type -AssemblyName System.Windows.Forms',
        '$f = New-Object System.Windows.Forms.FolderBrowserDialog',
        '$f.Description = "Escolha a pasta onde você salva os vídeos editados do CapCut"',
        `$f.SelectedPath = '${inicial}'`,
        '$f.ShowNewFolderButton = $true',
        '$o = New-Object System.Windows.Forms.Form; $o.TopMost = $true; $o.WindowState = "Minimized"; $o.ShowInTaskbar = $false; $o.Show()',
        '$r = $f.ShowDialog($o); $o.Close()',
        'if ($r -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::OutputEncoding = [Text.Encoding]::UTF8; Write-Output $f.SelectedPath }',
      ].join('; ');
      const ps = spawn('powershell.exe', ['-STA', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: false });
      let out = '';
      ps.stdout.on('data', (d) => (out += d.toString('utf8')));
      const timer = setTimeout(() => { try { ps.kill(); } catch {} reject(new Error('Tempo esgotado esperando a escolha da pasta.')); }, 5 * 60 * 1000);
      ps.on('error', (e) => { clearTimeout(timer); reject(e); });
      ps.on('close', () => {
        clearTimeout(timer);
        const pasta = out.trim().split(/\r?\n/).pop()?.trim();
        if (!pasta) return resolve({ cancelado: true, ...this.estadoPublico() });
        resolve({ cancelado: false, ...this.atualizar({ pastaExportacaoCapcut: pasta }) });
      });
    });
  }

  listarVideos() {
    const vigiadas = this.pastasVigiadasDetalhadas();
    if (!vigiadas.length) return [];
    const achados = [];
    const vistosArq = new Set();
    const varrer = (dir, nivel, maxNivel) => {
      let itens = [];
      try { itens = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const d of itens) {
        const abs = path.join(dir, d.name);
        if (d.isFile() && EXT_VIDEO.test(d.name) && !TEMP.test(d.name)) {
          const k = chavePasta(abs);
          if (vistosArq.has(k)) continue;
          vistosArq.add(k);
          try { const st = fs.statSync(abs); achados.push({ abs, tamanho: st.size, mtime: st.mtimeMs }); } catch {}
        } else if (d.isDirectory() && nivel < maxNivel && !/^(node_modules|\.|FlowStudio)/i.test(d.name)) {
          varrer(abs, nivel + 1, maxNivel);
        }
      }
    };
    for (const v of vigiadas) {
      varrer(v.pasta, 0, v.varrerSubpastas ? 1 : 0);
    }
    return achados;
  }

  iniciar() {
    if (this.timer || !this.cfg.monitorAtivo) return;
    this.vincularNovelaPendenteSeVazio({ salvar: false });
    const vigiadas = this.pastasVigiadasDetalhadas();
    if (!vigiadas.length) return;
    // ignora tudo que ja estava nas pastas antes de ligar o monitor
    this.baseline = new Map(this.listarVideos().map((v) => [v.abs, v.mtime]));
    this.estados.clear();
    this.timer = setInterval(() => this.tick().catch((e) => this.log(`Vigia CapCut: ${e.message}`, 'aviso')), this.intervaloMs);
    this.log(
      `Vigia do CapCut ligado em ${vigiadas.length} pasta(s): ${vigiadas.map((v) => v.pasta).join(' | ')} — ${this.baseline.size} vídeo(s) antigo(s) ignorado(s).`,
      'ok'
    );
    this.aoMudar(this.estadoPublico());
  }

  parar() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      this.log('Vigia do CapCut desligado.', 'aviso');
      this.aoMudar(this.estadoPublico());
    }
  }

  reiniciar() {
    const estava = !!this.timer;
    this.parar();
    this.baseline.clear();
    this.estados.clear();
    this.processados.clear();
    this.driveProcessados.clear();
    this.pendentesWhatsapp.clear();
    if (estava || this.cfg.monitorAtivo) this.iniciar();
  }

  /** Uma varredura: detecta novos videos e processa os que estabilizaram. (`agora` injetavel p/ teste) */
  async tick(agora = Date.now()) {
    for (const v of this.listarVideos()) {
      const chave = `${v.abs}|${Math.round(v.mtime)}`;
      // antigo = existia ao ligar E nao foi modificado depois (se o CapCut sobrescreveu o arquivo, o mtime muda e vira novo)
      if (this.baseline.has(v.abs) && v.mtime <= this.baseline.get(v.abs) + 1) continue;
      if (this.processados.has(chave)) continue;
      const leitura = { tamanho: v.tamanho, agora, travado: v.tamanho > MIN_BYTES ? arquivoTravado(v.abs) : false };
      const r = avaliarEstabilidade(this.estados.get(v.abs), leitura);
      this.estados.set(v.abs, r.estado);
      if (r.estavel) { v.chave = chave; await this.aoEstabilizar(v.abs, chave); }
    }
    for (const k of [...this.estados.keys()]) if (!fs.existsSync(k)) this.estados.delete(k);
  }

  escolherNovela(nomeArquivo) {
    const todas = this.store.listar().filter((n) => n.legendaFacebook);
    const pendentes = todas.filter((n) => !n.legendaEnviadaWhatsappEm);
    // 1) Casa pelo nome do arquivo (priorizando as ainda nao enviadas)
    const porNomePendente = novelaPeloNomeDoArquivo(nomeArquivo, pendentes);
    if (porNomePendente) return { n: porNomePendente, origem: 'nome do arquivo' };
    // 2) Novela selecionada / vinculada
    const manual = this.cfg.novelaAguardandoCapcutId ? this.store.obter(this.cfg.novelaAguardandoCapcutId) : null;
    if (manual?.legendaFacebook && !manual.legendaEnviadaWhatsappEm) return { n: manual, origem: 'novela vinculada' };
    // 3) Vincula automaticamente a novela mais recente que possua legendaFacebook ainda nao enviada
    const auto = this.novelaPendenteMaisRecente();
    if (auto) {
      this.cfg.novelaAguardandoCapcutId = auto.id;
      return { n: auto, origem: 'novela pendente mais recente (automática)' };
    }
    // 4) Se a manual ja tinha sido enviada ou casou por nome em novela ja enviada (para logar ja_enviada)
    if (manual?.legendaFacebook) return { n: manual, origem: 'novela selecionada' };
    const porNomeQualquer = novelaPeloNomeDoArquivo(nomeArquivo, todas);
    if (porNomeQualquer) return { n: porNomeQualquer, origem: 'nome do arquivo' };
    return null;
  }

  registrar(entrada) {
    this.cfg.historico = [{ t: new Date().toISOString(), ...entrada }, ...(this.cfg.historico || [])].slice(0, 50);
    this.salvar();
  }

  /**
   * Sobe o `.mp4`/`.mov` pro Google Drive, grava o link no historico do CapCut
   * e envia a Mensagem 2 no WhatsApp (separada da legenda limpa do Facebook).
   */
  async subirEEnviarLinkDrive(abs, { novela = null, numeroOpcional = '', origem = 'automático' } = {}) {
    const nome = path.basename(abs);
    const up = await this.gdrive.subirVideo(abs);
    this.cfg.ultimoVideoExportado = {
      abs,
      nome,
      em: up.enviadoEm,
      driveLink: up.webViewLink,
      driveDownloadLink: up.downloadLink,
      fileId: up.fileId,
    };

    // Anexa o link do Drive na entrada mais recente deste arquivo no historico (ou cria uma nova no envio manual)
    const hist = this.cfg.historico || [];
    const itemRecente = origem !== 'botão manual'
      ? hist.find((h) => h.arquivo === nome && !h.driveLink)
      : null;
    if (itemRecente) {
      itemRecente.driveLink = up.webViewLink;
      itemRecente.driveDownloadLink = up.downloadLink;
    } else {
      this.cfg.historico = [
        {
          t: new Date().toISOString(),
          arquivo: nome,
          novela: novela?.nome || '—',
          resultado: 'drive_enviado',
          detalhe: `${origem} → Google Drive`,
          driveLink: up.webViewLink,
          driveDownloadLink: up.downloadLink,
        },
        ...hist,
      ].slice(0, 50);
    }

    let enviadoWhatsapp = false;
    let jid = null;
    if (this.whatsapp?.status().conectado) {
      const msg2 = formatarMensagemWhatsappDrive(up);
      const rZap = await this.whatsapp.enviarTexto(msg2, String(numeroOpcional || this.cfg.destinoWhatsapp || '').trim());
      enviadoWhatsapp = true;
      jid = rZap?.jid || rZap?.para || null;
      this.log(`📲 Link do Google Drive enviado no WhatsApp (Mensagem 2 separada da legenda): ${up.webViewLink}`, 'ok');
    } else {
      this.log(`☁️ Vídeo salvo no Google Drive (${up.webViewLink}), mas o WhatsApp está desconectado — link disponível na tela.`, 'aviso');
    }
    this.salvar();
    return { ...up, enviadoWhatsapp, jid };
  }

  /** Botao manual "☁️ Subir Último Vídeo pro Drive e Mandar Link". */
  async subirUltimoVideoEMandarLink(numeroOpcional = '') {
    if (!this.gdrive || !this.gdrive.conectado()) {
      throw new Error('Conecte primeiro o Google Drive no card "Google Drive Automático".');
    }
    const ultimo = this.acharUltimoVideoLocal();
    if (!ultimo?.abs) {
      throw new Error('Nenhum vídeo exportado (.mp4 ou .mov acima de 1 MB) foi encontrado nas pastas vigiadas do CapCut.');
    }
    const alvo = this.escolherNovela(ultimo.nome);
    return await this.subirEEnviarLinkDrive(ultimo.abs, {
      novela: alvo?.n || null,
      numeroOpcional,
      origem: 'botão manual',
    });
  }

  _dispararDriveBackground(abs, chave, novela) {
    if (!this.gdrive?.deveSubirAutomatico() || this.driveProcessados.has(chave)) return;
    this.driveProcessados.add(chave);
    this._ultimoUploadPromise = this.subirEEnviarLinkDrive(abs, { novela, origem: 'automático pós-CapCut' })
      .catch((e) => this.log(`Google Drive automático falhou: ${e.message}`, 'erro'));
  }

  async aoEstabilizar(abs, chave = abs) {
    const nome = path.basename(abs);
    this.cfg.ultimoVideoExportado = {
      ...(this.cfg.ultimoVideoExportado?.abs === abs ? this.cfg.ultimoVideoExportado : {}),
      abs,
      nome,
      em: new Date().toISOString(),
    };
    const alvo = this.escolherNovela(nome);
    if (!alvo) {
      this.processados.add(chave);
      this.registrar({ arquivo: nome, resultado: 'ignorado', detalhe: 'nenhuma novela com legenda para casar' });
      this.log(`Vigia CapCut: "${nome}" pronto, mas nenhuma novela com legenda do Facebook foi encontrada.`, 'aviso');
      this._dispararDriveBackground(abs, chave, null);
      return;
    }
    if (!this.whatsapp.status().conectado) {
      this.pendentesWhatsapp.add(nome); // continua tentando a cada varredura ate o WhatsApp conectar
      if (!this._avisouSemZap) {
        this._avisouSemZap = true;
        this.log(`Vigia CapCut: "${nome}" terminou de salvar em ${path.dirname(abs)}, mas o WhatsApp não está conectado. Conecte para enviar a legenda.`, 'aviso');
      }
      return;
    }
    this._avisouSemZap = false;
    this.pendentesWhatsapp.delete(nome);
    const { n, origem } = alvo;
    if (n.legendaEnviadaWhatsappEm) {
      this.processados.add(chave);
      this.registrar({ arquivo: nome, novela: n.nome, resultado: 'ja_enviada', detalhe: `legenda já enviada em ${n.legendaEnviadaWhatsappEm}` });
      this._dispararDriveBackground(abs, chave, n);
      return;
    }
    try {
      // a) Mensagem 1 (IMEDIATA): SOMENTE a legenda limpa do Facebook + hashtags (zero link!)
      const r = await this.whatsapp.enviarTexto(n.legendaFacebook, this.cfg.destinoWhatsapp || '');
      n.legendaEnviadaWhatsappEm = new Date().toISOString();
      this.store.salvar(n);
      this.emitirNovela(n);
      this.processados.add(chave);
      // Apos enviar, se houver outra novela pendente, ja deixa pronta; senao limpa ou mantem
      const proxima = this.novelaPendenteMaisRecente();
      if (proxima) this.cfg.novelaAguardandoCapcutId = proxima.id;
      this.registrar({ arquivo: nome, novela: n.nome, resultado: 'enviada', detalhe: `casou por ${origem} → ${r.jid || r.para}` });
      this.log(`📲 Legenda de "${n.nome}" enviada ao WhatsApp (${r.jid || r.para}) após salvar "${nome}" em ${path.dirname(abs)}.`, 'ok');
      // b) Mensagem 2 (EM SEGUNDO PLANO): sobe pro Google Drive e manda o link separado!
      this._dispararDriveBackground(abs, chave, n);
    } catch (e) {
      this.registrar({ arquivo: nome, novela: n.nome, resultado: 'erro', detalhe: e.message });
      this.log(`Vigia CapCut: falha ao enviar legenda de "${n.nome}" — ${e.message}`, 'erro');
      this.processados.add(chave);
    }
  }

  /** Botao "🧪 Testar Disparo de Legenda Agora": executa o mesmo fluxo real de selecao + envio via Baileys. */
  async testarDisparoAgora(numeroOpcional = '') {
    this.vincularNovelaPendenteSeVazio({ salvar: false });
    let alvo = this.escolherNovela('teste_disparo_capcut.mp4');
    if (!alvo) {
      const qualquerComLegenda = this.store.listar().filter((n) => n.legendaFacebook).pop();
      if (qualquerComLegenda) alvo = { n: qualquerComLegenda, origem: 'última novela com legenda' };
    }
    if (!alvo?.n?.legendaFacebook) {
      throw new Error('Nenhuma novela com legenda do Facebook encontrada no Estúdio para testar.');
    }
    const destino = String(numeroOpcional || this.cfg.destinoWhatsapp || '').trim();
    const r = await this.whatsapp.enviarTexto(alvo.n.legendaFacebook, destino);
    this.registrar({
      arquivo: '(🧪 teste de disparo)',
      novela: alvo.n.nome,
      resultado: 'enviada',
      detalhe: `teste manual (${alvo.origem}) → ${r.jid || r.para}`,
    });
    this.log(`🧪 Disparo de legenda testado com sucesso: "${alvo.n.nome}" → ${r.jid || r.para}.`, 'ok');
    return { ok: true, novela: alvo.n.nome, jid: r.jid, para: r.para, origem: alvo.origem };
  }

  /** Chamado quando uma novela e atualizada ou importada: vincula automaticamente se estiver vazio ou concluir videos. */
  aoAtualizarNovela(n) {
    try {
      if (!n?.legendaFacebook) return;
      if (!this.cfg.novelaAguardandoCapcutId && !n.legendaEnviadaWhatsappEm) {
        this.cfg.novelaAguardandoCapcutId = n.id;
        this.salvar();
      }
      if (n.concluidaMarcada) return;
      const videos = (n.itens || []).filter((i) => i.tipo === 'video');
      if (!videos.length || !videos.every((i) => i.status === 'concluido')) return;
      n.concluidaMarcada = true;
      n.concluidaEm = new Date().toISOString();
      this.store.salvar(n);
      if (!n.legendaEnviadaWhatsappEm) {
        this.cfg.novelaAguardandoCapcutId = n.id;
        this.salvar();
      }
      this.log(`🎬 "${n.nome}" concluiu todos os vídeos no Flow — aguardando salvar no CapCut para disparar a legenda no WhatsApp.`, 'ok');
    } catch {}
  }
}
