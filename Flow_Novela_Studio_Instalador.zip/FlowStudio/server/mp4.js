// Leitor de MP4 em Node.js puro (sem ffprobe): duracao exata (mvhd/mdhd) e dimensoes (tkhd).
import fs from 'node:fs';

function lerBoxes(fd, inicio, fim) {
  const boxes = [];
  let pos = inicio;
  const h = Buffer.alloc(16);
  while (pos + 8 <= fim) {
    fs.readSync(fd, h, 0, 16, pos);
    let tam = h.readUInt32BE(0);
    const tipo = h.toString('latin1', 4, 8);
    let cab = 8;
    if (tam === 1) { tam = Number(h.readBigUInt64BE(8)); cab = 16; }
    else if (tam === 0) tam = fim - pos;
    if (tam < cab) break;
    boxes.push({ tipo, inicio: pos, dados: pos + cab, fim: pos + tam });
    pos += tam;
  }
  return boxes;
}

function lerBuffer(fd, b) {
  const buf = Buffer.alloc(b.fim - b.dados);
  fs.readSync(fd, buf, 0, buf.length, b.dados);
  return buf;
}

/** mvhd / mdhd: versao 0 (32 bits) ou 1 (64 bits) */
function timescaleDuracao(buf) {
  const versao = buf[0];
  if (versao === 1) return { timescale: buf.readUInt32BE(20), duracao: Number(buf.readBigUInt64BE(24)) };
  return { timescale: buf.readUInt32BE(12), duracao: buf.readUInt32BE(16) };
}

/**
 * @returns {{duracaoUs:number, duracaoSeg:number, largura:number, altura:number, temAudio:boolean, temVideo:boolean}}
 */
export function lerMp4(caminho) {
  const fd = fs.openSync(caminho, 'r');
  try {
    const tamanho = fs.fstatSync(fd).size;
    const topo = lerBoxes(fd, 0, tamanho);
    if (!topo.some((b) => b.tipo === 'ftyp')) throw new Error('Não é um MP4 válido (sem "ftyp").');
    const moov = topo.find((b) => b.tipo === 'moov');
    if (!moov) throw new Error('MP4 sem átomo "moov" (arquivo incompleto?).');
    const filhos = lerBoxes(fd, moov.dados, moov.fim);
    const mvhd = filhos.find((b) => b.tipo === 'mvhd');
    let { timescale, duracao } = timescaleDuracao(lerBuffer(fd, mvhd));
    let largura = 0, altura = 0, temAudio = false, temVideo = false, duracaoVideoUs = 0;
    for (const trak of filhos.filter((b) => b.tipo === 'trak')) {
      const tb = lerBoxes(fd, trak.dados, trak.fim);
      const mdia = tb.find((b) => b.tipo === 'mdia');
      if (!mdia) continue;
      const mb = lerBoxes(fd, mdia.dados, mdia.fim);
      const hdlr = mb.find((b) => b.tipo === 'hdlr');
      const handler = hdlr ? lerBuffer(fd, hdlr).toString('latin1', 8, 12) : '';
      if (handler === 'soun') temAudio = true;
      if (handler === 'vide') {
        temVideo = true;
        const tkhd = tb.find((b) => b.tipo === 'tkhd');
        if (tkhd) {
          const t = lerBuffer(fd, tkhd);
          const off = t[0] === 1 ? 88 : 76; // largura/altura 16.16 no fim do tkhd
          largura = Math.round(t.readUInt32BE(off) / 65536);
          altura = Math.round(t.readUInt32BE(off + 4) / 65536);
        }
        const mdhd = mb.find((b) => b.tipo === 'mdhd');
        if (mdhd) { const d = timescaleDuracao(lerBuffer(fd, mdhd)); if (d.timescale) duracaoVideoUs = Math.round((d.duracao / d.timescale) * 1e6); }
      }
    }
    let duracaoUs = timescale ? Math.round((duracao / timescale) * 1e6) : 0;
    if (!duracaoUs && duracaoVideoUs) duracaoUs = duracaoVideoUs;
    if (!duracaoUs) throw new Error('Não consegui ler a duração do MP4.');
    return { duracaoUs, duracaoSeg: duracaoUs / 1e6, duracaoVideoUs, largura, altura, temAudio, temVideo };
  } finally {
    fs.closeSync(fd);
  }
}
