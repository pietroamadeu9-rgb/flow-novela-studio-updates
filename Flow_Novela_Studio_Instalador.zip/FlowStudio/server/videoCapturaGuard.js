// =============================================================
//  Trava Dupla Anti-Duplicacao de Videos + Casamento de Cenas por Prompt
//  1) Normalizacao de URL de midia (sem query string / tokens assinados / prefixo /u/N/)
//  2) Hash SHA-256 real dos arquivos .mp4 salvos nas cenas anteriores da novela
//  3) Extracao de trechos exclusivos (falas entre aspas + acao unica) para casar cards no modo Elementos
// =============================================================
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

/**
 * Remove query strings temporarias (?Expires=...&Signature=...&authuser=...), hashes (#...)
 * e normaliza prefixos de conta (/u/0..99/) do Google Flow, preservando case-sensitivity do token /asb/...
 */
export function normalizarUrlMidia(url) {
  if (!url || typeof url !== 'string') return '';
  const limpa = url.trim();
  if (!limpa || limpa.startsWith('data:') || limpa.startsWith('blob:')) return '';
  try {
    const u = new URL(limpa, 'https://flow.google.com');
    let pathname = u.pathname || '/';
    if (u.hostname === 'flow.google.com' || u.hostname === 'labs.google') {
      pathname = pathname.replace(/^\/u\/\d+(?=\/|$)/, '') || '/';
    }
    pathname = pathname.replace(/\/+$/, '') || '/';
    return `${u.protocol.toLowerCase()}//${u.host.toLowerCase()}${pathname}`;
  } catch {
    return limpa.split(/[?#]/)[0].replace(/\/+$/, '');
  }
}

/** Calcula o hash SHA-256 (hex lowercase) de um caminho de arquivo ou Buffer. */
export function calcularSha256(arquivoOuBuffer) {
  const h = crypto.createHash('sha256');
  if (Buffer.isBuffer(arquivoOuBuffer)) {
    h.update(arquivoOuBuffer);
    return h.digest('hex');
  }
  if (typeof arquivoOuBuffer === 'string' && fs.existsSync(arquivoOuBuffer)) {
    h.update(fs.readFileSync(arquivoOuBuffer));
    return h.digest('hex');
  }
  return '';
}

/**
 * Coleta os Sets/Maps de URLs base (sem query params) e hashes SHA-256
 * dos videos ja concluidos na novela (ignorando `excluirItemId` ao regerar/substituir a propria cena).
 */
export function coletarAssinaturasVideosNovela(novela, pastaNovelaAbs, { excluirItemId = null } = {}) {
  const urlsUsadas = new Map();   // urlBaseNormalizada -> itemId
  const hashesUsados = new Map(); // sha256Hex -> itemId

  for (const it of novela?.itens || []) {
    if (it.tipo !== 'video' || it.id === excluirItemId) continue;
    if (it.status !== 'concluido' && !it.arquivo) continue;

    // 1) Hashes SHA-256 reais dos arquivos .mp4 ja salvos no disco
    let sha = it.sha256 || '';
    if (!sha && it.arquivo && pastaNovelaAbs) {
      const abs = path.join(pastaNovelaAbs, it.arquivo);
      if (fs.existsSync(abs)) {
        try {
          sha = calcularSha256(abs);
          it.sha256 = sha;
        } catch {}
      }
    }
    if (sha && !hashesUsados.has(sha)) {
      hashesUsados.set(sha, it.id);
    }

    // 2) URLs base normalizadas (sem query params) ja associadas a esta cena
    // Se duas cenas antigas compartilhavam a mesma chave por bug anterior, registra na primeira cena vista
    const brutas = [it.flowMidiaChave, ...(Array.isArray(it.flowMidiaUrls) ? it.flowMidiaUrls : [])].filter(Boolean);
    for (const raw of brutas) {
      const norm = normalizarUrlMidia(raw);
      if (norm && !urlsUsadas.has(norm)) {
        urlsUsadas.set(norm, it.id);
      }
    }
  }

  return { urlsUsadas, hashesUsados };
}

/**
 * Verifica se o video candidato repete URL base (sem query params) OU hash SHA-256 de outra cena da novela.
 */
export function verificarDuplicidadeVideo({
  itemId,
  urlsCandidatas = [],
  sha256Candidato = '',
  urlsUsadas = new Map(),
  hashesUsados = new Map(),
}) {
  for (const raw of urlsCandidatas) {
    const norm = normalizarUrlMidia(raw);
    if (!norm) continue;
    const dono = urlsUsadas.get(norm);
    if (dono && dono !== itemId) {
      return {
        duplicado: true,
        motivo: 'url',
        cenaOriginal: dono,
        valor: norm,
      };
    }
  }

  if (sha256Candidato) {
    const donoHash = hashesUsados.get(sha256Candidato);
    if (donoHash && donoHash !== itemId) {
      return {
        duplicado: true,
        motivo: 'sha256',
        cenaOriginal: donoHash,
        valor: sha256Candidato,
      };
    }
  }

  return { duplicado: false, motivo: null, cenaOriginal: null, valor: null };
}

// ---------------- Normalizacao e casamento por trecho unico do prompt ----------------

export function normalizarTextoPrompt(s) {
  return String(s || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[“”«»„]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

/** Extrai falas entre aspas ("...") de um prompt. */
export function extrairFalasPrompt(prompt) {
  const txt = String(prompt || '').replace(/[“”«»„]/g, '"');
  const achadas = [];
  const re = /"([^"\n]{6,260})"/g;
  let m;
  while ((m = re.exec(txt))) {
    const fala = normalizarTextoPrompt(m[1]).replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, '');
    if (fala.length >= 6 && !achadas.includes(fala)) achadas.push(fala);
  }
  return achadas;
}

/**
 * Extrai trechos exclusivos deste prompt que NAO ocorrem em nenhum dos `outrosPrompts` da novela
 * (falas em portugues + Opening shot + trechos de acao unicos).
 */
export function extrairAssinaturaPrompt(prompt, outrosPrompts = []) {
  const norm = normalizarTextoPrompt(prompt);
  const outrosNorm = outrosPrompts.map(normalizarTextoPrompt).filter((p) => p && p !== norm);
  const exclusivo = (trecho) => trecho && trecho.length >= 10 && outrosNorm.every((o) => !o.includes(trecho));

  const falas = extrairFalasPrompt(prompt);
  const falasExclusivas = falas.filter(exclusivo);

  const trechosExclusivos = [];
  // Prioriza "Opening shot: ..." e frases intermediarias de acao
  const mOpen = norm.match(/opening shot:\s*([^."]{15,140})/);
  if (mOpen && exclusivo(mOpen[1].trim())) trechosExclusivos.push(mOpen[1].trim());

  // Janelas deslizantes de ~48 caracteres ao longo do prompt que so existem nesta cena
  const passo = Math.max(24, Math.floor(norm.length / 18));
  for (let pos = 0; pos + 48 <= norm.length && trechosExclusivos.length < 10; pos += passo) {
    const sub = norm.slice(pos, pos + 48).trim();
    if (exclusivo(sub) && !trechosExclusivos.some((t) => t.includes(sub) || sub.includes(t))) {
      trechosExclusivos.push(sub);
    }
  }

  return { norm, falas, falasExclusivas, trechosExclusivos };
}

/**
 * Pontua o quanto `card` (prompt original + chips de ingredientes `imagem_NN`, ignorando `aria-label` renomeado)
 * corresponde a `cena` vs `todasCenas`.
 */
export function pontuarCardContraCena(cardOuPrompt, cena, assinaturasPorId, mapaChaveParaItemId = new Map()) {
  const objCard = typeof cardOuPrompt === 'string' ? { promptLimpo: cardOuPrompt } : (cardOuPrompt || {});
  const card = normalizarTextoPrompt(objCard.promptLimpo || '');
  const chipsTexto = (objCard.chips || []).map(normalizarTextoPrompt).filter(Boolean);
  const chipsChaves = (objCard.chipsChaves || []).map(normalizarUrlMidia).filter(Boolean);

  let pontos = 0;

  // Sinal extra: se o card expuser o chip `imagem_NN` (por nome ou pela chave de midia de imagem_01..12)
  const refsCena = new Set((cena.refs || []).map(normalizarTextoPrompt));
  for (const ch of chipsTexto) {
    const mImg = ch.match(/\b(imagem[\s_-]*\d+)\b/i);
    if (mImg) {
      const idImg = normalizarTextoPrompt(mImg[1].replace(/[\s-]+/g, '_'));
      if (refsCena.has(idImg)) pontos += 180;
      else return -500; // chip imagem_MM pertence exclusivamente a outra cena!
    }
  }
  for (const ck of chipsChaves) {
    const idRef = mapaChaveParaItemId.get(ck);
    if (idRef && /^imagem_\d+$/i.test(idRef)) {
      if (refsCena.has(normalizarTextoPrompt(idRef))) pontos += 180;
      else return -500;
    }
  }

  if (!card || card.length < 15) return pontos > 0 ? pontos : -1;

  const minha = assinaturasPorId.get(cena.id);
  if (!minha) return pontos > 0 ? pontos : -1;

  // Se o card contem fala exclusiva de OUTRA cena, penaliza fortemente (nunca confundir cenas no mesmo cenario!)
  for (const [outroId, outAss] of assinaturasPorId.entries()) {
    if (outroId === cena.id) continue;
    if (outAss.falasExclusivas.some((f) => f.length >= 10 && card.includes(f))) {
      return -500;
    }
  }

  for (const f of minha.falasExclusivas) {
    if (card.includes(f)) pontos += 150;
  }
  for (const f of minha.falas) {
    if (card.includes(f)) pontos += 60;
  }
  for (const t of minha.trechosExclusivos) {
    if (card.includes(t)) pontos += 35;
  }

  // Caso o prompt do card seja identico por inteiro
  if (card === minha.norm || card.includes(minha.norm) || (card.length > 180 && minha.norm.includes(card.replace(/…|\.\.\.$/, '').trim()))) {
    pontos += 80;
  }

  return pontos > 0 ? pontos : -1;
}

/**
 * Casa de forma bijetiva (1 card unico <-> 1 cena unica, ZERO repeticao de URL/card)
 * todos os cards de video escaneados no Google Flow com as `{Cena NN}` da novela.
 *
 * IMPORTANTE: Ignora por padrao `card.ariaLabel` (`Cena 06`, `Cena 12`), pois cards renomeados por cima
 * durante falhas anteriores estao com nomes errados! Usa prompt/fala unica + chip `imagem_NN` + desempate cronologico!
 */
export function casarCardsComCenas(cards = [], cenas = [], { itensNovela = [], usarDesempateCronologico = true } = {}) {
  const todosPrompts = cenas.map((c) => c.prompt || '');
  const assinaturasPorId = new Map(
    cenas.map((c) => [c.id, extrairAssinaturaPrompt(c.prompt || '', todosPrompts.filter((p) => p !== c.prompt))])
  );

  // Mapa chaveMidia -> itemId (ex.: URL /asb/ de imagem_01..imagem_12 salva na novela)
  const mapaChaveParaItemId = new Map();
  for (const it of itensNovela || []) {
    if (it.tipo === 'video') continue;
    for (const raw of [it.flowMidiaChave, ...(it.flowMidiaUrls || [])].filter(Boolean)) {
      const k = normalizarUrlMidia(raw);
      if (k) mapaChaveParaItemId.set(k, it.id);
    }
  }

  // Deduplica cards que compartilhem qualquer chave de midia normalizada
  const cardsUnicos = [];
  const chavesVistas = new Set();
  for (const c of cards) {
    const normChaves = (c.chaves || []).map(normalizarUrlMidia).filter(Boolean);
    if (!normChaves.length) continue;
    if (normChaves.some((k) => chavesVistas.has(k))) continue;
    normChaves.forEach((k) => chavesVistas.add(k));
    cardsUnicos.push({ ...c, chavesNorm: normChaves });
  }

  // No Google Flow, `ordemTopo = 0` e o card MAIS RECENTE (topo-esquerda) e `cardsUnicos.length - 1` e o MAIS ANTIGO (fundo-direita).
  // Portanto a posicao cronologica (0 = Cena 01 mais antiga ... N-1 = mais recente) e invertida em relacao ao topo!
  const posCronologicaCard = (idxCard) => {
    const c = cardsUnicos[idxCard];
    const ord = typeof c.ordemTopo === 'number' ? c.ordemTopo : idxCard;
    return Math.max(0, cardsUnicos.length - 1 - ord);
  };

  const pares = [];
  for (const [idxCena, cena] of cenas.entries()) {
    for (const [idxCard, card] of cardsUnicos.entries()) {
      const pts = pontuarCardContraCena(card, cena, assinaturasPorId, mapaChaveParaItemId);
      if (pts > 0) {
        const distCrono = Math.abs(posCronologicaCard(idxCard) - idxCena);
        pares.push({ idxCena, idxCard, cena, card, pontos: pts, distCrono, metodo: 'prompt' });
      }
    }
  }

  // Ordena maior pontuacao primeiro; em empate de pontuacao, desempata pela ordem cronologica na grade do Flow!
  pares.sort((a, b) => b.pontos - a.pontos || a.distCrono - b.distCrono);

  const cenasCasadas = new Set();
  const cardsUsados = new Set();
  const chavesAlocadas = new Set();
  const casamentos = [];

  for (const p of pares) {
    if (cenasCasadas.has(p.cena.id) || cardsUsados.has(p.idxCard)) continue;
    if (p.card.chavesNorm.some((k) => chavesAlocadas.has(k))) continue;
    cenasCasadas.add(p.cena.id);
    cardsUsados.add(p.idxCard);
    p.card.chavesNorm.forEach((k) => chavesAlocadas.add(k));
    casamentos.push({ cena: p.cena, card: p.card, pontos: p.pontos, metodo: p.metodo });
  }

  // Desempate cronologico garantido: se sobrarem cards sem prompt legivel E a contagem de cards bater com as cenas restantes,
  // pareia na ordem cronologica do mais antigo (Cena inicial) ao mais recente (Cena final), NUNCA pelo nome errado!
  if (usarDesempateCronologico) {
    const cenasRestantes = cenas.filter((c) => !cenasCasadas.has(c.id));
    const idxCardsRestantes = cardsUnicos
      .map((card, i) => ({ card, i, crono: posCronologicaCard(i) }))
      .filter((x) => !cardsUsados.has(x.i) && !x.card.chavesNorm.some((k) => chavesAlocadas.has(k)) && (!x.card.promptLimpo || x.card.promptLimpo.length < 20))
      .sort((a, b) => a.crono - b.crono);

    if (cenasRestantes.length > 0 && idxCardsRestantes.length === cenasRestantes.length) {
      for (let k = 0; k < cenasRestantes.length; k++) {
        const cena = cenasRestantes[k];
        const { card, i } = idxCardsRestantes[k];
        cenasCasadas.add(cena.id);
        cardsUsados.add(i);
        card.chavesNorm.forEach((ch) => chavesAlocadas.add(ch));
        casamentos.push({ cena, card, pontos: 5, metodo: 'ordem_cronologica' });
      }
    }
  }

  // Ordena resultado na ordem original das cenas da novela (Cena 01 -> Cena 12)
  const ordemMap = new Map(cenas.map((c, i) => [c.id, i]));
  casamentos.sort((a, b) => (ordemMap.get(a.cena.id) ?? 0) - (ordemMap.get(b.cena.id) ?? 0));

  const naoEncontradas = cenas.filter((c) => !cenasCasadas.has(c.id)).map((c) => c.id);
  return { casamentos, naoEncontradas, totalCardsUnicos: cardsUnicos.length };
}
