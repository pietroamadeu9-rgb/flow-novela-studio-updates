// Testes do importador: modo Elementos x Frame Inicial, multi-anexos preservados, 15s como padrao,
// e limpeza de flowConfig/1080p. Usa uma "Fabrica" temporaria (nao toca em C:\FabricaClaude) e nao gasta tokens.
//   node server/testFabricaModo.js
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const raizServer = path.dirname(fileURLToPath(import.meta.url));
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'fabrica-modo-'));
const fabrica = path.join(tmp, 'Fabrica');
process.env.FABRICA_DIR = fabrica; // ANTES de importar os modulos
const pasta = path.join(fabrica, 'prontos_para_flow', 'teste-modo', 'parte_01');
fs.mkdirSync(pasta, { recursive: true });
fs.mkdirSync(path.join(fabrica, 'dados'), { recursive: true });
const cfgFab = (c) => fs.writeFileSync(path.join(fabrica, 'dados', 'config.json'), JSON.stringify(c));
cfgFab({ modoOperacao: 'aprovacao', duracaoTotalMinutos: 3, tamanhoCenaSegundos: 30, formatoHistoria: 'unica', numeroPartesPadrao: 3 });

const TEC = 'Fixed cameras and hard cuts only. No music. Nobody looks into the lens.';
fs.writeFileSync(path.join(pasta, 'prompts_flow.txt'), [
  'BLOCO 1 — REFERÊNCIAS',
  '{ref_cida} -> (i) vertical 9:16 close-up, young woman.',
  '{ref_valdirene} -> (i) vertical 9:16 close-up, older woman.',
  '{ref_cenario_sala} -> (i) vertical 9:16 empty farmhouse room with no people.',
  '',
  'BLOCO 2 — IMAGENS-BASE',
  '{imagem_01} -> (i) [ref_cenario_sala] [ref_cida] [ref_valdirene] vertical 9:16 two-shot.',
  '{imagem_02} -> (i) [ref_cenario_sala] [ref_cida] vertical 9:16 single.',
  '',
  'BLOCO 3 — PROMPTS DE VÍDEO',
  `{Cena 01} -> (v) [imagem_01] [ref_cida] [ref_valdirene] Exactly 15 seconds vertical 9:16. The young woman on the left speaks in Portuguese: "Oi, tudo bem?" ${TEC}`,
  `{Cena 02} -> (v) [imagem_02] Exactly 15 seconds vertical 9:16. The young woman on the left speaks in Portuguese: "Tudo ótimo." ${TEC}`,
].join('\n'));
fs.writeFileSync(path.join(pasta, 'metadata_flow.json'), JSON.stringify({ titulo: 'Teste Modo', slug: 'teste-modo', serie: false, parte: 1, totalPartes: 1, numeroCenas: 2, tamanhoCenaSegundos: 15, flowConfig: { qualidadeVideo: '4k' } }));
fs.writeFileSync(path.join(pasta, 'legenda_facebook.txt'), 'Você perdoaria?\nEu não sei. 💔\n\n#filme #novela\n');

const { Store } = await import('./store.js');
const { FabricaService } = await import('./fabricaService.js');
const { novelaParaExtensao } = await import('./runner.js');
const { normalizarJid } = await import('./whatsappService.js');

let ok = 0;
const teste = async (nome, fn) => { try { await fn(); ok++; console.log(`  ✓ ${nome}`); } catch (e) { console.log(`  ✗ ${nome}\n    ${e.message}`); process.exitCode = 1; } };

const novoSvc = (padroes) => {
  const dados = fs.mkdtempSync(path.join(tmp, 'd-'));
  const store = new Store(dados, path.join(dados, 'proj'));
  return { store, svc: new FabricaService({ store, log: () => {}, emitirNovela: () => {}, broadcastUI: () => {}, obterPadroes: padroes ? () => padroes : null }) };
};

console.log('\n[1] 15s padrão (sem 30s) e config sem flowConfig');
await teste('lerConfigFabrica converte 30s antigo para 15s e salvarConfigFabrica recusa 30', () => {
  const { svc } = novoSvc();
  assert.equal(svc.lerConfigFabrica().tamanhoCenaSegundos, 15);
  const c = svc.salvarConfigFabrica({ tamanhoCenaSegundos: 30 });
  assert.equal(c.tamanhoCenaSegundos, 15, '30s não pode ser aceito');
  assert.equal(svc.salvarConfigFabrica({ tamanhoCenaSegundos: 10 }).tamanhoCenaSegundos, 10);
  assert.equal(svc.salvarConfigFabrica({ tamanhoCenaSegundos: 15 }).tamanhoCenaSegundos, 15);
  assert.equal(c.flowConfig, undefined, 'flowConfig não pode existir no config da Fábrica');
  assert.equal(JSON.parse(fs.readFileSync(path.join(fabrica, 'dados', 'config.json'), 'utf8')).flowConfig, undefined);
});
await teste('nenhum resquício de flowConfig / 1080p / 30 segundos em fabricaService.js e FabricaClaude.jsx', () => {
  const alvos = [path.join(raizServer, 'fabricaService.js'), path.join(raizServer, '..', 'web', 'src', 'components', 'FabricaClaude.jsx')];
  for (const f of alvos) {
    const t = fs.readFileSync(f, 'utf8').split('\n').filter((l) => !/^\s*(\/\/|\*)/.test(l)).join('\n');
    assert.ok(!/1080p/.test(t), `1080p em ${path.basename(f)}`);
    assert.ok(!/flowConfig\s*[:=]/.test(t.replace(/delete c\.flowConfig/g, '')), `flowConfig em ${path.basename(f)}`);
    assert.ok(!/30 segundos/.test(t), `opção 30 segundos em ${path.basename(f)}`);
  }
});

console.log('\n[2] Importador: modo Elementos (padrão) e Frame Inicial, anexos preservados');
const PAD = { modeloImagem: 'Nano Banana Pro', modeloVideo: 'Omni 1.1 Flash', qualidadeGeracaoVideo: '360p', qualidadeDownloadVideo: 'original', qualidadeDownloadImagem: '1k' };
await teste('modo ELEMENTOS: todos os vídeos em elementos_video, anexos intactos, forcarElementos=true, Padrões do usuário', () => {
  cfgFab({ modoGeracaoVideo: 'elementos', tamanhoCenaSegundos: 15 });
  const { svc } = novoSvc(PAD);
  const r = svc.importar({ slug: 'teste-modo', parte: 1 });
  const n = r.novela;
  assert.ok(r.validacao.ok, JSON.stringify(r.validacao.erros));
  assert.equal(n.forcarElementos, true); assert.equal(n.modoGeracaoVideo, 'elementos');
  const v1 = n.itens.find((i) => i.id === 'Cena 01'); const v2 = n.itens.find((i) => i.id === 'Cena 02');
  assert.deepEqual(v1.refs, ['imagem_01', 'ref_cida', 'ref_valdirene'], 'os 3 anexos devem ser preservados');
  assert.deepEqual(v2.refs, ['imagem_02']);
  assert.equal(v1.submodo, 'elementos_video'); assert.equal(v2.submodo, 'elementos_video', 'no modo elementos até 1 anexo roda em Elementos');
  assert.equal(v1.duracao, 15); assert.equal(v2.duracao, 15);
  assert.equal(n.modeloImagem, 'Nano Banana Pro'); assert.equal(n.qualidadeGeracaoVideo, '360p'); assert.equal(n.qualidadeDownloadVideo, 'original'); assert.equal(n.qualidadeDownloadImagem, '1k');
  const ext = novelaParaExtensao(n);
  assert.equal(ext.forcarElementos, true); assert.equal(ext.modoGeracaoVideo, 'elementos');
});
await teste('modo FRAME INICIAL: 1 anexo = frame_inicial; vários anexos continuam preservados (Elementos pelo parser)', () => {
  cfgFab({ modoGeracaoVideo: 'frame_inicial', tamanhoCenaSegundos: 15 });
  const { svc } = novoSvc(PAD);
  const n = svc.importar({ slug: 'teste-modo', parte: 1 }).novela;
  assert.equal(n.forcarElementos, false); assert.equal(n.modoGeracaoVideo, 'frame_inicial');
  const v1 = n.itens.find((i) => i.id === 'Cena 01'); const v2 = n.itens.find((i) => i.id === 'Cena 02');
  assert.equal(v2.submodo, 'frame_inicial'); assert.deepEqual(v2.refs, ['imagem_02']);
  assert.equal(v1.refs.length, 3, 'anexos nunca podem ser descartados');
  const ext = novelaParaExtensao(n);
  assert.equal(ext.forcarElementos, false); assert.equal(ext.modoGeracaoVideo, 'frame_inicial');
});
await teste('sem Padrões globais disponíveis o importador NÃO inventa qualidade (nada de 1080p forçado)', () => {
  cfgFab({ modoGeracaoVideo: 'elementos' });
  const { svc } = novoSvc(null);
  const n = svc.importar({ slug: 'teste-modo', parte: 1 }).novela;
  assert.equal(n.qualidadeDownloadVideo, undefined); assert.equal(n.qualidadeGeracaoVideo, undefined);
  assert.ok(!JSON.stringify(n).includes('flowConfig'));
});

console.log('\n[3] JID do WhatsApp');
await teste('sock.user.id com :device vira split(":")[0] + @s.whatsapp.net', () => {
  assert.equal(normalizarJid('5511913321436:33@s.whatsapp.net'), '5511913321436@s.whatsapp.net');
  assert.equal(normalizarJid('5511913321436:0@s.whatsapp.net').split('@')[0].includes(':'), false);
});

fs.rmSync(tmp, { recursive: true, force: true });
console.log(`\n${process.exitCode ? '❌ FALHOU' : `✅ ${ok} testes passaram`}`);
