// Testes da arquitetura de 2 chamadas (Prompt Mestre), modelo por chamada + cota, cenas mudas e Fichas Virais.
// SEM gastar tokens: o Claude é substituído por dublês. Usa uma "Fábrica" temporária (copia os prompts/fichas reais).
//   node server/testRoteirista.js
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const REAL = 'C:\\FabricaClaude';
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'roteirista-'));
const fabrica = path.join(tmp, 'Fabrica');
process.env.FABRICA_DIR = fabrica; // ANTES de importar (usage log e prompts ficam no temp: nada do real é tocado)
fs.mkdirSync(path.join(fabrica, 'prompts'), { recursive: true });
fs.mkdirSync(path.join(fabrica, 'fichas_virais'), { recursive: true });
fs.mkdirSync(path.join(fabrica, 'dados'), { recursive: true });
for (const f of ['prompt_mestre_roteirista.md', 'prompt_extrator_ficha.md']) fs.copyFileSync(path.join(REAL, 'prompts', f), path.join(fabrica, 'prompts', f));
fs.copyFileSync(path.join(REAL, 'fichas_virais', 'fichas.json'), path.join(fabrica, 'fichas_virais', 'fichas.json'));
fs.writeFileSync(path.join(fabrica, 'dados', 'config.json'), JSON.stringify({ modoOperacao: 'aprovacao', duracaoTotalMinutos: 3, tamanhoCenaSegundos: 15, formatoHistoria: 'serie', numeroPartesPadrao: 2, modoGeracaoVideo: 'elementos' }));

const { Store } = await import('./store.js');
const { FabricaService, garantirBlindagemCenasMudas, FRASE_CENA_MUDA, limparRoteiroDeJson } = await import('./fabricaService.js');
const { FichasService, inferirTipoConflito, normalizarFicha, lerSecoesPrompt } = await import('./fichasService.js');
const cb = await import('./claudeBridge.js');

let ok = 0;
const teste = async (nome, fn) => { try { await fn(); ok++; console.log(`  ✓ ${nome}`); } catch (e) { console.log(`  ✗ ${nome}\n    ${e.message}`); process.exitCode = 1; } };
const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
const dados = path.join(tmp, 'dados'); fs.mkdirSync(dados, { recursive: true });
const store = new Store(dados, path.join(dados, 'proj'));
const logs = [];
const novoSvc = () => new FabricaService({ store, log: (m, n) => logs.push({ m, n }), emitirNovela: () => {}, broadcastUI: () => {}, obterPadroes: () => ({}) });
const esperarFim = async (svc, id) => { for (let i = 0; i < 300; i++) { const j = svc.jobs.get(id); if (j.estado !== 'rodando') return j; await dormir(25); } throw new Error('job não terminou'); };

const BIBLIA = '{"titulo":"Teste Dupla","slug":"teste-dupla","universo":"urbano_simples","premissa":"Ana acha uma caixa escondida e desconfia do marido.","ironiaDramatica":"o marido só quer fazer uma surpresa","personagens":[{"nome":"ANA","papel":"protagonista","desejo":"saber a verdade","segredo":"leu o celular dele","medo":"ser trocada","voz":"seca e rápida","ref":"ref_ana"}],"cenarios":[{"ref":"ref_cenario_sala","descricao":"sala simples","interior":true}],"segredosEmCamadas":["a caixa","o recibo"],"partes":[{"parte":1,"arco":"suspeita","ganchoDeFim":"a filha chega com o bolo","escaleta":["CENA 01 — Ana acha a caixa"]}]}';
const SAIDA_A = `PARTE 1 — ESCALETA\nDesejos: Ana quer saber a verdade.\nCENA 01 — Ana acha a caixa\nCENA 02 — silêncio: Luiz guarda o presente\n\nPARTE 2 — ROTEIRO\nCENA 01\nANA [brava]: "Pra quem é essa caixa? Fala olhando pra mim!"\n\n===FILE:biblia_serie.json===\n${BIBLIA}\n===END_FILE===\n`;
const ROTEIRO_B = '# Teste Dupla — Parte 1 de 2\nUniverso: urbano_simples\nCenas: 2 x 15s\nTipo-final: aberto\nRelação exata: Ana é casada com Luiz e acha uma caixa escondida.\n\n## CENA 01 (15s) — Gancho\nOnde: ref_cenario_sala (INTERIOR)\nEm quadro: ANA, LUIZ\nNovidade: Ana acha a caixa escondida.\nANA [brava]: "Pra quem é essa caixa? Fala olhando pra mim!" (9 palavras)\nLUIZ [nervoso]: "Amor, calma, deixa eu explicar." (5 palavras)\n\n## CENA 02 (15s) — Silêncio\nOnde: ref_cenario_sala (INTERIOR)\nEm quadro: LUIZ\nNovidade: Luiz guarda o presente escondido.\nAção: Luiz guarda o presente no fundo do armário e apaga a mensagem do celular sorrindo.\n';
const PROMPTS_B = 'BLOCO 1 — REFERÊNCIAS\n{ref_ana} -> (i) vertical 9:16 close-up of Ana.\n\nBLOCO 2 — IMAGENS-BASE\n{imagem_01} -> (i) [ref_ana] x\n{imagem_02} -> (i) [ref_ana] y\n\nBLOCO 3 — PROMPTS DE VÍDEO\n{Cena 01} -> (v) [imagem_01] [ref_ana] Exactly 15 seconds vertical 9:16. The young woman wearing a blue dress on the left speaks in Portuguese: "Pra quem é essa caixa?" No music, narration. Nobody looks into the lens.\n{Cena 02} -> (v) [imagem_02] [ref_ana] Exactly 15 seconds vertical 9:16. A man hides a wrapped gift in a wardrobe, smiling. No music, narration. Nobody looks into the lens.\n';
const SAIDA_B = `===FILE:roteiro_humano.md===\n${ROTEIRO_B}\`\`\`json\n{"vazou": "json"}\n\`\`\`\n===END_FILE===\n===FILE:prompts_flow.txt===\n${PROMPTS_B}===END_FILE===\n===FILE:metadata_flow.json===\n{"titulo":"Teste Dupla — Parte 1","slug":"teste-dupla","parte":1,"totalPartes":2,"tipoFinal":"aberto"}\n===END_FILE===\n===FILE:legenda_linhas.txt===\nVocê já desconfiou de quem mais confia?\nÀs vezes a verdade vem embrulhada. 😅\n===END_FILE===\nRESULTADO_JSON: {"slug":"teste-dupla","parte":1}\n`;

console.log('\n[1] Prompt Mestre: Chamada A (criação e continuação) e Chamada B (formatação)');
await teste('prompt_mestre_roteirista.md tem as seções e a Chamada A pede escaleta + falas vivas + bíblia JSON, com régua de 10s 14–25 e fichas', () => {
  const svc = novoSvc();
  const sec = lerSecoesPrompt(svc.arquivoPromptMestre);
  for (const k of ['chamada_a_criacao', 'chamada_a_continuacao', 'chamada_b_formatacao', 'leis_resumo']) assert.ok(sec[k], `seção ${k} ausente`);
  const a = svc.montarPromptChamadaA({ entrada: 'Marido escondendo um presente e a esposa desconfia', config: { tamanhoCenaSegundos: 10, duracaoTotalMinutos: 3, formatoHistoria: 'serie', tipoConflito: 'traicao_ciume' }, tipoFinal: 'aberto' });
  assert.ok(/ESCALETA DRAMÁTICA/.test(a) && /Desejos/.test(a) && /Segredos/.test(a) && /Ironia dramática/.test(a) && /1 linha por cena|CENA 01 —/.test(a));
  assert.ok(/FALAS VIVAS/.test(a) && /hesita/i.test(a) && /veneno/i.test(a));
  assert.ok(/===FILE:biblia_serie\.json===/.test(a), 'bloco JSON da bíblia');
  assert.ok(/14 a 25 palavras/.test(a) && /18 a 21/.test(a) && /18 cenas/.test(a), 'régua de 10s e nº de cenas');
  assert.ok(/CENA MUDA|cenas mudas/i.test(a));
  assert.ok(/FICHAS DE REFERÊNCIA/.test(a) && /PROIBIDO copiar/.test(a) && /presente escondido/i.test(a), 'fichas injetadas');
  assert.ok(/FINAL ABERTO/i.test(a));
});
await teste('Chamada A de CONTINUAÇÃO usa a bíblia rica + últimas cenas LITERAIS + refs fixas', () => {
  const svc = novoSvc();
  fs.mkdirSync(path.join(fabrica, 'series', 'serie-x'), { recursive: true });
  fs.mkdirSync(path.join(fabrica, 'prontos_para_flow', 'serie-x', 'parte_01'), { recursive: true });
  fs.writeFileSync(path.join(fabrica, 'series', 'serie-x', 'biblia_serie.json'), JSON.stringify({ titulo: 'Série X', premissa: 'p', bibliaRica: { segredosEmCamadas: ['SEGREDO-RICO-123'] } }));
  fs.writeFileSync(path.join(fabrica, 'series', 'serie-x', 'catalogo_refs.json'), JSON.stringify({ personagens: { ref_ana: 'Ana, 30' }, cenarios: { ref_cenario_sala: 'sala' } }));
  const cenas = [1, 2, 3, 4, 5].map((n) => `## CENA 0${n} (15s) — Etapa\nANA [x]: "FALA-LITERAL-${n}"\n`).join('\n');
  fs.writeFileSync(path.join(fabrica, 'prontos_para_flow', 'serie-x', 'parte_01', 'roteiro_humano.md'), `# Série X — Parte 1 de 2\n${cenas}`);
  const a = svc.montarPromptChamadaA({ continuacao: true, config: { tamanhoCenaSegundos: 15, duracaoTotalMinutos: 3 }, tipoFinal: 'fechado', parte: 2, slug: 'serie-x', titulo: 'Série X', totalPartes: 2 });
  assert.ok(/SEGREDO-RICO-123/.test(a), 'bíblia rica');
  assert.ok(/FALA-LITERAL-5/.test(a) && /FALA-LITERAL-3/.test(a) && !/FALA-LITERAL-2/.test(a), 'só as 3 últimas cenas literais');
  assert.ok(/\{ref_ana\} -> Ana, 30/.test(a) && /ref_cenario_sala/.test(a), 'refs fixas');
});
await teste('Chamada B tira o JSON da bíblia do material, manda mexer o mínimo nas falas e só pede o roteiro quando completo=false', () => {
  const svc = novoSvc();
  const b = svc.montarPromptChamadaB({ saidaA: SAIDA_A, config: { tamanhoCenaSegundos: 15, duracaoTotalMinutos: 3 }, tipoFinal: 'aberto', parte: 1, completo: false });
  assert.ok(/FORMATADOR/.test(b) && /Mexa o mínimo possível nas falas/.test(b) && /subtexto, hesitação, veneno/.test(b));
  assert.ok(!/"segredosEmCamadas"/.test(b) && /Pra quem é essa caixa/.test(b), 'JSON da bíblia não pode ir para a Chamada B; as falas sim');
  assert.ok(/APENAS o bloco `===FILE:roteiro_humano\.md===`/.test(b));
  const bc = svc.montarPromptChamadaB({ saidaA: SAIDA_A, config: { tamanhoCenaSegundos: 15, duracaoTotalMinutos: 3 }, tipoFinal: 'aberto', parte: 1, completo: true });
  assert.ok(/TODOS os blocos/.test(bc) && /No spoken dialogue in this scene/.test(bc));
});

console.log('\n[2] Pipeline de 2 etapas (A opus -> B sonnet) com progresso e arquivos limpos');
await teste('criarAutomatico: Etapa 1/2 em Opus, Etapa 2/2 em Sonnet, JSON só na bíblia (nunca no roteiro) e cena muda blindada no prompt', async () => {
  const svc = novoSvc(); svc.autoRepararUmaVezSeNecessario = async () => {};
  const chamadas = []; const etapas = [];
  svc.rodarClaude = async (job, prompt, opts = {}) => {
    chamadas.push({ modelo: opts.modelo, etapaRotulo: opts.etapaRotulo, tipo: opts.tipo, tamanho: prompt.length });
    etapas.push(job.etapa);
    return chamadas.length === 1 ? SAIDA_A : SAIDA_B;
  };
  const j = svc.criarAutomatico({ origem: 'sementes', texto: 'marido escondendo presente', config: { duracaoTotalMinutos: 1, tamanhoCenaSegundos: 15, formatoHistoria: 'serie' }, tipoFinal: 'aberto', importar: false });
  const fim = await esperarFim(svc, j.id);
  assert.equal(fim.estado, 'ok', fim.erro);
  assert.equal(chamadas.length, 2, 'devem ser exatamente 2 chamadas');
  assert.equal(chamadas[0].modelo, 'opus'); assert.equal(chamadas[1].modelo, 'sonnet');
  assert.ok(/Etapa 1\/2: Escaleta e dramaturgia \(Opus\)/.test(chamadas[0].etapaRotulo));
  assert.ok(/Etapa 2\/2: Formatação e ajuste fino \(Sonnet\)/.test(chamadas[1].etapaRotulo));
  assert.ok(/Etapa 2\/2/.test(etapas[1]), 'job.etapa deve mudar para a etapa 2/2');
  assert.deepEqual(fim.etapas.map((e) => `${e.n}:${e.modelo}:${e.estado}`), ['1:opus:ok', '2:sonnet:ok']);
  const pasta = path.join(fabrica, 'prontos_para_flow', 'teste-dupla', 'parte_01');
  const rot = fs.readFileSync(path.join(pasta, 'roteiro_humano.md'), 'utf8');
  assert.ok(!/```|"vazou"|segredosEmCamadas/.test(rot), "nenhum JSON dentro do roteiro_humano.md :: " + rot.slice(-400));
  assert.ok(fs.existsSync(path.join(pasta, 'biblia_rica.json')), 'bíblia rica salva à parte');
  const bs = JSON.parse(fs.readFileSync(path.join(fabrica, 'series', 'teste-dupla', 'biblia_serie.json'), 'utf8'));
  assert.equal(bs.bibliaRica.personagens[0].desejo, 'saber a verdade');
  const prm = fs.readFileSync(path.join(pasta, 'prompts_flow.txt'), 'utf8').split('\n');
  const l1 = prm.find((l) => l.startsWith('{Cena 01}')); const l2 = prm.find((l) => l.startsWith('{Cena 02}'));
  assert.ok(!/No spoken dialogue/.test(l1), 'cena falada NÃO recebe a instrução');
  assert.ok(l2.includes(FRASE_CENA_MUDA) && /lips closed throughout the entire clip/.test(l2) && /pure visual storytelling/.test(l2), 'cena muda deve receber a blindagem');
  assert.ok(l2.indexOf('No spoken dialogue') < l2.indexOf('No music'), 'instrução entra antes do "No music"');
});
await teste('seletor Sonnet: Chamada A roda em sonnet (economia) e a B continua sonnet', async () => {
  const svc = novoSvc(); svc.autoRepararUmaVezSeNecessario = async () => {}; const modelos = [];
  svc.rodarClaude = async (job, p, o = {}) => { modelos.push(o.modelo); return modelos.length === 1 ? SAIDA_A : SAIDA_B; };
  svc.salvarConfigFabrica({ modeloRoteirista: 'sonnet' });
  assert.equal(svc.lerConfigFabrica().modeloRoteirista, 'sonnet');
  const j = svc.criarAutomatico({ origem: 'sementes', texto: 'x', config: { duracaoTotalMinutos: 1 }, tipoFinal: 'fechado', importar: false });
  await esperarFim(svc, j.id);
  assert.deepEqual(modelos, ['sonnet', 'sonnet']);
  svc.salvarConfigFabrica({ modeloRoteirista: 'opus' });
  assert.equal(svc.lerConfigFabrica().modeloRoteirista, 'opus');
  assert.equal(svc.modeloRoteirista(null, 'qualquer-coisa'), 'opus', 'valor inválido volta ao padrão opus');
});
await teste('blindagem de cena muda e limpeza de JSON são funções puras e idempotentes', () => {
  const rot = ROTEIRO_B;
  const a = garantirBlindagemCenasMudas(rot, PROMPTS_B);
  assert.deepEqual(a.corrigidas, [2]);
  const b = garantirBlindagemCenasMudas(rot, a.texto);
  assert.deepEqual(b.corrigidas, [], 'segunda passada não muda nada');
  assert.equal((b.texto.match(/No spoken dialogue/g) || []).length, 1);
  assert.ok(!/```/.test(limparRoteiroDeJson('a\n```json\n{"x":1}\n```\nb')));
});

console.log('\n[3] Modelo por chamada e peso proporcional na cota (claude_usage.jsonl)');
await teste('executarClaude passa --model opus|sonnet e registra o campo "modelo" no claude_usage.jsonl', async () => {
  const fake = path.join(tmp, 'fake_claude.cmd');
  fs.writeFileSync(fake, '@echo off\r\necho ARGS: %*\r\nmore >nul\r\n');
  const log = path.join(tmp, 'uso_teste.jsonl');
  const r1 = await cb.executarClaude({ prompt: 'oi', comando: fake, modelo: 'opus', arquivoUsageLog: log, extraArgs: ['--max-turns', '1', '--tools', ''], timeoutMs: 20000 });
  const r2 = await cb.executarClaude({ prompt: 'oi', comando: fake, arquivoUsageLog: log, timeoutMs: 20000 });
  const r3 = await cb.executarClaude({ prompt: 'oi', comando: fake, modelo: 'gpt-9', arquivoUsageLog: log, timeoutMs: 20000 });
  assert.ok(/"--model" "opus"/.test(r1), r1); assert.ok(/"--model" "sonnet"/.test(r2), r2); assert.ok(/"--model" "sonnet"/.test(r3), 'modelo inválido cai para sonnet');
  const reg = cb.lerRegistrosUsoClaude({ arquivoLog: log });
  assert.deepEqual(reg.map((x) => x.modelo), ['opus', 'sonnet', 'sonnet']);
  assert.equal(reg[0].pesoModelo, 5); assert.equal(reg[1].pesoModelo, 1);
  assert.equal(reg[0].tokensPonderados, reg[0].tokensEstimados * 5);
});
await teste('painel de cota: Opus pesa proporcionalmente mais, exibe Opus/Sonnet e registros antigos (sem modelo) contam como Sonnet', () => {
  const log = path.join(tmp, 'cota.jsonl'); const cal = path.join(tmp, 'cal.json');
  const agora = Date.now();
  const linha = (o) => JSON.stringify({ timestamp: new Date(agora - 60000).toISOString(), tipo: 'roteiro', charsPrompt: 4000, charsSaida: 4000, tokensEstimados: 2000, duracaoMs: 1000, ok: true, ...o });
  fs.writeFileSync(log, [linha({ modelo: 'sonnet', pesoModelo: 1, tokensPonderados: 2000 }), linha({ modelo: 'opus', pesoModelo: 5, tokensPonderados: 10000 }), linha({})].join('\n') + '\n');
  fs.writeFileSync(cal, JSON.stringify({ tokensPorHistoriaRef: 8500, pctPorHistoriaPadrao: 2.7 }));
  const r = cb.calcularResumoCotaClaude({ arquivoLog: log, arquivoCalibracao: cal, agora });
  assert.equal(r.janela5h.tokensEstimados, 2000 + 10000 + 2000, 'Opus conta 5x');
  assert.equal(r.janela5h.porModelo.opus.tokensPonderados, 10000); assert.equal(r.janela5h.porModelo.sonnet.chamadas, 2);
  const uo = r.ultimasChamadas.find((c) => c.modelo === 'opus');
  assert.ok(uo && uo.modeloRotulo === 'Opus' && uo.pesoModelo === 5 && uo.tokensReais === 2000);
  assert.ok(r.ultimasChamadas.some((c) => c.modeloRotulo === 'Sonnet'));
  assert.deepEqual(r.pesosModelo, { sonnet: 1, opus: 5 });
});

console.log('\n[4] 🎯 Fichas Virais');
await teste('banco já nasce com 2 fichas-exemplo editáveis; CRUD + ativar/desativar + métricas', () => {
  const fs_ = new FichasService({ dir: fabrica });
  const lista = fs_.listar();
  assert.equal(lista.length, 2); assert.ok(lista.every((f) => f.origem === 'exemplo' && f.ativa));
  const nova = fs_.criar({ titulo: 'Minha campeã', tipoConflito: 'dinheiro_divida', views: 900000, retencao3s: 70, retencao30s: 61, propria: true, estrutura: ['a → b', 'c → d'], melhoresFalas: ['x?', 'y!'] });
  assert.equal(nova.propria, true); assert.equal(fs_.listar()[0].id, nova.id, 'própria vem primeiro');
  const up = fs_.atualizar(nova.id, { views: 1200000, retencao30s: 64.5, ativa: false });
  assert.equal(up.views, 1200000); assert.equal(up.retencao30s, 64.5); assert.equal(up.ativa, false); assert.equal(up.titulo, 'Minha campeã');
  fs_.excluir(nova.id);
  assert.equal(fs_.listar().length, 2);
  assert.throws(() => fs_.excluir('nao-existe'), /não encontrada/);
});
await teste('seleção para a Chamada A: 2–3 fichas ATIVAS do mesmo tipo, prioriza própria > retenção 30s > views, ignora inativas', () => {
  const fs_ = new FichasService({ dir: fabrica });
  const mk = (t, extra) => fs_.criar({ titulo: t, tipoConflito: 'heranca_terra', ...extra });
  const a = mk('A fraca', { views: 10, retencao30s: 20 });
  const b = mk('B forte de fora', { views: 9000000, retencao30s: 70 });
  const c = mk('C própria', { propria: true, views: 100, retencao30s: 30 });
  const d = mk('D inativa', { ativa: false, views: 99999999, retencao30s: 99 });
  const e = mk('E média', { views: 500, retencao30s: 40 });
  const sel = fs_.selecionarParaPrompt({ tipoConflito: 'heranca_terra', max: 3 });
  assert.deepEqual(sel.fichas.map((f) => f.titulo), ['C própria', 'B forte de fora', 'E média']);
  assert.ok(!sel.fichas.some((f) => f.titulo === 'D inativa'));
  const outroTipo = fs_.selecionarParaPrompt({ tipoConflito: 'vinganca' });
  assert.ok(outroTipo.fichas.length >= 2 && outroTipo.completouComOutros, 'sem fichas do tipo: completa com as melhores (só ritmo)');
  assert.ok(/só o RITMO/.test(fs_.blocoParaPrompt(outroTipo)));
  for (const f of [a, b, c, d, e]) fs_.excluir(f.id);
});
await teste('inferir tipo de conflito pelo texto e normalizar métricas (0–100%)', () => {
  assert.equal(inferirTipoConflito('o marido escondeu o celular e a esposa acha que tem amante'), 'traicao_ciume');
  assert.equal(inferirTipoConflito('a diarista acusada pela patroa'), 'humilhacao_trabalho');
  assert.equal(normalizarFicha({ titulo: 't', retencao3s: 250, views: -5 }).retencao3s, 100);
  assert.equal(normalizarFicha({ titulo: 't', views: -5 }).views, 0);
});
await teste('promover novela própria campeã: gera ficha determinística (0 tokens) com métricas, estrutura e melhores falas', () => {
  const svc = novoSvc();
  fs.mkdirSync(path.join(fabrica, 'prontos_para_flow', 'camp', 'parte_01'), { recursive: true });
  fs.writeFileSync(path.join(fabrica, 'prontos_para_flow', 'camp', 'parte_01', 'roteiro_humano.md'),
    '# Campeã da Página — Parte 1 de 2\nRelação exata: patroa e diarista de vinte anos.\nConflito concreto: sumiu dinheiro da gaveta e a patroa acusa a diarista.\nFinal-fisgada: chegada — o marido aparece com a escritura.\n\n## CENA 01 (15s) — Gancho\nNovidade: a patroa acusa a diarista.\nPATROA [gritando]: "Vinte anos nessa casa e você me rouba?"\nDIARISTA [calma]: "A senhora olhou dentro da sua bolsa?"\n## CENA 02 (15s) — Silêncio\nNovidade: o filho esconde o dinheiro.\nAção: o filho esconde o dinheiro na mochila e olha para a porta com medo.\n## CENA 03 (15s) — Choque\nNovidade: o marido chega.\nMARIDO [firme]: "A casa dela está no nome dela há dez anos!"\nChoque: chegada — o marido mostra a escritura da casa da diarista.\n');
  const f = svc.promoverNovelaEmFicha({ slug: 'camp', parte: 1, views: 3200000, retencao3s: 83, retencao30s: 61, tipoConflito: 'humilhacao_trabalho' });
  assert.equal(f.propria, true); assert.equal(f.origem, 'novela'); assert.equal(f.views, 3200000); assert.equal(f.retencao30s, 61); assert.equal(f.tipoConflito, 'humilhacao_trabalho');
  assert.ok(/Vinte anos nessa casa/.test(f.gancho3s)); assert.equal(f.estrutura.length, 3); assert.ok(/cena muda/.test(f.estrutura[1]) === false || f.estrutura[1].includes('o filho esconde'));
  assert.ok(f.melhoresFalas.length >= 2 && f.melhoresFalas.length <= 4); assert.ok(/escritura/.test(f.virada));
  const f2 = svc.promoverNovelaEmFicha({ slug: 'camp', parte: 1, views: 4000000, retencao3s: 84, retencao30s: 62 });
  assert.equal(f2.id, f.id, 'promover de novo atualiza a mesma ficha (sem duplicar)'); assert.equal(f2.views, 4000000);
  new FichasService({ dir: fabrica }).excluir(f.id);
});
await teste('extrair ficha por transcrição: 1 chamada sonnet curta e salva só a ficha enxuta', async () => {
  const svc = novoSvc(); const chamadas = [];
  svc.rodarClaude = async (job, prompt, o = {}) => {
    chamadas.push({ modelo: o.modelo || job.modeloUnico, prompt });
    const resp = '```json\n{"titulo":"Ficha de teste","tipoConflito":"dinheiro_divida","gancho3s":"ela grita","conflitoConcreto":"dívida do pai","ironiaDramatica":"x","estrutura":["a → b"],"melhoresFalas":["f1","f2","f3"],"virada":"v","finalFisgada":"ff","ritmo":"r","tom":"t"}\n```';
    job.saida += resp; return resp;
  };
  const j = svc.extrairFicha({ transcricao: 'Ela entra gritando que o pai deve dinheiro ao armazém e ninguém ajuda a moça na frente de todos os vizinhos.', views: 100, retencao3s: 70, retencao30s: 50 });
  const fim = await esperarFim(svc, j.id);
  assert.equal(fim.estado, 'ok', fim.erro);
  assert.equal(chamadas.length, 1); assert.equal(chamadas[0].modelo, 'sonnet');
  assert.ok(/TRANSCRIÇÃO:/.test(chamadas[0].prompt) && /gancho3s/.test(chamadas[0].prompt) && /menos de 450 palavras/.test(chamadas[0].prompt));
  assert.equal(fim.fichaCriada.titulo, 'Ficha de teste');
  const fs_ = new FichasService({ dir: fabrica }); const f = fs_.listar().find((x) => x.titulo === 'Ficha de teste');
  assert.ok(f && f.origem === 'transcricao' && f.views === 100 && f.retencao30s === 50);
  fs_.excluir(f.id);
  assert.throws(() => svc.extrairFicha({}), /Cole um link viral/);
});

fs.rmSync(tmp, { recursive: true, force: true });
console.log(`\n${process.exitCode ? '❌ FALHOU' : `✅ ${ok} testes passaram`}`);
