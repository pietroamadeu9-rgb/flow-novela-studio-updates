// Testes locais da integracao Fabrica Claude (sem gastar tokens do Claude, sem WhatsApp real).
//   node server/testFabrica.js
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { parseRoteiro } from './parser.js';
import { Store } from './store.js';
import {
  FabricaService, converterPromptsParaEstudio, herdarReferenciasFisicas, validarLegenda, sortearHashtags, resortearLegenda, HASHTAGS_VALIDAS,
  normalizarTipoFinal, instrucaoTipoFinal, verificarTipoFinalRoteiro, extrairDialogosRoteiro,
  calcularNumeroCenas, blocoFidelidadeResumo, extrairArquivosDelimitados, gerarTabelaContinuidadeDeRoteiro,
} from './fabricaService.js';
import { avaliarEstabilidade, arquivoTravado, novelaPeloNomeDoArquivo, MIN_BYTES, ESTAVEL_MS, CapcutWatcher } from './capcutWatcher.js';
import { normalizarJid, variantesNumeroBrasil, WhatsappService } from './whatsappService.js';
import { extrairCredenciaisOAuth, montarLinksDrive, formatarMensagemWhatsappDrive, GoogleDriveService, PASTA_DRIVE_PADRAO } from './googleDriveService.js';
import { normalizarUrlMidia, calcularSha256, coletarAssinaturasVideosNovela, verificarDuplicidadeVideo, casarCardsComCenas } from './videoCapturaGuard.js';
import { Runner } from './runner.js';
import { FABRICA_DIR, PASTA_CLAUDE_VAZIA, obterPastaClaudeVazia } from './claudeBridge.js';

let ok = 0;
const teste = async (nome, fn) => { try { await fn(); ok++; console.log(`  ✓ ${nome}`); } catch (e) { console.log(`  ✗ ${nome}\n    ${e.message}`); process.exitCode = 1; } };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'fabrica-test-'));
const dadosDir = path.join(tmp, 'dados'); const projDir = path.join(tmp, 'Meus_Projetos_Flow');
fs.mkdirSync(dadosDir, { recursive: true });
const store = new Store(dadosDir, projDir);
const logs = [];
const svc = new FabricaService({ store, log: (m) => logs.push(m), emitirNovela: () => {}, broadcastUI: () => {} });

console.log('\n[1] Prontos da Fábrica');
await teste('o-caderno-de-fiado / parte_01 aparece pronta com legenda válida', () => {
  assert.ok(fs.existsSync(FABRICA_DIR), 'C:\\FabricaClaude não existe');
  const p = svc.listarProntos().find((x) => x.slug === 'o-caderno-de-fiado' && x.parte === 1);
  assert.ok(p, 'parte_01 não listada');
  assert.equal(p.pronta, true);
  assert.equal(p.legendaValida, true, 'legenda inválida');
  const v = validarLegenda(p.legendaFacebook);
  assert.ok(v.ok, v.erros.join('; '));
  const linhas = p.legendaFacebook.split('\n');
  const branco = linhas.findIndex((l) => !l.trim());
  assert.ok(branco === 2 || branco === 3, 'linha em branco no lugar errado');
  const tags = p.legendaFacebook.match(/#\w+/g);
  assert.equal(tags.length, 2); tags.forEach((t) => assert.ok(HASHTAGS_VALIDAS.includes(t)));
  console.log(`    legenda: ${JSON.stringify(p.legendaFacebook)}`);
});
await teste('série lista resumo da Parte 2 e status consistente das partes', () => {
  const s = svc.listarSeries().find((x) => x.slug === 'o-caderno-de-fiado');
  assert.ok(s); assert.equal(s.totalPartes, 2);
  assert.equal(s.partes[0].status, 'pronta');
  assert.ok(s.partes[1].resumo.includes('Parte 2') || s.partes[1].status === 'pronta');
  assert.equal(s.proximaParte, s.partes[1].status === 'pronta' ? null : 2);
});
await teste('prompts_flow.txt real converte e o parser do estúdio aceita (0 erros)', () => {
  const txt = fs.readFileSync(path.join(FABRICA_DIR, 'prontos_para_flow/o-caderno-de-fiado/parte_01/prompts_flow.txt'), 'utf8');
  const c = converterPromptsParaEstudio(txt);
  const r = parseRoteiro(c.texto);
  assert.deepEqual(r.validacao.erros, [], JSON.stringify(r.validacao.erros.slice(0, 3)));
  assert.ok(r.resumo.referencias >= 8, 'deve ter referências');
  assert.ok(r.resumo.imagensBase >= 10, 'deve ter imagens-base');
  assert.equal(r.resumo.videos, 12);
  assert.ok(r.itens.filter((i) => i.tipo === 'video').every((i) => i.duracao === 15));
  const falas = r.itens.find((i) => i.id === 'Cena 12').prompt;
  assert.ok(falas.includes('"'), 'Cena 12 deve conter fala entre aspas em português');
});
await teste('importar() herda 100% dos Padrões do FlowStudio (ignora flowConfig do metadata_flow.json)', () => {
  fs.writeFileSync(path.join(dadosDir, 'config.json'), JSON.stringify({
    padroes: {
      modeloImagem: 'Nano Banana Pro',
      modeloVideo: 'Omni 1.1 Flash',
      qualidadeGeracaoVideo: '720p',
      qualidadeDownloadVideo: '4k',
      qualidadeDownloadImagem: '1k',
    },
  }));
  const r = svc.importar({ slug: 'o-caderno-de-fiado', parte: 1 });
  const n = r.novela;
  assert.equal(n.serieSlug, 'o-caderno-de-fiado'); assert.equal(n.numeroParte, 1);
  assert.equal(n.modeloImagem, 'Nano Banana Pro'); assert.equal(n.modeloVideo, 'Omni 1.1 Flash');
  assert.equal(n.qualidadeGeracaoVideo, '720p'); assert.equal(n.qualidadeDownloadVideo, '4k'); assert.equal(n.qualidadeDownloadImagem, '1k');
  assert.equal(n.forcarElementos, true, 'modoGeracaoVideo padrão "elementos" deve ativar forcarElementos');
  assert.ok(n.itens.filter((i) => i.tipo === 'video').every((i) => i.submodo === 'elementos_video'), 'todos os vídeos devem ficar em elementos_video');
  assert.ok(n.legendaFacebook.includes('#')); assert.equal(n.legendaEnviadaWhatsappEm, null);
  assert.ok(n.itens.length >= 30); assert.ok(r.validacao.ok);
  assert.throws(() => svc.importar({ slug: 'o-caderno-de-fiado', parte: 1 }), /já foi importada/);
});

console.log('\n[2] Herança física de 01_Referencias (Parte 1 → Parte 2)');
await teste('copia fisicamente ref_ já geradas e marca concluido', () => {
  const p1 = store.listar().find((n) => n.numeroParte === 1);
  // simula a Parte 1 ja gerada: ref_cida e ref_osvaldo concluidas com arquivo no disco
  for (const id of ['ref_cida', 'ref_osvaldo']) {
    const it = p1.itens.find((i) => i.id === id);
    const rel = `01_Referencias/${id}.png`;
    fs.writeFileSync(path.join(store.pastaAbs(p1), rel), Buffer.from(`PNG-${id}`));
    Object.assign(it, { status: 'concluido', arquivo: rel, geradoEm: '2026-01-01T00:00:00Z', nomeAtivoFlow: 'x', flowMidiaChave: 'y' });
  }
  store.salvar(p1);
  // Parte 2 de teste: usa ref_cida/ref_osvaldo sem redeclarar + uma ref nova
  const n2 = store.criar('Teste Parte 2');
  Object.assign(n2, { serieSlug: 'o-caderno-de-fiado', numeroParte: 2 });
  const txt = ['BLOCO 1', '{ref_cida}', '(i) vertical 9:16 close', '{ref_osvaldo}', '(i) vertical 9:16 close', '{ref_nova}', '(i) vertical 9:16 new', 'BLOCO 2', '{imagem_01}', '(i) [ref_cida] [ref_nova] x'].join('\n');
  const r = parseRoteiro(txt); n2.itens = r.itens.map((it) => ({ ...it, status: 'pendente', arquivo: null }));
  const h = herdarReferenciasFisicas({ n: n2, anteriores: store.listar().filter((x) => x.id !== n2.id && x.numeroParte < 2), pastaAbsDe: (x) => store.pastaAbs(x) });
  assert.deepEqual(h.herdadas.map((x) => x.id).sort(), ['ref_cida', 'ref_osvaldo']);
  assert.deepEqual(h.faltando, ['ref_nova']);
  for (const id of ['ref_cida', 'ref_osvaldo']) {
    const it = n2.itens.find((i) => i.id === id);
    assert.equal(it.status, 'concluido'); assert.ok(it.arquivo);
    const abs = path.join(store.pastaAbs(n2), it.arquivo);
    assert.equal(fs.readFileSync(abs, 'utf8'), `PNG-${id}`, 'arquivo não copiado fisicamente');
    assert.notEqual(abs, path.join(store.pastaAbs(p1), '01_Referencias', `${id}.png`));
    assert.equal(it.nomeAtivoFlow, null, 'não pode herdar nomeAtivoFlow (ativo ainda não está no novo projeto do Flow)');
    assert.equal(it.herdadoDe.parte, 1);
  }
  assert.equal(n2.itens.find((i) => i.id === 'ref_nova').status, 'pendente');
});

console.log('\n[3] Vigia do CapCut: estabilização do .mp4');
await teste('avaliarEstabilidade: <1MB nunca estável; mudando reseta; 5s idêntico = estável', () => {
  let e; let r;
  r = avaliarEstabilidade(e, { tamanho: 500_000, agora: 0, travado: false }); assert.equal(r.estavel, false); e = r.estado;
  r = avaliarEstabilidade(e, { tamanho: 500_000, agora: 10_000, travado: false }); assert.equal(r.estavel, false); assert.equal(r.motivo, 'pequeno'); e = r.estado;
  r = avaliarEstabilidade(e, { tamanho: 3_000_000, agora: 11_000, travado: false }); assert.equal(r.estavel, false); e = r.estado; // cresceu: reseta
  r = avaliarEstabilidade(e, { tamanho: 3_000_000, agora: 14_000, travado: false }); assert.equal(r.estavel, false); assert.equal(r.motivo, 'tamanho_mudando'); e = r.estado;
  r = avaliarEstabilidade(e, { tamanho: 3_500_000, agora: 15_500, travado: false }); assert.equal(r.estavel, false); e = r.estado; // cresceu de novo
  r = avaliarEstabilidade(e, { tamanho: 3_500_000, agora: 20_400, travado: false }); assert.equal(r.estavel, false); e = r.estado; // 4,9 s
  r = avaliarEstabilidade(e, { tamanho: 3_500_000, agora: 20_500, travado: true }); assert.equal(r.estavel, false); assert.equal(r.motivo, 'travado'); e = r.estado;
  r = avaliarEstabilidade(e, { tamanho: 3_500_000, agora: 20_600, travado: false }); assert.equal(r.estavel, true);
});
await teste('arquivo real: travado enquanto aberto para escrita, livre depois', () => {
  const f = path.join(tmp, 'video.mp4'); const fd = fs.openSync(f, 'w'); fs.writeSync(fd, Buffer.alloc(2 * MIN_BYTES));
  // (no Windows, abrir r+ enquanto outro handle sem compartilhamento esta aberto falha; aqui ao menos garante que fechado = livre)
  fs.closeSync(fd);
  assert.equal(arquivoTravado(f), false);
});
await teste('tick: ignora antigos, espera 5 s, e só envia 1 vez a legenda limpa', async () => {
  const pastaCap = path.join(tmp, 'capcut'); fs.mkdirSync(pastaCap);
  fs.writeFileSync(path.join(pastaCap, 'antigo.mp4'), Buffer.alloc(2 * MIN_BYTES)); // existia antes de ligar
  const n = store.listar().find((x) => x.numeroParte === 1);
  const enviados = [];
  const zap = { status: () => ({ conectado: true }), enviarTexto: async (t) => { enviados.push(t); return { ok: true }; } };
  const w = new CapcutWatcher({ dadosDir: path.join(tmp, 'dadosW'), store, whatsapp: zap, log: () => {}, intervaloMs: 100000 });
  fs.mkdirSync(path.join(tmp, 'dadosW'), { recursive: true });
  w.cfg = { ...w.cfg, pastaExportacaoCapcut: pastaCap, monitorAtivo: true, novelaAguardandoCapcutId: n.id, historico: [] };
  w.arq = path.join(tmp, 'dadosW', 'capcut_config.json');
  w.baseline = new Map(w.listarVideos().map((v) => [v.abs, v.mtime])); // o que iniciar() faz
  const novo = path.join(pastaCap, 'meu_video_final.mp4');
  fs.writeFileSync(novo, Buffer.alloc(2 * MIN_BYTES));
  let t = 1_000_000;
  await w.tick(t); assert.equal(enviados.length, 0, 'enviou cedo demais');
  fs.appendFileSync(novo, Buffer.alloc(1000)); // ainda gravando
  await w.tick(t += 3000); await w.tick(t += 3000); assert.equal(enviados.length, 0, 'tamanho mudou: não pode enviar');
  await w.tick(t += ESTAVEL_MS + 100); assert.equal(enviados.length, 1, 'deveria enviar após 5 s estável');
  await w.tick(t += 10000); assert.equal(enviados.length, 1, 'duplicou envio');
  assert.equal(enviados[0], n.legendaFacebook); assert.ok(!/video|Parte|http/i.test(enviados[0].split('\n\n')[1] || ''), 'só legenda + hashtags');
  assert.ok(store.obter(n.id).legendaEnviadaWhatsappEm, 'não marcou legendaEnviadaWhatsappEm');
  assert.equal(w.cfg.historico[0].resultado, 'enviada');
});
await teste('export que SOBRESCREVE um arquivo antigo (mesmo nome, mtime novo) também dispara; sem WhatsApp fica pendente e envia ao conectar', async () => {
  const pasta = path.join(tmp, 'capcut2'); fs.mkdirSync(pasta);
  const antigo = path.join(pasta, '1016.mp4');
  fs.writeFileSync(antigo, Buffer.alloc(2 * MIN_BYTES));
  const n = store.listar().find((x) => x.legendaFacebook && !x.legendaEnviadaWhatsappEm) || store.criar('Pendente Overwrite');
  n.legendaFacebook = 'Fala sério?\nIsso dói. 💔\n\n#filme #novela'; n.legendaEnviadaWhatsappEm = null; store.salvar(n);
  const enviados = []; let conectado = false;
  const zap = { status: () => ({ conectado }), enviarTexto: async (t) => { enviados.push(t); return { ok: true, jid: '5511@s.whatsapp.net' }; } };
  fs.mkdirSync(path.join(tmp, 'dadosW2'), { recursive: true });
  const w = new CapcutWatcher({ dadosDir: path.join(tmp, 'dadosW2'), store, whatsapp: zap, log: () => {}, intervaloMs: 100000 });
  w.cfg = { ...w.cfg, pastaExportacaoCapcut: pasta, pastaCustomizada: true, monitorAtivo: true, novelaAguardandoCapcutId: n.id, historico: [] };
  w.baseline = new Map(w.listarVideos().map((v) => [v.abs, v.mtime]));
  let t = 5_000_000;
  await w.tick(t); assert.equal(enviados.length, 0, 'arquivo antigo inalterado não pode disparar');
  // CapCut re-exporta por cima do mesmo nome
  fs.writeFileSync(antigo, Buffer.alloc(2 * MIN_BYTES + 10)); const futuro = new Date(Date.now() + 60_000); fs.utimesSync(antigo, futuro, futuro);
  await w.tick(t += 1000); await w.tick(t += ESTAVEL_MS + 100);
  assert.equal(enviados.length, 0, 'WhatsApp desconectado: não envia');
  assert.deepEqual(w.estadoPublico().pendentesWhatsapp, ['1016.mp4'], 'deve ficar pendente aguardando o WhatsApp');
  conectado = true; await w.tick(t += 1000);
  assert.equal(enviados.length, 1, 'ao conectar, envia a legenda pendente');
  assert.equal(w.estadoPublico().pendentesWhatsapp.length, 0);
});
await teste('casa arquivo com a novela pelo nome', () => {
  const lista = store.listar().filter((x) => x.legendaFacebook);
  assert.equal(novelaPeloNomeDoArquivo('O Caderno de Fiado - parte 1 final.mp4', lista)?.numeroParte, 1);
  assert.equal(novelaPeloNomeDoArquivo('caderno_de_fiado_final.mov', lista)?.numeroParte, 1);
  assert.equal(novelaPeloNomeDoArquivo('ferias_2026.mp4', lista), null);
});

console.log('\n[4] Legenda e WhatsApp');
await teste('hashtags: embaralhamento real, sempre 2 distintas e válidas, cobre os 6 pares', () => {
  const pares = new Set();
  for (let i = 0; i < 600; i++) { const t = sortearHashtags(); assert.equal(new Set(t).size, 2); t.forEach((x) => assert.ok(HASHTAGS_VALIDAS.includes(x))); pares.add([...t].sort().join(' ')); }
  assert.equal(pares.size, 6);
});
await teste('resortearLegenda mantém texto, troca hashtags e continua válida', () => {
  const a = 'Linha um aqui, né?\nLinha dois forte. 💔\n\n#historia #novela\n';
  let diferente = false;
  for (let i = 0; i < 20; i++) { const b = resortearLegenda(a); assert.ok(validarLegenda(b).ok); if (b.split('\n\n')[1] !== a.split('\n\n')[1]) diferente = true; assert.equal(b.split('\n\n')[0], a.split('\n\n')[0]); }
  assert.ok(diferente);
});
await teste('legendas inválidas são reprovadas', () => {
  assert.equal(validarLegenda('uma linha só 💔\n\n#historia #novela').ok, false);
  assert.equal(validarLegenda('a\nb 💔 😢 🙏\n\n#historia #novela').ok, false);
  assert.equal(validarLegenda('a\nb 💔\n#historia #novela').ok, false);
  assert.equal(validarLegenda('a\nb 💔\n\n#historia #novela #filme').ok, false);
  assert.equal(validarLegenda('a\nb 💔\n\n#historia #drama').ok, false);
});
await teste('self-JID normalizado + variantes brasileiras 8/9 dígitos + onWhatsApp', async () => {
  assert.equal(normalizarJid('5511999998888:12@s.whatsapp.net'), '5511999998888@s.whatsapp.net');
  assert.equal(normalizarJid('(11) 99999-8888'), '5511999998888@s.whatsapp.net');
  assert.equal(normalizarJid('+55 11 99999-8888'), '5511999998888@s.whatsapp.net');
  assert.equal(normalizarJid(''), null);
  assert.deepEqual(variantesNumeroBrasil('5511913321436'), ['5511913321436', '551113321436']);
  assert.deepEqual(variantesNumeroBrasil('1113321436'), ['551113321436', '5511913321436']);

  const ws = new WhatsappService({ dadosDir: path.join(tmp, 'zap'), log: () => {} });
  ws.estado = 'conectado';
  ws.selfJid = normalizarJid('5511913321436:33@s.whatsapp.net');
  ws.numero = '5511913321436';
  let consultados = [];
  let enviadoPara = null;
  ws.sock = {
    user: { id: '5511913321436:33@s.whatsapp.net' },
    async onWhatsApp(...nums) {
      consultados = nums;
      // simula conta brasileira registrada sem o 9o digito na rede do WhatsApp:
      return nums.map((n) => ({ exists: n === '551113321436', jid: '551113321436:4@s.whatsapp.net' }));
    },
    async sendMessage(jid) {
      enviadoPara = jid;
      return { key: { id: 'MSG123' } };
    },
  };
  const r = await ws.enviarTexto('Legenda teste');
  assert.deepEqual(consultados, ['5511913321436', '551113321436']);
  assert.equal(enviadoPara, '551113321436@s.whatsapp.net', 'deve enviar para o JID real retornado pelo onWhatsApp sem :device');
  assert.equal(r.jid, '551113321436@s.whatsapp.net');
});
await teste('CapcutWatcher: vincula automaticamente novela pendente mais recente e vigia Videos + Desktop', () => {
  const nRecente = store.criar('Novela Nova Pendente');
  nRecente.legendaFacebook = 'Fala sério, você aceitaria isso?\nEu jamais! 💔\n\n#novela #historia';
  nRecente.legendaEnviadaWhatsappEm = null;
  store.salvar(nRecente);

  const wAuto = new CapcutWatcher({ dadosDir: path.join(tmp, 'dadosAuto'), store, whatsapp: { status: () => ({ conectado: true }) }, log: () => {}, intervaloMs: 100000 });
  const pub = wAuto.estadoPublico();
  assert.equal(pub.novelaAguardandoCapcutId, nRecente.id, 'deve vincular automaticamente a novela mais recente com legenda não enviada');
  const origens = pub.pastasVigiadas.map((x) => x.origem);
  assert.ok(origens.some((o) => /Vídeos/i.test(o)) || origens.some((o) => /Área de Trabalho/i.test(o)), 'deve vigiar Vídeos/Área de Trabalho quando sem pasta customizada');
});

console.log('\n[5] Google Drive OAuth + Mensagem 1 (legenda limpa) e Mensagem 2 (link Drive separado)');
await teste('GoogleDriveService: extrai credenciais de JSON/campos, gera URL PKCE e monta links iPhone', () => {
  const cJson = extrairCredenciaisOAuth({
    jsonBruto: JSON.stringify({ installed: { client_id: '123-abc.apps.googleusercontent.com', client_secret: 'GOCSPX-segredo' } }),
  });
  assert.equal(cJson.clientId, '123-abc.apps.googleusercontent.com');
  assert.equal(cJson.clientSecret, 'GOCSPX-segredo');

  const links = montarLinksDrive('FILE_XYZ_999');
  assert.equal(links.webViewLink, 'https://drive.google.com/file/d/FILE_XYZ_999/view?usp=drivesdk');
  assert.equal(links.downloadLink, 'https://drive.google.com/uc?export=download&id=FILE_XYZ_999');

  const msg2 = formatarMensagemWhatsappDrive(links);
  assert.ok(msg2.startsWith('🎬 Vídeo pronto no Google Drive (qualidade original):'));
  assert.ok(msg2.includes(links.webViewLink));
  assert.ok(msg2.includes(links.downloadLink));

  const gd = new GoogleDriveService({ dadosDir: path.join(tmp, 'dadosGd'), porta: 3456 });
  fs.mkdirSync(path.join(tmp, 'dadosGd'), { recursive: true });
  const oauth = gd.iniciarLoginOAuth({
    entradaCredenciais: { clientId: '123.apps.googleusercontent.com', clientSecret: 'GOCSPX-1' },
    abrirNavegador: false,
  });
  assert.ok(oauth.authUrl.includes('accounts.google.com/o/oauth2/v2/auth'));
  assert.ok(oauth.authUrl.includes(encodeURIComponent('http://127.0.0.1:3456/api/gdrive/callback')));
  assert.equal(gd.status().pastaNome, PASTA_DRIVE_PADRAO);
  assert.equal(gd.status().autoUploadCapcut, true);
});

await teste('CapCut + Google Drive: dispara Mensagem 1 (só legenda limpa) e Mensagem 2 (link Drive) + botão manual', async () => {
  const pasta = path.join(tmp, 'capcutDrive'); fs.mkdirSync(pasta, { recursive: true });
  const dadosD = path.join(tmp, 'dadosCapDrive'); fs.mkdirSync(dadosD, { recursive: true });
  const n = store.criar('Novela Teste Drive');
  n.legendaFacebook = 'Você perdoaria uma traição assim?\nEu saía na hora! 💔\n\n#novela #filme';
  n.legendaEnviadaWhatsappEm = null;
  store.salvar(n);

  const enviados = [];
  const zap = { status: () => ({ conectado: true }), enviarTexto: async (t) => { enviados.push(t); return { ok: true, jid: '551199999@s.whatsapp.net' }; } };
  let uploads = 0;
  const gdriveMock = {
    conectado: () => true,
    deveSubirAutomatico: () => true,
    subirVideo: async (abs) => {
      uploads++;
      const links = montarLinksDrive(`ID_DRIVE_${uploads}`);
      return { ...links, nome: path.basename(abs), enviadoEm: new Date().toISOString() };
    },
  };

  const w = new CapcutWatcher({ dadosDir: dadosD, store, whatsapp: zap, gdrive: gdriveMock, log: () => {}, intervaloMs: 100000 });
  w.cfg = { ...w.cfg, pastaExportacaoCapcut: pasta, pastaCustomizada: true, monitorAtivo: true, novelaAguardandoCapcutId: n.id, historico: [] };
  w.baseline = new Map();

  const arqVideo = path.join(pasta, 'novela_teste_drive.mp4');
  fs.writeFileSync(arqVideo, Buffer.alloc(2 * MIN_BYTES));
  let t = 9_000_000;
  await w.tick(t);
  await w.tick(t += ESTAVEL_MS + 200);
  if (w._ultimoUploadPromise) await w._ultimoUploadPromise;

  assert.equal(enviados.length, 2, 'deve enviar exatamente 2 mensagens separadas no WhatsApp');
  assert.equal(enviados[0], n.legendaFacebook, 'Mensagem 1 deve ser 100% a legenda limpa do Facebook (zero link)');
  assert.ok(!enviados[0].includes('http'), 'Mensagem 1 não pode conter nenhum link');
  assert.ok(enviados[1].includes('🎬 Vídeo pronto no Google Drive (qualidade original):'), 'Mensagem 2 deve trazer cabeçalho do Drive');
  assert.ok(enviados[1].includes('https://drive.google.com/uc?export=download&id=ID_DRIVE_1'), 'Mensagem 2 deve trazer link direto pro iPhone');
  assert.equal(w.cfg.historico[0].driveLink, 'https://drive.google.com/file/d/ID_DRIVE_1/view?usp=drivesdk');

  // Botão manual "Subir Último Vídeo pro Drive e Mandar Link"
  const manual = await w.subirUltimoVideoEMandarLink();
  assert.equal(manual.fileId, 'ID_DRIVE_2');
  assert.equal(enviados.length, 3, 'botão manual deve disparar o novo link no WhatsApp');
  assert.ok(enviados[2].includes('ID_DRIVE_2'));
});

console.log('\n[6] Trava Dupla Anti-Duplicação (URL sem query string + SHA-256) e Re-captura do Flow');
await teste('normalizarUrlMidia remove query strings assinadas e /u/N/, preservando token /asb/ case-sensitive', () => {
  const u1 = normalizarUrlMidia('https://flow.google.com/u/9/asb/ANqvLOaJVq_AbCd123?authuser=9&Expires=179999&Signature=xyz');
  const u2 = normalizarUrlMidia('https://flow.google.com/asb/ANqvLOaJVq_AbCd123?Expires=111111&Signature=outro');
  const u3 = normalizarUrlMidia('https://flow.google.com/asb/ANqvLOaJVq_abcd123');
  assert.equal(u1, 'https://flow.google.com/asb/ANqvLOaJVq_AbCd123');
  assert.equal(u1, u2, 'mesmo recurso com query string/token diferente deve ter exatamente a mesma URL base');
  assert.notEqual(u1, u3, 'case-sensitivity do token /asb/ deve ser preservada');
});

await teste('Runner.salvarResultado bloqueia duplicata tanto por URL base (sem query params) quanto por SHA-256 e nunca sobrescreve Cena 02', async () => {
  const criarMp4Falso = (semente) => {
    const b = Buffer.alloc(60 * 1024, 0);
    b.writeUInt32BE(24, 0);
    b.write('ftypisom', 4, 'latin1');
    b.write(String(semente), 32, 'utf8');
    return b;
  };

  const nv = store.criar('Novela Anti Duplicata');
  nv.itens = [
    { id: 'Cena 01', tipo: 'video', pasta: '03_Videos', caminhoRelativo: '03_Videos/Cena 01.mp4', status: 'pendente', prompt: 'Cena 1: "Jéssica não casa com o Velho Brandão."' },
    { id: 'Cena 02', tipo: 'video', pasta: '03_Videos', caminhoRelativo: '03_Videos/Cena 02.mp4', status: 'pendente', prompt: 'Cena 2: "Eu vou, papai. Jura que a casa da mamãe fica?"' },
  ];
  store.salvar(nv);

  const runner = new Runner({ store, bridge: { conectada: true }, emitirNovela: () => {}, emitirFila: () => {}, log: () => {} });
  const mp4Cena1 = criarMp4Falso('BINARIO_EXCLUSIVO_CENA_01');
  const mp4Cena2 = criarMp4Falso('BINARIO_EXCLUSIVO_CENA_02');

  // 1) Salva Cena 01 legitimamente
  await runner.salvarResultado(nv, nv.itens[0], {
    base64: mp4Cena1.toString('base64'),
    midiaChave: 'https://flow.google.com/u/9/asb/CHAVE_CENA_01?Expires=100&Signature=AAA',
    todasChaves: ['https://flow.google.com/u/9/asb/POSTER_CENA_01?authuser=9'],
  });
  nv.itens[0].status = 'concluido';
  store.salvar(nv);

  // 2) Tenta salvar Cena 02 com MESMA URL base (mas query string diferente!) e binario diferente -> DEVE BLOQUEAR por URL!
  await assert.rejects(
    () =>
      runner.salvarResultado(nv, nv.itens[1], {
        base64: mp4Cena2.toString('base64'),
        midiaChave: 'https://flow.google.com/asb/CHAVE_CENA_01?Expires=999&Signature=BBB',
      }),
    /\[DUPLICATA_VIDEO\].*Cena 01.*mesma URL base/
  );
  assert.equal(fs.existsSync(path.join(store.pastaAbs(nv), '03_Videos/Cena 02.mp4')), false, 'Cena 02 não pode ser gravada com URL repetida');

  // 3) Tenta salvar Cena 02 com URL nova, mas MESMO binário (mesmo hash SHA-256 de Cena 01!) -> DEVE BLOQUEAR por SHA-256!
  await assert.rejects(
    () =>
      runner.salvarResultado(nv, nv.itens[1], {
        base64: mp4Cena1.toString('base64'),
        midiaChave: 'https://flow.google.com/asb/CHAVE_CENA_02_NOVA',
      }),
    /\[DUPLICATA_VIDEO\].*Cena 01.*mesmo hash SHA-256/
  );
  assert.equal(fs.existsSync(path.join(store.pastaAbs(nv), '03_Videos/Cena 02.mp4')), false, 'Cena 02 jamais pode ser gravada com mesmo SHA-256 de Cena 01');

  // 4) Salva Cena 02 com URL inédita e binário inédito -> SUCESSO!
  await runner.salvarResultado(nv, nv.itens[1], {
    base64: mp4Cena2.toString('base64'),
    midiaChave: 'https://flow.google.com/asb/CHAVE_CENA_02_REAL?Expires=555',
  });
  assert.notEqual(nv.itens[0].sha256, nv.itens[1].sha256);
  assert.equal(nv.itens[1].flowMidiaChave, 'https://flow.google.com/asb/CHAVE_CENA_02_REAL');
});

await teste('casarCardsComCenas + recapturarVideosNovela: casa 12 cenas reais pelo diálogo único sem gastar créditos', async () => {
  const txt = fs.readFileSync(path.join(FABRICA_DIR, 'prontos_para_flow/o-caderno-de-fiado/parte_01/prompts_flow.txt'), 'utf8');
  const conv = converterPromptsParaEstudio(txt);
  const parsed = parseRoteiro(conv.texto, { forcarElementos: true });
  const cenas = parsed.itens.filter((i) => i.tipo === 'video');

  // Simula 12 cards na lista virtualizada em ordem invertida (mais novo no topo) e com aria-label trocado na Cena 01
  const cardsScan = [...cenas].reverse().map((c, idx) => ({
    idScan: `scan_${idx}`,
    chaves: [`https://flow.google.com/u/9/asb/CARD_REAL_${c.id.replace(/\s+/g, '_')}?Expires=${1000 + idx}&Signature=sig${idx}`],
    ariaLabel: c.id === 'Cena 01' ? 'Cena 06' : 'Video clip',
    promptLimpo: c.prompt,
    scrollTop: idx * 480,
  }));

  const m = casarCardsComCenas(cardsScan, cenas);
  assert.equal(m.casamentos.length, cenas.length, 'todas as cenas devem casar com 100% de precisão pelo diálogo');
  assert.deepEqual(m.naoEncontradas, []);
  const chavesAlocadas = new Set(m.casamentos.map((x) => x.card.chavesNorm[0]));
  assert.equal(chavesAlocadas.size, cenas.length, 'nenhum card pode ser alocado para duas cenas');
  for (const par of m.casamentos) {
    assert.ok(par.card.chavesNorm[0].endsWith(`CARD_REAL_${par.cena.id.replace(/\s+/g, '_')}`), `casamento incorreto em ${par.cena.id}`);
  }

  // Garante que nomes errados (`Cena 06` / `Cena 12`) JAMAIS enganam o casador, e que chips `imagem_NN` + ordem cronologica desempatam!
  const cardsSemPromptMasMesmaContagem = [...cenas].reverse().map((c, idx) => ({
    idScan: `crono_${idx}`,
    chaves: [`https://flow.google.com/asb/CRONO_${c.id.replace(/\s+/g, '_')}`],
    ariaLabel: idx === 0 ? 'Cena 12' : idx === 5 ? 'Cena 06' : 'Video clip',
    promptLimpo: '',
    ordemTopo: idx,
  }));
  const mCrono = casarCardsComCenas(cardsSemPromptMasMesmaContagem, cenas, { usarDesempateCronologico: true });
  assert.equal(mCrono.casamentos.length, 12);
  for (const par of mCrono.casamentos) {
    assert.equal(par.metodo, 'ordem_cronologica');
    assert.ok(par.card.chavesNorm[0].endsWith(`CRONO_${par.cena.id.replace(/\s+/g, '_')}`));
  }

  // Se houver 11 cards sem prompt e 12 cenas (ex.: creditos acabaram na 11), NAO confia em `Cena 06` / `Cena 12` falso!
  const mFalsoAria = casarCardsComCenas(cardsSemPromptMasMesmaContagem.slice(0, 11), cenas, { usarDesempateCronologico: true });
  assert.equal(mFalsoAria.casamentos.length, 0, 'jamais deve casar apenas pelo aria-label potencialmente corrompido');

  // Valida execucao ponta a ponta de recapturarVideosNovela (tanto v1.9.5 nativo quanto fallback automatico se SW estiver em v1.9.4)
  const criarMp4Cena = (idCena) => {
    const b = Buffer.alloc(60 * 1024, 0);
    b.writeUInt32BE(24, 0);
    b.write('ftypisom', 4, 'latin1');
    b.write(`MP4_UNICO_${idCena}`, 32, 'utf8');
    return b.toString('base64');
  };

  for (const simularSwAntigoV194 of [false, true]) {
    const nvRec = store.criar(`Novela Recaptura ${simularSwAntigoV194 ? 'v194' : 'v195'}`);
    nvRec.flowProjectUrl = 'https://flow.google.com/u/9/project/484251b0-2335-430e-aca7-490ac8e68bd8';
    nvRec.itens = cenas.slice(0, 3).map((c) => ({ ...c, status: 'concluido', arquivo: null }));
    store.salvar(nvRec);

    const bridgeMock = {
      conectada: true,
      async requisitar(cmd, payload) {
        if (cmd === 'abrir_projeto') return { inacessivel: false, url: payload.url };
        if (cmd === 'escanear_videos_projeto') {
          if (simularSwAntigoV194) throw new Error('Comando desconhecido: escanear_videos_projeto');
          return { totalCardsVideo: 3, cards: cardsScan.filter((x) => /Cena_0[123]\b/.test(x.chaves[0])) };
        }
        if (cmd === 'baixar_card_escaneado' || (cmd === 'baixar_item' && payload?.modo === 'recapturar_cena_v194')) {
          const id = payload.item.id;
          return {
            base64: criarMp4Cena(id),
            midiaChave: `https://flow.google.com/asb/CARD_REAL_${id.replace(/\s+/g, '_')}`,
            todasChaves: [`https://flow.google.com/asb/CARD_REAL_${id.replace(/\s+/g, '_')}`],
            nomeAtivo: id,
          };
        }
        if (cmd === 'baixar_item' && payload?.item?.id === '__reload__') throw new Error('reload');
        throw new Error(`Comando inesperado no mock: ${cmd}`);
      },
    };
    const rRec = new Runner({ store, bridge: bridgeMock, emitirNovela: () => {}, emitirFila: () => {}, log: () => {} });
    const out = await rRec.recapturarVideosNovela(nvRec.id);
    assert.equal(out.salvos, 3, `deve salvar as 3 cenas (${simularSwAntigoV194 ? 'compat v1.9.4' : 'nativo v1.9.5'})`);
    const hashes = new Set(store.obter(nvRec.id).itens.map((i) => i.sha256));
    assert.equal(hashes.size, 3, 'todas as cenas re-capturadas devem ter SHA-256 distintos');
  }
});

console.log('\n[7] Troca de conta do Flow (créditos esgotados) + cache de uploads por projectId');
await teste('créditos esgotados → adota projeto aberto em outra conta, zera cache só do projeto novo e re-envia anexos só quando preciso', async () => {
  const URL_VELHA = 'https://flow.google.com/u/9/project/projeto-antigo-sem-creditos';
  const URL_NOVA = 'https://flow.google.com/u/3/project/projeto-novo-outra-conta';
  const nv = store.criar('Novela Troca Conta');
  nv.flowProjectUrl = URL_VELHA;
  nv.validacao = { ok: true };
  nv.itens = [
    { id: 'imagem_01', tipo: 'imagem_base', status: 'concluido', arquivo: null, refs: [], caminhoRelativo: '02_Imagens_Base/imagem_01.png', nomeAtivoFlow: 'imagem_01' },
    { id: 'Cena 01', tipo: 'video', status: 'pendente', refs: ['imagem_01'], prompt: 'Cena 1 "fala"', caminhoRelativo: '03_Videos/Cena 01.mp4' },
  ];
  store.salvar(nv);

  const chamadas = [];
  const bridgeMock = {
    conectada: true,
    async requisitar(cmd, payload) {
      chamadas.push({ cmd, payload });
      if (cmd === 'abrir_projeto') return { url: URL_NOVA, adotadoProjetoAberto: true };
      throw new Error(`inesperado ${cmd}`);
    },
  };
  const r = new Runner({ store, bridge: bridgeMock, emitirNovela: () => {}, emitirFila: () => {}, log: () => {} });

  // projeto antigo: imagem_01 ja estava la
  r.garantirMapaUploads(nv);
  assert.equal(r.ativoJaEstaNoProjeto(nv, 'imagem_01'), true);

  // creditos acabam na conta /u/9/
  r.pausarPorCreditosEsgotados(nv, nv.itens[1], '[CREDITOS_ESGOTADOS] sem créditos');
  assert.equal(nv.flowProjetoSemCreditos, 'https://flow.google.com/u/9/project/projeto-antigo-sem-creditos');
  r.pausaSolicitada = false; r.motivoPausa = null;

  // usuario abre manualmente outra conta/projeto -> runner pede adocao e aceita a URL nova sem voltar a conta sem creditos
  await r.prepararProjetoFlow(nv);
  assert.equal(chamadas[0].cmd, 'abrir_projeto');
  assert.equal(chamadas[0].payload.adotarProjetoAbertoSeDiferente, true, 'deve sinalizar a extensão para adotar o projeto aberto');
  assert.equal(nv.flowProjectUrl, URL_NOVA);
  assert.equal(nv.flowProjetoSemCreditos, null, 'flag de conta sem créditos é limpa após adotar');
  assert.ok(nv.historicoProjetosFlow.includes(URL_VELHA));
  assert.deepEqual(nv.uploadedAssetsByProjectUrl['https://flow.google.com/u/3/project/projeto-novo-outra-conta'], [], 'cache do projeto novo começa vazio');
  assert.ok(nv.uploadedAssetsByProjectUrl['https://flow.google.com/u/9/project/projeto-antigo-sem-creditos'].includes('imagem_01'), 'cache do projeto antigo preservado');

  // no projeto novo a imagem precisa subir (jaExisteNoProjetoAtual=false)...
  let payload = r.montarPayloadExecucao(nv, nv.itens[1]);
  assert.equal(payload.refsInfo.imagem_01.jaExisteNoProjetoAtual, false);
  assert.equal(payload.refsInfo.imagem_01.midiaChave, null, 'chave da mídia do projeto antigo não vale no novo');

  // ...e depois de subir uma vez (registrado pela extensão), um retry NÃO reenviará
  r.registrarAtivosNoProjeto(nv, URL_NOVA, ['imagem_01']);
  payload = r.montarPayloadExecucao(nv, nv.itens[1]);
  assert.equal(payload.refsInfo.imagem_01.jaExisteNoProjetoAtual, true);

  // sem créditos esgotados antes, a flag de adoção não é enviada
  chamadas.length = 0;
  await r.prepararProjetoFlow(nv);
  assert.equal(chamadas[0].payload.adotarProjetoAbertoSeDiferente, false);
});

console.log('\n[8] Tipo de final (Final Aberto x Encerrar Aqui) + Gerar Novamente + Ler Só Diálogos');
await teste('flags finalAberto x encerrarAqui: normalização, instrução ao Claude e conferência do roteiro (Parte N de M)', () => {
  assert.equal(normalizarTipoFinal('finalAberto'), 'aberto');
  assert.equal(normalizarTipoFinal('aberto'), 'aberto');
  assert.equal(normalizarTipoFinal('encerrarAqui'), 'fechado');
  assert.equal(normalizarTipoFinal('fechado'), 'fechado');
  assert.equal(normalizarTipoFinal(''), null);

  const iAberto = instrucaoTipoFinal('aberto', { parte: 2, ehSerie: true });
  assert.ok(/FINAL ABERTO CHOCANTE/.test(iAberto) && /Armadilha:/.test(iAberto) && /Choque:/.test(iAberto));
  assert.ok(/Parte 2 de M/.test(iAberto) && /MAIOR que 2/.test(iAberto) && /Parte 3/.test(iAberto));
  assert.ok(/"tipoFinal": "aberto"/.test(iAberto));
  const iFechadoSerie = instrucaoTipoFinal('fechado', { parte: 2, ehSerie: true });
  assert.ok(/SE ENCERRA AQUI/.test(iFechadoSerie) && /Parte 2 de 2/.test(iFechadoSerie) && /totalPartes = 2/.test(iFechadoSerie));
  assert.ok(!/Armadilha:/.test(iFechadoSerie), 'final fechado não pode pedir Armadilha/Choque');
  const iFechadoUnica = instrucaoTipoFinal('fechado', { parte: 1, ehSerie: false });
  assert.ok(/parte única fechada/.test(iFechadoUnica));

  const rotAberto = '# A Herança — Parte 1 de 2\nFinal-fisgada: revelação — x\n## CENA 12 (15s) — Choque\nChoque: revelação — ela é a filha legítima\n';
  const rotFechado = '# A Herança — Parte 2 de 2\n## CENA 12 (15s) — Desfecho\n';
  assert.equal(verificarTipoFinalRoteiro(rotAberto, 'aberto').ok, true);
  assert.equal(verificarTipoFinalRoteiro(rotFechado, 'fechado').ok, true);
  assert.equal(verificarTipoFinalRoteiro(rotFechado, 'aberto').ok, false, 'pediu aberto mas veio "Parte 2 de 2"');
  assert.equal(verificarTipoFinalRoteiro(rotAberto, 'fechado').ok, false, 'pediu fechado mas veio "Parte 1 de 2"');
  assert.equal(verificarTipoFinalRoteiro('# Herança — Parte 1 de 2\n## CENA 12 (15s)\n', 'aberto').ok, false, 'aberto sem Choque é reprovado');
  assert.equal(verificarTipoFinalRoteiro('# História Única\n', 'fechado').ok, true);
});

await teste('tipo de final é obrigatório nas rotas que chamam o Claude (roteiro, automático, gerar parte, regerar)', () => {
  assert.throws(() => svc.criarRoteiro({ semente: 'x', config: {} }), /Escolha o tipo de final/);
  assert.throws(() => svc.criarAutomatico({ origem: 'sementes', config: {} }), /Escolha o tipo de final/);
  assert.throws(() => svc.gerarParte('o-caderno-de-fiado', { parte: 2 }), /Escolha o tipo de final/);
  assert.throws(() => svc.regerarParte({ slug: 'o-caderno-de-fiado', parte: 1 }), /Escolha o tipo de final/);
  assert.throws(() => svc.regerarParte({ slug: 'nao-existe-xyz', parte: 1, tipoFinal: 'aberto' }), /Não achei a pasta/);
  assert.throws(() => svc.regerarParte({ slug: '../etc', parte: 1, tipoFinal: 'aberto' }), /Slug inválido/);
});

await teste('rota de regerar rascunho: prompt reaproveita refs (Bloco 1 literal) + observação + tipo de final; sem refs quando desmarcado', () => {
  const pAberto = svc.montarPromptRegerar({ slug: 'o-caderno-de-fiado', parte: 1, tipoFinal: 'aberto', observacao: 'deixe mais simples', reaproveitarRefs: true, temPrompts: true, ehSerie: true });
  assert.ok(/REESCREVER do zero/.test(pAberto));
  assert.ok(/FINAL ABERTO CHOCANTE/.test(pAberto));
  assert.ok(/REAPROVEITAR PERSONAGENS\/CENÁRIOS/.test(pAberto) && /BLOCO 1/.test(pAberto) && /mesmos IDs \{ref_xxx\}/.test(pAberto));
  assert.ok(/deixe mais simples/.test(pAberto));
  assert.ok(/_versoes/.test(pAberto));
  assert.ok(/RESULTADO_JSON: \{"slug":"o-caderno-de-fiado","parte":1\}/.test(pAberto));
  const pFechado = svc.montarPromptRegerar({ slug: 'o-caderno-de-fiado', parte: 2, tipoFinal: 'fechado', reaproveitarRefs: false, ehSerie: true });
  assert.ok(/SE ENCERRA AQUI/.test(pFechado) && /Parte 2 de 2/.test(pFechado));
  assert.ok(!/REAPROVEITAR PERSONAGENS/.test(pFechado) && /refs novos/.test(pFechado));
  assert.ok(/Parte 1/.test(pFechado), 'Parte 2+ deve manter continuidade com a parte anterior');
});

await teste('👁️ Ler Só Diálogos: extrai as falas das 12 cenas do roteiro real da Fábrica', () => {
  const d = svc.dialogos('o-caderno-de-fiado', 1);
  assert.equal(d.cenas.length, 12);
  assert.ok(d.cenas.every((c) => c.falas.length >= 1), 'toda cena precisa ter fala');
  assert.ok(d.cenas[0].falas[0].quem && d.cenas[0].falas[0].texto.length > 3);
  assert.ok(['aberto', 'fechado'].includes(d.tipoFinal));
  const mini = extrairDialogosRoteiro('# T — Parte 1 de 2\n## CENA 01 (15s) — Gancho\nAção: x\nANA [brava]: "Sai daqui!" (2 palavras)\nZÉ [calmo]: “Calma.”\n## CENA 02 (15s)\nANA [triste]: "Fica."\n');
  assert.equal(mini.titulo, 'T — Parte 1 de 2');
  assert.deepEqual(mini.cenas.map((c) => c.falas.length), [2, 1]);
  assert.equal(mini.cenas[0].falas[1].texto, 'Calma.');
});

await teste('listarProntos expõe tipoFinal, rascunho e temRefsExistentes para os cards', () => {
  const p = svc.listarProntos().find((x) => x.slug === 'o-caderno-de-fiado' && x.parte === 1);
  assert.ok(p);
  assert.ok(['aberto', 'fechado'].includes(p.tipoFinal));
  assert.equal(typeof p.rascunho, 'boolean');
  assert.equal(p.temRefsExistentes, true);
});

console.log('\n[9] Parte 2 resgatada + Anti-Rollback Destrutivo + Corte de 85% de Cota (--max-turns 8 + guia inline)');
await teste('o-caderno-de-fiado / parte_02 está pronta, com final fechado, 0 erros no validador e 12 diálogos limpos', () => {
  const p2 = svc.listarProntos().find((x) => x.slug === 'o-caderno-de-fiado' && x.parte === 2);
  assert.ok(p2, 'parte_02 não listada');
  assert.equal(p2.pronta, true);
  assert.equal(p2.rascunho, false, `parte_02 não deve ser rascunho (${p2.motivoRascunho})`);
  assert.equal(p2.tipoFinal, 'fechado');
  assert.equal(p2.legendaValida, true);
  const val2 = svc.validarParte('o-caderno-de-fiado', 2);
  assert.equal(val2.ok, true, val2.saida);
  assert.equal(val2.faltaLegenda, false);
  const d2 = svc.dialogos('o-caderno-de-fiado', 2);
  assert.equal(d2.cenas.length, 12);
  assert.equal(d2.tipoFinal, 'fechado');
});

await teste('corte radical de cota (<3%): stateless 1 turno (--max-turns 1 --tools ""), cwd temporário VAZIO e parse de blocos ===FILE:===', () => {
  const extra = svc.montarExtraArgsClaude();
  assert.deepEqual(extra, ['--max-turns', '1', '--tools', ''], 'deve rodar 100% stateless de 1 turno sem tools');
  const cwdVazio = obterPastaClaudeVazia();
  assert.equal(cwdVazio, PASTA_CLAUDE_VAZIA);
  assert.ok(!cwdVazio.toLowerCase().startsWith(FABRICA_DIR.toLowerCase()), 'cwd do Claude jamais pode ser C:\\FabricaClaude');
  assert.ok(!cwdVazio.toLowerCase().startsWith(process.cwd().toLowerCase()), 'cwd do Claude jamais pode ser C:\\FlowStudio');
  assert.deepEqual(fs.readdirSync(cwdVazio), [], 'pasta temporária do Claude deve ficar 100% vazia');

  const arqs = extrairArquivosDelimitados([
    '===FILE:roteiro_humano.md===',
    '# A Camiseta da Discórdia',
    '## CENA 01 (10s) — Gancho',
    'Onde: ref_cenario_sala_interior (INTERIOR)',
    'Em quadro: MARIANA, LUCAS',
    'Novidade: Mariana descobre a camiseta.',
    'MARIANA [firme]: "Você pediu ajuda da sua irmã pra comprar essa camiseta?" (10 palavras)',
    'LUCAS [nervoso]: "Eu só queria fazer uma surpresa pra você hoje." (9 palavras)',
    '===END_FILE===',
    '===FILE:metadata_flow.json===',
    '{"titulo":"A Camiseta da Discórdia","slug":"a-camiseta-da-discordia","parte":1}',
    '===END_FILE===',
    'RESULTADO_JSON: {"slug":"a-camiseta-da-discordia","parte":1}',
  ].join('\n'));
  assert.ok(arqs['roteiro_humano.md']?.includes('# A Camiseta da Discórdia'));
  assert.ok(arqs['metadata_flow.json']?.includes('a-camiseta-da-discordia'));
  const tab = gerarTabelaContinuidadeDeRoteiro(arqs['roteiro_humano.md']);
  assert.ok(tab.includes('| 01 | ref_cenario_sala_interior (INTERIOR) | MARIANA, LUCAS |'));

  const promptP2 = svc.montarPromptRegerar({ slug: 'o-caderno-de-fiado', parte: 2, tipoFinal: 'fechado', reaproveitarRefs: true, temPrompts: true, ehSerie: true });
  assert.ok(/PROIBIDO usar Read\/Glob\/Grep para abrir `\.claude\/skills\/` ou `CLAUDE\.md`/.test(promptP2));
  assert.ok(/===FILE:roteiro_humano\.md===/.test(promptP2));
  assert.ok(/DIÁLOGOS LIMPOS DA PARTE 1/.test(promptP2), 'deve colar os diálogos limpos da Parte 1 direto no prompt');
  assert.ok(/\{ref_cida\}\s*->\s*\(i\)/.test(promptP2), 'deve colar o BLOCO 1 de referências da Parte 1 direto no prompt');
});

await teste('Meu Resumo + 10s (18 cenas, 14–25 palavras, ≥85% com 2 falas) vs 15s (12 cenas, 23–30 palavras) + validação --apenas-roteiro + auto-reparo máx 1 retry', async () => {
  assert.equal(calcularNumeroCenas(3, 10), 18, '3 min com cenas de 10s = 18 cenas');
  assert.equal(calcularNumeroCenas(3, 15), 12, '3 min com cenas de 15s = 12 cenas');

  const resumoDivorcio = 'Mariana pede o divórcio ao marido Lucas por causa de uma camiseta comprada com a ajuda da irmã dele, Carla, mas descobre na última cena que a camiseta era uma homenagem surpresa para o aniversário de casamento.';
  const pResumo10s = svc.montarPromptRoteiro({
    resumoUsuario: resumoDivorcio,
    origem: 'resumo',
    config: { duracaoTotalMinutos: 3, tamanhoCenaSegundos: 10, modoGeracaoVideo: 'elementos', formatoHistoria: 'unica' },
    tipoFinal: 'fechado',
  });
  assert.ok(pResumo10s.startsWith('OBRIGATÓRIO — FIDELIDADE TOTAL AO RESUMO DO USUÁRIO: Adapte EXATAMENTE esta história, personagens, conflito e reviravolta final fornecidos pelo usuário. É PROIBIDO inventar outra trama, trocar o tema para dívida/herança/terra ou usar esqueletos que descaracterizem o resumo abaixo:'));
  assert.ok(pResumo10s.includes(resumoDivorcio));
  assert.ok(/Cenas: 18 x 10s/.test(pResumo10s) && /EXATAMENTE 18 cenas de 10s \(CENA 01 até CENA 18\)/.test(pResumo10s));
  assert.ok(/14 a 25 palavras/.test(pResumo10s) && /18 a 21 palavras/.test(pResumo10s) && /máximo 20 palavras/.test(pResumo10s) && /85% das cenas FALADAS de 10s DEVEM ter 2 falas/.test(pResumo10s));
  assert.ok(/paced naturally across the full 10 seconds, with a brief natural beat before the clean cut to the second speaker/i.test(pResumo10s));
  assert.ok(/última cena \(Cena 18\)/.test(pResumo10s), 'regra de final deve apontar para a última cena (Cena 18), nunca hardcoded na Cena 12');

  const p15sAberto = svc.montarPromptRoteiro({
    semente: 'Semente 15s',
    config: { duracaoTotalMinutos: 3, tamanhoCenaSegundos: 15, modoGeracaoVideo: 'elementos', formatoHistoria: 'serie' },
    tipoFinal: 'aberto',
  });
  assert.ok(/Cenas: 12 x 15s/.test(p15sAberto) && /23 a 30 palavras/.test(p15sAberto) && /máximo 27 palavras/.test(p15sAberto));
  assert.ok(/penúltima cena \(Cena 11\)/.test(p15sAberto) && /última cena \(Cena 12\)/.test(p15sAberto));

  // Testa etapa Roteiro em fábrica isolada: 18 cenas de 10s + auto-reparo cirúrgico (1 retry) + --apenas-roteiro (zero falso erro!)
  const fabTmp10 = path.join(tmp, 'fab10s');
  fs.mkdirSync(path.join(fabTmp10, 'scripts'), { recursive: true });
  fs.mkdirSync(path.join(fabTmp10, 'dados'), { recursive: true });
  fs.copyFileSync(path.join(FABRICA_DIR, 'scripts', 'validar_novela.mjs'), path.join(fabTmp10, 'scripts', 'validar_novela.mjs'));
  fs.writeFileSync(path.join(fabTmp10, 'dados', 'config.json'), JSON.stringify({ duracaoTotalMinutos: 3, tamanhoCenaSegundos: 10, modoGeracaoVideo: 'elementos' }));
  fs.mkdirSync(path.join(fabTmp10, 'prompts'), { recursive: true });
  for (const f of ['prompt_mestre_roteirista.md', 'prompt_extrator_ficha.md']) fs.copyFileSync(path.join(FABRICA_DIR, 'prompts', f), path.join(fabTmp10, 'prompts', f));

  const montarRoteiro18Cenas10s = ({ comErroNaCena1 = false } = {}) => {
    const cenas = [];
    for (let i = 1; i <= 18; i++) {
      const n = String(i).padStart(2, '0');
      const fala1 = i === 1
        ? (comErroNaCena1
            ? 'MARIANA [chocada]: "Divórcio!" (1 palavra)' // apenas 10 palavras no total -> falha no mínimo 12 de 10s!
            : 'MARIANA [chocada, segurando a sacola]: "Amor, eu quero o divórcio por causa dessa camiseta escondida!" (10 palavras)')
        : `MARIANA [firme, olhando nos olhos]: "Lucas, você escondeu essa compra com a sua irmã Carla?" (10 palavras)`;
      const fala2 = i === 1
        ? 'LUCAS [aflito]: "Vida, a minha irmã só ajudou a comprar o presente." (10 palavras)'
        : i === 18
          ? 'LUCAS [emocionado, mostrando a foto]: "A estampa é a foto do nosso casamento, Mariana!" (9 palavras)'
          : `LUCAS [sério]: "Não foi traição nenhuma, espera só eu te mostrar." (9 palavras)`;
      cenas.push([
        `## CENA ${n} (10s) — Etapa ${n}`,
        'Onde: ref_cenario_sala_interior (INTERIOR)',
        'Em quadro: MARIANA, LUCAS',
        i > 1 ? `Transição: Logo após a fala da cena ${i - 1}, a conversa sobre a camiseta sobe de tom.` : '',
        `Novidade: Revelação da camada ${i} sobre a camiseta comprada com a irmã.`,
        'Ação: Mariana segura a camiseta dobrada diante de Lucas na sala.',
        fala1,
        fala2,
        i === 18 ? 'Fisgada: frase de impacto e catarse — Mariana vê a foto do casamento estampada na camiseta e abraça o marido.' : '',
      ].filter(Boolean).join('\n'));
    }
    return [
      '# A Camiseta do Casamento',
      'Universo: urbano_simples',
      'Cenas: 18 x 10s',
      'Tipo-final: fechado',
      'Esqueleto: B — mistério doméstico em camadas sobre a camiseta comprada pelo marido com ajuda da irmã.',
      'Relação exata: Mariana e Lucas são esposa e marido; Carla é a irmã de Lucas citada na conversa.',
      'Conflito concreto: Mariana pede o divórcio ao achar que a camiseta comprada pelo marido escondido com a irmã era para outra mulher.',
      'Ponte (Cenas 1–3):',
      '- Quem é quem: Mariana é a esposa desconfiada; Lucas é o marido que comprou a camiseta com ajuda da irmã.',
      '- Por que agora: Mariana acabou de achar a nota fiscal e a camiseta escondida no armário no dia do aniversário de casamento.',
      '- Regra/acordo em jogo: se for mentira de Lucas, Mariana assina o divórcio; se for a homenagem real, o casamento é salvo.',
      'Final-fisgada: revelação e frase de impacto — Lucas abre a camiseta e mostra a foto do casamento estampada.',
      'Teste da Dona Maria: APROVADO — a esposa achou que o marido estava traindo por causa de uma camiseta comprada escondido com a irmã, mas no final descobriu que era um presente com a foto do casamento deles.',
      'Personagens:',
      '- MARIANA | protagonista | ref_mariana | Voz: mulher direta e emotiva, frases curtas do cotidiano urbano',
      '- LUCAS | aliado | ref_lucas | Voz: marido calmo e sincero, tenta explicar sem levantar a voz',
      '',
      ...cenas,
    ].join('\n');
  };

  class Fab10 extends FabricaService { get dir() { return fabTmp10; } }
  const store10 = new Store(path.join(tmp, 'dados10'), path.join(tmp, 'proj10'));
  const svc10 = new Fab10({ store: store10, log: () => {}, emitirNovela: () => {}, broadcastUI: () => {} });

  let chamadasClaude = 0;
  let ultimoPromptRecebido = '';
  svc10.rodarClaude = async (_job, prompt) => {
    chamadasClaude++;
    ultimoPromptRecebido = prompt;
    // Chamada A e B devolvem Cena 01 curta demais; a 3a (auto-reparo cirúrgico) devolve corrigida
    const rot = montarRoteiro18Cenas10s({ comErroNaCena1: chamadasClaude <= 2 });
    return `===FILE:roteiro_humano.md===\n${rot}\n===END_FILE===\nRESULTADO_JSON: {"slug":"a-camiseta-do-casamento","parte":1}`;
  };

  const jRot = svc10.criarRoteiro({
    resumoUsuario: resumoDivorcio,
    origem: 'resumo',
    config: { duracaoTotalMinutos: 3, tamanhoCenaSegundos: 10, formatoHistoria: 'unica', modoGeracaoVideo: 'elementos' },
    tipoFinal: 'fechado',
  });
  for (let i = 0; i < 80; i++) {
    if (svc10.obterJob(jRot.id)?.estado !== 'rodando') break;
    await new Promise((r) => setTimeout(r, 25));
  }
  const fimRot = svc10.obterJob(jRot.id);
  assert.equal(chamadasClaude, 3, 'deve fazer Chamada A + Chamada B + 1 auto-reparo cirúrgico curto quando houver erro no validador');
  assert.ok(/MODO AUTO-REPARO CIRÚRGICO/.test(ultimoPromptRecebido) && /Cena 1 \(10s\)/.test(ultimoPromptRecebido));
  assert.equal(fimRot.estado, 'ok');
  assert.equal(fimRot.validacao?.ok, true, `validação --apenas-roteiro deve aprovar sem prompts_flow.txt (${fimRot.validacao?.saida})`);
  assert.equal(fimRot.validacao?.apenasRoteiro, true);
  assert.equal(fimRot.dialogos?.cenas?.length, 18, 'job concluído deve trazer os 18 diálogos limpos para a tela de aprovação');

  // Persistência do estado do Criador no backend + recuperação automática após reinício do servidor (jobId antigo que não está mais em memória)
  svc10.salvarEstadoCriador({ modo: 'aprovacao', origem: 'resumo', texto: resumoDivorcio, tamanho: 10, wiz: { etapa: 'roteiro', jobId: fimRot.id, estado: 'ok' } });
  const estSalvo = svc10.obterEstadoCriador();
  assert.equal(estSalvo.origem, 'resumo');
  assert.equal(estSalvo.tamanho, 10);
  assert.equal(estSalvo.wiz?.jobId, fimRot.id);

  // Simula reinício do servidor limpando svc10.jobs em memória -> obterEstadoCriador limpa jobId órfão e recupera o roteiro do disco
  svc10.jobs.clear();
  const estRecuperado = svc10.obterEstadoCriador();
  assert.equal(estRecuperado.wiz?.jobId, null, 'deve limpar jobId órfão após reinício para nunca travar em Carregando tarefa');
  assert.equal(estRecuperado.wiz?.rodando, false);
  assert.equal(estRecuperado.wiz?.estado, 'ok');
  assert.equal(estRecuperado.wiz?.resultado?.slug, 'a-camiseta-do-casamento');
  assert.equal(estRecuperado.wiz?.dialogos?.cenas?.length, 18);
});

await teste('PROIBIDO rollback destrutivo: se o CLI estoura cota/timeout APÓS gravar arquivos válidos, APROVA e mantém; se inválidos, salva em _versoes/parcial_*', async () => {
  // Fábrica isolada em pasta temporária (zero chamada real ao Claude CLI e zero alteração em C:\FabricaClaude)
  const fabTmp = path.join(tmp, 'fabIsolada');
  fs.mkdirSync(path.join(fabTmp, 'scripts'), { recursive: true });
  fs.mkdirSync(path.join(fabTmp, 'dados'), { recursive: true });
  fs.copyFileSync(path.join(FABRICA_DIR, 'scripts', 'validar_novela.mjs'), path.join(fabTmp, 'scripts', 'validar_novela.mjs'));
  if (fs.existsSync(path.join(FABRICA_DIR, 'scripts', 'gerar_legenda.mjs'))) {
    fs.copyFileSync(path.join(FABRICA_DIR, 'scripts', 'gerar_legenda.mjs'), path.join(fabTmp, 'scripts', 'gerar_legenda.mjs'));
  }
  fs.writeFileSync(path.join(fabTmp, 'dados', 'config.json'), JSON.stringify({ duracaoTotalMinutos: 3, tamanhoCenaSegundos: 15, modoGeracaoVideo: 'elementos' }));
  fs.mkdirSync(path.join(fabTmp, 'prompts'), { recursive: true });
  for (const f of ['prompt_mestre_roteirista.md', 'prompt_extrator_ficha.md']) fs.copyFileSync(path.join(FABRICA_DIR, 'prompts', f), path.join(fabTmp, 'prompts', f));

  const pastaRealP2 = path.join(FABRICA_DIR, 'prontos_para_flow', 'o-caderno-de-fiado', 'parte_02');
  const pastaIsoP2 = path.join(fabTmp, 'prontos_para_flow', 'novela-isolada', 'parte_02');
  fs.mkdirSync(pastaIsoP2, { recursive: true });

  // Semente inicial "versão velha" na pasta isolada
  fs.writeFileSync(path.join(pastaIsoP2, 'roteiro_humano.md'), '# Versão Antiga — Parte 2 de 2\nVERSAO_VELHA_SENTINELA\n');
  fs.writeFileSync(path.join(pastaIsoP2, 'prompts_flow.txt'), 'BLOCO 1\n{ref_cida} -> (i) old\nBLOCO 2\n{imagem_01} -> (i) [ref_cida] old\nBLOCO 3\n{Cena 01} -> (v) [imagem_01] [ref_cida] Exactly 15 seconds old\n');
  fs.writeFileSync(path.join(pastaIsoP2, 'metadata_flow.json'), JSON.stringify({ titulo: 'Versão Antiga', tipoFinal: 'fechado' }));
  fs.writeFileSync(path.join(pastaIsoP2, 'legenda_facebook.txt'), 'Linha antiga um\nLinha antiga dois 🙏\n\n#historia #novela\n');

  class FabricaIsolada extends FabricaService {
    get dir() { return fabTmp; }
  }
  const storeIso = new Store(path.join(tmp, 'dadosIso'), path.join(tmp, 'projIso'));
  const nvImp = storeIso.criar('Novela Isolada — Parte 2');
  Object.assign(nvImp, { serieSlug: 'novela-isolada', numeroParte: 2, forcarElementos: true, itens: [] });
  storeIso.salvar(nvImp);

  let simuladorClaude = null;
  const svcIso = new FabricaIsolada({
    store: storeIso,
    log: () => {},
    emitirNovela: () => {},
    broadcastUI: () => {},
    reprocessarNovela: (n, texto) => {
      const r = parseRoteiro(texto, { forcarElementos: true });
      n.itens = r.itens.map((it) => ({ ...it, status: 'pendente' }));
      n.roteiro = texto;
      storeIso.salvar(n);
    },
  });
  svcIso.rodarClaude = async (job) => simuladorClaude(job);

  const esperarFim = async (jobId) => {
    for (let i = 0; i < 80; i++) {
      const j = svcIso.obterJob(jobId);
      if (j && j.estado !== 'rodando') return j;
      await new Promise((r) => setTimeout(r, 25));
    }
    throw new Error('Job isolado não terminou a tempo');
  };

  // CASO B PRIMEIRO: CLI grava arquivos INCOMPLETOS/INVÁLIDOS e cai por timeout -> salva em _versoes/parcial_* e restaura a versão antiga
  simuladorClaude = async () => {
    fs.writeFileSync(path.join(pastaIsoP2, 'roteiro_humano.md'), '# Rascunho Parcial Quebrado\nCONTEUDO_PARCIAL_QUE_CUSTOU_COTA\n');
    fs.writeFileSync(path.join(pastaIsoP2, 'prompts_flow.txt'), 'PROMPT_INCOMPLETO_SEM_BLOCOS');
    throw new Error('Claude Code CLI excedeu 2700s.');
  };
  const jParcial = svcIso.regerarParte({ slug: 'novela-isolada', parte: 2, tipoFinal: 'fechado', importar: true });
  const fimParcial = await esperarFim(jParcial.id);
  assert.equal(fimParcial.estado, 'erro', 'arquivos inválidos não devem ser aprovados');
  assert.equal(fimParcial.restaurado, true, 'versão anterior deve ser restaurada após salvar o parcial');
  assert.ok(fs.readFileSync(path.join(pastaIsoP2, 'roteiro_humano.md'), 'utf8').includes('VERSAO_VELHA_SENTINELA'), 'versão anterior restaurada na pasta principal');
  const pastasParciais = fs.readdirSync(path.join(pastaIsoP2, '_versoes')).filter((d) => d.startsWith('parcial_'));
  assert.equal(pastasParciais.length, 1, 'deve criar _versoes/parcial_TIMESTAMP/');
  const salvoParcial = fs.readFileSync(path.join(pastaIsoP2, '_versoes', pastasParciais[0], 'roteiro_humano.md'), 'utf8');
  assert.ok(salvoParcial.includes('CONTEUDO_PARCIAL_QUE_CUSTOU_COTA'), 'JAMAIS pode apagar o arquivo parcial gerado pelo Claude');

  // CASO A: CLI grava os 5 arquivos VÁLIDOS e estoura limite de cota ("hit your limit · resets 1am") no último segundo -> APROVA E MANTÉM (ZERO ROLLBACK!)
  simuladorClaude = async () => {
    for (const f of ['roteiro_humano.md', 'continuidade_cenas.md', 'prompts_flow.txt', 'metadata_flow.json', 'legenda_facebook.txt']) {
      fs.copyFileSync(path.join(pastaRealP2, f), path.join(pastaIsoP2, f));
      const agora = new Date(Date.now() + 2000);
      fs.utimesSync(path.join(pastaIsoP2, f), agora, agora);
    }
    throw new Error("You've hit your limit · resets 1am (America/Sao_Paulo)");
  };
  const jValido = svcIso.regerarParte({ slug: 'novela-isolada', parte: 2, tipoFinal: 'fechado', importar: true });
  const fimValido = await esperarFim(jValido.id);
  assert.equal(fimValido.estado, 'ok', `arquivos prontos e válidos DEVEM aprovar mesmo com erro final de cota (erro: ${fimValido.erro})`);
  assert.ok(!fimValido.restaurado, 'NÃO pode fazer rollback quando os arquivos novos passaram na validação');
  assert.ok(!fs.readFileSync(path.join(pastaIsoP2, 'roteiro_humano.md'), 'utf8').includes('VERSAO_VELHA_SENTINELA'), 'roteiro novo deve permanecer na pasta principal');
  assert.ok(fs.readFileSync(path.join(pastaIsoP2, 'roteiro_humano.md'), 'utf8').includes('Bem-vinda em casa, Cida.'), 'roteiro novo válido mantido intacto');
  assert.equal(fimValido.importacao?.atualizada, true, 'novela já importada deve ser atualizada automaticamente com os arquivos resgatados');

  // CASO C: Etapa 2 (criarPrompts / ⚡ Gerar Prompts pro Flow) com roteiro_humano.md de mtime antigo (Etapa 1) e importar: true -> NÃO pode dar auto-deadlock nem mover arquivos validados para _versoes/parcial_*
  const rotBaseP1 = fs.readFileSync(path.join(pastaRealP2, 'roteiro_humano.md'), 'utf8').replace(/^#\s+.*$/m, '# Ele Já Tinha Comprado');
  const prmBaseP1 = fs.readFileSync(path.join(pastaRealP2, 'prompts_flow.txt'), 'utf8');
  const metaBaseP1 = JSON.stringify({ ...JSON.parse(fs.readFileSync(path.join(pastaRealP2, 'metadata_flow.json'), 'utf8')), titulo: 'Ele Já Tinha Comprado', slug: 'ele-ja-tinha-comprado-iso', serie: false, parte: 1, totalPartes: 1 });
  const legBaseP1 = fs.readFileSync(path.join(pastaRealP2, 'legenda_facebook.txt'), 'utf8');

  const pastaIsoP1Prompts = path.join(fabTmp, 'prontos_para_flow', 'ele-ja-tinha-comprado-iso', 'parte_01');
  fs.mkdirSync(pastaIsoP1Prompts, { recursive: true });
  fs.writeFileSync(path.join(pastaIsoP1Prompts, 'roteiro_humano.md'), rotBaseP1, 'utf8');
  const mtimeEtapa1 = new Date(Date.now() - 300000); // 5 minutos atrás (Etapa 1)
  fs.utimesSync(path.join(pastaIsoP1Prompts, 'roteiro_humano.md'), mtimeEtapa1, mtimeEtapa1);

  simuladorClaude = async () => {
    return `===FILE:prompts_flow.txt===\n${prmBaseP1}\n===END_FILE===\n===FILE:metadata_flow.json===\n${metaBaseP1}\n===END_FILE===\n===FILE:legenda_facebook.txt===\n${legBaseP1}\n===END_FILE===\nRESULTADO_JSON: {"slug":"ele-ja-tinha-comprado-iso","parte":1}\n`;
  };
  const jPrompts = svcIso.criarPrompts({ slug: 'ele-ja-tinha-comprado-iso', parte: 1, importar: true, iniciarFila: false });
  const fimPrompts = await esperarFim(jPrompts.id);
  assert.equal(fimPrompts.estado, 'ok', `criarPrompts com importar:true não pode sofrer auto-deadlock (erro: ${fimPrompts.erro})`);
  assert.equal(fimPrompts.validacao?.ok, true, 'validador deve aprovar roteiro + prompts + legenda na Etapa 2');
  assert.ok(fimPrompts.importacao?.novelaId, 'deve auto-importar a novela ao final do criarPrompts sem erro de lock próprio');
  assert.ok(fs.existsSync(path.join(pastaIsoP1Prompts, 'prompts_flow.txt')), 'prompts_flow.txt deve permanecer na pasta parte_01');
  assert.ok(fs.existsSync(path.join(pastaIsoP1Prompts, 'metadata_flow.json')), 'metadata_flow.json deve permanecer na pasta parte_01');
  assert.ok(fs.existsSync(path.join(pastaIsoP1Prompts, 'legenda_facebook.txt')), 'legenda_facebook.txt deve permanecer na pasta parte_01');
  const parciaisPrompts = fs.existsSync(path.join(pastaIsoP1Prompts, '_versoes'))
    ? fs.readdirSync(path.join(pastaIsoP1Prompts, '_versoes')).filter((d) => d.startsWith('parcial_'))
    : [];
  assert.equal(parciaisPrompts.length, 0, 'NUNCA deve mover arquivos já aprovados pelo validador para _versoes/parcial_*');

  // CASO D: Etapa 2 (criarPrompts) lança erro pós-geração com roteiro_humano.md antigo da Etapa 1 -> tentarResgatarOuArquivarParciais RESGATA e aprova sem mover para _versoes/parcial_*
  const pastaIsoP1Resgate = path.join(fabTmp, 'prontos_para_flow', 'ele-ja-tinha-comprado-resgate', 'parte_01');
  fs.mkdirSync(pastaIsoP1Resgate, { recursive: true });
  fs.writeFileSync(path.join(pastaIsoP1Resgate, 'roteiro_humano.md'), rotBaseP1, 'utf8');
  fs.utimesSync(path.join(pastaIsoP1Resgate, 'roteiro_humano.md'), mtimeEtapa1, mtimeEtapa1);
  simuladorClaude = async (job) => {
    job.saida += `===FILE:prompts_flow.txt===\n${prmBaseP1}\n===END_FILE===\n===FILE:metadata_flow.json===\n${metaBaseP1}\n===END_FILE===\n===FILE:legenda_facebook.txt===\n${legBaseP1}\n===END_FILE===\nRESULTADO_JSON: {"slug":"ele-ja-tinha-comprado-resgate","parte":1}\n`;
    throw new Error('Falha inesperada no último segundo após gravar prompts');
  };
  const jPromptsResg = svcIso.criarPrompts({ slug: 'ele-ja-tinha-comprado-resgate', parte: 1, importar: true, iniciarFila: false });
  const fimPromptsResg = await esperarFim(jPromptsResg.id);
  assert.equal(fimPromptsResg.estado, 'ok', 'deve resgatar prompts válidos na Etapa 2 mesmo quando roteiro_humano.md tem mtime da Etapa 1');
  assert.ok(fimPromptsResg.importacao?.novelaId, 'deve importar a novela resgatada na Etapa 2 sem deadlock de lock próprio');
  const parciaisResg = fs.existsSync(path.join(pastaIsoP1Resgate, '_versoes'))
    ? fs.readdirSync(path.join(pastaIsoP1Resgate, '_versoes')).filter((d) => d.startsWith('parcial_'))
    : [];
  assert.equal(parciaisResg.length, 0, 'NUNCA deve arquivar em _versoes/parcial_* quando os prompts da Etapa 2 passaram no validador');
});

// =========================================================================
// 10. Escada Inteligente de Auto-Recuperação + Cartada Final 100% Descritiva Sem Imagem
// =========================================================================
console.log('\n[10] Escada Inteligente + Prompt 100% Descritivo Sem Imagem (Text-to-Video)');
await teste('montarPrompt100DescritivoSemImagem extrai dados de ref_* e imagem_XX com zero anexos e preserva 100% das falas', async () => {
  const {
    montarPrompt100DescritivoSemImagem,
    aplicarModoDescritivoSemImagem,
    aplicarSuavizacaoComImagem,
    restaurarItemOriginal,
  } = await import('./claudeBridge.js');

  const arqEle = path.join('C:\\FlowStudio\\dados\\novelas', 'mwnkjrds8qwju.json');
  const novEle = JSON.parse(fs.readFileSync(arqEle, 'utf8'));
  const c03 = novEle.itens.find((i) => i.id === 'Cena 03');
  const c07 = novEle.itens.find((i) => i.id === 'Cena 07');
  assert.ok(c03 && c07, 'Cena 03 e Cena 07 devem existir em Ele Já Tinha Comprado');

  // Verifica que o resgate imediato já está aplicado no JSON real de Ele Já Tinha Comprado
  for (const cena of [c03, c07]) {
    assert.ok(['pendente', 'concluido'].includes(cena.status), `${cena.id} deve estar pendente ou concluido (atual: ${cena.status})`);
    assert.equal(cena.erro, null, `${cena.id} deve estar sem erro`);
    assert.deepEqual(cena.refs, [], `${cena.id} deve estar com refs: [] (zero imagens anexadas)`);
    assert.equal(cena.semAnexos, true, `${cena.id} deve ter semAnexos: true`);
    assert.equal(cena.modoDescritivoSemImagem, true, `${cena.id} deve ter modoDescritivoSemImagem: true`);
    assert.ok(cena.promptOriginalBackup && cena.anexosOriginaisBackup?.length >= 2, `${cena.id} deve preservar promptOriginalBackup e anexosOriginaisBackup`);
    assert.ok(cena.prompt.includes('Visual consistency anchor ('), `${cena.id} deve injetar o bloco de consistência visual de ref_* + imagem_XX`);
    assert.ok(!/\bultrarealistic\b|\baggressive\b|\bcomplaining\b|\bconfrontational\b/i.test(cena.prompt), `${cena.id} não pode conter termos gatilho do Veo`);
    assert.ok(!/```|O que foi trocado|Dois ajustes aplicados/i.test(cena.prompt), `${cena.id} não pode conter vazamento de explicação markdown`);
  }
  assert.ok(c03.prompt.includes('"Bruna, pedi cinquenta reais pro meu marido. Ele mandou eu esperar o cartão."'), 'fala da Cena 03 100% preservada');
  assert.ok(c07.prompt.includes('"Meu ex sabia me tratar. Você não consegue nem me dar cinquenta reais."'), 'fala da Cena 07 100% preservada');
  assert.ok(c07.prompt.includes('white tank top and blue jeans') && c07.prompt.includes('dark delivery jacket with reflective strips'), 'roupas exatas de Sara e Lucas injetadas no prompt descritivo');

  // Testa ciclo completo em cópia em memória: Restaurar Original -> Suavizar (só imagem_07) -> 100% Descritivo (0 anexos)
  const clone07 = JSON.parse(JSON.stringify(c07));
  restaurarItemOriginal(clone07, novEle);
  assert.deepEqual(clone07.refs, ['imagem_07', 'ref_sara', 'ref_lucas'], 'restaurarItemOriginal devolve todos os anexos originais');
  assert.equal(clone07.semAnexos, false);

  aplicarSuavizacaoComImagem(novEle, clone07);
  assert.deepEqual(clone07.refs, ['imagem_07'], 'Tentativa 2 / Suavizar (com imagem) mantém APENAS imagem_07 e remove ref_* extras');
  assert.equal(clone07.semAnexos, false);

  const desc = montarPrompt100DescritivoSemImagem(novEle, clone07);
  assert.deepEqual(desc.refs, [], 'montarPrompt100DescritivoSemImagem zera lista de anexos');
  assert.equal(desc.semAnexos, true);
  aplicarModoDescritivoSemImagem(novEle, clone07);
  assert.deepEqual(clone07.refs, []);
  assert.equal(clone07.semAnexos, true);
  assert.equal(clone07.modoDescritivoSemImagem, true);
});

await teste('claude_usage.jsonl: registro e agregação real de cotas (5h, 24h, 7d, % por história e reset)', async () => {
  const {
    registrarUsoClaude,
    atualizarUltimoRegistroUsoClaude,
    calcularResumoCotaClaude,
    salvarCalibracaoCotaClaude,
  } = await import('./claudeBridge.js');

  const pastaLogTmp = fs.mkdtempSync(path.join(tmp, 'cota-'));
  const arqLog = path.join(pastaLogTmp, 'claude_usage.jsonl');
  const arqCal = path.join(pastaLogTmp, 'claude_cota_config.json');
  const agora = Date.now();

  // 1) Chamada antiga (6 dias atrás -> entra na semana, mas não em hoje nem na janela de 5h)
  registrarUsoClaude({
    timestamp: new Date(agora - 6 * 24 * 3600 * 1000).toISOString(),
    tipo: 'roteiro',
    novelaSlug: 'historia-semana-passada',
    novelaTitulo: 'História Semana Passada',
    charsPrompt: 12000,
    charsSaida: 22000,
    duracaoMs: 42000,
    ok: true,
  }, { arquivoLog: arqLog });

  // 2) Chamada de ontem (18h atrás -> entra em Hoje 24h e Semana 7d, mas fora da janela móvel de 5h)
  registrarUsoClaude({
    timestamp: new Date(agora - 18 * 3600 * 1000).toISOString(),
    tipo: 'automatico',
    novelaSlug: 'historia-ontem',
    novelaTitulo: 'História de Ontem',
    charsPrompt: 14000,
    charsSaida: 20000,
    duracaoMs: 39000,
    ok: true,
  }, { arquivoLog: arqLog });

  // 3) História completa de 18 cenas em modo Resumo dentro da janela atual de 5h (2 chamadas stateless: roteiro + prompts ≈ 8.500 tokens)
  registrarUsoClaude({
    timestamp: new Date(agora - 30 * 60 * 1000).toISOString(),
    tipo: 'roteiro',
    novelaSlug: null,
    novelaTitulo: 'Gerar Roteiro',
    charsPrompt: 4500,
    charsSaida: 6300, // 10800 / 4 = 2700 tokens
    duracaoMs: 24000,
    ok: true,
  }, { arquivoLog: arqLog });

  // Enriquece o registro após descobrir slug e título
  atualizarUltimoRegistroUsoClaude({
    novelaSlug: 'ele-ja-tinha-comprado',
    novelaTitulo: 'Ele Já Tinha Comprado',
  }, { arquivoLog: arqLog });

  registrarUsoClaude({
    timestamp: new Date(agora - 25 * 60 * 1000).toISOString(),
    tipo: 'prompts',
    novelaSlug: 'ele-ja-tinha-comprado',
    novelaTitulo: 'Ele Já Tinha Comprado',
    charsPrompt: 6700,
    charsSaida: 16500, // 23200 / 4 = 5800 tokens
    duracaoMs: 31000,
    ok: true,
  }, { arquivoLog: arqLog });

  const cota = calcularResumoCotaClaude({ arquivoLog: arqLog, arquivoCalibracao: arqCal, agora });
  assert.equal(cota.janela5h.chamadas, 2, 'janela de 5h deve contabilizar apenas as 2 chamadas dos últimos 300 min');
  assert.equal(cota.janela5h.tokensEstimados, 8500, 'tokens estimados na janela de 5h devem somar 8.500');
  assert.ok(cota.janela5h.percentual >= 2.5 && cota.janela5h.percentual <= 3.0, `1 história completa de 18 cenas em modo Resumo deve consumir ~2.7% da janela de 5h (recebido: ${cota.janela5h.percentual}%)`);
  assert.ok(cota.janela5h.liberaTotalEm, 'deve informar horário estimado de liberação da janela de 5h');
  assert.equal(cota.hoje24h.chamadas, 3, 'hoje (24h) deve somar 3 chamadas');
  assert.equal(cota.semana7d.chamadas, 4, 'semana (7d) deve somar 4 chamadas');
  assert.equal(cota.semana7d.historias, 3, 'semana (7d) deve identificar 3 histórias distintas');
  assert.equal(cota.ultimasChamadas[1].novelaSlug, 'ele-ja-tinha-comprado', 'atualizarUltimoRegistroUsoClaude deve ter enriquecido o slug');

  // Testa o botão Zerar Janela 5h
  salvarCalibracaoCotaClaude({ zerarJanela5h: true }, { arquivoCalibracao: arqCal });
  const cotaZerada = calcularResumoCotaClaude({ arquivoLog: arqLog, arquivoCalibracao: arqCal, agora: Date.now() + 10 });
  assert.equal(cotaZerada.janela5h.chamadas, 0, 'após zerar janela 5h o contador de 5h deve cair para 0');
  assert.equal(cotaZerada.janela5h.percentual, 0);
  assert.equal(cotaZerada.semana7d.chamadas, 4, 'zerar janela 5h preserva histórico da semana');
});

await teste('Herança de padroesGlobais no store.criar/importar + classificação Parte Única + edição inline de falas', async () => {
  const { editarFalaEmRoteiroTexto, extrairDialogosRoteiro } = await import('./fabricaService.js');
  const { agruparProntos, agruparNovelas } = await import('../web/src/agrupamento.js');

  // 1) store.criar e fabricaService.importar leem diretamente config.json do disco mesmo sem callback obterPadroes
  const dadosIso = fs.mkdtempSync(path.join(tmp, 'pad-iso-'));
  fs.writeFileSync(path.join(dadosIso, 'config.json'), JSON.stringify({
    padroes: {
      modeloImagem: 'Nano Banana 2.1',
      modeloVideo: 'Omni 1.1 Flash',
      qualidadeGeracaoVideo: '720p',
      qualidadeDownloadVideo: '720p',
      qualidadeDownloadImagem: '1k',
    },
  }), 'utf8');
  const storeIso = new Store(dadosIso, path.join(dadosIso, 'proj'));
  const svcIso = new FabricaService({ store: storeIso, log: () => {}, emitirNovela: () => {}, broadcastUI: () => {} });
  const nImp = svcIso.importar({ slug: 'ele-ja-tinha-comprado', parte: 1 }).novela;
  assert.equal(nImp.qualidadeDownloadVideo, '720p', 'importar() sem callback deve ler 720p do config.json do disco (nunca cair em 1080p)');
  assert.equal(nImp.qualidadeDownloadImagem, '1k');
  assert.equal(nImp.modeloVideo, 'Omni 1.1 Flash');
  assert.equal(nImp.serie, false, 'Ele Já Tinha Comprado (totalPartes=1, fechado) deve ser marcado serie=false');
  assert.equal(nImp.formatoHistoria, 'unica');

  // 2) Classificação Parte Única vs Série em listarProntos e agruparProntos/agruparNovelas
  const prontos = svcIso.listarProntos();
  const prontoEle = prontos.find((p) => p.slug === 'ele-ja-tinha-comprado');
  assert.ok(prontoEle, 'ele-ja-tinha-comprado deve estar em listarProntos()');
  assert.equal(prontoEle.serie, false, 'história com totalPartes=1 e 1 parte no disco deve ter serie: false');
  assert.equal(prontoEle.formato, 'unica');
  const agrP = agruparProntos(prontos);
  assert.ok(agrP.unicas.some((p) => p.slug === 'ele-ja-tinha-comprado'), 'ele-ja-tinha-comprado deve ficar em Parte Única');
  assert.ok(!agrP.series.some((g) => g.chave === 'ele-ja-tinha-comprado'), 'ele-ja-tinha-comprado NUNCA pode aparecer em Séries');
  const agrN = agruparNovelas([nImp]);
  assert.equal(agrN.unicas.length, 1, 'novela importada de parte única deve ficar em Parte Única na barra lateral');
  assert.equal(agrN.series.length, 0);

  // 3) Edição inline de fala em roteiro_humano.md (0 tokens do Claude)
  const rotExemplo = [
    '# Teste Inline',
    'Cenas: 18 x 10s',
    '## CENA 01 (10s) — Gancho',
    'SARA [animada]: "Amor, preciso de cinquenta reais agora mesmo." (7 palavras)',
    'LUCAS [calmo]: "Amor, o dinheiro tá curto hoje. Espera o cartão virar amanhã." (11 palavras)',
    '[Total da cena: 18 palavras]',
  ].join('\n');
  const rotEditado = editarFalaEmRoteiroTexto(rotExemplo, {
    cena: 1,
    falaIndex: 0,
    texto: 'Amor, preciso de cinquenta reais. Tem uma camiseta linda na promoção.',
  });
  assert.ok(rotEditado.includes('SARA [animada]: "Amor, preciso de cinquenta reais. Tem uma camiseta linda na promoção." (11 palavras)'), 'deve atualizar a fala e recalcular (11 palavras)');
  assert.ok(rotEditado.includes('[Total da cena: 22 palavras]'), 'deve recalcular [Total da cena: 22 palavras]');
  const dExtraido = extrairDialogosRoteiro(rotEditado);
  assert.equal(dExtraido.tamanhoCenaSegundos, 10);
  assert.equal(dExtraido.cenas[0].totalPalavras, 22);
});

await teste('Fidelidade estrita ao resumo + Sonnet padrão + corte da Etapa 2/2 quando Chamada A já sai válida + modo Com Aprovação no regerar + JSON usage CLI', async () => {
  const { extrairEnvelopeJsonClaude, registrarUsoClaude, calcularResumoCotaClaude, salvarCalibracaoCotaClaude } = await import('./claudeBridge.js');

  // 1) Modelo padrão = sonnet (opus continua disponível sob escolha)
  assert.equal(svc.lerConfigFabrica().modeloRoteirista, 'sonnet', 'modeloRoteirista padrão deve ser sonnet para economizar cota na janela de 5h');
  assert.equal(svc.modeloRoteirista(), 'sonnet');
  assert.equal(svc.modeloRoteirista(null, 'opus'), 'opus', 'usuário ainda pode escolher opus quando quiser');

  // 2) Fidelidade estrita ao resumo: fatos intocáveis, proibição de cartão estourado/lanchonete inventados, fichas subordinadas só à cadência, cenas mudas (até 2)
  const resumoFiel = 'Sara pede 50 reais ao marido Lucas para comprar uma camiseta, ele nega dizendo para esperar o cartão, ela o humilha comparando com o ex, mas descobre no fim que Lucas já tinha comprado a camiseta e vendido o relógio do pai falecido para pagar a cirurgia da mãe dela.';
  const promptA = svc.montarPromptChamadaA({
    continuacao: false,
    entrada: resumoFiel,
    resumoUsuario: resumoFiel,
    config: { duracaoTotalMinutos: 3, tamanhoCenaSegundos: 10, formatoHistoria: 'unica', modoGeracaoVideo: 'elementos' },
    tipoFinal: 'fechado',
  });
  assert.ok(/FATOS INTOCÁVEIS/.test(promptA), 'deve conter trava de fatos intocáveis do resumo');
  assert.ok(/proibido inventar cartão estourado, lanchonete/i.test(promptA), 'deve proibir explicitamente inventar cartão estourado/lanchonete fora do resumo');
  assert.ok(/ONDE ENTRA A CRIATIVIDADE/.test(promptA) && /reação real de quem escuta/i.test(promptA), 'deve direcionar a criatividade para fala natural e reação de quem escuta');
  assert.ok(/CENAS MUDAS \(ATÉ 2 POR HISTÓRIA\)/i.test(promptA), 'deve permitir até 2 cenas mudas estratégicas');
  assert.ok(!/FICHAS DE REFERÊNCIA \(histórias que já funcionaram/.test(promptA), 'quando há resumo do usuário, não deve injetar enredos completos de fichas externas');

  // 3) Corte da Etapa 2/2 (Chamada B) quando a Chamada A já entrega roteiro_humano.md válido + modo Com Aprovação no regerarParte
  const fabEco = path.join(tmp, 'fabEco');
  fs.mkdirSync(path.join(fabEco, 'scripts'), { recursive: true });
  fs.mkdirSync(path.join(fabEco, 'dados'), { recursive: true });
  fs.mkdirSync(path.join(fabEco, 'prompts'), { recursive: true });
  fs.copyFileSync(path.join(FABRICA_DIR, 'scripts', 'validar_novela.mjs'), path.join(fabEco, 'scripts', 'validar_novela.mjs'));
  for (const f of ['prompt_mestre_roteirista.md', 'prompt_extrator_ficha.md']) {
    fs.copyFileSync(path.join(FABRICA_DIR, 'prompts', f), path.join(fabEco, 'prompts', f));
  }
  fs.writeFileSync(path.join(fabEco, 'dados', 'config.json'), JSON.stringify({
    modoOperacao: 'aprovacao',
    duracaoTotalMinutos: 3,
    tamanhoCenaSegundos: 10,
    modoGeracaoVideo: 'elementos',
    modeloRoteirista: 'sonnet',
  }));

  class FabEco extends FabricaService { get dir() { return fabEco; } }
  const storeEco = new Store(path.join(tmp, 'dadosEco'), path.join(tmp, 'projEco'));
  const svcEco = new FabEco({ store: storeEco, log: () => {}, emitirNovela: () => {}, broadcastUI: () => {} });

  const rotValido18 = (() => {
    const cenas = [];
    for (let i = 1; i <= 18; i++) {
      const n = String(i).padStart(2, '0');
      const f1 = i === 1
        ? 'SARA [irritada, olhando nos olhos]: "Amor, você não tem nem cinquenta reais pra minha camiseta?" (10 palavras)'
        : `SARA [firme, cobrando resposta]: "Lucas, até pra comprar uma camiseta eu preciso implorar?" (9 palavras)`;
      const f2 = i === 18
        ? 'LUCAS [emocionado, voz embargada]: "Eu vendi o relógio do meu pai pela sua mãe." (10 palavras)'
        : `LUCAS [calmo, segurando o celular]: "Espera só o meu turno acabar que eu te explico." (10 palavras)`;
      cenas.push([
        `## CENA ${n} (10s) — Etapa ${n}`,
        'Onde: ref_cenario_sala_interior (INTERIOR)',
        'Em quadro: SARA, LUCAS',
        i > 1 ? `Transição: Logo depois da fala da cena ${i - 1}, a tensão sobre os cinquenta reais aumenta.` : '',
        `Novidade: Avanço ${i} do conflito sobre os cinquenta reais e o sacrifício de Lucas.`,
        'Ação: Sara encara Lucas no meio da sala enquanto ele segura o capacete de entregas.',
        f1,
        f2,
        i === 18 ? 'Fisgada: revelação e frase de impacto — Sara descobre que Lucas já tinha comprado a camiseta e pago o hospital da mãe dela.' : '',
      ].filter(Boolean).join('\n'));
    }
    return [
      '# Ele Já Tinha Comprado',
      'Universo: urbano_simples',
      'Cenas: 18 x 10s',
      'Tipo-final: fechado',
      'Esqueleto: B — julgamento injusto do marido trabalhador seguido da revelação do sacrifício pela sogra.',
      'Relação exata: Sara e Lucas são esposa e marido recém-casados morando em apartamento simples.',
      'Conflito concreto: Sara humilha o marido por negar cinquenta reais para uma camiseta sem saber que ele pagou a cirurgia da mãe dela.',
      'Ponte (Cenas 1–3):',
      '- Quem é quem: Sara é a esposa impaciente; Lucas é o marido entregador que esconde o sacrifício.',
      '- Por que agora: Sara viu a camiseta em promoção e pediu cinquenta reais no fim do turno de Lucas.',
      '- Regra/acordo em jogo: Sara ameaça sair de casa achando que é mesquinharia, mas a verdade muda tudo.',
      'Final-fisgada: revelação e frase de impacto — a mãe de Sara revela que Lucas vendeu o relógio do pai falecido para salvar a vida dela.',
      'Teste da Dona Maria: APROVADO — a esposa brigou por causa de cinquenta reais de uma camiseta, mas descobriu no fim que o marido já tinha comprado a camiseta e ainda vendeu o relógio do pai para pagar o hospital da mãe dela.',
      'Personagens:',
      '- SARA | protagonista | ref_sara | Voz: mulher jovem impulsiva e direta, frases curtas do cotidiano urbano',
      '- LUCAS | aliado | ref_lucas | Voz: marido trabalhador de fala calma e firme, engole o orgulho pela família',
      '',
      ...cenas,
    ].join('\n');
  })();

  let chamadasEco = 0;
  svcEco.rodarClaude = async () => {
    chamadasEco++;
    return [
      '===FILE:roteiro_humano.md===',
      rotValido18,
      '===END_FILE===',
      '===FILE:biblia_serie.json===',
      JSON.stringify({ slug: 'ele-ja-tinha-comprado', titulo: 'Ele Já Tinha Comprado', premissa: resumoFiel }),
      '===END_FILE===',
      'RESULTADO_JSON: {"slug":"ele-ja-tinha-comprado","parte":1}',
    ].join('\n');
  };

  const jCria = svcEco.criarRoteiro({
    resumoUsuario: resumoFiel,
    origem: 'resumo',
    config: { modoOperacao: 'aprovacao', duracaoTotalMinutos: 3, tamanhoCenaSegundos: 10, formatoHistoria: 'unica', modoGeracaoVideo: 'elementos' },
    tipoFinal: 'fechado',
  });
  for (let i = 0; i < 80; i++) {
    if (svcEco.obterJob(jCria.id)?.estado !== 'rodando') break;
    await new Promise((r) => setTimeout(r, 20));
  }
  const fimCria = svcEco.obterJob(jCria.id);
  assert.equal(fimCria.estado, 'ok');
  assert.equal(chamadasEco, 1, 'quando a Chamada A já entrega roteiro válido, NÃO deve disparar a Etapa 2/2 (apenas 1 chamada!)');
  assert.equal(fimCria.modeloA, 'sonnet', 'deve usar Sonnet por padrão');
  assert.ok(/0 tokens extras/.test(fimCria.etapas?.[1]?.rotulo || ''), 'Etapa 2/2 deve indicar validação local com 0 tokens extras');
  const pastaP1Eco = path.join(fabEco, 'prontos_para_flow', 'ele-ja-tinha-comprado', 'parte_01');
  assert.equal(fs.existsSync(path.join(pastaP1Eco, 'prompts_flow.txt')), false, 'no modo Com Aprovação não pode gerar prompts_flow.txt antes da aprovação');
  assert.ok(fs.readFileSync(path.join(pastaP1Eco, 'resumo_original.txt'), 'utf8').includes('vendi o relógio') || fs.readFileSync(path.join(pastaP1Eco, 'resumo_original.txt'), 'utf8').includes('relógio do pai'), 'deve salvar resumo_original.txt para preservar fatos em futuras reescritas');

  // 4) Gerar Novamente (regerarParte) em modo Com Aprovação: para na revisão do roteiro (não gera prompts_flow.txt) e mantém fidelidade ao resumo_original.txt
  let promptRegerarRecebido = '';
  chamadasEco = 0;
  svcEco.rodarClaude = async (_job, prompt) => {
    chamadasEco++;
    promptRegerarRecebido = prompt;
    return `===FILE:roteiro_humano.md===\n${rotValido18}\n===END_FILE===\nRESULTADO_JSON: {"slug":"ele-ja-tinha-comprado","parte":1}`;
  };
  const jReg = svcEco.regerarParte({
    slug: 'ele-ja-tinha-comprado',
    parte: 1,
    tipoFinal: 'fechado',
    observacao: 'Deixar a reação de Lucas ainda mais forte na Cena 07',
  });
  for (let i = 0; i < 80; i++) {
    if (svcEco.obterJob(jReg.id)?.estado !== 'rodando') break;
    await new Promise((r) => setTimeout(r, 20));
  }
  const fimReg = svcEco.obterJob(jReg.id);
  assert.equal(fimReg.estado, 'ok', `regerarParte em modo Com Aprovação deve aprovar apenas roteiro (${fimReg.erro})`);
  assert.equal(chamadasEco, 1, 'regerarParte com roteiro válido na Chamada A também poupa a Etapa 2/2');
  assert.equal(fimReg.validacao?.apenasRoteiro, true, 'regerarParte em modo Com Aprovação deve validar com apenasRoteiro: true');
  assert.equal(fs.existsSync(path.join(pastaP1Eco, 'prompts_flow.txt')), false, 'regerarParte em modo Com Aprovação NÃO deve gerar prompts_flow.txt sem aprovação');
  assert.ok(promptRegerarRecebido.includes(resumoFiel), 'regerarParte deve injetar o resumo original completo do usuário para nunca perder o enredo');

  // 5) Parser de JSON usage/custo do Claude CLI + sincronização de % 5h real
  const envJson = extrairEnvelopeJsonClaude(JSON.stringify({
    type: 'result',
    subtype: 'success',
    is_error: false,
    total_cost_usd: 0.0485,
    result: '===FILE:roteiro_humano.md===\n# Teste\n===END_FILE===',
    usage: {
      input_tokens: 1800,
      output_tokens: 2400,
      cache_creation_input_tokens: 1200,
      cache_read_input_tokens: 4000,
      thinking_tokens: 500,
    },
  }));
  assert.equal(envJson.eraJson, true);
  assert.equal(envJson.texto, '===FILE:roteiro_humano.md===\n# Teste\n===END_FILE===');
  assert.equal(envJson.metricas.custoUsd, 0.0485);
  assert.equal(envJson.metricas.inputTokens, 1800);
  assert.equal(envJson.metricas.outputTokens, 2400);
  assert.equal(envJson.metricas.thinkingTokens, 500);
  assert.equal(envJson.metricas.tokensReaisCli, 1800 + 2400 + 500 + 300 + 200);

  const pastaCotaJson = fs.mkdtempSync(path.join(tmp, 'cota-json-'));
  const arqLogJson = path.join(pastaCotaJson, 'usage.jsonl');
  const arqCalJson = path.join(pastaCotaJson, 'cal.json');
  registrarUsoClaude({
    timestamp: new Date().toISOString(),
    tipo: 'roteiro_ideacao',
    novelaSlug: 'ele-ja-tinha-comprado',
    novelaTitulo: 'Ele Já Tinha Comprado',
    charsPrompt: 4000,
    charsSaida: 8000,
    tokensReaisCli: envJson.metricas.tokensReaisCli,
    tokensInput: envJson.metricas.inputTokens,
    tokensOutput: envJson.metricas.outputTokens,
    custoUsd: envJson.metricas.custoUsd,
    duracaoMs: 19000,
    ok: true,
    modelo: 'sonnet',
  }, { arquivoLog: arqLogJson });
  salvarCalibracaoCotaClaude({ percentual5hAtualReal: 34.5 }, { arquivoCalibracao: arqCalJson, arquivoLog: arqLogJson });
  const resumoSincronizado = calcularResumoCotaClaude({ arquivoLog: arqLogJson, arquivoCalibracao: arqCalJson });
  assert.equal(resumoSincronizado.janela5h.percentual, 34.5, 'deve sincronizar exatamente o percentual de 5h informado pelo usuário');
  assert.equal(resumoSincronizado.janela5h.custoUsd, 0.0485);
});

await teste('Link Viral / Sementes: preenche semente limpa automaticamente, zero falso aviso de validador e cache local de transcrição (yt-dlp + whisper)', async () => {
  const { extrairSementeLimpaDeSaida } = await import('./fabricaService.js');

  const saidaViralBruta = [
    'Tentando download (direto, sem cookies) ...',
    'Transcrevendo as falas com whisper.cpp (offline, pode levar alguns minutos)...',
    '',
    '# Extração — 16M views · 619K reactions | Como hombre, la primera mujer que tienes que cuidar es tu madre.',
    '- Pasta: C:\\FabricaClaude\\temp_midia\\ext_20261120003634',
    '- Vídeo: C:\\FabricaClaude\\temp_midia\\ext_20261120003634\\video.mp4',
    '- Duração: 157.408s',
    '- Transcrição: OK via whisper.cpp offline, com timestamps (transcricao.json) → transcricao.txt',
    '- Frames: OK (20 quadros em frames/ + mosaico.jpg)',
    '',
    'Próximo passo: ler transcricao.txt e olhar os frames, depois usar a skill adaptador-viral. Apague a pasta temp_midia quando terminar.',
    '**SEMENTE — TRÍADE CONCRETA**',
    '',
    '1. **Objeto físico em disputa:** Um par de botas de couro surradas do pai viúvo.',
    '2. **Vínculo familiar/social:** Filho recém-promovido a gerente e a namorada que zomba das botas.',
    '3. **Ironia plantada:** No jantar caro, o filho revela diante das amigas dela que aquelas botas pagaram sua faculdade.',
    '',
    '---',
    '',
    'RESULTADO_JSON: {"slug":"botas-surradas","parte":1}',
  ].join('\n');

  const semLimpa = extrairSementeLimpaDeSaida(saidaViralBruta);
  assert.ok(semLimpa.startsWith('**SEMENTE — TRÍADE CONCRETA**'), 'deve remover o cabeçalho técnico do yt-dlp/whisper');
  assert.ok(semLimpa.includes('Um par de botas de couro surradas'), 'deve manter integralmente o corpo da semente');
  assert.ok(!semLimpa.includes('RESULTADO_JSON'), 'deve remover RESULTADO_JSON da caixa de semente');
  assert.ok(!semLimpa.includes('Tentando download'), 'não pode vazar log de download na caixa de semente');

  // Fabrica isolada para testar criarSementes com Link Viral + cache de transcrição + zero validacao falsa
  const fabLink = path.join(tmp, 'fabLink');
  fs.mkdirSync(path.join(fabLink, 'dados'), { recursive: true });
  fs.writeFileSync(path.join(fabLink, 'dados', 'config.json'), JSON.stringify({
    modoOperacao: 'aprovacao',
    duracaoTotalMinutos: 3,
    tamanhoCenaSegundos: 15,
    modoGeracaoVideo: 'elementos',
    modeloRoteirista: 'sonnet',
  }));

  class FabLink extends FabricaService { get dir() { return fabLink; } }
  const storeLink = new Store(path.join(tmp, 'dadosLink'), path.join(tmp, 'projLink'));
  const svcLink = new FabLink({ store: storeLink, log: () => {}, emitirNovela: () => {}, broadcastUI: () => {} });

  let extracoesMidia = 0;
  svcLink.extrairVideoLocal = async (_url, job) => {
    extracoesMidia++;
    const dirMidia = path.join(fabLink, 'temp_midia', `ext_${extracoesMidia}`);
    fs.mkdirSync(dirMidia, { recursive: true });
    fs.writeFileSync(path.join(dirMidia, 'transcricao.txt'), 'Filho, eu vim trazer suas ferramentas com minhas botas velhas. Amor, que vergonha dessas botas furadas!', 'utf8');
    fs.writeFileSync(path.join(dirMidia, 'RESUMO.md'), '# Extração — Botas do Pai\nResumo do vídeo viral.', 'utf8');
    job.saida += 'Tentando download (direto, sem cookies) ...\n# Extração — Botas do Pai\n- Pasta: ' + dirMidia + '\n';
    return dirMidia;
  };
  svcLink.rodarClaude = async () => {
    return '**SEMENTE — TRÍADE CONCRETA**\n1. Objeto: Botas surradas do pai eletricista.\n2. Vínculo: Filho gerente e noiva vaidosa.\n3. Ironia: As botas pagaram a faculdade dele.\nRESULTADO_JSON: {"slug":"botas-do-pai","parte":1}';
  };

  const urlTeste = 'https://www.facebook.com/share/v/1FYMZ17eXd/?mibextid=wwXIfr';
  svcLink.salvarEstadoCriador({ modo: 'aprovacao', origem: 'link', link: urlTeste, semente: '' });

  // 1a execução: extrai vídeo, salva no cache, gera semente limpa, NÃO gera job.validacao falso e preenche estado.semente
  const jSem1 = svcLink.criarSementes({ origem: 'link', link: urlTeste, config: { tamanhoCenaSegundos: 15 } });
  for (let i = 0; i < 80; i++) {
    if (svcLink.obterJob(jSem1.id)?.estado !== 'rodando') break;
    await new Promise((r) => setTimeout(r, 20));
  }
  const fimSem1 = svcLink.obterJob(jSem1.id);
  assert.equal(fimSem1.estado, 'ok');
  assert.equal(extracoesMidia, 1, '1ª chamada deve extrair mídia local');
  assert.equal(fimSem1.validacao, null, 'etapa de semente NUNCA pode ter job.validacao (evita aviso falso "Nenhum arquivo para validar")');
  assert.ok(fimSem1.sementeGerada?.includes('Botas surradas do pai eletricista'), 'job deve expor sementeGerada limpa');
  assert.ok(!fimSem1.sementeGerada?.includes('RESULTADO_JSON'), 'sementeGerada não pode conter RESULTADO_JSON');
  assert.ok(fimSem1.resultado?.transcricaoViral?.includes('botas velhas'), 'deve preservar transcrição viral no resultado');

  const estAposSem1 = svcLink.obterEstadoCriador();
  assert.ok(estAposSem1.semente?.includes('Botas surradas do pai eletricista'), 'estado do Criador deve ter campo semente preenchido automaticamente');

  // 2a execução com o MESMO link: deve usar o cache local de transcrição (0 chamadas ao extrairVideoLocal / yt-dlp / whisper!)
  const jSem2 = svcLink.criarSementes({ origem: 'link', link: urlTeste, config: { tamanhoCenaSegundos: 15 } });
  for (let i = 0; i < 80; i++) {
    if (svcLink.obterJob(jSem2.id)?.estado !== 'rodando') break;
    await new Promise((r) => setTimeout(r, 20));
  }
  const fimSem2 = svcLink.obterJob(jSem2.id);
  assert.equal(fimSem2.estado, 'ok');
  assert.equal(extracoesMidia, 1, '2ª chamada no mesmo link DEVE reaproveitar a transcrição do cache sem rodar yt-dlp/whisper de novo');
  assert.equal(fimSem2.transcricaoDoCache, true);

  // Recuperação automática de estado antigo que tinha wiz.saida preenchido mas semente: "" e validacao falsa
  svcLink.salvarEstadoCriador({
    modo: 'aprovacao',
    origem: 'link',
    semente: '',
    wiz: {
      etapa: 'sementes',
      jobId: 'job-antigo-orfao',
      rodando: false,
      estado: 'ok',
      saida: saidaViralBruta,
      validacao: { ok: false, saida: 'Nenhum arquivo para validar.' },
    },
  });
  const estRecuperado = svcLink.obterEstadoCriador();
  assert.ok(estRecuperado.semente.startsWith('**SEMENTE — TRÍADE CONCRETA**'), 'obterEstadoCriador deve preencher semente vazia a partir de wiz.saida');
  assert.equal(estRecuperado.wiz?.validacao, undefined, 'obterEstadoCriador deve limpar validacao falsa de etapa sementes');
});

await teste('Automático Link Viral: injeta transcricao.txt direto no prompt (delimitada em 3 atos p/ vídeo >180s e traduzida de espanhol), limpa temp_midia mesmo em erro e usa timeout prudente (240s-300s)', async () => {
  const {
    prepararTranscricaoViralParaPrompt,
    TIMEOUT_PADRAO_CLAUDE_SEG,
    TIMEOUT_MAX_CLAUDE_SEG,
  } = await import('./fabricaService.js');

  // 1) Timeout prudente: padrão 270s (entre 240s e 300s), teto 300s, respeita config menor (ex.: 240s)
  assert.ok(TIMEOUT_PADRAO_CLAUDE_SEG >= 240 && TIMEOUT_PADRAO_CLAUDE_SEG <= 300, 'timeout padrão deve ficar entre 240s e 300s');
  assert.equal(TIMEOUT_MAX_CLAUDE_SEG, 300, 'teto máximo de timeout por chamada deve ser 300s (nunca 1500s)');
  assert.equal(svc.obterTimeoutClaudeMs({ timeoutClaudeSegundos: 240 }, 270), 240000, 'deve respeitar timeout menor configurado em config.json');
  assert.equal(svc.obterTimeoutClaudeMs({ timeoutClaudeSegundos: 1500 }, 270), 270000, 'deve bloquear valores gigantes como 1500s');

  // 2) prepararTranscricaoViralParaPrompt com vídeo longo (285.6s) em espanhol (como o vídeo do bolo de 3 andares)
  const transcricaoEspanhol = [
    '[00:00] Prima, necesito que me prepares el mejor pastel que hayas hecho en tu vida.',
    '[00:10] Lo necesito para mañana temprano porque le voy a celebrar los 15 años de mi hija Valentina.',
    '[00:25] Está bien Prima, voy a trabajar toda la noche para tener ese pastel listo para mañana.',
    '[01:10] Amor, ¿qué haces con nuestros ahorros? Los voy a usar para comprar los materiales del pastel.',
    '[02:15] Además como es para ti, de seguro tu prima te lo va a regalar.',
    '[02:35] ¿En serio te vas a poner a cobrarle a tu propia familia? Todos se van a enterar.',
    '[03:30] Este pastel no sale de mi local hasta que tu mamá me lo pague por completo.',
    '[03:50] Señorita, véndame ese pastel, la fiesta de mi nieta va a empezar y le pago el doble ahora mismo.',
    '[04:20] No Prima, tú no le puedes vender el pastel a este anciano, recuerda que somos familia.',
    '[04:42] ¿Debería darle prioridad a su prima irresponsable o venderle el pastel al cliente que valora su trabajo?',
  ].join('\n');

  const prep = prepararTranscricaoViralParaPrompt({
    transcricaoTxt: transcricaoEspanhol,
    infoJson: {
      titulo: '5.9M views · 193K reactions | Le Exigió A Su Prima Que Le Regalara Un Pastel De Tres Pisos #novelas #reflexiones | Relatos que Enseñan',
      duracaoSegundos: 285.6,
    },
  });
  assert.equal(prep.idioma, 'es', 'deve detectar idioma espanhol automaticamente');
  assert.equal(prep.ehLongo, true, 'vídeo de 285.6s (>180s) deve ser marcado como longo');
  assert.ok(prep.textoDelimitado.includes('[ATO 1 — ABERTURA E GANCHO INICIAL]'), 'vídeo longo deve ser estruturado em 3 atos claros');
  assert.ok(prep.textoDelimitado.includes('[ATO 3 — CLÍMAX, VIRADA E LIÇÃO FINAL]'), 'deve preservar o clímax/virada final');
  assert.ok(!/\[\d{2}:\d{2}\]/.test(prep.textoDelimitado), 'deve limpar timestamps [MM:SS] repetitivos');
  assert.ok(prep.blocoPrompt.includes('NÃO tente abrir `transcricao.txt` nem olhar `frames/` no disco'), 'deve proibir explicitamente tentar ler arquivos do disco sem tools');
  assert.ok(prep.blocoPrompt.includes('TRADUZA E ADAPTE 100% PARA PORTUGUÊS DO BRASIL'), 'deve instruir tradução/adaptação para PT-BR');

  // 3) criarAutomatico com origem='link' injeta a transcrição direto no promptA e limpa temp_midia/ext_* MESMO quando o Claude falha/dá timeout
  const fabAuto = path.join(tmp, 'fabAutoLink');
  fs.mkdirSync(path.join(fabAuto, 'dados'), { recursive: true });
  fs.mkdirSync(path.join(fabAuto, 'prompts'), { recursive: true });
  for (const f of ['prompt_mestre_roteirista.md', 'prompt_extrator_ficha.md']) {
    fs.copyFileSync(path.join(FABRICA_DIR, 'prompts', f), path.join(fabAuto, 'prompts', f));
  }
  fs.writeFileSync(path.join(fabAuto, 'dados', 'config.json'), JSON.stringify({
    modoOperacao: 'automatico',
    duracaoTotalMinutos: 3,
    tamanhoCenaSegundos: 15,
    modoGeracaoVideo: 'elementos',
    modeloRoteirista: 'sonnet',
    timeoutClaudeSegundos: 240,
  }));

  class FabAuto extends FabricaService { get dir() { return fabAuto; } }
  const storeAuto = new Store(path.join(tmp, 'dadosAutoLink'), path.join(tmp, 'projAutoLink'));
  const svcAuto = new FabAuto({ store: storeAuto, log: () => {}, emitirNovela: () => {}, broadcastUI: () => {} });

  let pastaMidiaCriada = null;
  let promptARecebido = '';
  svcAuto.extrairVideoLocal = async (_url, job) => {
    pastaMidiaCriada = path.join(fabAuto, 'temp_midia', 'ext_20261120999999');
    fs.mkdirSync(pastaMidiaCriada, { recursive: true });
    fs.writeFileSync(path.join(pastaMidiaCriada, 'transcricao.txt'), transcricaoEspanhol, 'utf8');
    fs.writeFileSync(path.join(pastaMidiaCriada, 'info.json'), JSON.stringify({ titulo: 'Pastel de Tres Pisos', duracaoSegundos: 285.6 }), 'utf8');
    fs.writeFileSync(path.join(pastaMidiaCriada, 'video.mp4'), Buffer.alloc(1024), 'utf8');
    job.saida += `Tentando download...\n- Pasta: ${pastaMidiaCriada}\nPróximo passo: ler transcricao.txt e olhar os frames\n`;
    return pastaMidiaCriada;
  };
  svcAuto.rodarClaude = async (_job, prompt) => {
    promptARecebido = prompt;
    throw new Error('Falha em "Etapa 1/2: Escaleta e dramaturgia (Sonnet)" após 240s: Claude Code CLI excedeu 240s.');
  };

  const urlBolo = 'https://www.facebook.com/share/v/19p2WGxCL9/?mibextid=wwXIfr';
  const jAuto = svcAuto.criarAutomatico({
    origem: 'link',
    link: urlBolo,
    config: { duracaoTotalMinutos: 3, tamanhoCenaSegundos: 15 },
    tipoFinal: 'fechado',
  });
  for (let i = 0; i < 80; i++) {
    if (svcAuto.obterJob(jAuto.id)?.estado !== 'rodando') break;
    await new Promise((r) => setTimeout(r, 20));
  }
  const fimAuto = svcAuto.obterJob(jAuto.id);
  assert.equal(fimAuto.estado, 'erro');
  assert.ok(promptARecebido.includes('Prima, necesito que me prepares el mejor pastel'), 'transcricao.txt DEVE estar injetada diretamente dentro do prompt enviado ao Claude');
  assert.ok(promptARecebido.includes('NÃO tente abrir `transcricao.txt`'), 'prompt deve avisar explicitamente para não tentar ler transcricao.txt do disco');
  assert.ok(!fimAuto.saida.includes('Próximo passo: ler transcricao.txt'), 'deve remover a frase enganosa "Próximo passo: ler transcricao.txt" do log visível');
  assert.equal(fs.existsSync(pastaMidiaCriada), false, 'pasta temp_midia/ext_* DEVE ser apagada mesmo quando a chamada ao Claude falha por timeout');
  assert.equal(fimAuto.etapas?.[0]?.estado, 'erro', 'etapa que falhou não pode ficar pendurada como "rodando"');
  assert.ok(/Falha em "Etapa 1\/2/.test(fimAuto.erro || ''), 'mensagem de erro deve indicar claramente qual etapa falhou e o tempo decorrido');
});

fs.rmSync(tmp, { recursive: true, force: true });
console.log(`\n${process.exitCode ? '❌ FALHOU' : `✅ ${ok} testes passaram`}`);
