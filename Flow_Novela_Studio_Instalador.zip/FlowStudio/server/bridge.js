// Ponte WebSocket com a Extensao do Chrome (requisicao/resposta com timeout)
export class Bridge {
  constructor({ onChange, log }) {
    this.socket = null;
    this.info = null;
    this.pendentes = new Map();
    this.seq = 0;
    this.onChange = onChange || (() => {});
    this.log = log || (() => {});
  }

  get conectada() {
    return !!this.socket && this.socket.readyState === 1;
  }

  estado() {
    return { conectada: this.conectada, info: this.info };
  }

  anexar(ws, info) {
    if (this.socket && this.socket !== ws) {
      try { this.socket.close(4000, 'substituida'); } catch {}
    }
    this.socket = ws;
    this.info = { ...info, conectadaEm: new Date().toISOString() };
    this.onChange();
  }

  desanexar(ws) {
    if (this.socket !== ws) return;
    this.socket = null;
    this.info = null;
    for (const [id, p] of this.pendentes) {
      clearTimeout(p.timer);
      p.reject(new Error('Extensão desconectou durante a operação.'));
      this.pendentes.delete(id);
    }
    this.onChange();
  }

  atualizarInfo(parcial) {
    this.info = { ...(this.info || {}), ...parcial };
    this.onChange();
  }

  enviar(msg) {
    if (!this.conectada) return false;
    this.socket.send(JSON.stringify(msg));
    return true;
  }

  /** Envia um comando para a extensao e aguarda a resposta. */
  requisitar(comando, payload = {}, timeoutMs = 120000) {
    return new Promise((resolve, reject) => {
      if (!this.conectada) return reject(new Error('Extensão do Chrome não está conectada.'));
      const requestId = `r${Date.now().toString(36)}_${++this.seq}`;
      const timer = setTimeout(() => {
        this.pendentes.delete(requestId);
        reject(new Error(`Tempo esgotado aguardando a extensão (${comando}, ${Math.round(timeoutMs / 1000)}s).`));
      }, timeoutMs);
      this.pendentes.set(requestId, { resolve, reject, timer, comando });
      this.socket.send(JSON.stringify({ type: 'comando', requestId, comando, payload }));
    });
  }

  cancelarTodas(motivo = 'Cancelado pelo usuário.') {
    for (const [id, p] of this.pendentes) {
      clearTimeout(p.timer);
      p.reject(new Error(motivo));
      this.pendentes.delete(id);
    }
  }

  receberResposta(msg) {
    const p = this.pendentes.get(msg.requestId);
    if (!p) return;
    clearTimeout(p.timer);
    this.pendentes.delete(msg.requestId);
    if (msg.ok) p.resolve(msg.data ?? {});
    else p.reject(new Error(msg.erro || 'Erro desconhecido na extensão.'));
  }
}
