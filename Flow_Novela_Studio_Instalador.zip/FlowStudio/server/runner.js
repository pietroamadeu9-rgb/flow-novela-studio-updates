// Orquestrador da fila: executa novelas em sequencia, 1 projeto do Google Flow por novela,
// com troca automatica de conta/projeto, re-upload sob demanda de referencias locais,
// auto-conserto em 3 tentativas (Claude Code CLI + fallback local) e pulo inteligente.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { validarMidia } from './validarMidia.js';
import { atualizarCenaCapcut, localizarDraftNovela } from './capcutExporter.js';
import {
  repairBlockedPrompt,
  salvarBackupsOriginaisItem,
  aplicarSuavizacaoComImagem,
  aplicarModoDescritivoSemImagem,
} from './claudeBridge.js';
import {
  normalizarUrlMidia,
  calcularSha256,
  coletarAssinaturasVideosNovela,
  verificarDuplicidadeVideo,
  casarCardsComCenas,
} from './videoCapturaGuard.js';

export const MSG_CREDITOS_ESGOTADOS =
  'Créditos esgotados nesta conta! Troque para outra conta na aba do Google Flow e clique em Rodar/Continuar — o estúdio criará um novo projeto na nova conta e continuará da cena exata onde parou.';

/** Dados da novela enviados para a extensao (inclui as qualidades de geracao/download). */
export function novelaParaExtensao(n) {
  // modoGeracaoVideo (da Fabrica) manda; sem ele vale a flag antiga forcarElementos
  const forcarElementos = n.modoGeracaoVideo ? n.modoGeracaoVideo === 'elementos' : !!n.forcarElementos;
  return {
    id: n.id,
    nome: n.nome,
    modeloImagem: n.modeloImagem,
    modeloVideo: n.modeloVideo,
    flowProjectUrl: n.flowProjectUrl,
    forcarElementos,
    modoGeracaoVideo: forcarElementos ? 'elementos' : 'frame_inicial',
    qualidadeGeracaoVideo: n.qualidadeGeracaoVideo || '720p',
    qualidadeDownloadVideo: n.qualidadeDownloadVideo || '1080p',
    qualidadeDownloadImagem: n.qualidadeDownloadImagem || '2k',
  };
}

const TIMEOUTS = {
  criar_projeto: 3 * 60 * 1000,
  abrir_projeto: 3 * 60 * 1000,
  referencia_imagem: 12 * 60 * 1000,
  imagem_base: 12 * 60 * 1000,
  video: 35 * 60 * 1000,
};

const RE_CREDITOS_MSG =
  /\[CREDITOS_ESGOTADOS\]|cr[eé]ditos?\s+(?:insuficientes?|esgotados?|acabaram)|sem\s+cr[eé]ditos?|n[aã]o\s+(?:h[aá]|tem|possui)\s+cr[eé]ditos?|out\s+of\s+(?:ai\s+)?credits?|not\s+enough\s+(?:ai\s+)?credits?|insufficient\s+(?:ai\s+)?credits?|no\s+(?:ai\s+)?credits?\s+(?:left|remaining)|monthly\s+credit\s+limit|limite\s+de\s+cr[eé]ditos?\s+atingido|quota\s+exceeded|cota\s+excedida/i;

const RE_PROJ_INACESSIVEL_MSG =
  /\[PROJETO_INACESSIVEL\]|projeto\s+n[aã]o\s+encontrado|project\s+not\s+found|403|404|acesso\s+negado|access\s+denied|sem\s+permiss[aã]o/i;

const RE_ATIVIDADE_INCOMUM_MSG =
  /\[ATIVIDADE_INCOMUM\]|atividade\s+incomum|unusual\s+activity|extens[oõ]es?\s+do\s+navegador\s+que\s+modificam\s+a\s+p[aá]gina|browser\s+extensions?\s+that\s+modify|tr[aá]fego\s+incomum|unusual\s+traffic|automated\s+queries|consulta[s]?\s+automatizada|detectamos\s+uma?\s+atividade\s+incomum/i;

const RE_POLITICA_EXPLICITA_MSG =
  /\[BLOQUEIO_FLOW\]|viola(?:tes?|r|ç[aã]o)?|pol[ií]tica|policy|guidelines|diretrizes|unsafe|inappropriate|impr[oó]pri|tente\s+outro\s+comando|try\s+a\s+different\s+prompt|conte[uú]do\s+n[aã]o\s+permitido|unable\s+to\s+(?:generate|create)|couldn.?t\s+(?:generate|create)|can.?t\s+(?:generate|create)|n[aã]o\s+foi\s+poss[ií]vel\s+(?:gerar|criar)/i;

const RESFRIAMENTO_ATIVIDADE_INCOMUM_MS = 3 * 60 * 1000; // 3 minutos de pausa de resfriamento

const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
const intervaloAleatorioMs = (minMs, maxMs) => minMs + Math.floor(Math.random() * (maxMs - minMs + 1));

export function chaveProjetoFlow(url) {
  if (!url) return '';
  try {
    const u = new URL(url);
    return `${u.origin}${u.pathname.replace(/\/+$/, '')}`;
  } catch {
    return String(url).split(/[?#]/)[0].replace(/\/+$/, '');
  }
}

function limparPrefixosInternos(msg) {
  return String(msg || '')
    .replace(/^\[(CREDITOS_ESGOTADOS|PROJETO_INACESSIVEL|ATIVIDADE_INCOMUM|BLOQUEIO_FLOW|FALHA_TECNICA|DUPLICATA_VIDEO)\]\s*/i, '')
    .trim();
}

export function ehNovelaConcluidaManual(n) {
  return Boolean(n?.concluidaManualmente || n?.statusManual === 'concluida');
}

export class Runner {
  constructor({ store, bridge, emitirNovela, emitirFila, log, contextoHistoria = null }) {
    this.contextoHistoria = contextoHistoria; // Fabrica Claude: roteiro/resumo da historia para o auto-conserto
    this.store = store;
    this.bridge = bridge;
    this.emitirNovela = emitirNovela;
    this.emitirFila = emitirFila;
    this.log = log;
    this.fila = []; // [{novelaId, itemIds|null}]
    this.filaIsolada = []; // [{novelaId, itemIds}] executadas isoladamente quando a fila global esta pausada
    this.atualizarCapcutMap = new Map(); // "${novelaId}:${itemId}" -> boolean
    this.rodando = false;
    this.pausado = false;
    this.modoIsolado = false;
    this.pausaSolicitada = false;
    this._pularNovelaAtual = false;
    this.motivoPausa = null; // null | 'manual' | 'creditos_esgotados'
    this.alertaCreditos = null;
    this.novelaAtual = null;
    this.itemAtual = null;
    this.tentativaAtual = null;
    this.recapturando = null;
    this.bloqueiosAtividadeIncomumSeguidos = 0;
    this._wakeProc = null;
    this.mensagem = 'Parado';
  }

  /** Ativa prevencao de suspensao/hibernacao do Windows enquanto a fila estiver rodando (SetThreadExecutionState). */
  ativarWakeLockWindows() {
    if (process.platform !== 'win32' || this._wakeProc) return;
    try {
      const psCmd = [
        'Add-Type -MemberDefinition \'[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint esFlags);\' -Name Win32Power -Namespace FNS -PassThru | Out-Null;',
        'while ($true) { [FNS.Win32Power]::SetThreadExecutionState(0x80000003) | Out-Null; Start-Sleep -Seconds 30 }',
      ].join(' ');
      const child = spawn('powershell.exe', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', psCmd], {
        stdio: 'ignore',
        windowsHide: true,
      });
      child.on('exit', () => { if (this._wakeProc === child) this._wakeProc = null; });
      child.on('error', () => { if (this._wakeProc === child) this._wakeProc = null; });
      child.unref();
      this._wakeProc = child;
    } catch {}
  }

  desativarWakeLockWindows() {
    const p = this._wakeProc;
    this._wakeProc = null;
    if (!p) return;
    try { p.kill(); } catch {}
  }

  estado() {
    return {
      rodando: this.rodando,
      pausado: this.pausado,
      modoIsolado: this.modoIsolado,
      recapturando: this.recapturando,
      pausaSolicitada: this.pausaSolicitada,
      motivoPausa: this.motivoPausa,
      alertaCreditos: this.alertaCreditos,
      wakeLockAtivo: Boolean(this._wakeProc || this.rodando),
      fila: this.fila.map((f) => f.novelaId),
      novelaPausadaId: this.pausado && this.fila[0] ? this.fila[0].novelaId : null,
      novelaAtual: this.novelaAtual,
      itemAtual: this.itemAtual,
      tentativaAtual: this.tentativaAtual,
      mensagem: this.mensagem,
    };
  }

  setMsg(m) {
    this.mensagem = m;
    this.emitirFila();
  }

  /** Garante o mapa `uploadedAssetsByProjectUrl` na novela e migra ativos renomeados do projeto original. */
  garantirMapaUploads(n) {
    if (!n.uploadedAssetsByProjectUrl || typeof n.uploadedAssetsByProjectUrl !== 'object') {
      n.uploadedAssetsByProjectUrl = {};
    }
    const chave = chaveProjetoFlow(n.flowProjectUrl);
    if (!chave) return null;
    if (!Array.isArray(n.uploadedAssetsByProjectUrl[chave])) {
      // Se for o primeiro projeto historico da novela e ja havia itens gerados com nomeAtivoFlow, preserva-os
      const tinhaOutrosProjetos = Object.keys(n.uploadedAssetsByProjectUrl).length > 0;
      n.uploadedAssetsByProjectUrl[chave] = tinhaOutrosProjetos
        ? []
        : (n.itens || []).filter((i) => i.status === 'concluido' && i.nomeAtivoFlow).map((i) => i.id);
    }
    return chave;
  }

  registrarAtivosNoProjeto(n, urlProjeto, ids = []) {
    const chave = chaveProjetoFlow(urlProjeto || n.flowProjectUrl);
    if (!chave || !ids.length) return;
    this.garantirMapaUploads(n);
    const lista = n.uploadedAssetsByProjectUrl[chave] || [];
    for (const id of ids) {
      if (id && !lista.includes(id)) lista.push(id);
    }
    n.uploadedAssetsByProjectUrl[chave] = lista;
  }

  ativoJaEstaNoProjeto(n, id) {
    const chave = chaveProjetoFlow(n.flowProjectUrl);
    if (!chave) return false;
    this.garantirMapaUploads(n);
    return (n.uploadedAssetsByProjectUrl[chave] || []).includes(id);
  }

  caminhoLocalExistente(n, item) {
    if (!item) return null;
    const base = this.store.pastaAbs(n);
    if (item.arquivo) {
      const abs = path.join(base, item.arquivo);
      if (fs.existsSync(abs)) return abs;
    }
    if (item.caminhoRelativo) {
      const pasta = path.dirname(item.caminhoRelativo);
      const nomeBase = path.basename(item.caminhoRelativo, path.extname(item.caminhoRelativo));
      for (const ext of ['jpg', 'png', 'webp', 'mp4']) {
        const abs = path.join(base, `${pasta}/${nomeBase}.${ext}`);
        if (fs.existsSync(abs)) {
          item.arquivo = `${pasta}/${nomeBase}.${ext}`;
          return abs;
        }
      }
    }
    return null;
  }

  temItensPendentesNaEntrada(entrada) {
    if (!entrada?.novelaId) return false;
    const n = this.store.obter(entrada.novelaId);
    if (!n || !Array.isArray(n.itens)) return false;
    const selecaoExplicita = Array.isArray(entrada.itemIds) && entrada.itemIds.length > 0;
    if (!selecaoExplicita && ehNovelaConcluidaManual(n)) return false;
    return n.itens.some((it) => {
      if (it.status === 'concluido' || it.status === 'falha_revisar' || it.status === 'bloqueado_dependencia') return false;
      if (selecaoExplicita) return entrada.itemIds.includes(it.id);
      return it.status === 'na_fila' || it.status === 'pendente' || it.status === 'erro';
    });
  }

  /**
   * Remove imediatamente uma ou várias novelas da fila ativa/pendente (ex.: quando marcadas como Concluídas manualmente).
   * Se alguma delas estiver gerando neste instante e `interromperSeRodando` for true, interrompe/pula apenas essa novela
   * para a fila continuar nas demais (ou parar se não sobrar nenhuma).
   */
  removerNovelasDaFila(novelaIds = [], { interromperSeRodando = true } = {}) {
    const alvos = new Set((Array.isArray(novelaIds) ? novelaIds : [novelaIds]).filter(Boolean));
    if (!alvos.size) return this.estado();

    this.fila = this.fila.filter((f) => !alvos.has(f.novelaId));
    this.filaIsolada = this.filaIsolada.filter((f) => !alvos.has(f.novelaId));

    for (const id of alvos) {
      const n = this.store.obter(id);
      if (!n || !Array.isArray(n.itens)) continue;
      let mudou = false;
      for (const it of n.itens) {
        if (it.status === 'na_fila' || it.status === 'gerando') {
          it.status = 'pendente';
          it.progresso = null;
          delete it.tentativaAtual;
          mudou = true;
        }
      }
      if (mudou) {
        this.store.salvar(n);
        this.emitirNovela(n);
      }
    }

    if (this.alertaCreditos?.novelaId && alvos.has(this.alertaCreditos.novelaId)) {
      this.alertaCreditos = null;
      if (this.motivoPausa === 'creditos_esgotados') this.motivoPausa = null;
    }

    if (this.rodando && this.novelaAtual && alvos.has(this.novelaAtual) && interromperSeRodando) {
      this._pularNovelaAtual = true;
      this.bridge.cancelarTodas('Novela marcada como concluída manualmente.');
    }

    if (!this.rodando && this.pausado && this.fila.length === 0) {
      this.pausado = false;
      this.motivoPausa = null;
      this.setMsg('Parado');
    } else {
      this.emitirFila();
    }
    return this.estado();
  }

  registrarFlagCapcutEntrada(novelaId, itemIds, atualizarCapcut = false) {
    const n = this.store.obter(novelaId);
    if (!n || !Array.isArray(n.itens)) return;
    const alvos = Array.isArray(itemIds) && itemIds.length > 0
      ? n.itens.filter((i) => itemIds.includes(i.id))
      : n.itens.filter((i) => i.status !== 'concluido');
    for (const it of alvos) {
      const chave = `${novelaId}:${it.id}`;
      if (atualizarCapcut) {
        this.atualizarCapcutMap.set(chave, true);
        it._atualizarCapcut = true;
      } else {
        this.atualizarCapcutMap.delete(chave);
        delete it._atualizarCapcut;
      }
    }
  }

  /**
   * Adiciona novelas (ou itens especificos) na fila.
   * - Se a fila global estiver PAUSADA e `opcoes.isoladoSePausado` for true (ex.: Regenerar cena de outra novela),
   *   executa APENAS os itens solicitados de forma isolada sem mexer na fila global pausada!
   * - Se `opcoes.preservarPausa` for true e a fila estiver pausada, apenas anexa ao final da fila mantendo a pausa.
   */
  enfileirar(entradas, opcoes = {}) {
    const { isoladoSePausado = false, preservarPausa = false } = opcoes;
    const filaEstaPausadaOuPausando = this.pausado || (this.rodando && !this.modoIsolado && this.pausaSolicitada) || this.modoIsolado;

    let adicionouIsolado = false;
    let adicionouGlobal = false;

    for (const e of entradas) {
      const selecaoExplicita = Array.isArray(e.itemIds) && e.itemIds.length > 0;
      const atualizarCapcut = Boolean(e.atualizarCapcut);
      this.registrarFlagCapcutEntrada(e.novelaId, e.itemIds, atualizarCapcut);

      const n = this.store.obter(e.novelaId);
      if (n) {
        n.itens.forEach((it) => {
          if (selecaoExplicita) {
            if (e.itemIds.includes(it.id) && it.status !== 'gerando') {
              it.status = 'na_fila';
              it.erro = null;
            }
          } else if (it.status === 'pendente' || it.status === 'erro') {
            it.status = 'na_fila';
          }
        });
        this.store.salvar(n);
        this.emitirNovela(n);
      }

      if (isoladoSePausado && selecaoExplicita && filaEstaPausadaOuPausando) {
        const exIso = this.filaIsolada.find((f) => f.novelaId === e.novelaId);
        if (exIso) {
          exIso.itemIds = [...new Set([...(exIso.itemIds || []), ...e.itemIds])];
        } else {
          this.filaIsolada.push({ novelaId: e.novelaId, itemIds: [...e.itemIds] });
        }
        adicionouIsolado = true;
        continue;
      }

      // Fila global normal
      const inicio = this.rodando && !this.modoIsolado ? 1 : 0;
      const existente = this.fila.slice(inicio).find((f) => f.novelaId === e.novelaId);
      if (existente) {
        if (existente.itemIds && e.itemIds) existente.itemIds = [...new Set([...existente.itemIds, ...e.itemIds])];
        else existente.itemIds = null;
      } else {
        // Se for a mesma novela que ja esta no slot 0 (rodando ou pausada), apenas garante que itemIds contemple tudo
        const noTopo = this.fila[0] && this.fila[0].novelaId === e.novelaId;
        if (noTopo) {
          if (this.fila[0].itemIds && e.itemIds) {
            this.fila[0].itemIds = [...new Set([...this.fila[0].itemIds, ...e.itemIds])];
          } else {
            this.fila[0].itemIds = null;
          }
        } else {
          this.fila.push({ novelaId: e.novelaId, itemIds: e.itemIds || null });
        }
      }
      adicionouGlobal = true;
    }

    if (adicionouIsolado) {
      this.emitirFila();
      if (!this.rodando) this.loopIsolado();
      return;
    }

    if (preservarPausa && this.pausado) {
      this.emitirFila();
      return;
    }

    if (adicionouGlobal) {
      this.alertaCreditos = null;
      this.motivoPausa = null;
      this.pausado = false;
      this.pausaSolicitada = false;
      this.emitirFila();
      if (!this.rodando) this.loop();
    }
  }

  pausar({ limpar = false } = {}) {
    if (limpar) {
      this.pausaSolicitada = true;
      this.pausado = false;
      this.motivoPausa = null;
      this.fila = [];
      this.filaIsolada = [];
      this.limparMarcacoesFila();
      if (!this.rodando && !this.recapturando) this.setMsg('Parado');
      return;
    }
    if (!this.rodando && !this.recapturando) {
      if (this.fila.length > 0) {
        this.pausado = true;
        this.motivoPausa = 'manual';
        this.setMsg('Pausado');
      } else {
        this.pausado = false;
        this.motivoPausa = null;
        this.setMsg('Parado');
      }
      return;
    }
    this.pausaSolicitada = true;
    this.motivoPausa = 'manual';
    this.setMsg('Pausando após concluir o item atual no Flow...');
    this.log('⏸️ Pausa solicitada: aguardando apenas a conclusão do item em andamento na extensão do Flow...', 'aviso');
  }

  retomar() {
    if (this.rodando) return this.estado();
    // Remove da fila residual qualquer novela que tenha sido marcada como concluída manualmente
    this.fila = this.fila.filter((f) => {
      const nv = this.store.obter(f.novelaId);
      return nv && !ehNovelaConcluidaManual(nv);
    });
    if (!this.fila.length) {
      // Se nao havia entrada residual em this.fila, procura novelas que ficaram com itens 'na_fila' (ignorando concluídas manualmente!)
      const comItensNaFila = this.store
        .listar()
        .filter((n) => !ehNovelaConcluidaManual(n) && n.validacao?.ok && (n.itens || []).some((i) => i.status === 'na_fila'));
      for (const n of comItensNaFila) {
        this.fila.push({ novelaId: n.id, itemIds: null });
      }
    }
    if (!this.fila.length) {
      this.pausado = false;
      this.motivoPausa = null;
      this.setMsg('Parado');
      return this.estado();
    }
    this.pausado = false;
    this.pausaSolicitada = false;
    this.motivoPausa = null;
    this.alertaCreditos = null;
    const nTopo = this.store.obter(this.fila[0]?.novelaId);
    this.log(`▶️ Retomando fila global${nTopo ? ` em "${nTopo.nome}" do item exato onde parou` : ''}...`, 'ok');
    this.loop();
    return this.estado();
  }

  limparMarcacoesFila() {
    for (const n of this.store.listar()) {
      let mudou = false;
      n.itens.forEach((it) => {
        if (it.status === 'na_fila') {
          it.status = 'pendente';
          mudou = true;
        }
      });
      if (mudou) {
        this.store.salvar(n);
        this.emitirNovela(n);
      }
    }
  }

  async aguardarExtensao() {
    if (this.bridge.conectada) return true;
    this.setMsg('Aguardando Extensão do Chrome conectar...');
    this.log('Fila aguardando a extensão do Chrome conectar.', 'aviso');
    while (!this.bridge.conectada) {
      if (this.pausaSolicitada) return false;
      await dormir(1000);
    }
    return true;
  }

  /** Executa regeneracoes isoladas disparadas enquanto a fila global esta pausada, sem misturar pastas/indices com a novela pausada. */
  async loopIsolado() {
    if (this.rodando) return;
    this.rodando = true;
    this.modoIsolado = true;
    this.pausaSolicitada = false;
    this.ativarWakeLockWindows();
    this.emitirFila();
    while (this.rebaixando) await dormir(1000);
    try {
      while (this.filaIsolada.length && !this.pausaSolicitada) {
        const entrada = this.filaIsolada.shift();
        const n = this.store.obter(entrada.novelaId);
        if (n) {
          this.log(`⚡ Regeneração isolada em "${n.nome}" (${(entrada.itemIds || []).map((i) => `{${i}}`).join(', ')}) com a fila global pausada...`, 'info');
        }
        await this.rodarNovela(entrada);
      }
    } catch (e) {
      this.log(`Erro na regeneração isolada: ${e.message}`, 'erro');
    }
    this.rodando = false;
    this.modoIsolado = false;
    this.novelaAtual = null;
    this.itemAtual = null;
    this.tentativaAtual = null;
    this.pausaSolicitada = false;
    this.pausado = this.fila.length > 0;
    this.desativarWakeLockWindows();
    const nPausada = this.pausado && this.fila[0] ? this.store.obter(this.fila[0].novelaId) : null;
    this.setMsg(
      this.pausado
        ? `Pausado${nPausada ? ` (${nPausada.nome})` : ''} — clique em Retomar para continuar`
        : 'Parado'
    );
    this.log(
      this.pausado
        ? `✅ Regeneração isolada concluída. Fila global continua pausada${nPausada ? ` em "${nPausada.nome}"` : ''} pronta para Retomar.`
        : '✅ Regeneração isolada concluída.',
      'ok'
    );
  }

  async loop() {
    this.rodando = true;
    this.modoIsolado = false;
    this.pausado = false;
    this.ativarWakeLockWindows();
    this.emitirFila();
    while (this.rebaixando) await dormir(1000);
    try {
      while (this.fila.length && !this.pausaSolicitada) {
        const entrada = this.fila[0];
        await this.rodarNovela(entrada);
        if (this.pausaSolicitada) {
          // Se a novela do topo acabou seu ultimo item justo quando a pausa foi pedida, avanca para a proxima
          if (!this.temItensPendentesNaEntrada(entrada)) {
            this.fila.shift();
          }
          break;
        }
        this.fila.shift();
        // Ritmo natural humanizado: intervalo de 8s a 14s APENAS na troca de uma novela inteira para a próxima da fila
        if (this.fila.length > 0 && !this.pausaSolicitada) {
          const pausaTrocaMs = intervaloAleatorioMs(8000, 14000);
          const proxNovela = this.store.obter(this.fila[0]?.novelaId);
          this.log(
            `⏱️ Ritmo natural entre novelas: aguardando ${(pausaTrocaMs / 1000).toFixed(1)}s antes de iniciar "${proxNovela?.nome || 'próxima novela'}"...`,
            'info'
          );
          this.setMsg(`Aguardando ${Math.round(pausaTrocaMs / 1000)}s antes de iniciar "${proxNovela?.nome || 'próxima novela'}"...`);
          for (let dec = 0; dec < pausaTrocaMs && !this.pausaSolicitada; dec += 500) {
            await dormir(Math.min(500, pausaTrocaMs - dec));
          }
        }
      }
    } catch (e) {
      this.log(`Erro inesperado na fila: ${e.message}`, 'erro');
    }
    const pausada = this.pausaSolicitada;
    const motivo = this.motivoPausa;
    this.rodando = false;
    this.novelaAtual = null;
    this.itemAtual = null;
    this.tentativaAtual = null;
    this.pausaSolicitada = false;
    this.desativarWakeLockWindows();

    if (pausada && this.fila.length > 0) {
      // PRESERVA a fila e os itens 'na_fila' intactos para poder Retomar do ponto exato!
      this.pausado = true;
    } else {
      this.pausado = false;
      this.limparMarcacoesFila();
      this.fila = [];
    }

    if (motivo === 'creditos_esgotados') {
      this.setMsg(MSG_CREDITOS_ESGOTADOS);
    } else if (this.pausado) {
      const nPausada = this.fila[0] ? this.store.obter(this.fila[0].novelaId) : null;
      this.setMsg(`Pausado${nPausada ? ` (${nPausada.nome})` : ''}`);
      this.log(`⏸️ Fila pausada${nPausada ? ` em "${nPausada.nome}"` : ''}. Clique em Retomar para continuar exatamente de onde parou.`, 'aviso');
    } else {
      this.setMsg(pausada ? 'Pausado' : 'Fila concluída');
      this.log(pausada ? 'Fila pausada.' : 'Fila concluída.', pausada ? 'aviso' : 'ok');
    }

    // Se o usuario clicou em Regenerar em uma cena enquanto aguardava o item em andamento pausar, roda agora!
    if (this.filaIsolada.length > 0 && !this.rodando) {
      this.loopIsolado();
    }
  }

  /** Prepara ou migra automaticamente o projeto do Google Flow na conta ativa do navegador. */
  async prepararProjetoFlow(n, { forcarNovo = false, motivo = '' } = {}) {
    // Migra o projeto antigo no mapa ANTES de eventual troca de URL para nova conta
    if (n.flowProjectUrl) this.garantirMapaUploads(n);

    if (!n.flowProjectUrl || forcarNovo) {
      const msg = forcarNovo
        ? `Criando novo projeto na conta ativa para continuar "${n.nome}"${motivo ? ` (${motivo})` : ''}...`
        : `Criando projeto no Google Flow para "${n.nome}"...`;
      this.setMsg(msg);
      const urlAnterior = n.flowProjectUrl;
      const r = await this.bridge.requisitar('criar_projeto', { nome: n.nome, novelaId: n.id }, TIMEOUTS.criar_projeto);
      if (!r?.url) throw new Error('A extensão não retornou a URL do projeto criado.');
      if (urlAnterior && chaveProjetoFlow(urlAnterior) !== chaveProjetoFlow(r.url)) {
        n.historicoProjetosFlow = [...new Set([...(n.historicoProjetosFlow || []), urlAnterior])];
        n.flowProjectUrl = r.url;
        n.uploadedAssetsByProjectUrl[chaveProjetoFlow(r.url)] = [];
      } else {
        n.flowProjectUrl = r.url;
        this.garantirMapaUploads(n);
      }
      n.flowProjetoSemCreditos = null;
      this.store.salvar(n);
      this.emitirNovela(n);
      this.log(
        forcarNovo
          ? `Novo projeto criado na conta atual para continuar "${n.nome}": ${r.url}`
          : `Projeto criado no Flow para "${n.nome}": ${r.url}`,
        'ok'
      );
      return;
    }

    this.setMsg(`Abrindo projeto de "${n.nome}" no Google Flow...`);
    const urlAntiga = n.flowProjectUrl;
    const r = await this.bridge.requisitar(
      'abrir_projeto',
      {
        url: n.flowProjectUrl,
        nome: n.nome,
        novelaId: n.id,
        // creditos acabaram nesta conta antes: aceita o projeto que o usuario abriu manualmente em outra conta
        adotarProjetoAbertoSeDiferente: !!n.flowProjetoSemCreditos,
      },
      TIMEOUTS.abrir_projeto
    );
    if (r?.url && chaveProjetoFlow(r.url) !== chaveProjetoFlow(urlAntiga)) {
      n.historicoProjetosFlow = [...new Set([...(n.historicoProjetosFlow || []), urlAntiga])];
      n.flowProjectUrl = r.url;
      // projeto novo = cache de uploads limpo SO para ele (o historico dos projetos antigos e preservado)
      n.uploadedAssetsByProjectUrl[chaveProjetoFlow(r.url)] = [];
      n.flowProjetoSemCreditos = null;
      this.store.salvar(n);
      this.emitirNovela(n);
      this.log(
        r.adotadoProjetoAberto
          ? `Projeto aberto manualmente em outra conta adotado para "${n.nome}": ${r.url} (só os anexos dos itens pendentes serão enviados, aguardando 100% do upload).`
          : `Conta trocada ou projeto anterior sem acesso → novo projeto criado para "${n.nome}": ${r.url} (referências já salvas no PC serão enviadas sob demanda).`,
        'ok'
      );
    } else {
      this.garantirMapaUploads(n);
      this.store.salvar(n);
    }
  }

  montarPayloadExecucao(n, item, { quantidadeResultados = 1 } = {}) {
    this.garantirMapaUploads(n);
    const semAnexos = Boolean(item.semAnexos || item.modoDescritivoSemImagem || !Array.isArray(item.refs) || item.refs.length === 0);
    if (semAnexos && item.tipo === 'video') {
      item.refs = [];
      item.semAnexos = true;
    } else if (item.tipo === 'video' && (n.forcarElementos || n.modoGeracaoVideo === 'elementos') && item.refs?.length > 0) {
      item.submodo = 'elementos_video';
    }
    const base = this.store.pastaAbs(n);
    const { urlsUsadas } = item.tipo === 'video'
      ? coletarAssinaturasVideosNovela(n, base, { excluirItemId: item.id })
      : { urlsUsadas: new Map() };
    const outrosPrompts = item.tipo === 'video'
      ? (n.itens || []).filter((i) => i.tipo === 'video' && i.id !== item.id).map((i) => i.prompt).filter(Boolean)
      : [];

    const refsEfetivas = semAnexos ? [] : (item.refs || []);
    const qtdEfetiva = (item.tipo !== 'video' && Number(quantidadeResultados) === 4) ? 4 : 1;
    return {
      novela: novelaParaExtensao(n),
      item: semAnexos ? { ...item, refs: [], semAnexos: true, quantidadeResultados: qtdEfetiva } : { ...item, quantidadeResultados: qtdEfetiva },
      quantidadeResultados: qtdEfetiva,
      chavesProibidas: [...urlsUsadas.keys()],
      outrosPrompts,
      refsInfo: Object.fromEntries(
        refsEfetivas.map((r) => {
          const ri = n.itens.find((i) => i.id === r);
          if (!ri) return [r, null];
          const abs = this.caminhoLocalExistente(n, ri);
          const existe = !!abs;
          const jaNoProj = this.ativoJaEstaNoProjeto(n, ri.id);
          return [
            r,
            {
              tipo: ri.tipo,
              status: ri.status,
              tamanhoBytes: ri.tamanhoBytes || null,
              midiaChave: jaNoProj ? ri.flowMidiaChave || null : null,
              origem: ri.resolucaoDownload || null,
              jaExisteNoProjetoAtual: jaNoProj,
              arquivoAbs: existe ? abs : null,
              arquivoUrl: existe
                ? `http://localhost:${process.env.PORT || 3456}/api/novelas/${n.id}/itens/${encodeURIComponent(ri.id)}/arquivo-bin`
                : null,
              nomeArquivo: existe ? path.basename(abs) : null,
            },
          ];
        })
      ),
    };
  }

  resumoNovelaParaIa(n, itemAtual) {
    const refs = (n.itens || [])
      .filter((i) => i.tipo === 'referencia_imagem')
      .slice(0, 12)
      .map((i) => `${i.id}: ${String(i.prompt || '').slice(0, 110)}`)
      .join(' | ');
    const idx = n.itens.findIndex((i) => i.id === itemAtual.id);
    const neighborItems = [n.itens[idx - 1], n.itens[idx + 1]].filter(Boolean);
    return {
      novelSummary: `Novela "${n.nome}". ${refs ? `Personagens/cenários: ${refs}` : ''}`.trim(),
      neighborItems,
    };
  }

  pausarPorCreditosEsgotados(n, item, detalhe) {
    if (n?.flowProjectUrl) n.flowProjetoSemCreditos = chaveProjetoFlow(n.flowProjectUrl);
    if (item) {
      item.status = 'pendente';
      item.erro = null;
      item.progresso = null;
      delete item.tentativaAtual;
    }
    this.motivoPausa = 'creditos_esgotados';
    this.pausaSolicitada = true;
    this.alertaCreditos = {
      ativo: true,
      novelaId: n.id,
      novelaNome: n.nome,
      itemId: item?.id || null,
      detalhe: limparPrefixosInternos(detalhe),
      em: new Date().toISOString(),
      mensagem: MSG_CREDITOS_ESGOTADOS,
    };
    this.log(`⚠️ ${MSG_CREDITOS_ESGOTADOS}${detalhe ? ` (${limparPrefixosInternos(detalhe)})` : ''}`, 'aviso');
    this.setMsg(MSG_CREDITOS_ESGOTADOS);
    if (item) {
      this.store.salvar(n);
      this.emitirNovela(n);
    }
  }

  /** Marca apenas os itens futuros que dependem desta ref/imagem-base como `bloqueado_dependencia`. */
  marcarDependentesBloqueados(n, itemFalho) {
    if (itemFalho.tipo === 'video') return [];
    if (this.caminhoLocalExistente(n, itemFalho)) return []; // se ja havia um arquivo valido no PC, dependentes ainda podem usar!

    const bloqueados = [];
    const filaIds = [itemFalho.id];
    const visitados = new Set([itemFalho.id]);
    while (filaIds.length) {
      const origemId = filaIds.shift();
      for (const cand of n.itens) {
        if (cand.ordem <= itemFalho.ordem || cand.status === 'concluido') continue;
        if (!cand.refs?.includes(origemId)) continue;
        cand.status = 'bloqueado_dependencia';
        cand.progresso = null;
        cand.erro = origemId === itemFalho.id
          ? `Bloqueado porque depende diretamente de {${itemFalho.id}} (marcado como falha_revisar).`
          : `Bloqueado porque depende de {${origemId}} → {${itemFalho.id}} (marcado como falha_revisar).`;
        bloqueados.push(cand.id);
        if (cand.tipo !== 'video' && !this.caminhoLocalExistente(n, cand) && !visitados.has(cand.id)) {
          visitados.add(cand.id);
          filaIds.push(cand.id);
        }
      }
    }
    return bloqueados;
  }

  consumirFlagCapcut(novelaId, item) {
    if (!item) return false;
    const chave = `${novelaId}:${item.id}`;
    const flagMap = Boolean(this.atualizarCapcutMap.get(chave));
    const flagItem = Boolean(item._atualizarCapcut);
    this.atualizarCapcutMap.delete(chave);
    delete item._atualizarCapcut;
    return flagMap || flagItem;
  }

  async rodarNovela(entrada) {
    const { novelaId } = entrada || {};
    const n = this.store.obter(novelaId);
    if (!n) return;
    const selecaoExplicita = Array.isArray(entrada?.itemIds) && entrada.itemIds.length > 0;
    if (!selecaoExplicita && ehNovelaConcluidaManual(n)) {
      this.log(`✅ "${n.nome}" está marcada como Concluída manualmente — ignorando na fila automática.`, 'info');
      return;
    }
    this._pularNovelaAtual = false;
    this.novelaAtual = novelaId;
    this.emitirFila();

    if (!n.validacao?.ok) {
      this.log(`"${n.nome}" tem erros de validação no roteiro e foi pulada.`, 'erro');
      n.itens.forEach((it) => {
        if (it.status === 'na_fila') it.status = 'pendente';
      });
      this.store.salvar(n);
      this.emitirNovela(n);
      return;
    }

    const obterProximoAlvo = (tentados) => {
      const selecaoExplicita = Array.isArray(entrada?.itemIds) && entrada.itemIds.length > 0;
      return n.itens.find((it) => {
        if (tentados.has(it.id)) return false;
        if (it.status === 'concluido' || it.status === 'falha_revisar' || it.status === 'bloqueado_dependencia') return false;
        if (selecaoExplicita) return entrada.itemIds.includes(it.id);
        return it.status === 'na_fila' || it.status === 'pendente' || it.status === 'erro';
      });
    };

    const primeiroAlvo = obterProximoAlvo(new Set());
    if (!primeiroAlvo) {
      this.log(`"${n.nome}": nada pendente para gerar.`, 'info');
      return;
    }

    if (!(await this.aguardarExtensao())) return;

    let projetoPronto = false;
    let ultimoErroProjeto = null;
    for (let tentProj = 1; tentProj <= 3 && !projetoPronto && !this.pausaSolicitada; tentProj++) {
      try {
        await this.prepararProjetoFlow(n);
        projetoPronto = true;
      } catch (e) {
        ultimoErroProjeto = e;
        if (RE_CREDITOS_MSG.test(e.message || '')) {
          this.pausarPorCreditosEsgotados(n, primeiroAlvo, e.message);
          return;
        }
        if (tentProj < 3 && !this.pausaSolicitada) {
          this.log(`"${n.nome}": falha ao abrir/criar projeto no Flow (tentativa ${tentProj}/3: ${e.message}) — tentando novamente em 3s...`, 'aviso');
          await dormir(3000);
        }
      }
    }
    if (!projetoPronto) {
      if (this.pausaSolicitada) return;
      const msgProj = ultimoErroProjeto?.message || 'Falha ao abrir/criar projeto no Google Flow';
      this.log(`⏭️ "${n.nome}": falha após 3 tentativas ao preparar projeto no Flow (${msgProj}) — marcando como pendente de revisão e seguindo para a próxima novela da fila!`, 'erro');
      n.itens.forEach((it) => {
        if (it.status === 'na_fila') {
          it.status = 'erro';
          it.erro = `Falha ao preparar projeto no Flow: ${msgProj}`;
        }
      });
      this.store.salvar(n);
      this.emitirNovela(n);
      return;
    }

    const tentadosNestaRodada = new Set();
    while (!this.pausaSolicitada && !this._pularNovelaAtual) {
      if (!selecaoExplicita && ehNovelaConcluidaManual(n)) break;
      const item = obterProximoAlvo(tentadosNestaRodada);
      if (!item) break;
      tentadosNestaRodada.add(item.id);

      // Se um ancestral falhou nesta mesma execucao e marcou este item como bloqueado_dependencia, pula na hora!
      if (item.status === 'bloqueado_dependencia') {
        this.log(`⏭️ Pulando {${item.id}} (${item.erro || 'dependência falhou'}).`, 'aviso');
        continue;
      }

      // Verifica se todas as referencias exigidas existem (concluidas ou arquivo salvo no PC)
      const refsSemArquivo = (item.refs || []).filter((rId) => {
        const ri = n.itens.find((x) => x.id === rId);
        return !ri || (ri.status !== 'concluido' && !this.caminhoLocalExistente(n, ri));
      });
      if (refsSemArquivo.length) {
        if (item.tipo === 'video') {
          // Estágio 5 (Continuidade Garantida): se uma imagem-base falhou após todas as rodadas,
          // converte a cena de vídeo automaticamente para o Prompt 100% Descritivo de consistência visual para NUNCA deixar a novela sem vídeo!
          aplicarModoDescritivoSemImagem(n, item);
          this.log(
            `⚡ Continuidade Garantida em {${item.id}}: anexo(s) ${refsSemArquivo.map((r) => `{${r}}`).join(', ')} indisponível(is) — gerando vídeo via Prompt 100% Descritivo de consistência visual!`,
            'aviso'
          );
          this.store.salvar(n);
          this.emitirNovela(n);
        } else {
          // Para imagem_base que dependia de um ref_* que falhou, remove apenas o ref_* ausente e mantém os demais + descrição no prompt
          salvarBackupsOriginaisItem(item, n);
          item.refs = (item.refs || []).filter((rId) => !refsSemArquivo.includes(rId));
          this.log(
            `⚡ Continuidade Garantida em {${item.id}}: referência(s) ${refsSemArquivo.map((r) => `{${r}}`).join(', ')} indisponível(is) — gerando imagem-base pelo prompt descritivo com as referências disponíveis!`,
            'aviso'
          );
          this.store.salvar(n);
          this.emitirNovela(n);
        }
      }

      if (!(await this.aguardarExtensao())) break;

      this.itemAtual = item.id;
      item.status = 'gerando';
      item.erro = null;
      item.progresso = null;
      item.iniciadoEm = new Date().toISOString();
      this.store.salvar(n);
      this.emitirNovela(n);

      await this.processarItemResiliente(n, item);

      // Se foi interrompido por pausa antes de concluir/falhar, devolve para 'na_fila' para retomar deste item exato
      if (item.status === 'gerando') {
        item.status = 'na_fila';
      }

      item.progresso = null;
      delete item.tentativaAtual;
      this.tentativaAtual = null;
      this.store.salvar(n);
      this.emitirNovela(n);

      // Ritmo rápido humanizado entre cenas da mesma novela: intervalo curto aleatório de 2s a 5s
      if (!this.pausaSolicitada && obterProximoAlvo(tentadosNestaRodada)) {
        const pausaCenaMs = intervaloAleatorioMs(2000, 5000);
        this.setMsg(`"${n.nome}" → próximo item em ${(pausaCenaMs / 1000).toFixed(1)}s...`);
        for (let dec = 0; dec < pausaCenaMs && !this.pausaSolicitada; dec += 400) {
          await dormir(Math.min(400, pausaCenaMs - dec));
        }
      }
    }

    this.itemAtual = null;
    this.tentativaAtual = null;
  }

  /**
   * Executa um item com resiliência total — ESCADA AUTOMÁTICA DE DESTRAVAMENTO (5 Estágios, ZERO Pausa por Erro de Imagem/Política):
   * - Estágio 1 (Níveis 0, 1, 2 -> Até 3 tentativas diretas em 1x):
   *     Se falhar por erro técnico/rede/geração, tenta novamente até 3 vezes com respiro curto (3s–5s).
   *     Se bater em rejeição explícita de política/conteúdo, aciona o Claude direto sem desperdiçar tentativas iguais.
   * - Estágio 2 + Estágio 3 (Nível 3 -> Reescrita cirúrgica via Claude Rodada 1 + Modo Burst 4x na imagem travada):
   *     Chama o Claude (`claudeBridge.js`) enviando o prompt que falhou + motivo do erro + contexto da personagem/cena,
   *     suavizando apenas os termos sensíveis e preservando 100% da aparência física, roupa, cenário, continuidade e fala em português.
   *     Em imagens (`referencia_imagem` / `imagem_base`), altera temporariamente o seletor do Google Flow para gerar 4 imagens de uma vez (`4x`)
   *     SOMENTE nesse item problemático — se pelo menos 1 das 4 imagens passar, salva imediatamente e volta o seletor para `1x`!
   * - Estágio 4 (Níveis 4, 5, 6 -> Sucessivas reformulações progressivas com Claude Rodadas 2, 3 e 4 + Modo Burst 4x):
   *     Se as 4 imagens ainda falharem, repete o ciclo chamando o Claude novamente (até mais 3 rodadas progressivamente mais seguras/neutras
   *     no vocabulário visual + lote de 4 imagens `4x`) até aprovar pelo menos 1 imagem.
   * - Estágio 5 (Continuidade Garantida — Nunca Travar a Fila):
   *     Assim que gerar em qualquer estágio, retoma e continua normalmente todo o restante do projeto. No caso extremo de esgotar
   *     absolutamente todas as rodadas em um item específico, registra alerta visual naquele card e segue gerando o restante do projeto até o fim.
   */
  async processarItemResiliente(n, item) {
    const historicoErros = [];
    const promptsTentados = [];
    let migracoesProjeto = 0;
    const ehVideo = item.tipo === 'video';
    const jaIniciouSemImagem = Boolean(ehVideo && (item.modoDescritivoSemImagem || item.semAnexos));
    // Níveis:
    //  0, 1, 2 = Estágio 1 (até 3 tentativas diretas 1x)
    //  3       = Estágio 2 & 3 (Claude Rodada 1 + Modo Burst 4x em imagens / Suavização com imagem_XX em vídeos)
    //  4, 5, 6 = Estágio 4 (Claude Rodadas 2, 3 e 4 progressivamente mais seguras + Modo Burst 4x em imagens / Descritivo em vídeos)
    const maxNivel = jaIniciouSemImagem ? 2 : 6;

    for (let nivel = 0; nivel <= maxNivel; nivel++) {
      if (this.pausaSolicitada || this._pularNovelaAtual || ehNovelaConcluidaManual(n)) return;
      if (!(await this.aguardarExtensao())) return;

      let quantidadeResultados = 1;

      if (nivel === 0) {
        this.tentativaAtual = null;
        delete item.tentativaAtual;
        if (jaIniciouSemImagem) {
          this.log(`📝 Gerando {${item.id}} com Prompt 100% Descritivo de consistência visual (Tentativa 1/3)...`, 'aviso');
          item.progresso = 'Tentativa 1/3: Prompt 100% Descritivo (sem imagem)...';
        }
        this.setMsg(`"${n.nome}" → gerando {${item.id}} (${jaIniciouSemImagem ? '100% descritivo sem imagem' : item.tipo})`);
      } else {
        const ultimoMotivo = historicoErros[historicoErros.length - 1] || 'falha na geração';
        await this.bridge.requisitar('limpar_composer', { limparTexto: true }, 20000).catch(() => {});

        if (jaIniciouSemImagem) {
          const numTentDesc = nivel + 1;
          this.tentativaAtual = numTentDesc;
          item.tentativaAtual = numTentDesc;
          const pausaMs = intervaloAleatorioMs(3000, 5000);
          await dormir(pausaMs);
          if (nivel >= 1) {
            const { novelSummary, neighborItems } = this.resumoNovelaParaIa(n, item);
            const reparo = await repairBlockedPrompt({
              item,
              errorReason: ultimoMotivo,
              novelSummary,
              neighborItems,
              attempt: nivel + 1,
              previousAttempts: promptsTentados,
              log: this.log,
              contextoHistoria: this.contextoHistoria?.(n, item) || '',
              permitirClaude: true,
            });
            item.prompt = reparo.prompt;
            item.promptAutoAjustado = reparo.origem;
          }
          const txtRetryDesc = `Auto-recuperação (${numTentDesc}/3 sem imagem) em {${item.id}}: reenviando Prompt 100% Descritivo reformulado...`;
          item.progresso = `Tentativa ${numTentDesc}/3: Prompt 100% Descritivo (sem imagem)...`;
          this.log(`📝 ${txtRetryDesc}`, 'aviso');
          this.setMsg(txtRetryDesc);
        } else if (nivel <= 2) {
          // ==================== ESTÁGIO 1: ATÉ 3 TENTATIVAS DIRETAS (1x) COM RESPIRO 3s-5s ====================
          const numDireta = nivel + 1; // 2 ou 3
          this.tentativaAtual = numDireta;
          item.tentativaAtual = numDireta;
          const respiroMs = intervaloAleatorioMs(3000, 5000);
          const txtEst1 = `Estágio 1 (Tentativa direta ${numDireta}/3) em {${item.id}}: aguardando ${(respiroMs / 1000).toFixed(1)}s, limpando composer e tentando novamente...`;
          item.progresso = `Estágio 1 · Tentativa direta ${numDireta}/3 (respiro ${(respiroMs / 1000).toFixed(1)}s)...`;
          this.log(`🔄 ${txtEst1}`, 'aviso');
          this.setMsg(txtEst1);
          this.store.salvar(n);
          this.emitirNovela(n);
          await dormir(respiroMs);
        } else {
          // ==================== ESTÁGIOS 2, 3 E 4: CLAUDE PROGRESSIVO (RODADAS 1 A 4) + MODO BURST 4x ====================
          const rodadaClaude = nivel - 2; // nivel 3 -> Rodada 1 | nivel 4 -> Rodada 2 | nivel 5 -> Rodada 3 | nivel 6 -> Rodada 4
          this.tentativaAtual = rodadaClaude;
          item.tentativaAtual = rodadaClaude;
          salvarBackupsOriginaisItem(item, n);

          if (!ehVideo) {
            // Para IMAGEM (referencia_imagem ou imagem_base): ativa Modo Burst 4x SOMENTE neste item travado!
            quantidadeResultados = 4;
            item.progresso = `Estágio ${rodadaClaude === 1 ? '2/3' : '4'} · Rodada ${rodadaClaude}/4: Claude reescrevendo termos sensíveis + Modo Burst 4x...`;
            this.store.salvar(n);
            this.emitirNovela(n);

            const { novelSummary, neighborItems } = this.resumoNovelaParaIa(n, item);
            const reparo = await repairBlockedPrompt({
              item,
              errorReason: ultimoMotivo,
              novelSummary,
              neighborItems,
              attempt: rodadaClaude,
              previousAttempts: promptsTentados,
              log: this.log,
              contextoHistoria: this.contextoHistoria?.(n, item) || '',
              permitirClaude: true,
            });
            item.prompt = reparo.prompt;
            item.promptAutoAjustado = reparo.origem;

            const fonteTxt = reparo.origem === 'claude-cli' ? `Claude CLI (Rodada ${rodadaClaude}/4)` : `Suavização progressiva (Rodada ${rodadaClaude}/4)`;
            const txtBurst = `Auto-destravamento (${fonteTxt} + ⚡ Modo Burst 4x) em {${item.id}}: gerando 4 imagens simultâneas (basta 1 aprovar!)...`;
            item.progresso = `⚡ Rodada ${rodadaClaude}/4 (${fonteTxt} + Burst 4x — basta 1/4 aprovar)...`;
            this.log(`🛡️ ${txtBurst}`, 'aviso');
            this.setMsg(txtBurst);
          } else {
            // Para VÍDEO:
            // Rodadas 1 e 2 (niveis 3 e 4): mantém só imagem_XX + reescrita cirúrgica via Claude (Rodadas 1 e 2)
            // Rodadas 3 e 4 (niveis 5 e 6): Prompt 100% Descritivo sem imagem + reescrita progressiva via Claude (Rodadas 3 e 4)
            const { novelSummary, neighborItems } = this.resumoNovelaParaIa(n, item);
            if (rodadaClaude <= 2) {
              const apenasImagem = (item.anexosOriginaisBackup || item.refs || []).filter((r) => /^imagem_/i.test(r));
              if (apenasImagem.length) item.refs = apenasImagem;
              item.progresso = `Estágio 2 · Rodada ${rodadaClaude}/4: Claude suavizando prompt + mantendo só imagem_XX...`;
              this.store.salvar(n);
              this.emitirNovela(n);

              const reparo = await repairBlockedPrompt({
                item,
                errorReason: ultimoMotivo,
                novelSummary,
                neighborItems,
                attempt: rodadaClaude,
                previousAttempts: promptsTentados,
                log: this.log,
                contextoHistoria: this.contextoHistoria?.(n, item) || '',
                permitirClaude: true,
              });
              aplicarSuavizacaoComImagem(n, item, reparo.prompt);
              item.prompt = reparo.prompt;
              item.promptAutoAjustado = reparo.origem;
              const fonteTxt = reparo.origem === 'claude-cli' ? `Claude CLI Rodada ${rodadaClaude}/4 + só imagem_XX` : `Suavização Rodada ${rodadaClaude}/4 + só imagem_XX`;
              const txtVid = `Auto-destravamento em {${item.id}}: tentando vídeo com prompt suavizado (${fonteTxt})...`;
              item.progresso = `Rodada ${rodadaClaude}/4: gerando (${fonteTxt})...`;
              this.log(`🛡️ ${txtVid}`, 'aviso');
              this.setMsg(txtVid);
            } else {
              aplicarModoDescritivoSemImagem(n, item);
              const reparo = await repairBlockedPrompt({
                item,
                errorReason: ultimoMotivo,
                novelSummary,
                neighborItems,
                attempt: rodadaClaude,
                previousAttempts: promptsTentados,
                log: this.log,
                contextoHistoria: this.contextoHistoria?.(n, item) || '',
                permitirClaude: true,
              });
              item.prompt = reparo.prompt;
              item.promptAutoAjustado = `${reparo.origem}-descritivo`;
              const txtCartada = `Auto-destravamento (Rodada ${rodadaClaude}/4 · Prompt 100% Descritivo sem imagem) em {${item.id}}...`;
              item.progresso = `Rodada ${rodadaClaude}/4: Prompt 100% Descritivo (0 anexos)...`;
              this.log(`📝 ${txtCartada}`, 'aviso');
              this.setMsg(txtCartada);
            }
          }
        }
        this.store.salvar(n);
        this.emitirNovela(n);
      }

      try {
        if (item.prompt && !promptsTentados.includes(item.prompt)) {
          promptsTentados.push(item.prompt);
        }
        const payloadExec = this.montarPayloadExecucao(n, item, { quantidadeResultados });
        let res = await this.bridge.requisitar(
          'executar_item',
          payloadExec,
          TIMEOUTS[item.tipo] || TIMEOUTS.video
        );
        if (Array.isArray(res.ativosSubidos) && res.ativosSubidos.length) {
          this.registrarAtivosNoProjeto(n, res.projetoUrl || n.flowProjectUrl, res.ativosSubidos);
        }
        try {
          await this.salvarResultado(n, item, res);
        } catch (errSalvar) {
          // Se a trava anti-duplicacao bloqueou um card antigo/repetido, varre o DOM pelo prompt unico SEM gastar creditos regerando!
          if (!/^\[DUPLICATA_VIDEO\]/.test(errSalvar?.message || '')) throw errSalvar;
          this.log(`🛡️ ${limparPrefixosInternos(errSalvar.message)} → re-varrendo o DOM do Flow pelo prompt único de {${item.id}} (sem gastar créditos)...`, 'aviso');
          let recuperouNoDom = false;
          for (let varr = 1; varr <= 2 && !recuperouNoDom; varr++) {
            await dormir(3000 * varr);
            const { urlsUsadas } = coletarAssinaturasVideosNovela(n, this.store.pastaAbs(n), { excluirItemId: item.id });
            try {
              const resRecap = await this.bridge.requisitar(
                'baixar_card_escaneado',
                {
                  novela: novelaParaExtensao(n),
                  item,
                  chavesProibidas: [...urlsUsadas.keys()],
                  outrosPrompts: payloadExec.outrosPrompts,
                  renomear: true,
                },
                15 * 60 * 1000
              );
              await this.salvarResultado(n, item, resRecap);
              res = resRecap;
              recuperouNoDom = true;
              this.log(`✅ Card correto de {${item.id}} recuperado na varredura do DOM (tentativa ${varr}/2)!`, 'ok');
            } catch (eRec) {
              this.log(`Varredura anti-duplicação (${varr}/2) para {${item.id}}: ${limparPrefixosInternos(eRec.message)}`, 'aviso');
              if (varr === 2) throw errSalvar;
            }
          }
        }
        if (res.midiaChave) item.flowMidiaChave = normalizarUrlMidia(res.midiaChave) || res.midiaChave;
        item.nomeAtivoFlow = res.nomeAtivo || null;
        if (res.nomeAtivo) {
          this.registrarAtivosNoProjeto(n, res.projetoUrl || n.flowProjectUrl, [item.id]);
        }
        if (item.modoDescritivoSemImagem || item.semAnexos) {
          item.geradoPorDescricaoSemImagem = true;
        }
        item.status = 'concluido';
        item.erro = null;
        item.geradoEm = new Date().toISOString();
        this.bloqueiosAtividadeIncomumSeguidos = 0;
        const detalheRecuperacao = item.geradoPorDescricaoSemImagem
          ? ' (📝 gerado por descrição sem imagem!)'
          : nivel >= 3
            ? ` (✅ destravado na Rodada ${nivel - 2}/4 com Claude${quantidadeResultados === 4 ? ' + Modo Burst 4x' : ''}!)`
            : nivel > 0
              ? ` (✅ recuperado na tentativa direta ${nivel + 1}/3!)`
              : '';
        this.log(`{${item.id}} salvo em ${n.pasta}/${item.arquivo}${detalheRecuperacao}`, 'ok');
        if (this.consumirFlagCapcut(n.id, item)) {
          this.atualizarCapcutSePreciso(n, item, { forcar: true });
        }
        return;
      } catch (e) {
        const msgCrua = e?.message || String(e);
        if (this.pausaSolicitada || this._pularNovelaAtual || ehNovelaConcluidaManual(n)) return;

        // 1) Creditos esgotados -> pausa imediata e limpa na cena exata
        if (RE_CREDITOS_MSG.test(msgCrua)) {
          await this.bridge.requisitar('limpar_composer', { limparTexto: true }, 15000).catch(() => {});
          this.pausarPorCreditosEsgotados(n, item, msgCrua);
          return;
        }

        // 1.b) Bloqueio real de conta/CAPTCHA ("atividade incomum" fora de falha comum de card):
        // Aplica resfriamento de 3 minutos na 1ª vez, mas AVANÇA para o estágio do Claude + Burst 4x na retomada;
        // só pausa a fila se repetir 2 vezes seguidas mesmo após o resfriamento.
        if (RE_ATIVIDADE_INCOMUM_MSG.test(msgCrua)) {
          this.bloqueiosAtividadeIncomumSeguidos = (this.bloqueiosAtividadeIncomumSeguidos || 0) + 1;
          await this.bridge.requisitar('limpar_composer', { limparTexto: true }, 15000).catch(() => {});
          const detLimpo = limparPrefixosInternos(msgCrua);

          if (this.bloqueiosAtividadeIncomumSeguidos >= 2) {
            item.status = 'na_fila';
            item.erro = `Pausado por segurança (2 alertas seguidos de atividade incomum no Google Flow): ${detLimpo}`;
            item.progresso = null;
            delete item.tentativaAtual;
            this.motivoPausa = 'atividade_incomum';
            this.pausaSolicitada = true;
            const msgPausa2x = `🛑 Segurança Anti-Bloqueio: o Google Flow reportou "atividade incomum" 2 vezes seguidas em {${item.id}}. A fila foi pausada automaticamente para proteger sua conta.`;
            this.log(msgPausa2x, 'erro');
            this.setMsg(msgPausa2x);
            this.store.salvar(n);
            this.emitirNovela(n);
            return;
          }

          const totalSeg = Math.round(RESFRIAMENTO_ATIVIDADE_INCOMUM_MS / 1000);
          this.log(
            `🛡️ Alerta de "atividade incomum" detectado no Google Flow em {${item.id}} (${detLimpo}). Aplicando pausa de resfriamento de 3 minutos (${totalSeg}s) e acionando reescrita do Claude na retomada...`,
            'aviso'
          );
          for (let segRest = totalSeg; segRest > 0 && !this.pausaSolicitada; segRest--) {
            const minFmt = Math.floor(segRest / 60);
            const segFmt = String(segRest % 60).padStart(2, '0');
            const msgCool = `🛡️ Resfriamento anti-bloqueio (1/2): aguardando ${minFmt}m${segFmt}s antes de retomar {${item.id}}...`;
            item.progresso = msgCool;
            this.setMsg(msgCool);
            if (segRest === totalSeg || segRest % 15 === 0) {
              this.emitirNovela(n);
            }
            await dormir(1000);
          }
          if (this.pausaSolicitada) return;
          if (nivel < 2) nivel = 2; // Após o resfriamento, já retoma no Estágio 2/3 (Claude + Burst 4x)
          continue;
        }

        // 2) Projeto ficou inacessivel (usuario trocou de conta Google durante a execucao) -> cria projeto novo sem gastar tentativa!
        if (RE_PROJ_INACESSIVEL_MSG.test(msgCrua) && migracoesProjeto < 2) {
          migracoesProjeto++;
          this.log(`Conta alterada ou projeto inacessível durante {${item.id}} — migrando para um novo projeto na conta ativa...`, 'aviso');
          try {
            await this.prepararProjetoFlow(n, { forcarNovo: true, motivo: limparPrefixosInternos(msgCrua) });
            nivel--; // repete o mesmo nivel no projeto novo sem queimar tentativa
            continue;
          } catch (errProj) {
            if (RE_CREDITOS_MSG.test(errProj.message || '')) {
              this.pausarPorCreditosEsgotados(n, item, errProj.message);
              return;
            }
          }
        }

        const motivoLimpo = limparPrefixosInternos(msgCrua);
        historicoErros.push(motivoLimpo);

        // Estágio 1 -> Estágio 2 (Atalho inteligente de política):
        // Se falhou por erro explícito de política/conteúdo no Estágio 1 (nivel 0 ou 1), pula tentativas diretas idênticas e já aciona o Claude + Burst 4x (nivel = 2 -> próximo loop é nivel 3)!
        if (!jaIniciouSemImagem && nivel < 2 && RE_POLITICA_EXPLICITA_MSG.test(msgCrua)) {
          this.log(
            `⚡ {${item.id}} bloqueado por política/filtro do Flow (${motivoLimpo}) — pulando tentativas diretas iguais e acionando Claude + ${!ehVideo ? 'Modo Burst 4x' : 'suavização'} imediatamente!`,
            'aviso'
          );
          nivel = 2;
          continue;
        }

        const rotuloFalha = jaIniciouSemImagem
          ? `na tentativa ${nivel + 1}/3 sem imagem`
          : nivel <= 2
            ? `no Estágio 1 (tentativa direta ${nivel + 1}/3)`
            : `na Rodada ${nivel - 2}/4 (Claude${!ehVideo ? ' + Burst 4x' : ''})`;
        this.log(
          `{${item.id}} falhou ${rotuloFalha}: ${motivoLimpo}`,
          nivel < maxNivel ? 'aviso' : 'erro'
        );
      }
    }

    // ESTÁGIO 5: Continuidade Garantida — NUNCA travar nem pausar a novela!
    await this.bridge.requisitar('limpar_composer', { limparTexto: true }, 15000).catch(() => {});
    const motivoFinal = historicoErros[historicoErros.length - 1] || 'Falha desconhecida no Google Flow';
    item.status = 'falha_revisar';
    item.erro = `Alerta: esgotou todas as rodadas de auto-destravamento (3 diretas + 4 rodadas Claude/4x): ${motivoFinal}`;
    this.log(
      `⏭️ Estágio 5 (Continuidade Garantida): {${item.id}} marcado com alerta visual (falha_revisar) após esgotar todas as rodadas (${motivoFinal}). Seguindo a geração do restante do projeto até o fim sem pausar a fila!`,
      'erro'
    );
    this.setMsg(`Alerta em {${item.id}} — continuando "${n.nome}" automaticamente até o fim...`);
  }

  /**
   * Substitui cirurgicamente SO esta cena no rascunho existente do CapCut PC (quando acionado pelo Botão 2: 🔄✂️ Regenerar + CapCut),
   * sem recriar o projeto e preservando a ordem e os cortes das demais cenas.
   */
  atualizarCapcutSePreciso(n, item, { forcar = false } = {}) {
    if (!forcar) return;
    if (item.tipo !== 'video' || !item.arquivo) return;
    try {
      const pastaDraft = localizarDraftNovela({ novela: n });
      if (!pastaDraft || !fs.existsSync(pastaDraft)) {
        this.log(`CapCut: nenhum rascunho encontrado para "${n.nome}" no CapCut PC — clique em "✂️ CapCut" no topo do projeto primeiro.`, 'aviso');
        return;
      }
      if (!n.capcutDraftPath || n.capcutDraftPath !== pastaDraft) {
        n.capcutDraftPath = pastaDraft;
        n.capcutExported = true;
      }
      const r = atualizarCenaCapcut({
        pastaDraft,
        arquivoAbs: path.join(this.store.pastaAbs(n), item.arquivo),
        itemId: item.id,
      });
      if (!r.ok) { this.log(`CapCut: {${item.id}} não foi atualizado (${r.motivo}).`, 'aviso'); return; }
      const extra = [];
      if (r.deltaUs) extra.push(`duração ${r.deltaUs > 0 ? '+' : ''}${(r.deltaUs / 1e6).toFixed(2)}s, cenas seguintes deslocadas`);
      if (r.cortados) extra.push('corte manual preservado');
      n.capcutAtualizadoEm = new Date().toISOString();
      this.log(`✂️ {${item.id}} substituída automaticamente na timeline do CapCut PC ("${path.basename(pastaDraft)}")${extra.length ? ' — ' + extra.join('; ') : ''}.`, 'ok');
      if (r.aberto) this.log(`CapCut: o rascunho parece estar ABERTO agora. Volte à tela inicial do CapCut e abra-o de novo para ver a cena nova.`, 'aviso');
    } catch (e) {
      this.log(`CapCut: falha ao atualizar {${item.id}}: ${e.message}`, 'erro');
    }
  }

  /** Baixa de novo um item ja gerado no Flow (sem gerar outra vez), com a qualidade atual da novela. */
  async rebaixarItem(novelaId, itemId) {
    if (this.rodando || this.rebaixando) throw new Error('Aguarde a fila/download atual terminar.');
    const n = this.store.obter(novelaId);
    const item = n?.itens.find((i) => i.id === itemId);
    if (!item) throw new Error('Item não encontrado.');
    if (!n.flowProjectUrl) throw new Error('Esta novela ainda não tem projeto no Flow.');
    if (!this.bridge.conectada) throw new Error('Extensão do Chrome não está conectada.');
    this.rebaixando = true;
    item.status = 'gerando'; item.erro = null; item.progresso = 'Baixando de novo do Flow...';
    this.store.salvar(n); this.emitirNovela(n);
    this.log(`Baixando de novo {${item.id}} de "${n.nome}"...`);
    try {
      const outrosPrompts = item.tipo === 'video'
        ? (n.itens || []).filter((i) => i.tipo === 'video' && i.id !== item.id).map((i) => i.prompt).filter(Boolean)
        : [];
      const res = await this.bridge.requisitar(
        'baixar_item',
        { novela: novelaParaExtensao(n), item, outrosPrompts },
        item.tipo === 'video' ? 25 * 60000 : 8 * 60000
      );
      await this.salvarResultado(n, item, res);
      if (res.midiaChave) item.flowMidiaChave = normalizarUrlMidia(res.midiaChave) || res.midiaChave;
      item.status = 'concluido';
      item.geradoEm = new Date().toISOString();
      this.log(`{${item.id}} baixado de novo e validado (${item.formatoReal}, ${Math.round(item.tamanhoBytes / 1024)} KB, ${item.resolucaoDownload || 'original'}).`, 'ok');
      this.atualizarCapcutSePreciso(n, item);
    } catch (e) {
      item.status = 'erro'; item.erro = limparPrefixosInternos(e.message);
      this.log(`Baixar de novo {${item.id}} falhou: ${limparPrefixosInternos(e.message)}`, 'erro');
    } finally {
      this.rebaixando = false;
      item.progresso = null;
      this.store.salvar(n); this.emitirNovela(n);
    }
  }

  /**
   * Botao "🔄 Re-capturar Vídeos Prontos do Flow" (ZERO gasto de creditos):
   * 1) Rola a pagina aberta do projeto no Google Flow do inicio ao fim para montar todos os cards virtualizados;
   * 2) Casa cada card de video com sua respectiva `{Cena NN}` pelo dialogo/acao unica do prompt;
   * 3) Baixa e substitui os `.mp4` garantindo URLs distintas e hashes SHA-256 distintos em todas as cenas!
   */
  async recapturarVideosNovela(novelaId) {
    if (this.rodando || this.rebaixando) throw new Error('Aguarde a fila ou captura atual terminar.');
    const n = this.store.obter(novelaId);
    if (!n) throw new Error('Novela não encontrada.');
    if (!n.flowProjectUrl) throw new Error('Esta novela ainda não possui URL de projeto no Google Flow.');
    if (!this.bridge.conectada) throw new Error('Extensão do Chrome não está conectada.');
    const cenas = (n.itens || []).filter((i) => i.tipo === 'video');
    if (!cenas.length) throw new Error('Esta novela não possui cenas de vídeo no roteiro.');

    this.rebaixando = true;
    this.recapturando = novelaId;
    this.pausaSolicitada = false;
    this.setMsg(`🔄 Re-capturando vídeos prontos de "${n.nome}" no Google Flow (sem gastar créditos)...`);
    this.log(`🔄 Iniciando re-captura sem créditos dos ${cenas.length} vídeo(s) de "${n.nome}" em ${n.flowProjectUrl}...`, 'info');

    try {
      await this.bridge.requisitar(
        'abrir_projeto',
        { url: n.flowProjectUrl, nome: n.nome, novelaId: n.id, naoRecriarProjeto: true },
        TIMEOUTS.abrir_projeto
      );

      this.setMsg(`🔍 Varrendo todos os cards da lista virtualizada do Flow para "${n.nome}"...`);
      const assinaturasSessao = { urlsUsadas: new Map(), hashesUsados: new Map() };
      const todosPrompts = cenas.map((c) => c.prompt || '');
      let salvos = 0;
      let naoEncontradas = [];

      let scan = null;
      let modoCompatV194 = false;
      try {
        scan = await this.bridge.requisitar(
          'escanear_videos_projeto',
          { novelaId: n.id, flowProjectUrl: n.flowProjectUrl },
          8 * 60 * 1000
        );
      } catch (eScan) {
        if (/Comando desconhecido:\s*escanear_videos_projeto/i.test(eScan?.message || '')) {
          // Caso o navegador do usuario ainda esteja com o Service Worker v1.9.4 em RAM (sem clicar Reload em edge://extensions):
          // forca recarregamento dos content scripts da aba a partir do disco (v1.9.5) alternando a barra final da URL e usa o canal `baixar_item`!
          modoCompatV194 = true;
          this.log(
            '⚡ Extensão ainda com Service Worker v1.9.4 em memória — recarregando script da aba do projeto (v1.9.5) e executando re-captura compatível automaticamente!',
            'aviso'
          );
          await this.bridge
            .requisitar('baixar_item', { novela: { flowProjectUrl: 'https://flow.google.com/' }, item: { id: '__reload__' } }, 25000)
            .catch(() => {});
          await this.bridge.requisitar(
            'abrir_projeto',
            { url: n.flowProjectUrl, nome: n.nome, novelaId: n.id, naoRecriarProjeto: true },
            TIMEOUTS.abrir_projeto
          );
        } else {
          throw eScan;
        }
      }

      if (modoCompatV194) {
        for (const [idx, cena] of cenas.entries()) {
          if (this.pausaSolicitada) {
            this.log('Re-captura interrompida pelo usuário.', 'aviso');
            break;
          }
          const item = n.itens.find((i) => i.id === cena.id);
          if (!item) continue;

          this.itemAtual = item.id;
          const statusAnterior = item.status;
          item.status = 'gerando';
          item.erro = null;
          item.progresso = idx === 0
            ? `🔍 Varrendo galeria do Flow e baixando {${item.id}} (1/${cenas.length})...`
            : `🔄 Re-capturando (${idx + 1}/${cenas.length}) do Flow...`;
          this.setMsg(`🔄 "${n.nome}" → re-capturando {${item.id}} (${idx + 1}/${cenas.length}, 0 créditos)...`);
          this.store.salvar(n);
          this.emitirNovela(n);

          try {
            const res = await this.bridge.requisitar(
              'baixar_item',
              {
                modo: 'recapturar_cena_v194',
                forcarNovoScan: idx === 0,
                novela: novelaParaExtensao(n),
                item,
                chavesProibidas: [...assinaturasSessao.urlsUsadas.keys()],
                outrosPrompts: todosPrompts.filter((p) => p !== item.prompt),
              },
              20 * 60 * 1000
            );
            await this.salvarResultado(n, item, res, { assinaturasExternas: assinaturasSessao });
            item.status = 'concluido';
            item.erro = null;
            item.geradoEm = new Date().toISOString();
            if (res.nomeAtivo) this.registrarAtivosNoProjeto(n, res.projetoUrl || n.flowProjectUrl, [item.id]);
            salvos++;
            this.log(
              `✅ {${item.id}} re-capturado com sucesso (${Math.round((item.tamanhoBytes || 0) / 1024)} KB · SHA-256 ${String(item.sha256 || '').slice(0, 10)})!`,
              'ok'
            );
            this.atualizarCapcutSePreciso(n, item);
          } catch (eCena) {
            naoEncontradas.push(item.id);
            item.status = item.arquivo ? statusAnterior : 'erro';
            item.erro = `Falha ao re-capturar: ${limparPrefixosInternos(eCena.message)}`;
            this.log(`❌ Re-captura de {${item.id}} falhou: ${limparPrefixosInternos(eCena.message)}`, 'erro');
          } finally {
            item.progresso = null;
            this.store.salvar(n);
            this.emitirNovela(n);
          }
        }
      } else {
        const casados = casarCardsComCenas(scan.cards || [], cenas, {
          itensNovela: n.itens || [],
          usarDesempateCronologico: true,
        });
        const { casamentos, totalCardsUnicos } = casados;
        naoEncontradas = casados.naoEncontradas;
        this.log(
          `🔍 Varredura concluída: ${totalCardsUnicos} card(s) de vídeo único(s) lidos no Flow → ${casamentos.length}/${cenas.length} cena(s) casadas pelo diálogo/prompt + chips.`,
          casamentos.length === cenas.length ? 'ok' : 'aviso'
        );
        if (naoEncontradas.length) {
          this.log(`⚠️ Cenas ainda não geradas/localizadas na página do Flow: ${naoEncontradas.map((c) => `{${c}}`).join(', ')}`, 'aviso');
        }
        if (!casamentos.length) {
          throw new Error(
            `Nenhum dos ${totalCardsUnicos} card(s) de vídeo encontrados na página do Flow casou com as cenas de "${n.nome}". Confirme se a aba está no projeto certo.`
          );
        }

        for (const [idx, par] of casamentos.entries()) {
          if (this.pausaSolicitada) {
            this.log('Re-captura interrompida pelo usuário.', 'aviso');
            break;
          }
          const item = n.itens.find((i) => i.id === par.cena.id);
          if (!item) continue;

          this.itemAtual = item.id;
          const statusAnterior = item.status;
          item.status = 'gerando';
          item.erro = null;
          item.progresso = `🔄 Re-capturando e renomeando (${idx + 1}/${casamentos.length}) no Flow...`;
          this.setMsg(`🔄 "${n.nome}" → renomeando e baixando {${item.id}} (${idx + 1}/${casamentos.length}, 0 créditos)...`);
          this.store.salvar(n);
          this.emitirNovela(n);

          try {
            const res = await this.bridge.requisitar(
              'baixar_card_escaneado',
              {
                novela: novelaParaExtensao(n),
                item,
                cardAlvo: par.card,
                chavesProibidas: [...assinaturasSessao.urlsUsadas.keys()],
                outrosPrompts: todosPrompts.filter((p) => p !== item.prompt),
                renomear: true,
              },
              20 * 60 * 1000
            );
            await this.salvarResultado(n, item, res, { assinaturasExternas: assinaturasSessao });
            item.status = 'concluido';
            item.erro = null;
            item.geradoEm = new Date().toISOString();
            if (res.nomeAtivo) {
              this.registrarAtivosNoProjeto(n, res.projetoUrl || n.flowProjectUrl, [item.id]);
            }
            salvos++;
            this.log(
              `✅ {${item.id}} renomeado e re-capturado (${Math.round((item.tamanhoBytes || 0) / 1024)} KB · SHA-256 ${String(item.sha256 || '').slice(0, 10)} · método: ${par.metodo})!`,
              'ok'
            );
            this.atualizarCapcutSePreciso(n, item);
          } catch (eCena) {
            item.status = item.arquivo ? statusAnterior : 'erro';
            item.erro = `Falha ao re-capturar: ${limparPrefixosInternos(eCena.message)}`;
            this.log(`❌ Re-captura de {${item.id}} falhou: ${limparPrefixosInternos(eCena.message)}`, 'erro');
          } finally {
            item.progresso = null;
            this.store.salvar(n);
            this.emitirNovela(n);
          }
        }
      }

      // Se alguma cena (ex.: Cena 12 quando acabaram os creditos na 11) nao existia no Flow mas tinha um .mp4 duplicado no PC,
      // limpa a copia falsa e marca como "pendente" para nunca sobrar video repetido na pasta!
      if (!this.pausaSolicitada && naoEncontradas.length > 0 && salvos > 0) {
        const basePasta = this.store.pastaAbs(n);
        for (const idFaltando of naoEncontradas) {
          const itFaltando = n.itens.find((i) => i.id === idFaltando);
          if (!itFaltando?.arquivo) continue;
          const absFaltando = path.join(basePasta, itFaltando.arquivo);
          if (!fs.existsSync(absFaltando)) continue;
          const shaExistente = calcularSha256(absFaltando);
          const urlExistente = normalizarUrlMidia(itFaltando.flowMidiaChave || '');
          if ((shaExistente && assinaturasSessao.hashesUsados.has(shaExistente)) || (urlExistente && assinaturasSessao.urlsUsados.has(urlExistente))) {
            try { fs.unlinkSync(absFaltando); } catch {}
            Object.assign(itFaltando, {
              status: 'pendente',
              arquivo: null,
              sha256: null,
              flowMidiaChave: null,
              flowMidiaUrls: [],
              tamanhoBytes: null,
              erro: 'Ainda não gerada no projeto do Flow (duplicata anterior removida). Clique em Rodar para gerar apenas esta cena.',
            });
            this.log(`🧹 {${idFaltando}} continha um .mp4 repetido de outra cena e ainda não existe no projeto do Flow — duplicata removida e cena marcada como pendente.`, 'aviso');
          }
        }
        this.store.salvar(n);
        this.emitirNovela(n);
      }

      const msgFim = `✅ Re-captura concluída em "${n.nome}": ${salvos}/${cenas.length} vídeo(s) único(s) salvos e validados (0 créditos gastos)!`;
      this.log(msgFim, salvos === cenas.length ? 'ok' : 'aviso');
      this.setMsg(msgFim);
      return { ok: true, salvos, totalCenas: cenas.length, naoEncontradas };
    } catch (e) {
      this.log(`❌ Re-captura de "${n.nome}" falhou: ${e.message}`, 'erro');
      this.setMsg(`Erro na re-captura: ${e.message}`);
      throw e;
    } finally {
      this.rebaixando = false;
      this.recapturando = null;
      this.itemAtual = null;
      this.emitirFila();
    }
  }

  /**
   * Grava o arquivo retornado pela extensao na pasta da novela.
   * Valida:
   *  1) Cabecalho binario real (MP4 "ftyp" / JPEG / PNG / WEBP);
   *  2) TRAVA DUPLA ANTI-DUPLICACAO em videos: URL base (sem query string) + Hash SHA-256 contra as outras cenas!
   */
  async salvarResultado(n, item, res, { assinaturasExternas = null } = {}) {
    const base = this.store.pastaAbs(n);
    const pastaItem = path.join(base, path.dirname(item.caminhoRelativo));
    fs.mkdirSync(pastaItem, { recursive: true });
    const nomeBase = path.basename(item.caminhoRelativo, path.extname(item.caminhoRelativo));

    let origemLocal = null, buffer = null;
    if (res.arquivoLocal) {
      origemLocal = path.resolve(String(res.arquivoLocal));
      if (!origemLocal.split(path.sep).includes('FlowNovelaStudio_tmp')) throw new Error('Caminho de download não permitido.');
      if (/\.(crdownload|tmp|part)$/i.test(origemLocal)) throw new Error('O download ainda não terminou (.crdownload).');
      if (!fs.existsSync(origemLocal)) throw new Error(`Arquivo baixado não encontrado: ${origemLocal}`);
    } else if (res.base64) {
      buffer = Buffer.from(String(res.base64).replace(/^data:[^,]+,/, ''), 'base64');
    } else {
      throw new Error('A extensão não enviou o arquivo gerado (download do navegador ou mídia validada).');
    }

    let info;
    try {
      info = validarMidia(origemLocal || buffer, item.tipo);
    } catch (e) {
      if (origemLocal) { try { fs.unlinkSync(origemLocal); } catch {} }
      throw e;
    }

    // ---------- TRAVA DUPLA ANTI-DUPLICACAO (URL base sem query params + SHA-256) ----------
    let sha256 = '';
    let urlsCandidatas = [];
    let mapaAssinaturas = null;
    if (item.tipo === 'video') {
      sha256 = calcularSha256(origemLocal || buffer);
      urlsCandidatas = [
        ...new Set(
          [res.midiaChave, res.urlMidia, res.urlDownload, ...(Array.isArray(res.todasChaves) ? res.todasChaves : [])]
            .map(normalizarUrlMidia)
            .filter(Boolean)
        ),
      ];
      mapaAssinaturas = assinaturasExternas || coletarAssinaturasVideosNovela(n, base, { excluirItemId: item.id });
      const verif = verificarDuplicidadeVideo({
        itemId: item.id,
        urlsCandidatas,
        sha256Candidato: sha256,
        urlsUsadas: mapaAssinaturas.urlsUsadas,
        hashesUsados: mapaAssinaturas.hashesUsados,
      });
      if (verif.duplicado) {
        // JAMAIS sobrescrever cena_02.mp4 com o binario repetido de cena_01.mp4!
        if (origemLocal) { try { fs.unlinkSync(origemLocal); } catch {} }
        throw new Error(
          `[DUPLICATA_VIDEO] Bloqueado: o vídeo capturado para {${item.id}} é idêntico ao já salvo em {${verif.cenaOriginal}} (${
            verif.motivo === 'sha256'
              ? `mesmo hash SHA-256 ${verif.valor.slice(0, 12)}…`
              : `mesma URL base ${verif.valor.slice(-28)}`
          }).`
        );
      }
    }

    const rel = `${path.dirname(item.caminhoRelativo)}/${nomeBase}.${info.ext}`;
    const destino = path.join(base, rel);
    const tmp = destino + '.parcial';
    if (origemLocal) { fs.copyFileSync(origemLocal, tmp); } else { fs.writeFileSync(tmp, buffer); }
    if (fs.statSync(tmp).size !== info.tamanho) { try { fs.unlinkSync(tmp); } catch {} throw new Error('Cópia do arquivo incompleta.'); }
    try {
      fs.renameSync(tmp, destino);
    } catch {
      try { fs.copyFileSync(tmp, destino); fs.unlinkSync(tmp); }
      catch { try { fs.unlinkSync(tmp); } catch {} throw new Error(`Não consegui substituir "${path.basename(destino)}": o arquivo está aberto em outro programa (player/CapCut). Feche e tente de novo.`); }
    }
    if (origemLocal) { try { fs.unlinkSync(origemLocal); } catch {} }
    for (const ext of ['png', 'jpg', 'jpeg', 'webp', 'mp4']) {
      const velho = path.join(pastaItem, `${nomeBase}.${ext}`);
      if (ext !== info.ext && fs.existsSync(velho)) { try { fs.unlinkSync(velho); } catch {} }
    }

    item.arquivo = rel;
    item.tamanhoBytes = info.tamanho;
    item.formatoReal = info.tipo;
    item.resolucaoDownload = res.resolucao || (String(res.origem || '').startsWith('midia-direta') ? 'original (mídia do card)' : null);
    item.upscale = !!res.upscale;
    if (res.nomeAtivo) item.nomeAtivoFlow = res.nomeAtivo;
    if (item.tipo === 'video') {
      item.sha256 = sha256;
      if (urlsCandidatas.length) {
        item.flowMidiaChave = normalizarUrlMidia(res.midiaChave || res.urlMidia || '') || urlsCandidatas[0];
        item.flowMidiaUrls = urlsCandidatas;
      }
      if (mapaAssinaturas) {
        if (sha256) mapaAssinaturas.hashesUsados.set(sha256, item.id);
        for (const u of urlsCandidatas) mapaAssinaturas.urlsUsadas.set(u, item.id);
      }
    }
  }
}
