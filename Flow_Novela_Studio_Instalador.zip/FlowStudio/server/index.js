// =============================================================
//  Flow Novela Studio - Servidor local (Express + WebSocket)
//  http://localhost:3456   |   ws://localhost:3456
// =============================================================
import express from 'express';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';
import QRCode from 'qrcode';
import { Store, escreverJsonAtomico, lerJson } from './store.js';
import { parseRoteiro, aplicarModoElementos, compararNumerico } from './parser.js';
import { detectarPastaCapcut, exportarParaCapcut, limparAprimoramentoDraftsFlow } from './capcutExporter.js';
import { Bridge } from './bridge.js';
import { Runner, ehNovelaConcluidaManual } from './runner.js';
import { SELETORES_MODELO } from './seletoresModelo.js';
import {
  detectarClaudeCli,
  statusClaudeCompleto,
  aplicarSuavizacaoComImagem,
  aplicarModoDescritivoSemImagem,
  restaurarItemOriginal,
  calcularResumoCotaClaude,
  salvarCalibracaoCotaClaude,
} from './claudeBridge.js';
import { TIPOS_CONFLITO } from './fichasService.js';
import { FabricaService } from './fabricaService.js';
import { WhatsappService } from './whatsappService.js';
import { CapcutWatcher } from './capcutWatcher.js';
import { GoogleDriveService } from './googleDriveService.js';
import { TunnelService } from './tunnelService.js';
import { lerVersionInfo, verificarAtualizacao, aplicarAtualizacao } from './updaterService.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DADOS = path.join(ROOT, 'dados');
const PROJ = path.join(ROOT, 'Meus_Projetos_Flow');
const DIST = path.join(ROOT, 'web', 'dist');
const ARQ_STARTUP_LOG = path.join(DADOS, 'startup.log');

// ---------------- Proteção Global contra Quedas (uncaughtException / unhandledRejection) ----------------
function gravarErroGlobalSemCair(origem, err) {
  const textoErro = err?.stack || err?.message || String(err || 'Erro desconhecido');
  const linha = `[${new Date().toISOString()}] [${origem}] ${textoErro}\n`;
  try {
    fs.mkdirSync(DADOS, { recursive: true });
    fs.appendFileSync(ARQ_STARTUP_LOG, linha, 'utf8');
  } catch {}
  try {
    console.error(`\x1b[31m[${origem}]\x1b[0m`, textoErro);
    if (typeof log === 'function') {
      log(`🛡️ Proteção anti-queda (${origem}): ${err?.message || String(err)}`, 'aviso');
    }
  } catch {}
}

process.on('uncaughtException', (err) => {
  gravarErroGlobalSemCair('uncaughtException', err);
});
process.on('unhandledRejection', (reason) => {
  gravarErroGlobalSemCair('unhandledRejection', reason);
});

// Carrega .env local (se existir) e garante STUDIO_PIN forte de 6 digitos automatico
const ARQ_ENV = path.join(ROOT, '.env');
function salvarStudioPinNoEnv(novoPin) {
  const pinLimpo = String(novoPin || '').trim();
  process.env.STUDIO_PIN = pinLimpo;
  let linhas = [];
  if (fs.existsSync(ARQ_ENV)) {
    try { linhas = fs.readFileSync(ARQ_ENV, 'utf8').split(/\r?\n/); } catch {}
  }
  let trocou = false;
  const novas = linhas.map((raw) => {
    if (/^\s*STUDIO_PIN\s*=/.test(raw)) {
      trocou = true;
      return `STUDIO_PIN=${pinLimpo}`;
    }
    return raw;
  });
  if (!trocou) {
    if (novas.length === 0) {
      novas.push('# Flow Novela Studio - Configuracao Local (.env)');
      novas.push('PORT=3456');
      novas.push('HOST=0.0.0.0');
    }
    novas.push(`STUDIO_PIN=${pinLimpo}`);
  }
  try { fs.writeFileSync(ARQ_ENV, novas.join('\r\n').trim() + '\r\n', 'utf8'); } catch {}
  return pinLimpo;
}

if (fs.existsSync(ARQ_ENV)) {
  try {
    for (const raw of fs.readFileSync(ARQ_ENV, 'utf8').split(/\r?\n/)) {
      const l = raw.trim();
      if (!l || l.startsWith('#')) continue;
      const eq = l.indexOf('=');
      if (eq <= 0) continue;
      const k = l.slice(0, eq).trim();
      const v = l.slice(eq + 1).trim().replace(/^['"]|['"]$/g, '');
      if (k && process.env[k] === undefined) process.env[k] = v;
    }
  } catch {}
}

if (!String(process.env.STUDIO_PIN || '').trim()) {
  const pinAleatorio6 = String(crypto.randomInt(100000, 1000000));
  salvarStudioPinNoEnv(pinAleatorio6);
}

const PORT = Number(process.env.PORT) || 3456;
const HOST = process.env.HOST || '0.0.0.0';
const obterStudioPin = () => String(process.env.STUDIO_PIN || '').trim();
const SEGREDO_SESSAO_PIN = crypto.randomBytes(24).toString('hex');
function gerarTokenPin(pin) {
  return crypto.createHmac('sha256', SEGREDO_SESSAO_PIN).update(String(pin || '')).digest('hex');
}

const ARQ_DOM_MAP = path.join(DADOS, 'flow-dom-map.json');
const ARQ_SELETORES = path.join(DADOS, 'flow-selectors.json');
const ARQ_CONFIG = path.join(DADOS, 'config.json');

fs.mkdirSync(DADOS, { recursive: true });
fs.mkdirSync(PROJ, { recursive: true });

if (!fs.existsSync(ARQ_CONFIG)) {
  escreverJsonAtomico(ARQ_CONFIG, {
    modelosImagem: ['Nano Banana 2.1', 'Nano Banana Pro'],
    modelosVideo: ['Omni 1.2 Flash', 'Omni 1.1 Flash'],
    flowUrlInicial: 'https://flow.google.com/',
    flowUrlLabs: 'https://labs.google/fx/pt/tools/flow',
  });
}
if (!fs.existsSync(ARQ_SELETORES)) escreverJsonAtomico(ARQ_SELETORES, SELETORES_MODELO);

const PADROES_QUALIDADE = {
  modeloImagem: 'Nano Banana 2.1',
  modeloVideo: 'Omni 1.1 Flash',
  forcarElementos: false,
  qualidadeGeracaoVideo: '720p',
  qualidadeDownloadVideo: '720p',
  qualidadeDownloadImagem: '1k',
};
const OPCOES_QUALIDADE = {
  qualidadeGeracaoVideo: ['360p', '720p', '1080p', '4k'],
  qualidadeDownloadVideo: ['original', '720p', '1080p', '4k'],
  qualidadeDownloadImagem: ['original', '1k', '2k', '4k'],
};
const config = () => {
  const c = lerJson(ARQ_CONFIG, {});
  c.padroes = { ...PADROES_QUALIDADE, ...(c.padroes || {}) };
  c.opcoesQualidade = OPCOES_QUALIDADE;
  return c;
};
function aplicarQualidades(destino, origem) {
  if (!origem || typeof origem !== 'object') return destino;
  for (const [campo, validas] of Object.entries(OPCOES_QUALIDADE)) {
    if (typeof origem[campo] === 'string' && validas.includes(origem[campo])) destino[campo] = origem[campo];
  }
  if (typeof origem.modeloImagem === 'string' && origem.modeloImagem.trim()) destino.modeloImagem = origem.modeloImagem.trim();
  if (typeof origem.modeloVideo === 'string' && origem.modeloVideo.trim()) destino.modeloVideo = origem.modeloVideo.trim();
  if (typeof origem.forcarElementos === 'boolean') destino.forcarElementos = origem.forcarElementos;
  return destino;
}
const seletores = () => lerJson(ARQ_SELETORES, SELETORES_MODELO);

// ---------------- Estado / broadcast -----------------
const store = new Store(DADOS, PROJ);
// migracao: novelas enviadas ao CapCut antes da flag capcutExported
for (const n of store.listar()) {
  if (n.capcut?.pasta && !n.capcutExported) { n.capcutExported = true; n.capcutDraftPath = n.capcut.pasta; store.salvar(n); }
}
// Limpa 100% de qualquer flag de aprimoramento de qualidade (QualityEnhance) herdada em drafts do CapCut
try {
  const detCapcut = detectarPastaCapcut(config().capcutDraftsPath);
  if (detCapcut?.pasta) limparAprimoramentoDraftsFlow(detCapcut.pasta);
} catch {}
const uiClients = new Set();
const logs = [];

function broadcastUI(msg) {
  const s = JSON.stringify(msg);
  for (const c of uiClients) if (c.readyState === 1) c.send(s);
}

function log(msg, nivel = 'info') {
  const entrada = { t: new Date().toISOString(), msg, nivel };
  logs.push(entrada);
  if (logs.length > 300) logs.shift();
  const cor = { erro: '\x1b[31m', aviso: '\x1b[33m', ok: '\x1b[32m' }[nivel] || '\x1b[36m';
  console.log(`${cor}[${entrada.t.slice(11, 19)}]\x1b[0m ${msg}`);
  broadcastUI({ type: 'log', entrada });
}

function resumoDomMap() {
  const m = lerJson(ARQ_DOM_MAP, null);
  if (!m) return { existe: false, capturas: 0 };
  return {
    existe: true,
    capturas: m.capturas?.length || 0,
    atualizadoEm: m.atualizadoEm,
    elementos: (m.capturas || []).reduce((s, c) => s + (c.elementos?.length || 0), 0),
  };
}

const bridge = new Bridge({
  onChange: () => broadcastUI({ type: 'extensao', extensao: bridge.estado() }),
  log,
});

let capcutWatcher = null; // criado mais abaixo (Fabrica Claude)
let fabrica = null;
const emitirNovela = (n) => { broadcastUI({ type: 'novela', novela: n }); capcutWatcher?.aoAtualizarNovela(n); };
const runner = new Runner({
  store,
  bridge,
  emitirNovela,
  emitirFila: () => broadcastUI({ type: 'fila', fila: runner.estado() }),
  log,
  contextoHistoria: (n, item) => fabrica?.contextoHistoria(n, item) || '',
});

// ---------------- Fabrica Claude / WhatsApp / Vigia CapCut ----------------
fabrica = new FabricaService({
  store, log, emitirNovela, broadcastUI, runner,
  obterPadroes: () => config().padroes,
  aoImportarNovela: (n) => capcutWatcher?.aoAtualizarNovela(n),
  reprocessarNovela: (n, texto) => {
    if (runner.rodando && runner.novelaAtual === n.id) throw new Error('Esta novela está rodando na fila. Pause antes de atualizar o roteiro.');
    mesclarRoteiroNovela(n, texto); // funcao declarada (hoisted) mais abaixo
    store.salvar(n);
    emitirNovela(n);
  },
});
const whatsapp = new WhatsappService({ dadosDir: DADOS, log, aoMudar: (s) => broadcastUI({ type: 'whatsapp', whatsapp: { ...s } }) });
const gdrive = new GoogleDriveService({ dadosDir: DADOS, porta: PORT, log, aoMudar: (s) => broadcastUI({ type: 'gdrive', gdrive: s }) });
const tunel = new TunnelService({ rootDir: ROOT, dadosDir: DADOS, porta: PORT, log, aoMudar: (s) => broadcastUI({ type: 'tunel', tunel: s }) });
capcutWatcher = new CapcutWatcher({
  dadosDir: DADOS, store, whatsapp, gdrive, log, emitirNovela,
  aoMudar: (s) => broadcastUI({ type: 'capcut_monitor', capcut: s }),
});
// Migracao: novelas vindas da Fabrica sem modoGeracaoVideo seguem o modo atual de C:\FabricaClaude\dados\config.json
{
  const modoFab = fabrica.existe ? fabrica.lerConfigFabrica().modoGeracaoVideo : 'elementos';
  if (modoFab === 'elementos') {
    for (const n of store.listar()) {
      if (n.origemFabrica && !n.modoGeracaoVideo && !n.forcarElementos) {
        n.modoGeracaoVideo = 'elementos';
        n.forcarElementos = true;
        n.itens = aplicarModoElementos(n.itens, true);
        store.salvar(n);
      }
    }
  }
}

// ---------------- Mapa DOM do Google Flow -----------------
function salvarDomMap({ modo = 'novo', rotulo = '', relatorio }) {
  if (!relatorio || typeof relatorio !== 'object') throw new Error('Relatório vazio.');
  let mapa = lerJson(ARQ_DOM_MAP, null);
  if (modo === 'novo' || !mapa) {
    if (mapa) escreverJsonAtomico(path.join(DADOS, 'flow-dom-map.anterior.json'), mapa);
    mapa = {
      app: 'Flow Novela Studio',
      descricao: 'Mapa dos elementos interativos do Google Flow para calibrar a automação (Etapa 3).',
      criadoEm: new Date().toISOString(),
      capturas: [],
    };
  }
  const captura = {
    numero: mapa.capturas.length + 1,
    modo,
    rotulo: rotulo || (modo === 'novo' ? 'Captura principal' : `Captura complementar ${mapa.capturas.length + 1}`),
    recebidoEm: new Date().toISOString(),
    ...relatorio,
  };
  mapa.capturas.push(captura);
  mapa.atualizadoEm = captura.recebidoEm;
  mapa.totalCapturas = mapa.capturas.length;
  escreverJsonAtomico(ARQ_DOM_MAP, mapa);
  const qtd = relatorio.elementos?.length || 0;
  log(`Mapa do Google Flow salvo: captura #${captura.numero} "${captura.rotulo}" com ${qtd} elementos → dados/flow-dom-map.json`, 'ok');
  broadcastUI({ type: 'dom_map', domMap: resumoDomMap() });
  return { numero: captura.numero, totalCapturas: mapa.capturas.length, elementos: qtd, arquivo: ARQ_DOM_MAP };
}

// ---------------- Express + Rede (0.0.0.0 / Túnel HTTPS Cloudflare / Wi-Fi / PIN Blindado) -----------------
const app = express();
app.use(express.json({ limit: '500mb' }));

const origemPermitida = (o) => {
  if (!o || o.startsWith('chrome-extension://')) return true;
  try {
    const u = new URL(o);
    const h = u.hostname.toLowerCase();
    if (h === 'localhost' || h === '127.0.0.1' || h === '::1' || h === '[::1]') return true;
    if (h.endsWith('.trycloudflare.com') || h.endsWith('.local')) return true;
    // IPv4 privado (Wi-Fi local 192.168.x.x, 10.x.x.x, 172.16-31.x.x)
    if (/^(192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})$/.test(h)) {
      return true;
    }
  } catch {}
  return false;
};

/**
 * Identifica o IP real do cliente (considerando headers do Cloudflare Quick Tunnel quando acesso vem pela internet).
 */
function obterIpCliente(req) {
  const cfIp = String(req.headers?.['cf-connecting-ip'] || '').trim();
  if (cfIp) return cfIp;
  const xff = String(req.headers?.['x-forwarded-for'] || '').split(',')[0].trim();
  if (xff) return xff;
  return String(req.socket?.remoteAddress || 'desconhecido').replace(/^::ffff:/, '');
}

/**
 * Retorna TRUE somente quando a requisicao partiu diretamente do navegador local do PC (`localhost` / `127.0.0.1` / extensao Chrome),
 * e FALSE para qualquer acesso vindo pelo tunel `*.trycloudflare.com` ou por outro dispositivo na rede.
 */
function ehRequisicaoLocalPc(req) {
  const origem = String(req.headers?.origin || '');
  if (origem.startsWith('chrome-extension://')) return true;
  // Se tiver qualquer cabecalho de proxy/Cloudflare Tunnel, NAO e acesso direto do PC!
  if (req.headers?.['cf-connecting-ip'] || req.headers?.['cf-ray'] || req.headers?.['x-forwarded-for'] || req.headers?.['x-forwarded-host']) {
    return false;
  }
  const remote = String(req.socket?.remoteAddress || '').replace(/^::ffff:/, '');
  if (remote !== '127.0.0.1' && remote !== '::1') return false;
  const host = String(req.headers?.host || '').toLowerCase().split(':')[0];
  if (host && host !== 'localhost' && host !== '127.0.0.1' && host !== '[::1]') return false;
  if (origem) {
    try {
      const hOrig = new URL(origem).hostname.toLowerCase();
      if (hOrig !== 'localhost' && hOrig !== '127.0.0.1' && hOrig !== '[::1]') return false;
    } catch {
      return false;
    }
  }
  return true;
}

// ---------------- Protecao Anti-Forca Bruta (Bloqueio de 15 min apos 5 tentativas erradas) ----------------
const MAX_TENTATIVAS_PIN = 5;
const BLOQUEIO_PIN_MS = 15 * 60 * 1000;
const tentativasPinPorIp = new Map(); // ip -> { falhas: number, bloqueadoAte: number }

function verificarBloqueioIp(ip) {
  const reg = tentativasPinPorIp.get(ip);
  if (!reg) return { bloqueado: false, minutosRestantes: 0 };
  if (reg.bloqueadoAte && Date.now() < reg.bloqueadoAte) {
    const min = Math.max(1, Math.ceil((reg.bloqueadoAte - Date.now()) / 60000));
    return { bloqueado: true, minutosRestantes: min };
  }
  if (reg.bloqueadoAte && Date.now() >= reg.bloqueadoAte) {
    tentativasPinPorIp.delete(ip);
  }
  return { bloqueado: false, minutosRestantes: 0 };
}

function registrarFalhaPin(ip) {
  const atual = tentativasPinPorIp.get(ip) || { falhas: 0, bloqueadoAte: 0 };
  atual.falhas += 1;
  if (atual.falhas >= MAX_TENTATIVAS_PIN) {
    atual.bloqueadoAte = Date.now() + BLOQUEIO_PIN_MS;
    log(`🛡️ Segurança: IP ${ip} bloqueado por 15 minutos após ${atual.falhas} tentativas incorretas de PIN.`, 'aviso');
  }
  tentativasPinPorIp.set(ip, atual);
  return {
    falhas: atual.falhas,
    restantes: Math.max(0, MAX_TENTATIVAS_PIN - atual.falhas),
    bloqueado: Boolean(atual.bloqueadoAte && Date.now() < atual.bloqueadoAte),
  };
}

function limparFalhasPin(ip) {
  tentativasPinPorIp.delete(ip);
}

function validarValorPinOuToken(valorEnviado) {
  const pinConfig = obterStudioPin();
  if (!pinConfig) return true;
  const v = String(valorEnviado || '').trim();
  if (!v) return false;
  return v === pinConfig || v === gerarTokenPin(pinConfig);
}

function verificarPinReq(req) {
  // Acesso local direto no PC (localhost / 127.0.0.1 / extensao Chrome) e sempre liberado
  if (ehRequisicaoLocalPc(req)) return true;
  const ip = obterIpCliente(req);
  if (verificarBloqueioIp(ip).bloqueado) return false;
  const headerPin = String(req.headers?.['x-studio-pin'] || '').trim();
  let queryPin = '';
  try {
    const u = new URL(req.url || '/', 'http://localhost');
    queryPin = String(u.searchParams.get('pin') || '').trim();
  } catch {}
  return validarValorPinOuToken(headerPin) || validarValorPinOuToken(queryPin);
}

export async function detectarEnderecosRede(req = null) {
  const ifs = os.networkInterfaces() || {};
  const locais = [];
  const vistos = new Set();

  for (const [nomeIf, lista] of Object.entries(ifs)) {
    for (const info of lista || []) {
      const fam = info.family === 'IPv4' || info.family === 4;
      if (!fam || info.internal || !info.address) continue;
      const ip = info.address.trim();
      if (vistos.has(ip)) continue;
      // Ignora IPs de VPN/CGNAT (100.x.x.x) na lista de Wi-Fi local — usamos Túnel HTTPS Cloudflare sem VPN!
      const ehLocal = /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(ip) && !/tailscale|tun|tap|vpn/i.test(nomeIf);
      if (!ehLocal) continue;
      vistos.add(ip);
      const url = `http://${ip}:${PORT}`;
      const qrDataUrl = await QRCode.toDataURL(url, { margin: 1, width: 240 }).catch(() => null);
      locais.push({ interface: nomeIf, ip, url, qrDataUrl, tipo: 'wifi' });
    }
  }

  // Prioriza 192.168.x.x na lista de Wi-Fi local
  locais.sort((a, b) => (b.ip.startsWith('192.168.') ? 1 : 0) - (a.ip.startsWith('192.168.') ? 1 : 0));
  const estTunel = tunel.estadoPublico();
  const ehLocal = req ? ehRequisicaoLocalPc(req) : false;
  const principalUrl = estTunel.url || locais[0]?.url || `http://localhost:${PORT}`;
  const principalQr = estTunel.qrDataUrl || locais[0]?.qrDataUrl || null;
  return {
    porta: PORT,
    host: HOST,
    ehLocalPc: ehLocal,
    pinAtivo: true,
    // SEGURANCA: o PIN em texto puro SO e enviado quando a requisicao vem da tela local do PC (localhost)!
    pinAtual: ehLocal ? obterStudioPin() : null,
    tunel: estTunel,
    ipsLocais: locais,
    urlPrincipal: principalUrl,
    qrPrincipal: principalQr,
  };
}

app.use((req, res, next) => {
  const o = req.headers.origin;
  if (o && !origemPermitida(o)) return res.status(403).json({ erro: 'Origem não permitida.' });
  if (o) {
    res.setHeader('Access-Control-Allow-Origin', o);
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-studio-pin');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// nenhuma resposta da API pode ficar em cache (evita mostrar roteiro/lista antigos)
app.use('/api', (req, res, next) => {
  res.set('Cache-Control', 'no-store, max-age=0');
  if (req.path === '/health' || req.path.startsWith('/auth/') || req.path === '/gdrive/callback') {
    return next();
  }
  // A extensao Chrome local acessa /novelas/:id/itens/:itemId/arquivo-bin em localhost
  if (ehRequisicaoLocalPc(req) && (req.path === '/status' || /^\/novelas\/[^/]+\/itens\/[^/]+\/arquivo-bin$/.test(req.path))) {
    return next();
  }
  const ip = obterIpCliente(req);
  const bloq = verificarBloqueioIp(ip);
  if (bloq.bloqueado) {
    return res.status(429).json({
      erro: `Muitas tentativas incorretas de PIN. Acesso bloqueado temporariamente por ${bloq.minutosRestantes} minuto(s).`,
      pinExigido: true,
      bloqueado: true,
    });
  }
  if (!verificarPinReq(req)) {
    return res.status(401).json({ erro: 'PIN de segurança exigido para acesso externo.', pinExigido: true });
  }
  next();
});
const wrap = (fn) => (req, res) => {
  try {
    const r = fn(req, res);
    if (r && typeof r.then === 'function') r.catch((e) => res.status(400).json({ erro: e.message }));
  } catch (e) {
    res.status(400).json({ erro: e.message });
  }
};

function novelaOu404(req, res) {
  const n = store.obter(req.params.id);
  if (!n) { res.status(404).json({ erro: 'Novela não encontrada.' }); return null; }
  return n;
}

app.get('/api/health', (req, res) => {
  const info = lerVersionInfo(ROOT);
  res.json({
    ok: true,
    version: info.version,
    repo: info.repo || null,
    uptime: Math.round(process.uptime()),
    pid: process.pid,
  });
});

app.get('/api/status', (req, res) =>
  res.json({ ok: true, app: 'Flow Novela Studio', version: lerVersionInfo(ROOT).version, porta: PORT, host: HOST, pinExigido: !ehRequisicaoLocalPc(req), tunel: tunel.estadoPublico(), extensao: bridge.estado(), fila: runner.estado(), domMap: resumoDomMap(), claudeCli: detectarClaudeCli() })
);

// ---------------- Auto-Update via GitHub (HTTPS Nativo, Zero Git no PC do amigo) ----------------
app.get('/api/update/status', (req, res) => {
  res.json(lerVersionInfo(ROOT));
});

const handlerVerificarUpdate = wrap(async (req, res) => {
  const st = await verificarAtualizacao({ rootDir: ROOT, timeoutMs: 4000 });
  broadcastUI({ type: 'update_status', update: st });
  res.json(st);
});
app.get('/api/update/verificar', handlerVerificarUpdate);
app.post('/api/update/verificar', handlerVerificarUpdate);

app.post('/api/update/aplicar', wrap(async (req, res) => {
  const check = await verificarAtualizacao({ rootDir: ROOT, timeoutMs: 5000 });
  const zipUrl = req.body?.zipUrl || check.zipUrl;
  const versaoAlvo = req.body?.versaoAlvo || check.versaoRemota || '';
  if (!zipUrl) {
    throw new Error(check.motivo || check.erro || 'Repositório de atualização ainda não configurado.');
  }
  log(`🔄 Iniciando atualização automática do estúdio${versaoAlvo ? ` para v${versaoAlvo}` : ''}...`, 'info');
  const resultado = await aplicarAtualizacao({
    rootDir: ROOT,
    zipUrl,
    versaoAlvo,
    log: (m) => log(m, 'info'),
  });

  // Se a pasta extensao-chrome/ mudou, envia sinal via WebSocket para a extensão rodar chrome.runtime.reload() sozinha
  if (resultado.extensaoMudou || req.body?.recarregarExtensao) {
    log('🧩 Pasta da extensão alterada na atualização — enviando sinal WebSocket para chrome.runtime.reload()...', 'ok');
    bridge.enviar({ type: 'recarregar_extensao' });
    bridge.requisitar('recarregar_extensao', {}, 2500).catch(() => {});
  }

  broadcastUI({ type: 'update_aplicado', ...resultado });
  res.json(resultado);

  // Reinicia o servidor suavemente em background para carregar o código novo
  if (req.body?.reiniciar !== false) {
    setTimeout(() => {
      try {
        const child = spawn(process.execPath, [path.join(ROOT, 'launcher.mjs'), '--restart', '--no-window'], {
          cwd: ROOT,
          detached: true,
          stdio: 'ignore',
          windowsHide: true,
        });
        child.unref();
      } catch {
        process.exit(42);
      }
    }, 900);
  }
}));
app.get('/api/auth/status', (req, res) => {
  const ip = obterIpCliente(req);
  const bloq = verificarBloqueioIp(ip);
  res.json({
    pinExigido: !ehRequisicaoLocalPc(req),
    ehLocalPc: ehRequisicaoLocalPc(req),
    autenticado: verificarPinReq(req),
    bloqueado: bloq.bloqueado,
    minutosRestantes: bloq.minutosRestantes,
  });
});
app.post('/api/auth/verificar', (req, res) => {
  const ip = obterIpCliente(req);
  const bloq = verificarBloqueioIp(ip);
  if (bloq.bloqueado) {
    return res.status(429).json({
      ok: false,
      bloqueado: true,
      erro: `Muitas tentativas incorretas. Aguarde ${bloq.minutosRestantes} minuto(s) para tentar novamente.`,
    });
  }
  const pinConfig = obterStudioPin();
  const enviado = String(req.body?.pin || '').trim();
  if (!validarValorPinOuToken(enviado)) {
    const stFalha = registrarFalhaPin(ip);
    const msg = stFalha.bloqueado
      ? 'PIN incorreto (5x). Seu IP foi bloqueado temporariamente por 15 minutos.'
      : `PIN incorreto. Restam ${stFalha.restantes} tentativa(s) antes do bloqueio de 15 min.`;
    return res.status(stFalha.bloqueado ? 429 : 401).json({ ok: false, erro: msg, restantes: stFalha.restantes, bloqueado: stFalha.bloqueado });
  }
  limparFalhasPin(ip);
  res.json({ ok: true, pinExigido: true, token: gerarTokenPin(pinConfig) });
});
app.post('/api/auth/trocar-pin', wrap((req, res) => {
  if (!ehRequisicaoLocalPc(req)) {
    return res.status(403).json({ erro: 'Por segurança, o PIN só pode ser alterado diretamente na tela local do PC (localhost).' });
  }
  const custom = String(req.body?.pin || '').replace(/\D+/g, '').trim();
  const novoPin = custom.length >= 4 && custom.length <= 8
    ? custom
    : String(crypto.randomInt(100000, 1000000));
  salvarStudioPinNoEnv(novoPin);
  tentativasPinPorIp.clear();
  log(`🔒 PIN de segurança para acesso externo atualizado no PC (${novoPin.length} dígitos).`, 'ok');
  res.json({ ok: true, pin: novoPin });
}));

// ---------------- Túnel HTTPS Direto (Cloudflare Quick Tunnel via cloudflared — Sem VPN) ----------------
app.get('/api/tunel/status', (req, res) => res.json(tunel.estadoPublico()));
app.post('/api/tunel/iniciar', wrap(async (req, res) => {
  const st = await tunel.iniciar();
  res.json(st);
}));
app.post('/api/tunel/parar', wrap(async (req, res) => {
  const st = await tunel.parar();
  res.json(st);
}));
app.patch('/api/tunel/config', wrap((req, res) => {
  res.json(tunel.salvarConfig(req.body || {}));
}));
app.post('/api/tunel/enviar-whatsapp', wrap(async (req, res) => {
  const st = tunel.estadoPublico();
  if (!st.url) throw new Error('Ligue o Túnel HTTPS primeiro para gerar o link.');
  const destino = String(req.body?.numero || capcutWatcher.cfg.destinoWhatsapp || '');
  const pin = obterStudioPin();
  const msg = `🌍 *Flow Novela Studio — Acesso Remoto HTTPS (Sem VPN)*\n\n🔗 Link: ${st.url}\n🔒 PIN de acesso: *${pin}*\n\n_(Abra no Safari do iPhone e digite o PIN uma única vez)_`;
  const r = await whatsapp.enviarTexto(msg, destino);
  log(`📲 Link do Túnel HTTPS + PIN enviados para o WhatsApp (${r.para}).`, 'ok');
  res.json({ ok: true, ...r });
}));

app.get('/api/rede', wrap(async (req, res) => res.json(await detectarEnderecosRede(req))));
app.get('/manifest.json', (req, res) => {
  res.json({
    name: 'Flow Novela Studio',
    short_name: 'Flow Studio',
    description: 'Controle remoto em tempo real e fila global autônoma para Google Flow & CapCut',
    start_url: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#0B0D12',
    theme_color: '#0B0D12',
    icons: [
      {
        src: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0' stop-color='%23a855f7'/%3E%3Cstop offset='1' stop-color='%23ec4899'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='192' height='192' rx='42' fill='url(%23g)'/%3E%3Cpath d='M72 54l66 42-66 42z' fill='white'/%3E%3C/svg%3E",
        sizes: '192x192',
        type: 'image/svg+xml',
        purpose: 'any maskable',
      },
    ],
  });
});
app.get('/api/estado', (req, res) =>
  res.json({ novelas: store.listar(), extensao: bridge.estado(), fila: runner.estado(), domMap: resumoDomMap(), config: config(), claudeCli: detectarClaudeCli(), tunel: tunel.estadoPublico(), logs })
);
app.get('/api/claude/status', (req, res) => res.json(statusClaudeCompleto({ forcar: true })));

// ================= FÁBRICA CLAUDE (C:\FabricaClaude) =================
app.get('/api/fabrica/status', (req, res) => res.json(fabrica.status({ forcar: req.query.forcar === '1' })));
app.post('/api/fabrica/abrir-login-claude', wrap((req, res) => res.json(fabrica.abrirLogin())));
app.get('/api/fabrica/config', wrap((req, res) => { fabrica.exigirFabrica(); res.json(fabrica.lerConfigFabrica()); }));
app.patch('/api/fabrica/config', wrap((req, res) => res.json(fabrica.salvarConfigFabrica(req.body || {}))));
app.get('/api/fabrica/estado-criador', wrap((req, res) => res.json(fabrica.obterEstadoCriador())));
app.put('/api/fabrica/estado-criador', wrap((req, res) => res.json(fabrica.salvarEstadoCriador(req.body || {}))));
app.get('/api/fabrica/prontos', wrap((req, res) => res.json(fabrica.listarProntos())));
app.get('/api/fabrica/series', wrap((req, res) => res.json(fabrica.listarSeries())));
app.post('/api/fabrica/importar', wrap((req, res) => {
  const slug = String(req.body?.slug || '');
  const parte = Number(req.body?.parte) || 1;
  const r = fabrica.importar({ slug, parte, substituir: !!req.body?.substituir });
  if (req.body?.iniciarFila && r.validacao.ok) runner.enfileirar([{ novelaId: r.novela.id }]);
  res.json({ ok: true, novelaId: r.novela.id, nome: r.novela.nome, validacao: r.validacao, heranca: r.heranca, filaIniciada: !!(req.body?.iniciarFila && r.validacao.ok) });
}));
app.post('/api/fabrica/sincronizar-importada', wrap((req, res) => {
  const slug = String(req.body?.slug || '');
  const parte = Number(req.body?.parte) || 1;
  const existente = fabrica.novelaImportada(slug, parte);
  if (!existente) throw new Error(`A Parte ${parte} de "${slug}" ainda não está importada no Estúdio.`);
  const at = fabrica.atualizarNovelaImportada(existente, slug, parte);
  res.json({ ok: true, novelaId: existente.id, nome: existente.nome, ...at });
}));
app.post('/api/fabrica/sementes', wrap((req, res) => res.json(fabrica.criarSementes(req.body || {}))));
app.post('/api/fabrica/roteiro', wrap((req, res) => res.json(fabrica.criarRoteiro(req.body || {}))));
app.post('/api/fabrica/prompts', wrap((req, res) => res.json(fabrica.criarPrompts(req.body || {}))));
app.post('/api/fabrica/automatico', wrap((req, res) => res.json(fabrica.criarAutomatico(req.body || {}))));
app.post('/api/fabrica/series/:slug/gerar-parte', wrap((req, res) => res.json(fabrica.gerarParte(req.params.slug, req.body || {}))));
app.post('/api/fabrica/regerar', wrap((req, res) => res.json(fabrica.regerarParte(req.body || {}))));

// ---------------- 🎯 Fichas Virais (C:\FabricaClaude\fichas_virais\fichas.json) ----------------
app.get('/api/fabrica/fichas', wrap((req, res) => { fabrica.exigirFabrica(); res.json({ fichas: fabrica.fichas.listar(), tipos: TIPOS_CONFLITO }); }));
app.post('/api/fabrica/fichas', wrap((req, res) => { fabrica.exigirFabrica(); res.json(fabrica.fichas.criar({ origem: 'manual', ...(req.body || {}) })); }));
app.post('/api/fabrica/fichas/extrair', wrap((req, res) => res.json(fabrica.extrairFicha(req.body || {}))));
app.post('/api/fabrica/fichas/promover', wrap((req, res) => res.json(fabrica.promoverNovelaEmFicha(req.body || {}))));
app.patch('/api/fabrica/fichas/:id', wrap((req, res) => { fabrica.exigirFabrica(); res.json(fabrica.fichas.atualizar(req.params.id, req.body || {})); }));
app.delete('/api/fabrica/fichas/:id', wrap((req, res) => { fabrica.exigirFabrica(); res.json(fabrica.fichas.excluir(req.params.id)); }));
app.get('/api/fabrica/dialogos', wrap((req, res) => { res.set('Cache-Control', 'no-store, max-age=0'); res.json(fabrica.dialogos(String(req.query.slug || ''), Number(req.query.parte) || 1)); }));
app.patch('/api/fabrica/dialogos', wrap((req, res) => res.json(fabrica.editarFalaRoteiro(req.body || {}))));
app.get('/api/fabrica/cota', wrap((req, res) => res.json(calcularResumoCotaClaude({ padroes: config().padroes }))));
app.post('/api/fabrica/cota/calibrar', wrap((req, res) => {
  salvarCalibracaoCotaClaude(req.body || {}, { padroes: config().padroes });
  res.json(calcularResumoCotaClaude({ padroes: config().padroes }));
}));
app.get('/api/fabrica/jobs', (req, res) => res.json(fabrica.listarJobs()));
app.get('/api/fabrica/jobs/:id', wrap((req, res) => { const j = fabrica.obterJob(req.params.id); if (!j) throw new Error('Tarefa não encontrada.'); res.json(j); }));
app.post('/api/fabrica/jobs/:id/cancelar', wrap((req, res) => res.json(fabrica.cancelarJob(req.params.id))));
app.get('/api/fabrica/agendamento', wrap((req, res) => res.json(fabrica.agendamento())));
app.post('/api/fabrica/agendamento', wrap((req, res) => res.json(fabrica.salvarAgendamento(req.body || {}))));
app.post('/api/fabrica/agendamento/buscar', wrap(async (req, res) => res.json(fabrica.buscarAgora())));

app.post('/api/novelas/:id/herdar-referencias', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  res.json(fabrica.herdarReferencias(n));
}));
app.post('/api/novelas/:id/legenda/sortear', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  res.json({ legendaFacebook: fabrica.sortearLegendaNovela(n) });
}));
app.patch('/api/novelas/:id/legenda', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  res.json({ legendaFacebook: fabrica.salvarLegendaManualNovela(n, req.body?.texto) });
}));
app.post('/api/novelas/:id/legenda/gerar', wrap(async (req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const legendaFacebook = await fabrica.gerarLegendaClaudeParaNovela(n);
  let envio = null;
  if (req.body?.enviarWhatsapp) {
    try {
      const r = await whatsapp.enviarTexto(legendaFacebook, String(req.body?.numero || capcutWatcher.cfg.destinoWhatsapp || ''));
      n.legendaEnviadaWhatsappEm = new Date().toISOString();
      store.salvar(n); emitirNovela(n);
      capcutWatcher.registrar({ arquivo: '(gerar + enviar)', novela: n.nome, resultado: 'enviada', detalhe: 'botão Legenda WhatsApp' });
      log(`📲 Legenda de "${n.nome}" gerada via Claude e enviada ao WhatsApp (${r.para}).`, 'ok');
      envio = { ok: true, ...r, enviadaEm: n.legendaEnviadaWhatsappEm };
    } catch (e) {
      envio = { ok: false, erro: e.message };
    }
  }
  res.json({ legendaFacebook, envio, enviadaEm: n.legendaEnviadaWhatsappEm || null });
}));

// ---------------- WhatsApp ----------------
app.get('/api/whatsapp/status', (req, res) => res.json(whatsapp.status()));
app.post('/api/whatsapp/conectar', wrap(async (req, res) => res.json(await whatsapp.conectar())));
app.post('/api/whatsapp/desconectar', wrap(async (req, res) => res.json(await whatsapp.desconectar())));
app.post('/api/whatsapp/enviar-teste', wrap(async (req, res) => {
  const destino = String(req.body?.numero || capcutWatcher.cfg.destinoWhatsapp || '');
  const r = await whatsapp.enviarTexto('📲 Teste do Flow Novela Studio: o WhatsApp está conectado e a legenda do Facebook chegará aqui quando você salvar o vídeo no CapCut.', destino);
  log(`WhatsApp: mensagem de teste enviada para ${r.para}.`, 'ok');
  res.json(r);
}));
app.post('/api/novelas/:id/enviar-legenda', wrap(async (req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  if (!n.legendaFacebook || req.body?.regerar) {
    await fabrica.gerarLegendaClaudeParaNovela(n);
  }
  const r = await whatsapp.enviarTexto(n.legendaFacebook, String(req.body?.numero || capcutWatcher.cfg.destinoWhatsapp || ''));
  n.legendaEnviadaWhatsappEm = new Date().toISOString();
  store.salvar(n); emitirNovela(n);
  capcutWatcher.registrar({ arquivo: '(envio manual)', novela: n.nome, resultado: 'enviada', detalhe: 'botão Enviar Legenda Agora' });
  log(`📲 Legenda de "${n.nome}" enviada ao WhatsApp (envio manual).`, 'ok');
  res.json({ ...r, legendaFacebook: n.legendaFacebook, enviadaEm: n.legendaEnviadaWhatsappEm });
}));

// ---------------- Vigia de exportação do CapCut ----------------
app.get('/api/capcut/config', (req, res) => res.json(capcutWatcher.estadoPublico()));
app.get('/api/capcut/monitor', (req, res) => res.json(capcutWatcher.estadoPublico()));
app.patch('/api/capcut/config', wrap((req, res) => res.json(capcutWatcher.atualizar(req.body || {}))));
app.post('/api/capcut/escolher-pasta', wrap(async (req, res) => res.json(await capcutWatcher.escolherPasta())));
app.post('/api/capcut/testar-disparo', wrap(async (req, res) => res.json(await capcutWatcher.testarDisparoAgora(req.body?.numero))));

// ---------------- Google Drive (upload automático pós-CapCut + link pro iPhone) ----------------
app.get('/api/gdrive/status', (req, res) => res.json(gdrive.status()));
app.post('/api/gdrive/credenciais', wrap((req, res) => res.json(gdrive.salvarCredenciais(req.body || {}))));
app.patch('/api/gdrive/config', wrap((req, res) => res.json(gdrive.atualizarPreferencias(req.body || {}))));
app.post('/api/gdrive/conectar', wrap((req, res) => res.json(gdrive.iniciarLoginOAuth({ entradaCredenciais: req.body, abrirNavegador: req.body?.abrirNavegador !== false }))));
app.post('/api/gdrive/desconectar', wrap((req, res) => res.json(gdrive.desconectar({ apagarCredenciais: !!req.body?.apagarCredenciais }))));
app.post('/api/gdrive/subir-ultimo', wrap(async (req, res) => res.json(await capcutWatcher.subirUltimoVideoEMandarLink(req.body?.numero))));
app.get('/api/gdrive/callback', async (req, res) => {
  const esc = (s) => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  try {
    const st = await gdrive.concluirCallback(req.query || {});
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Google Drive Conectado</title></head>
<body style="background:#0c0c12;color:#f4f4f5;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0">
  <div style="max-width:460px;padding:28px;border-radius:16px;background:#161622;border:1px solid #2e2e42;text-align:center">
    <div style="font-size:40px;margin-bottom:10px">☁️✅</div>
    <h2 style="margin:0 0 8px;color:#6ee7b7">Google Drive conectado!</h2>
    <p style="margin:0 0 14px;color:#a1a1aa;font-size:14px">Conta: <b style="color:#fff">${esc(st.email || 'autorizada')}</b><br>Pasta automática: <code>${esc(st.pastaNome)}</code></p>
    <p style="margin:0;color:#71717a;font-size:12px">Pode voltar para o Flow Novela Studio. Esta guia fechará sozinha.</p>
  </div>
  <script>setTimeout(()=>{try{window.close()}catch(e){}},2000);</script>
</body></html>`);
  } catch (e) {
    log(`Google Drive callback falhou: ${e.message}`, 'erro');
    res.status(400).setHeader('Content-Type', 'text/html; charset=utf-8').send(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Erro ao conectar Google Drive</title></head>
<body style="background:#0c0c12;color:#f4f4f5;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0">
  <div style="max-width:480px;padding:28px;border-radius:16px;background:#161622;border:1px solid #7f1d1d;text-align:center">
    <div style="font-size:36px;margin-bottom:10px">⚠️</div>
    <h2 style="margin:0 0 8px;color:#fca5a5">Não foi possível conectar o Google Drive</h2>
    <p style="margin:0;color:#fecaca;font-size:13px">${esc(e.message)}</p>
  </div>
</body></html>`);
  }
});
app.get('/api/config', (req, res) => res.json(config()));
app.patch('/api/config', wrap((req, res) => {
  const atual = lerJson(ARQ_CONFIG, {});
  const origemPadroes = req.body?.padroes || req.body || {};
  atual.padroes = aplicarQualidades({ ...PADROES_QUALIDADE, ...(atual.padroes || {}) }, origemPadroes);
  if (typeof req.body?.capcutDraftsPath === 'string') {
    const p = req.body.capcutDraftsPath.trim();
    if (p && !fs.existsSync(p)) throw new Error('Essa pasta do CapCut não existe.');
    atual.capcutDraftsPath = p || null;
  }
  escreverJsonAtomico(ARQ_CONFIG, atual);

  // Propaga automaticamente os novos Padroes para novelas pendentes / em andamento (ou todas se aplicarEmTodas=true)
  const aplicarPendentes = req.body?.aplicarNasPendentes !== false && origemPadroes?.aplicarNasPendentes !== false;
  const aplicarTodas = Boolean(req.body?.aplicarEmTodas || origemPadroes?.aplicarEmTodas);
  let sincronizadas = 0;
  if (aplicarPendentes || aplicarTodas) {
    for (const n of store.listar()) {
      const todosConcluidos = Array.isArray(n.itens) && n.itens.length > 0 && n.itens.every((i) => i.status === 'concluido');
      const deveAplicar = aplicarTodas || (!n.qualidadeCustomizadaManualmente && !todosConcluidos);
      if (!deveAplicar) continue;
      aplicarQualidades(n, atual.padroes);
      if (aplicarTodas) n.qualidadeCustomizadaManualmente = false;
      store.salvar(n);
      emitirNovela(n);
      sincronizadas++;
    }
  }

  log(`Padrões globais de qualidade atualizados${sincronizadas ? ` (${sincronizadas} novela(s) sincronizada(s))` : ''}.`, 'ok');
  broadcastUI({ type: 'config', config: config() });
  res.json({ ...config(), sincronizadas });
}));

app.get('/api/novelas', (req, res) => res.json(store.listar()));

app.post('/api/novelas', wrap((req, res) => {
  const pad = config().padroes;
  const n = store.criar(req.body?.nome, pad);
  aplicarQualidades(n, pad);
  store.salvar(n);
  log(`Nova novela criada: "${n.nome}" (pasta Meus_Projetos_Flow/${n.pasta})`, 'ok');
  emitirNovela(n);
  res.json(n);
}));

app.get('/api/novelas/:id', (req, res) => { const n = novelaOu404(req, res); if (n) res.json(n); });

app.patch('/api/novelas/:id', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const b = req.body || {};
  if (typeof b.nome === 'string' && b.nome.trim()) n.nome = b.nome.trim();
  if (b.sincronizarComPadroes === true) {
    n.qualidadeCustomizadaManualmente = false;
    aplicarQualidades(n, config().padroes);
  } else {
    if (typeof b.modeloImagem === 'string') { n.modeloImagem = b.modeloImagem; n.qualidadeCustomizadaManualmente = true; }
    if (typeof b.modeloVideo === 'string') { n.modeloVideo = b.modeloVideo; n.qualidadeCustomizadaManualmente = true; }
    if (b.qualidadeGeracaoVideo || b.qualidadeDownloadVideo || b.qualidadeDownloadImagem) {
      n.qualidadeCustomizadaManualmente = true;
    }
    aplicarQualidades(n, b);
  }
  if (typeof b.roteiro === 'string') {
    const midiasDisco = inspecionarMidiasPastaNovela(n);
    if (!b.roteiro.trim() && midiasDisco.total > 0 && !b.forcarSubstituicao) {
      throw new Error(`Proteção Anti-Perda: Esta novela possui ${midiasDisco.videos.length} vídeo(s) e ${midiasDisco.referencias.length + midiasDisco.imagensBase.length} imagem(ns) salvos na pasta. O roteiro não pode ser apagado sem confirmação.`);
    }
    if (n.roteiro && n.roteiro.trim() && b.roteiro.trim() !== n.roteiro.trim()) {
      salvarBackupRoteiroNovela(n);
    }
    n.roteiro = b.roteiro;
  }
  if ('flowProjectUrl' in b) n.flowProjectUrl = b.flowProjectUrl || null;
  if (typeof b.concluidaManualmente === 'boolean') {
    n.concluidaManualmente = b.concluidaManualmente;
    n.statusManual = b.concluidaManualmente ? 'concluida' : null;
    n.concluidaManualmenteEm = b.concluidaManualmente ? new Date().toISOString() : null;
    if (b.concluidaManualmente) {
      runner.removerNovelasDaFila([n.id], { interromperSeRodando: true });
    }
  }
  if (typeof b.forcarElementos === 'boolean') {
    n.forcarElementos = b.forcarElementos;
    n.modoGeracaoVideo = n.forcarElementos ? 'elementos' : 'frame_inicial'; // mantem os dois campos coerentes
    n.itens = aplicarModoElementos(n.itens, n.forcarElementos);
  }
  store.salvar(n); emitirNovela(n); res.json(n);
}));

/**
 * Marca ou desmarca uma ou várias histórias como Concluídas manualmente em lote:
 * POST /api/novelas/marcar-concluidas { ids: string[], concluida: boolean }
 */
app.post('/api/novelas/marcar-concluidas', wrap((req, res) => {
  const ids = Array.isArray(req.body?.ids) ? req.body.ids.map((x) => String(x || '').trim()).filter(Boolean) : [];
  if (!ids.length) throw new Error('Selecione pelo menos uma história.');
  const concluida = req.body?.concluida !== false;

  if (concluida) {
    runner.removerNovelasDaFila(ids, { interromperSeRodando: true });
  }

  const alteradas = [];
  for (const id of ids) {
    const n = store.obter(id);
    if (!n) continue;
    n.concluidaManualmente = concluida;
    n.statusManual = concluida ? 'concluida' : null;
    n.concluidaManualmenteEm = concluida ? new Date().toISOString() : null;
    if (concluida && Array.isArray(n.itens)) {
      for (const it of n.itens) {
        if (it.status === 'na_fila' || it.status === 'gerando') {
          it.status = 'pendente';
          it.progresso = null;
          delete it.tentativaAtual;
        }
      }
    }
    store.salvar(n);
    emitirNovela(n);
    alteradas.push(n);
  }

  if (concluida) {
    log(
      `✅ ${alteradas.length} história(s) marcada(s) como Concluída(s) manualmente e removida(s) da fila automática: ${alteradas.map((n) => `"${n.nome}"`).join(', ')}.`,
      'ok'
    );
  } else {
    log(
      `↩️ ${alteradas.length} história(s) reaberta(s) para a fila de geração: ${alteradas.map((n) => `"${n.nome}"`).join(', ')}.`,
      'info'
    );
  }

  runner.emitirFila?.();
  res.json({
    ok: true,
    concluida,
    ids: alteradas.map((n) => n.id),
    novelas: alteradas,
    fila: runner.estado(),
  });
}));

app.delete('/api/novelas/:id', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  if (runner.novelaAtual === n.id) throw new Error('Esta novela está rodando. Pause a fila antes de excluir.');
  store.remover(n.id);
  log(`Novela "${n.nome}" removida do estúdio (arquivos de mídia mantidos na pasta).`, 'aviso');
  broadcastUI({ type: 'novela_removida', id: n.id });
  res.json({ ok: true });
}));

// Pre-visualizacao do parser (nao salva)
app.post('/api/parse', wrap((req, res) => {
  res.json(parseRoteiro(req.body?.texto || '', { forcarElementos: !!req.body?.forcarElementos }));
}));

/**
 * Escaneia os arquivos reais existentes na pasta da novela (01_Referencias, 02_Imagens_Base, 03_Videos).
 */
function inspecionarMidiasPastaNovela(n) {
  const base = store.pastaAbs(n);
  const lerSub = (sub, regexExt) => {
    const dir = path.join(base, sub);
    if (!fs.existsSync(dir)) return [];
    const lista = [];
    for (const f of fs.readdirSync(dir)) {
      if (!regexExt.test(f)) continue;
      const abs = path.join(dir, f);
      try {
        const st = fs.statSync(abs);
        if (!st.isFile() || st.size < 1024) continue;
        const id = path.basename(f, path.extname(f));
        lista.push({
          id,
          arquivo: `${sub}/${f}`,
          abs,
          tamanhoBytes: st.size,
          mtimeIso: st.mtime.toISOString(),
          ext: path.extname(f).toLowerCase(),
        });
      } catch {}
    }
    return lista.sort((a, b) => compararNumerico(a.id, b.id));
  };
  const referencias = lerSub('01_Referencias', /\.(jpe?g|png|webp)$/i);
  const imagensBase = lerSub('02_Imagens_Base', /\.(jpe?g|png|webp)$/i);
  const videos = lerSub('03_Videos', /\.(mp4|mov|webm)$/i);
  return {
    referencias,
    imagensBase,
    videos,
    total: referencias.length + imagensBase.length + videos.length,
  };
}

/**
 * Salva sempre uma cópia automática `roteiro_backup.txt` (e `itens_backup_concluido.json`) na pasta da novela
 * antes de qualquer edição de roteiro.
 */
function salvarBackupRoteiroNovela(n, textoExplicito = null) {
  try {
    const base = store.pastaAbs(n);
    fs.mkdirSync(base, { recursive: true });
    const txt = typeof textoExplicito === 'string' ? textoExplicito : String(n?.roteiro || '');
    if (txt.trim()) {
      fs.writeFileSync(path.join(base, 'roteiro_backup.txt'), txt, 'utf8');
    }
    if (Array.isArray(n?.itens) && n.itens.some((i) => i.status === 'concluido')) {
      escreverJsonAtomico(path.join(base, 'itens_backup_concluido.json'), n.itens);
    }
  } catch {}
}

// Processar roteiro: parse + merge preservando status/arquivos ja gerados
function mesclarRoteiroNovela(n, texto, { religarArquivosDoDisco = true } = {}) {
  const r = parseRoteiro(texto, { forcarElementos: n.forcarElementos });
  const antigos = new Map((n.itens || []).map((i) => [i.id, i]));
  const base = store.pastaAbs(n);
  const idsReescritos = new Set();
  n.itens = r.itens.map((it) => {
    const a = antigos.get(it.id);
    // o arquivo pode ter a extensao real (ex.: .jpg) diferente da planejada (.png)
    const nomeBase = path.basename(it.caminhoRelativo, path.extname(it.caminhoRelativo));
    const candidatos = [a?.arquivo, it.caminhoRelativo, ...['jpg', 'png', 'webp', 'mp4'].map((e) => `${it.pasta}/${nomeBase}.${e}`)].filter(Boolean);
    const arquivoExistente = candidatos.find((c) => fs.existsSync(path.join(base, c))) || null;
    const existeArquivo = !!arquivoExistente;
    const igual = Boolean(
      a &&
      a.tipo === it.tipo &&
      (a.prompt === it.prompt || a.originalPrompt === it.prompt || a.promptOriginalBackup === it.prompt) &&
      (a.refs.join('|') === it.refs.join('|') || (a.anexosOriginaisBackup || []).join('|') === it.refs.join('|')) &&
      a.duracao === it.duracao
    );
    // Se o arquivo de mídia já existe fisicamente na pasta para este {id}, preserva como concluído!
    const preservar = Boolean((igual && a?.status === 'concluido' && existeArquivo) || (religarArquivosDoDisco && existeArquivo));
    if (a && !preservar) idsReescritos.add(it.id);
    let stDisco = null;
    if (preservar && arquivoExistente) {
      try { stDisco = fs.statSync(path.join(base, arquivoExistente)); } catch {}
    }
    const extReal = arquivoExistente ? path.extname(arquivoExistente).toLowerCase() : '';
    const formatoInferido = extReal === '.mp4' ? 'mp4' : extReal === '.png' ? 'png' : extReal === '.webp' ? 'webp' : extReal ? 'jpeg' : null;
    return {
      ...it,
      prompt: igual && a?.promptAutoAjustado ? a.prompt : it.prompt,
      refs: igual && a?.promptAutoAjustado ? (a.refs || []) : it.refs,
      originalPrompt: igual ? (a?.originalPrompt || null) : null,
      promptOriginalBackup: igual ? (a?.promptOriginalBackup || null) : null,
      anexosOriginaisBackup: igual ? (a?.anexosOriginaisBackup || null) : null,
      promptAutoAjustado: igual ? (a?.promptAutoAjustado || null) : null,
      semAnexos: igual ? Boolean(a?.semAnexos) : false,
      modoDescritivoSemImagem: igual ? Boolean(a?.modoDescritivoSemImagem) : false,
      geradoPorDescricaoSemImagem: preservar ? Boolean(a?.geradoPorDescricaoSemImagem) : false,
      status: preservar ? 'concluido' : 'pendente',
      arquivo: preservar ? arquivoExistente : null,
      geradoEm: preservar ? (a?.geradoEm || stDisco?.mtime?.toISOString() || new Date().toISOString()) : null,
      erro: null,
      nomeAtivoFlow: preservar ? (a?.nomeAtivoFlow || it.id) : null,
      flowMidiaChave: preservar ? (a?.flowMidiaChave || null) : null,
      todasChavesMidia: preservar ? (a?.todasChavesMidia || undefined) : undefined,
      sha256: preservar ? (a?.sha256 || undefined) : undefined,
      herdadoDe: preservar ? (a?.herdadoDe || undefined) : undefined,
      tamanhoBytes: preservar ? (a?.tamanhoBytes || stDisco?.size || null) : null,
      formatoReal: preservar ? (a?.formatoReal || formatoInferido) : null,
      resolucaoDownload: preservar ? (a?.resolucaoDownload || null) : null,
    };
  });
  if (idsReescritos.size && n.uploadedAssetsByProjectUrl && typeof n.uploadedAssetsByProjectUrl === 'object') {
    for (const k of Object.keys(n.uploadedAssetsByProjectUrl)) {
      if (Array.isArray(n.uploadedAssetsByProjectUrl[k])) {
        n.uploadedAssetsByProjectUrl[k] = n.uploadedAssetsByProjectUrl[k].filter((id) => !idsReescritos.has(id));
      }
    }
  }
  n.roteiro = texto;
  n.resumo = r.resumo;
  n.validacao = r.validacao;
  n.ignoradas = r.ignoradas;
  n.processadoEm = new Date().toISOString();
  return r;
}

app.post('/api/novelas/:id/roteiro', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  if (runner.rodando && runner.novelaAtual === n.id) throw new Error('Esta novela está rodando no momento. Pause a fila antes de reprocessar o roteiro dela.');
  const texto = typeof req.body?.texto === 'string' ? req.body.texto : n.roteiro;
  const forcarSubstituicao = Boolean(req.body?.forcarSubstituicao);
  const midiasDisco = inspecionarMidiasPastaNovela(n);

  // TRAVA DEFINITIVA CONTRA PERDA ACIDENTAL DE VÍDEOS/IMAGENS JÁ GERADOS:
  if (midiasDisco.total > 0 && !forcarSubstituicao) {
    if (!String(texto || '').trim()) {
      return res.status(409).json({
        erro: `🛡️ Proteção Anti-Perda: "${n.nome}" já possui ${midiasDisco.videos.length} vídeo(s) e ${midiasDisco.referencias.length + midiasDisco.imagensBase.length} imagem(ns) gerados na pasta. O roteiro vazio foi bloqueado para não zerar sua novela.`,
        requerConfirmacao: true,
        midiasExistentes: {
          referencias: midiasDisco.referencias.length,
          imagensBase: midiasDisco.imagensBase.length,
          videos: midiasDisco.videos.length,
          total: midiasDisco.total,
        },
      });
    }
    const preParse = parseRoteiro(texto, { forcarElementos: n.forcarElementos });
    const novosIds = new Set(preParse.itens.map((i) => i.id));
    const refsDiscoMantidas = midiasDisco.referencias.filter((m) => novosIds.has(m.id)).length;
    const videosDiscoMantidos = midiasDisco.videos.filter((m) => novosIds.has(m.id)).length;
    // Se a novela já tem referências ou vídeos na pasta e o novo texto troca os personagens (0 refs em comum) ou derruba vídeos já prontos
    const trocouHistoriaInteira = midiasDisco.referencias.length >= 2 && refsDiscoMantidas === 0;
    const perdeVideosProntos = midiasDisco.videos.length > 0 && videosDiscoMantidos < midiasDisco.videos.length;
    if (trocouHistoriaInteira || perdeVideosProntos) {
      return res.status(409).json({
        erro: `🛡️ Proteção Anti-Perda: "${n.nome}" já possui ${midiasDisco.videos.length} vídeo(s), ${midiasDisco.imagensBase.length} imagem(ns)-base e ${midiasDisco.referencias.length} referência(s) prontos na pasta! O roteiro colado parece ser de outra história ou removeria mídias já geradas. Crie uma "+ Nova Novela" ou confirme a substituição.`,
        requerConfirmacao: true,
        midiasExistentes: {
          referencias: midiasDisco.referencias.length,
          imagensBase: midiasDisco.imagensBase.length,
          videos: midiasDisco.videos.length,
          total: midiasDisco.total,
        },
      });
    }
  }

  // Salva cópia automática roteiro_backup.txt antes de qualquer alteração
  if (n.roteiro && n.roteiro.trim()) {
    salvarBackupRoteiroNovela(n);
  }

  const r = mesclarRoteiroNovela(n, texto);
  salvarBackupRoteiroNovela(n, texto);
  store.salvar(n); emitirNovela(n);
  log(`Roteiro de "${n.nome}" processado (100% parser local): ${r.resumo.referencias} referências, ${r.resumo.imagensBase} imagens-base, ${r.resumo.videos} vídeos` +
    (r.validacao.erros.length ? ` — ${r.validacao.erros.length} erro(s) de validação!` : ''), r.validacao.erros.length ? 'aviso' : 'ok');

  // Auto-Fila Contínua entre Projetos: se o roteiro for válido e a fila global já estiver ativa (ou iniciarFila=true),
  // entra automaticamente no final da fila global de execução sem precisar clicar em "Rodar Fila"!
  let autoEnfileirada = false;
  const temPendentes = !ehNovelaConcluidaManual(n) && n.itens.some((i) => i.status === 'pendente' || i.status === 'na_fila' || i.status === 'erro');
  const filaAtiva = runner.rodando || runner.pausado || runner.fila.length > 0;
  if (r.validacao.ok && temPendentes && req.body?.autoEnfileirar !== false && (filaAtiva || req.body?.iniciarFila === true)) {
    if (n.serieSlug && n.numeroParte > 1) fabrica.herdarReferencias(n);
    const jaNaFila = runner.fila.some((f) => f.novelaId === n.id);
    runner.enfileirar([{ novelaId: n.id }], { preservarPausa: runner.pausado && !req.body?.iniciarFila });
    autoEnfileirada = true;
    const pos = runner.fila.findIndex((f) => f.novelaId === n.id) + 1;
    if (!jaNaFila) {
      log(`⚡ Auto-Fila: "${n.nome}" entrou automaticamente no final da fila global (posição #${pos || runner.fila.length}).`, 'ok');
    }
  }
  res.json({ ...n, autoEnfileirada, fila: runner.estado() });
}));

/**
 * Botão "🔄 Recuperar Mídias da Pasta":
 * Escaneia os .mp4 e imagens já salvos em Meus_Projetos_Flow/<pasta>, restaura roteiro_backup.txt (ou reconstrói
 * os blocos caso o roteiro tenha sido apagado/sobrescrito) e religa todos os itens concluídos na interface.
 */
app.post('/api/novelas/:id/recuperar-midias', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const base = store.pastaAbs(n);
  const midiasDisco = inspecionarMidiasPastaNovela(n);
  if (midiasDisco.total === 0) {
    throw new Error(`Nenhum arquivo .mp4 ou imagem encontrado na pasta Meus_Projetos_Flow\\${n.pasta}.`);
  }

  let textoBase = String(n.roteiro || '').trim();
  let roteiroRestauradoDeBackup = false;
  const arqBackup = path.join(base, 'roteiro_backup.txt');
  const txtBackup = fs.existsSync(arqBackup) ? fs.readFileSync(arqBackup, 'utf8').trim() : '';

  // Verifica se o roteiro atual casa com as referências/vídeos existentes no disco
  const idsAtuais = new Set((n.itens || []).map((i) => i.id));
  const refsBatendo = midiasDisco.referencias.filter((m) => idsAtuais.has(m.id)).length;
  const vidsBatendo = midiasDisco.videos.filter((m) => idsAtuais.has(m.id)).length;

  if ((!textoBase || (midiasDisco.referencias.length > 0 && refsBatendo === 0) || (midiasDisco.videos.length > 0 && vidsBatendo === 0)) && txtBackup) {
    const parseBk = parseRoteiro(txtBackup, { forcarElementos: n.forcarElementos });
    const idsBk = new Set(parseBk.itens.map((i) => i.id));
    const refsBk = midiasDisco.referencias.filter((m) => idsBk.has(m.id)).length;
    const vidsBk = midiasDisco.videos.filter((m) => idsBk.has(m.id)).length;
    if (refsBk >= refsBatendo && vidsBk >= vidsBatendo && (refsBk > 0 || vidsBk > 0)) {
      textoBase = txtBackup;
      roteiroRestauradoDeBackup = true;
    }
  }

  // Se ainda faltarem itens do disco no textoBase (ex.: roteiro foi apagado e não havia backup prévio), reconstrói os blocos a partir dos arquivos da pasta
  let parsed = textoBase ? parseRoteiro(textoBase, { forcarElementos: n.forcarElementos }) : { itens: [] };
  const idsParsed = new Set(parsed.itens.map((i) => i.id));
  const faltamNoRoteiro =
    midiasDisco.referencias.some((m) => !idsParsed.has(m.id)) ||
    midiasDisco.imagensBase.some((m) => !idsParsed.has(m.id)) ||
    midiasDisco.videos.some((m) => !idsParsed.has(m.id));

  if (faltamNoRoteiro) {
    const arqItensBk = path.join(base, 'itens_backup_concluido.json');
    const itensBk = fs.existsSync(arqItensBk) ? lerJson(arqItensBk, []) : [];
    const mapPrompts = new Map();
    for (const it of [...itensBk, ...(n.itens || []), ...(parsed.itens || [])]) {
      if (it?.id && it?.prompt && !mapPrompts.has(it.id)) {
        mapPrompts.set(it.id, { prompt: it.prompt, refs: it.refs || [] });
      }
    }

    const linhas = ['BLOCO 1 — REFERÊNCIAS', ''];
    const refIds = midiasDisco.referencias.map((r) => r.id);
    for (const r of midiasDisco.referencias) {
      const salvo = mapPrompts.get(r.id);
      linhas.push(`{${r.id}}`);
      linhas.push(`(i) ${salvo?.prompt || `Photorealistic vertical 9:16 reference portrait/scene for ${r.id}.`}`);
      linhas.push('');
    }
    linhas.push('BLOCO 2 — IMAGENS-BASE', '');
    for (const im of midiasDisco.imagensBase) {
      const salvo = mapPrompts.get(im.id);
      const refsIm = (salvo?.refs || []).filter((x) => refIds.includes(x));
      const refTag = refsIm.length ? refsIm.map((x) => `[${x}]`).join(' ') : (refIds[0] ? `[${refIds[0]}]` : '');
      linhas.push(`{${im.id}}`);
      linhas.push(`(i) ${refTag ? refTag + ' ' : ''}${salvo?.prompt || `Photorealistic vertical 9:16 scene frame for ${im.id}.`}`);
      linhas.push('');
    }
    linhas.push('BLOCO 3 — PROMPTS DE VÍDEO', '');
    const imgIds = midiasDisco.imagensBase.map((im) => im.id);
    for (const [idx, vd] of midiasDisco.videos.entries()) {
      const salvo = mapPrompts.get(vd.id);
      const numMatch = vd.id.match(/(\d+)/);
      const imgCand = numMatch ? `imagem_${String(numMatch[1]).padStart(2, '0')}` : imgIds[idx];
      const refsVd = (salvo?.refs || []).filter((x) => refIds.includes(x) || imgIds.includes(x));
      const tags = refsVd.length
        ? refsVd.map((x) => `[${x}]`).join(' ')
        : imgIds.includes(imgCand)
          ? `[${imgCand}]`
          : '';
      linhas.push(`{${vd.id}}`);
      linhas.push(`(v) ${tags ? tags + ' ' : ''}${salvo?.prompt || `Exactly 10 seconds, vertical 9:16 live-action TV drama scene for ${vd.id}.`}`);
      linhas.push('');
    }
    textoBase = linhas.join('\n').trim() + '\n';
    roteiroRestauradoDeBackup = true;
  }

  mesclarRoteiroNovela(n, textoBase, { religarArquivosDoDisco: true });
  salvarBackupRoteiroNovela(n, textoBase);
  store.salvar(n);
  emitirNovela(n);

  const refsReligadas = n.itens.filter((i) => i.tipo === 'referencia_imagem' && i.status === 'concluido').length;
  const imgsReligadas = n.itens.filter((i) => i.tipo === 'imagem_base' && i.status === 'concluido').length;
  const videosReligados = n.itens.filter((i) => i.tipo === 'video' && i.status === 'concluido').length;

  log(
    `🔄 Mídias recuperadas da pasta para "${n.nome}": ${videosReligados} vídeo(s), ${imgsReligadas} imagem(ns)-base e ${refsReligadas} referência(s) religados com sucesso!`,
    'ok'
  );

  res.json({
    ok: true,
    novela: n,
    roteiroRestauradoDeBackup,
    religados: {
      referencias: refsReligadas,
      imagensBase: imgsReligadas,
      videos: videosReligados,
      total: refsReligadas + imgsReligadas + videosReligados,
    },
  });
}));

function desbloquearDependentes(n, origemId) {
  const fila = [origemId];
  const vistos = new Set([origemId]);
  const desbloqueados = [];
  while (fila.length) {
    const idAtual = fila.shift();
    for (const d of n.itens) {
      if (vistos.has(d.id) || !d.refs?.includes(idAtual)) continue;
      vistos.add(d.id);
      if (d.status === 'bloqueado_dependencia') {
        d.status = 'pendente';
        d.erro = null;
        desbloqueados.push(d.id);
      }
      fila.push(d.id);
    }
  }
  return desbloqueados;
}

app.patch('/api/novelas/:id/itens/:itemId', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const it = n.itens.find((i) => i.id === req.params.itemId);
  if (!it) throw new Error('Item não encontrado.');
  const acao = req.body?.acao || (req.body?.restaurarPromptOriginal ? 'restaurar_original' : req.body?.suavizarComImagem ? 'suavizar_com_imagem' : req.body?.descritivoSemImagem ? 'descritivo_sem_imagem' : null);

  if (acao === 'marcar_feito_manual') {
    const base = store.pastaAbs(n);
    const nomeBase = path.basename(it.caminhoRelativo || it.id, path.extname(it.caminhoRelativo || ''));
    const pastaSub = it.pasta || (it.tipo === 'video' ? '03_Videos' : it.tipo === 'imagem_base' ? '02_Imagens_Base' : '01_Referencias');
    const candidatos = [it.arquivo, it.caminhoRelativo, ...['mp4', 'jpg', 'jpeg', 'png', 'webp'].map((e) => `${pastaSub}/${nomeBase}.${e}`)].filter(Boolean);
    const arqDisco = candidatos.find((c) => fs.existsSync(path.join(base, c))) || null;
    if (arqDisco) {
      it.arquivo = arqDisco;
      try {
        const st = fs.statSync(path.join(base, arqDisco));
        it.tamanhoBytes = st.size;
      } catch {}
    }
    it.status = 'concluido';
    it.feitoManual = true;
    it.erro = null;
    it.progresso = null;
    delete it.tentativaAtual;
    it.geradoEm = it.geradoEm || new Date().toISOString();
    desbloquearDependentes(n, it.id);
    log(`✅ {${it.id}} marcado como Feito manual em "${n.nome}".`, 'ok');
  } else if (acao === 'desmarcar_feito_manual') {
    it.feitoManual = false;
    it.status = 'pendente';
    it.erro = null;
    it.progresso = null;
    log(`↩️ {${it.id}} reaberto para geração em "${n.nome}".`, 'info');
  } else if (acao === 'restaurar_original') {
    restaurarItemOriginal(it, n);
    if (it.status === 'falha_revisar' || it.status === 'erro') { it.status = 'pendente'; it.erro = null; desbloquearDependentes(n, it.id); }
    log(`🔄 {${it.id}}: prompt e anexos originais restaurados.`, 'info');
  } else if (acao === 'suavizar_com_imagem') {
    aplicarSuavizacaoComImagem(n, it);
    it.status = 'pendente'; it.erro = null; desbloquearDependentes(n, it.id);
    log(`🛡️ {${it.id}}: refs extras removidas (mantida só imagem_XX) e gatilhos suavizados.`, 'aviso');
  } else if (acao === 'descritivo_sem_imagem') {
    aplicarModoDescritivoSemImagem(n, it);
    it.status = 'pendente'; it.erro = null; desbloquearDependentes(n, it.id);
    log(`📝 Última cartada em ${it.id}: imagens removidas (bloqueio de rosto no Flow) — tentando com Prompt 100% Descritivo de consistência visual...`, 'aviso');
  } else if (typeof req.body?.prompt === 'string') {
    it.prompt = req.body.prompt.trim();
    it.promptEditado = true;
    it.promptAutoAjustado = null;
    if (it.status === 'falha_revisar' || it.status === 'erro') { it.status = 'pendente'; it.erro = null; desbloquearDependentes(n, it.id); }
  }
  if (req.body?.duracao === 10 || req.body?.duracao === 15) it.duracao = req.body.duracao;
  store.salvar(n); emitirNovela(n);
  if (req.body?.rodar && it.status !== 'gerando') {
    runner.enfileirar([{ novelaId: n.id, itemIds: [it.id] }], { isoladoSePausado: true });
  }
  res.json(it);
}));

// Acao em lote para todos os itens falhos (falha_revisar / erro) da novela
app.post('/api/novelas/:id/itens-falhos/acao', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const acao = String(req.body?.acao || '');
  const rodar = req.body?.rodar !== false;
  const alvos = n.itens.filter((i) => {
    if (acao === 'restaurar_original') {
      return Boolean(i.promptOriginalBackup || i.originalPrompt || i.anexosOriginaisBackup || i.modoDescritivoSemImagem);
    }
    return (i.status === 'falha_revisar' || i.status === 'erro') && i.tipo === 'video';
  });
  if (!alvos.length) throw new Error('Nenhum item elegível para esta ação.');

  for (const it of alvos) {
    if (acao === 'suavizar_com_imagem') {
      aplicarSuavizacaoComImagem(n, it);
      it.status = 'pendente'; it.erro = null; desbloquearDependentes(n, it.id);
    } else if (acao === 'descritivo_sem_imagem') {
      aplicarModoDescritivoSemImagem(n, it);
      it.status = 'pendente'; it.erro = null; desbloquearDependentes(n, it.id);
      log(`📝 Última cartada em ${it.id}: imagens removidas (bloqueio de rosto no Flow) — tentando com Prompt 100% Descritivo de consistência visual...`, 'aviso');
    } else if (acao === 'restaurar_original') {
      restaurarItemOriginal(it, n);
      if (it.status === 'falha_revisar' || it.status === 'erro') { it.status = 'pendente'; it.erro = null; desbloquearDependentes(n, it.id); }
    } else {
      throw new Error(`Ação desconhecida: ${acao}`);
    }
  }
  store.salvar(n); emitirNovela(n);
  const ids = alvos.map((i) => i.id);
  if (rodar && acao !== 'restaurar_original') {
    runner.enfileirar([{ novelaId: n.id, itemIds: ids }], { isoladoSePausado: true });
  }
  res.json({ ok: true, alterados: ids, enfileirados: rodar && acao !== 'restaurar_original' ? ids : [] });
}));

// Arquivo ja salvo de um item (usado pela extensao para reenviar referencias ao Flow)
app.get('/api/novelas/:id/itens/:itemId/arquivo-bin', (req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const it = n.itens.find((i) => i.id === req.params.itemId);
  const abs = it?.arquivo ? path.join(store.pastaAbs(n), it.arquivo) : null;
  if (!abs || !fs.existsSync(abs)) return res.status(404).json({ erro: 'Arquivo não encontrado no PC.' });
  res.sendFile(abs);
});

// Baixar de novo um item ja gerado no Flow (sem gerar de novo), com a qualidade atual da novela
app.post('/api/novelas/:id/itens/:itemId/rebaixar', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const it = n.itens.find((i) => i.id === req.params.itemId);
  if (!it) throw new Error('Item não encontrado.');
  if (runner.rodando || runner.rebaixando) throw new Error('Aguarde a fila/download atual terminar.');
  if (!n.flowProjectUrl) throw new Error('Esta novela ainda não tem projeto no Flow.');
  runner.rebaixarItem(n.id, it.id).catch(() => {});
  res.json({ ok: true });
}));

// Re-capturar todos os videos ja gerados na pagina aberta do projeto no Google Flow (sem gastar creditos)
app.post('/api/novelas/:id/recapturar-videos', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  if (runner.rodando || runner.rebaixando) throw new Error('Aguarde a fila ou captura atual terminar.');
  if (!n.flowProjectUrl) throw new Error('Esta novela ainda não tem projeto criado no Google Flow.');
  const qtdVideos = (n.itens || []).filter((i) => i.tipo === 'video').length;
  if (!qtdVideos) throw new Error('Esta novela não possui cenas de vídeo no roteiro.');
  runner.recapturarVideosNovela(n.id).catch(() => {});
  res.json({ ok: true, cenas: qtdVideos });
}));

app.post('/api/novelas/:id/itens/:itemId/regerar', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const it = n.itens.find((i) => i.id === req.params.itemId);
  if (!it) throw new Error('Item não encontrado.');
  if (it.status === 'gerando') throw new Error('Este item já está sendo gerado.');
  const atualizarCapcut = Boolean(req.body?.atualizarCapcut);
  // desbloqueia dependentes que estavam parados esperando esta ref/imagem-base
  const desbloqueados = desbloquearDependentes(n, it.id);
  const pedidos = Array.isArray(req.body?.cascata) ? req.body.cascata : [];
  const cascata = n.itens
    .filter((i) => (pedidos.includes(i.id) || desbloqueados.includes(i.id)) && i.id !== it.id && i.status !== 'gerando')
    .map((i) => i.id);
  for (const alvo of [it, ...n.itens.filter((i) => cascata.includes(i.id))]) { alvo.status = 'pendente'; alvo.erro = null; }
  store.salvar(n); emitirNovela(n);
  log(
    `Regenerar${atualizarCapcut ? ' + CapCut ✂️' : ''} {${it.id}} de "${n.nome}"${
      cascata.length ? ` + cascata: ${cascata.map((c) => `{${c}}`).join(', ')}` : ''
    }${runner.pausado ? ' (execução isolada com fila global pausada)' : ''} adicionado à fila.`
  );
  runner.enfileirar([{ novelaId: n.id, itemIds: [it.id, ...cascata], atualizarCapcut }], { isoladoSePausado: true });
  res.json({ ok: true, cascata, atualizarCapcut, isolado: runner.pausado || runner.modoIsolado });
}));

// ---------------- CapCut PC ----------------
app.get('/api/capcut/status', (req, res) => res.json(detectarPastaCapcut(config().capcutDraftsPath)));

app.post('/api/novelas/:id/capcut', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const det = detectarPastaCapcut(config().capcutDraftsPath);
  if (!det.encontrada) throw new Error('Não encontrei a pasta de rascunhos do CapCut. Informe o caminho em ⚙ Padrões.');
  const base = store.pastaAbs(n);
  const mapVideos = new Map();
  for (const i of n.itens || []) {
    if (i.tipo !== 'video' || !i.arquivo) continue;
    const abs = path.join(base, i.arquivo);
    if (fs.existsSync(abs)) {
      mapVideos.set(path.basename(abs).toLowerCase(), { id: i.id, arquivoAbs: abs });
    }
  }
  // Inclui também todos os .mp4 que existirem fisicamente em 03_Videos (mesmo se a novela foi marcada como Concluída manualmente ou se um vídeo foi colocado manualmente na pasta)
  for (const vd of inspecionarMidiasPastaNovela(n).videos) {
    const k = path.basename(vd.abs).toLowerCase();
    if (!mapVideos.has(k)) {
      mapVideos.set(k, { id: vd.id, arquivoAbs: vd.abs });
    }
  }
  const videos = [...mapVideos.values()].sort((a, b) => compararNumerico(path.basename(a.arquivoAbs), path.basename(b.arquivoAbs)));
  const r = exportarParaCapcut({ novela: n, videos, pastaDrafts: det.pasta });
  n.capcut = { pasta: r.pasta, nomeProjeto: r.nomeProjeto, enviadoEm: new Date().toISOString(), cenas: r.cenas.length, duracaoSeg: +(r.duracaoTotalUs / 1e6).toFixed(2) };
  n.capcutExported = true;
  n.capcutDraftPath = r.pasta;
  store.salvar(n); emitirNovela(n);
  log(`CapCut: projeto "${r.nomeProjeto}" ${r.atualizado ? 'ATUALIZADO' : 'criado'} com ${r.cenas.length} cena(s), ${(r.duracaoTotalUs / 1e6).toFixed(1)}s (modelo de compatibilidade: ${r.modelo}, CapCut ${r.versaoCapcut}).`, 'ok');
  res.json(r);
}));

app.post('/api/novelas/:id/rodar', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  if (!n.itens.length) throw new Error('Processe o roteiro antes de rodar.');
  if (!n.validacao?.ok) throw new Error('O roteiro tem referências faltando ou erros. Corrija antes de rodar.');
  if (ehNovelaConcluidaManual(n)) {
    // Se o usuário clicou explicitamente em "Rodar" dentro desta novela específica, reabre automaticamente para rodar
    n.concluidaManualmente = false;
    n.statusManual = null;
    n.concluidaManualmenteEm = null;
    store.salvar(n);
    emitirNovela(n);
    log(`↩️ "${n.nome}" foi reaberta automaticamente ao clicar em Rodar.`, 'info');
  }
  const temPendentesNormais = n.itens.some((i) => i.status === 'pendente' || i.status === 'na_fila' || i.status === 'erro');
  if (!temPendentesNormais) {
    // Se so restaram itens falha_revisar / bloqueado_dependencia e o usuario clicou em Rodar, reativa-os para nova tentativa
    let reativados = 0;
    n.itens.forEach((i) => {
      if (i.status === 'falha_revisar' || i.status === 'bloqueado_dependencia') {
        i.status = 'pendente'; i.erro = null; reativados++;
      }
    });
    if (reativados) {
      store.salvar(n); emitirNovela(n);
      log(`Reativando ${reativados} item(ns) com revisão pendente em "${n.nome}".`, 'info');
    }
  }
  if (n.serieSlug && n.numeroParte > 1) fabrica.herdarReferencias(n); // Parte 2+: copia refs ja geradas da Parte 1
  log(`"${n.nome}" adicionada à fila.`);
  runner.enfileirar([{ novelaId: n.id }]);
  res.json(runner.estado());
}));

app.post('/api/fila/rodar', wrap((req, res) => {
  const temIdsExplicitos = Array.isArray(req.body?.novelaIds) && req.body.novelaIds.length > 0;
  // Se a fila estava pausada e o usuario clicou em "Rodar Fila" / "Retomar", preserva a novela pausada no topo e acrescenta eventuais novas novelas pendentes ao final (NUNCA puxando novelas marcadas como concluídas manualmente!)
  if (runner.pausado && !temIdsExplicitos && runner.fila.length > 0) {
    const jaNaFila = new Set(runner.fila.map((f) => f.novelaId));
    const extras = store.listar()
      .filter((n) => !ehNovelaConcluidaManual(n) && !jaNaFila.has(n.id) && n.validacao?.ok && n.itens.length && n.itens.some((i) => i.status !== 'concluido'))
      .map((n) => n.id);
    if (extras.length) {
      extras.forEach((id) => { const nv = store.obter(id); if (nv?.serieSlug && nv.numeroParte > 1) fabrica.herdarReferencias(nv); });
      runner.enfileirar(extras.map((novelaId) => ({ novelaId })), { preservarPausa: true });
    }
    return res.json(runner.retomar());
  }
  const ids = temIdsExplicitos
    ? req.body.novelaIds.filter((id) => !ehNovelaConcluidaManual(store.obter(id)))
    : store.listar().filter((n) => !ehNovelaConcluidaManual(n) && n.itens.some((i) => i.status !== 'concluido')).map((n) => n.id);
  const validas = ids.filter((id) => {
    const nv = store.obter(id);
    return nv && !ehNovelaConcluidaManual(nv) && nv.validacao?.ok && nv.itens.length;
  });
  const puladas = ids.filter((id) => !validas.includes(id)).map((id) => store.obter(id)?.nome).filter(Boolean);
  if (!validas.length) throw new Error('Nenhuma novela pronta com itens pendentes (processe e valide os roteiros).');
  if (puladas.length) log(`Puladas na fila geral (roteiro com erro ou vazio): ${puladas.join(', ')}`, 'aviso');
  validas.forEach((id) => { const nv = store.obter(id); if (nv?.serieSlug && nv.numeroParte > 1) fabrica.herdarReferencias(nv); });
  log(`Fila geral iniciada com ${validas.length} novela(s).`);
  runner.enfileirar(validas.map((novelaId) => ({ novelaId })));
  res.json(runner.estado());
}));

app.post('/api/fila/retomar', wrap((req, res) => {
  res.json(runner.retomar());
}));

app.post('/api/fila/pausar', (req, res) => { runner.pausar({ limpar: Boolean(req.body?.limpar) }); res.json(runner.estado()); });

app.post('/api/novelas/:id/abrir-pasta', wrap((req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  store.garantirPastas(n);
  const sub = ['01_Referencias', '02_Imagens_Base', '03_Videos'].includes(req.body?.sub) ? req.body.sub : '';
  const alvo = path.join(store.pastaAbs(n), sub);
  if (process.platform === 'win32') spawn('explorer.exe', [alvo], { detached: true, stdio: 'ignore' }).unref();
  else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [alvo], { detached: true, stdio: 'ignore' }).unref();
  res.json({ ok: true, pasta: alvo });
}));

// Upload manual/alternativo de arquivo gerado (base64 ou url)
app.post('/api/novelas/:id/itens/:itemId/arquivo', wrap(async (req, res) => {
  const n = novelaOu404(req, res); if (!n) return;
  const it = n.itens.find((i) => i.id === req.params.itemId);
  if (!it) throw new Error('Item não encontrado.');
  await runner.salvarResultado(n, it, req.body || {});
  it.status = 'concluido'; it.geradoEm = new Date().toISOString();
  store.salvar(n); emitirNovela(n); res.json(it);
}));

// Mapa DOM
app.get('/api/dom-map', (req, res) => res.json(lerJson(ARQ_DOM_MAP, { capturas: [] })));
app.post('/api/dom-map', wrap((req, res) => res.json(salvarDomMap(req.body || {}))));
app.post('/api/extensao/mapear', wrap(async (req, res) => {
  const r = await bridge.requisitar('mapear', { modo: req.body?.modo || 'novo', rotulo: req.body?.rotulo || '' }, 60000);
  res.json(r);
}));
app.post('/api/extensao/recarregar', wrap(async (req, res) => {
  const r = await bridge.requisitar('recarregar_extensao', {}, 10000).catch((e) => ({ ok: false, erro: e.message }));
  res.json(r);
}));

// Seletores calibrados (Etapa 3)
app.get('/api/seletores', (req, res) => res.json(seletores()));

app.get('/api/logs', (req, res) => res.json(logs));

// Midia gerada + interface
app.use('/media', express.static(PROJ, { dotfiles: 'deny', maxAge: 0 }));
if (fs.existsSync(DIST)) {
  app.use(express.static(DIST, { etag: false, maxAge: 0, setHeaders: (res) => res.set('Cache-Control', 'no-store, no-cache, must-revalidate') }));
  app.get(/^(?!\/api|\/media).*/, (req, res) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.sendFile(path.join(DIST, 'index.html'));
  });
} else {
  app.get('/', (req, res) => res.send('<h2 style="font-family:sans-serif">Interface não compilada. Rode <code>npm run build</code>.</h2>'));
}

// ---------------- HTTP + WebSocket -----------------
const server = http.createServer(app);
const wss = new WebSocketServer({ server, maxPayload: 1024 * 1024 * 1024 });

wss.on('connection', (ws, req) => {
  const origem = req.headers.origin;
  if (!origemPermitida(origem)) { ws.close(1008, 'Origem não permitida'); return; }
  if (!verificarPinReq(req)) { ws.close(4401, 'PIN exigido'); return; }
  let papel = null;
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));

  ws.on('message', async (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    const responder = (o) => ws.readyState === 1 && ws.send(JSON.stringify(o));

    switch (msg.type) {
      case 'hello':
        papel = msg.role === 'extension' ? 'extension' : 'ui';
        if (papel === 'extension') {
          const versaoExtensaoDisco = lerJson(path.join(ROOT, 'extensao-chrome', 'manifest.json'), {})?.version || null;
          bridge.anexar(ws, { versao: msg.versao, navegador: msg.navegador, flowAberto: !!msg.flowAberto });
          responder({ type: 'bem_vindo', app: 'Flow Novela Studio', seletores: seletores(), config: config(), versaoExtensaoDisco });
          log(`Extensão do Chrome conectada (v${msg.versao || '?'}).`, 'ok');
        } else {
          uiClients.add(ws);
          responder({ type: 'estado', novelas: store.listar(), extensao: bridge.estado(), fila: runner.estado(), domMap: resumoDomMap(), config: config(), claudeCli: detectarClaudeCli(), tunel: tunel.estadoPublico(), logs });
        }
        break;
      case 'ping':
        responder({ type: 'pong', t: Date.now() });
        break;
      case 'resposta':
        bridge.receberResposta(msg);
        break;
      case 'status_extensao':
        bridge.atualizarInfo({ flowAberto: !!msg.flowAberto, flowUrl: msg.flowUrl || null });
        break;
      case 'progresso': {
        const n = store.obter(msg.novelaId);
        const it = n?.itens.find((i) => i.id === msg.itemId);
        if (it) { it.progresso = msg.texto || null; emitirNovela(n); }
        break;
      }
      case 'log':
        log(`[Extensão] ${msg.msg}`, msg.nivel || 'info');
        break;
      case 'dom_map':
        try {
          const r = salvarDomMap(msg);
          responder({ type: 'dom_map_salvo', requestId: msg.requestId, ok: true, ...r });
        } catch (e) {
          responder({ type: 'dom_map_salvo', requestId: msg.requestId, ok: false, erro: e.message });
        }
        break;
      case 'clique_gravado':
        log(`[Gravação] clique em ${msg.descricao || 'elemento'}`);
        break;
    }
  });

  ws.on('close', () => {
    if (papel === 'extension') {
      const eraAtiva = bridge.socket === ws;
      bridge.desanexar(ws);
      if (eraAtiva) log('Extensão do Chrome desconectou.', 'aviso');
    }
    uiClients.delete(ws);
  });
  ws.on('error', () => {});
});

// heartbeat para detectar conexoes mortas
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
}, 15000);

// Recarrega seletores quando o arquivo muda e envia para a extensao
fs.watchFile(ARQ_SELETORES, { interval: 2000 }, () => {
  bridge.enviar({ type: 'seletores', seletores: seletores() });
  log('flow-selectors.json alterado — seletores reenviados para a extensão.');
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`\n[ERRO] A porta ${PORT} já está em uso. O Flow Novela Studio provavelmente já está aberto.\n`);
    process.exit(2);
  }
  console.error(e);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log('\n\x1b[35m==============================================\x1b[0m');
  console.log('\x1b[35m   FLOW NOVELA STUDIO\x1b[0m  rodando em \x1b[1mhttp://localhost:' + PORT + '\x1b[0m');
  console.log('   Dados:   ' + DADOS);
  console.log('   Mídias:  ' + PROJ);
  console.log('\x1b[35m==============================================\x1b[0m\n');
  log(`Servidor iniciado na porta ${PORT}. ${store.listar().length} novela(s) carregada(s).`, 'ok');
  // Fabrica: reconecta o WhatsApp se ja houver sessao salva, liga o vigia do CapCut e auto-inicia o Tunel HTTPS se configurado
  whatsapp.iniciarSeTiverSessao().catch(() => {});
  if (capcutWatcher.cfg.monitorAtivo) capcutWatcher.iniciar();
  if (tunel.cfg.autoIniciar) tunel.iniciar().catch((e) => log(`Túnel HTTPS auto-iniciar falhou: ${e.message}`, 'aviso'));
});

const encerrar = () => {
  log('Servidor encerrando...');
  capcutWatcher.parar();
  tunel.parar({ silencioso: true }).catch(() => {});
  whatsapp.desconectar({ apagarSessao: false }).catch(() => {});
  server.close();
  process.exit(0);
};
process.on('SIGINT', encerrar);
process.on('SIGTERM', encerrar);
