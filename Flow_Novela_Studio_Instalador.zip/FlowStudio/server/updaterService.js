// =========================================================================
//  Flow Novela Studio — Auto-Updater Nativo via GitHub (HTTPS puro, sem Git)
//  - Verifica version.json remoto com timeout estrito (3s no boot)
//  - Baixa Flow_Novela_Studio_Instalador.zip e atualiza APENAS codigo
//    (server/, web/dist/, extensao-chrome/, package.json, scripts de boot)
//  - Preserva 100% intactos: .env, dados/novelas/, Meus_Projetos_Flow/
// =========================================================================
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import https from 'node:https';
import http from 'node:http';
import crypto from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';

export function lerJsonSeguro(arq, padrao = null) {
  try {
    if (!fs.existsSync(arq)) return padrao;
    return JSON.parse(fs.readFileSync(arq, 'utf8').replace(/^\uFEFF/, ''));
  } catch {
    return padrao;
  }
}

export function compararSemver(vA, vB) {
  const limpar = (v) =>
    String(v || '0.0.0')
      .trim()
      .replace(/^v/i, '')
      .split('-')[0]
      .split('.')
      .map((n) => Number(n) || 0);
  const a = limpar(vA);
  const b = limpar(vB);
  const len = Math.max(a.length, b.length, 3);
  for (let i = 0; i < len; i++) {
    const na = a[i] || 0;
    const nb = b[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

export function lerVersionInfo(rootDir) {
  const arqVer = path.join(rootDir, 'version.json');
  const arqPkg = path.join(rootDir, 'package.json');
  const arqCfgUpdate = path.join(rootDir, 'dados', 'update_config.json');

  const ver = lerJsonSeguro(arqVer, {}) || {};
  const pkg = lerJsonSeguro(arqPkg, {}) || {};
  const cfg = lerJsonSeguro(arqCfgUpdate, {}) || {};

  const version = String(ver.version || pkg.version || '1.0.0').trim();
  const repo = String(
    process.env.GITHUB_UPDATE_REPO ||
    cfg.repo ||
    ver.repo ||
    ''
  ).trim();
  const branch = String(cfg.branch || ver.branch || 'main').trim();

  const versionUrl = String(
    process.env.GITHUB_VERSION_URL ||
    cfg.versionUrl ||
    ver.versionUrl ||
    (repo ? `https://raw.githubusercontent.com/${repo}/${branch}/version.json` : '')
  ).trim();

  const zipUrl = String(
    process.env.GITHUB_ZIP_URL ||
    cfg.zipUrl ||
    ver.zipUrl ||
    (repo ? `https://raw.githubusercontent.com/${repo}/${branch}/Flow_Novela_Studio_Instalador.zip` : '')
  ).trim();

  return {
    version,
    releasedAt: ver.releasedAt || null,
    notes: ver.notes || '',
    repo,
    branch,
    versionUrl,
    zipUrl,
  };
}

export function buscarJsonHttps(urlStr, timeoutMs = 3000, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (!urlStr) return reject(new Error('URL de atualização não configurada.'));
    const sep = urlStr.includes('?') ? '&' : '?';
    const urlComCacheBust = `${urlStr}${sep}_t=${Date.now()}`;
    let finalizado = false;
    const concluir = (fn, val) => {
      if (finalizado) return;
      finalizado = true;
      clearTimeout(timer);
      fn(val);
    };

    const timer = setTimeout(() => {
      try { req?.destroy(); } catch {}
      concluir(reject, new Error(`Timeout (${timeoutMs}ms) ao consultar atualização.`));
    }, timeoutMs);

    const mod = urlComCacheBust.startsWith('https:') ? https : http;
    const req = mod.get(
      urlComCacheBust,
      {
        headers: {
          'User-Agent': 'FlowNovelaStudio-Updater/1.1',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          Pragma: 'no-cache',
        },
      },
      (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          res.resume();
          if (maxRedirects <= 0) return concluir(reject, new Error('Muitos redirecionamentos HTTP.'));
          const destino = new URL(res.headers.location, urlComCacheBust).toString();
          clearTimeout(timer);
          finalizado = true;
          return buscarJsonHttps(destino, timeoutMs, maxRedirects - 1).then(resolve, reject);
        }
        if (res.statusCode !== 200) {
          res.resume();
          return concluir(reject, new Error(`HTTP ${res.statusCode} ao consultar version.json remoto.`));
        }
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          try {
            const txt = Buffer.concat(chunks).toString('utf8').replace(/^\uFEFF/, '');
            concluir(resolve, JSON.parse(txt));
          } catch (e) {
            concluir(reject, new Error(`JSON inválido no version.json remoto: ${e.message}`));
          }
        });
      }
    );
    req.on('error', (e) => concluir(reject, e));
  });
}

export function baixarArquivoHttps(urlStr, destinoAbs, timeoutMs = 60000, maxRedirects = 6) {
  return new Promise((resolve, reject) => {
    if (!urlStr) return reject(new Error('URL do pacote .zip não informada.'));
    const sep = urlStr.includes('?') ? '&' : '?';
    const urlFinal = maxRedirects === 6 ? `${urlStr}${sep}_t=${Date.now()}` : urlStr;
    let finalizado = false;
    const concluir = (fn, val) => {
      if (finalizado) return;
      finalizado = true;
      clearTimeout(timer);
      fn(val);
    };

    const timer = setTimeout(() => {
      try { req?.destroy(); } catch {}
      concluir(reject, new Error(`Timeout (${Math.round(timeoutMs / 1000)}s) ao baixar pacote de atualização.`));
    }, timeoutMs);

    const mod = urlFinal.startsWith('https:') ? https : http;
    const req = mod.get(
      urlFinal,
      {
        headers: {
          'User-Agent': 'FlowNovelaStudio-Updater/1.1',
          'Cache-Control': 'no-cache',
        },
      },
      (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          res.resume();
          if (maxRedirects <= 0) return concluir(reject, new Error('Muitos redirecionamentos no download do .zip.'));
          const destino = new URL(res.headers.location, urlFinal).toString();
          clearTimeout(timer);
          finalizado = true;
          return baixarArquivoHttps(destino, destinoAbs, timeoutMs, maxRedirects - 1).then(resolve, reject);
        }
        if (res.statusCode !== 200) {
          res.resume();
          return concluir(reject, new Error(`Falha ao baixar pacote de atualização (HTTP ${res.statusCode}).`));
        }
        fs.mkdirSync(path.dirname(destinoAbs), { recursive: true });
        const fileStream = fs.createWriteStream(destinoAbs);
        res.pipe(fileStream);
        fileStream.on('finish', () => {
          fileStream.close(() => {
            try {
              const sz = fs.statSync(destinoAbs).size;
              if (sz < 5000) return concluir(reject, new Error(`Arquivo .zip baixado parece incompleto (${sz} bytes).`));
              concluir(resolve, { arquivo: destinoAbs, tamanhoBytes: sz });
            } catch (e) {
              concluir(reject, e);
            }
          });
        });
        fileStream.on('error', (e) => {
          try { fs.unlinkSync(destinoAbs); } catch {}
          concluir(reject, e);
        });
      }
    );
    req.on('error', (e) => concluir(reject, e));
  });
}

export function calcularHashPasta(dirAbs) {
  if (!fs.existsSync(dirAbs)) return '';
  const hash = crypto.createHash('sha256');
  const visitar = (p) => {
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const item of fs.readdirSync(p).sort()) {
        visitar(path.join(p, item));
      }
    } else {
      hash.update(path.relative(dirAbs, p).replace(/\\/g, '/'));
      hash.update(fs.readFileSync(p));
    }
  };
  try {
    visitar(dirAbs);
    return hash.digest('hex');
  } catch {
    return '';
  }
}

export function calcularHashArquivo(arqAbs) {
  try {
    if (!fs.existsSync(arqAbs)) return '';
    return crypto.createHash('sha256').update(fs.readFileSync(arqAbs)).digest('hex');
  } catch {
    return '';
  }
}

export async function verificarAtualizacao({ rootDir, timeoutMs = 3000 } = {}) {
  const local = lerVersionInfo(rootDir);
  if (!local.versionUrl) {
    return {
      configurado: false,
      atualizacaoDisponivel: false,
      versaoLocal: local.version,
      versaoRemota: null,
      repo: local.repo || null,
      motivo: 'Repositório GitHub de distribuição ainda não configurado neste PC.',
    };
  }
  try {
    const remoto = await buscarJsonHttps(local.versionUrl, timeoutMs);
    const versaoRemota = String(remoto?.version || '').trim();
    if (!versaoRemota) {
      return {
        configurado: true,
        atualizacaoDisponivel: false,
        versaoLocal: local.version,
        versaoRemota: null,
        repo: remoto?.repo || local.repo,
        motivo: 'version.json remoto sem campo version.',
      };
    }
    const disponivel = compararSemver(versaoRemota, local.version) > 0;
    const repoEfetivo = remoto.repo || local.repo;
    const branchEfetivo = remoto.branch || local.branch || 'main';
    const zipUrl =
      remoto.zipUrl ||
      local.zipUrl ||
      (repoEfetivo ? `https://raw.githubusercontent.com/${repoEfetivo}/${branchEfetivo}/Flow_Novela_Studio_Instalador.zip` : '');
    return {
      configurado: true,
      atualizacaoDisponivel: disponivel,
      versaoLocal: local.version,
      versaoRemota,
      repo: repoEfetivo,
      zipUrl,
      notes: remoto.notes || '',
      releasedAt: remoto.releasedAt || null,
    };
  } catch (e) {
    return {
      configurado: true,
      atualizacaoDisponivel: false,
      versaoLocal: local.version,
      versaoRemota: null,
      repo: local.repo,
      erro: e.message,
    };
  }
}

function copiarRecursivoPreservandoDados(orig, dest) {
  if (!fs.existsSync(orig)) return;
  const st = fs.statSync(orig);
  if (st.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const nome of fs.readdirSync(orig)) {
      if (nome === '.env' || nome === 'node_modules' || nome === '.git') continue;
      copiarRecursivoPreservandoDados(path.join(orig, nome), path.join(dest, nome));
    }
  } else {
    if (path.basename(orig) === '.env') return;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(orig, dest);
  }
}

export async function aplicarAtualizacao({ rootDir, zipUrl = '', versaoAlvo = '', log = () => {} } = {}) {
  const local = lerVersionInfo(rootDir);
  let urlDownload = zipUrl || local.zipUrl;
  let infoVer = null;

  if (!urlDownload || !versaoAlvo) {
    infoVer = await verificarAtualizacao({ rootDir, timeoutMs: 6000 });
    if (infoVer.zipUrl) urlDownload = infoVer.zipUrl;
    if (!versaoAlvo && infoVer.versaoRemota) versaoAlvo = infoVer.versaoRemota;
  }
  if (!urlDownload) {
    throw new Error('URL do pacote de atualização (zipUrl) não configurada.');
  }

  const ts = Date.now();
  const tmpZip = path.join(os.tmpdir(), `fns_update_${ts}.zip`);
  const tmpExtract = path.join(os.tmpdir(), `fns_update_extract_${ts}`);

  try {
    log(`⬇️ Baixando atualização ${versaoAlvo ? `v${versaoAlvo} ` : ''}do GitHub...`);
    await baixarArquivoHttps(urlDownload, tmpZip, 60000);

    fs.rmSync(tmpExtract, { recursive: true, force: true });
    fs.mkdirSync(tmpExtract, { recursive: true });

    const psUnzip = `
      Add-Type -AssemblyName System.IO.Compression.FileSystem
      [System.IO.Compression.ZipFile]::ExtractToDirectory('${tmpZip.replace(/'/g, "''")}', '${tmpExtract.replace(/'/g, "''")}')
    `;
    execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psUnzip], {
      windowsHide: true,
      stdio: 'ignore',
    });

    const origemRaiz = fs.existsSync(path.join(tmpExtract, 'FlowStudio', 'package.json'))
      ? path.join(tmpExtract, 'FlowStudio')
      : tmpExtract;

    if (!fs.existsSync(path.join(origemRaiz, 'server', 'index.js'))) {
      throw new Error('Pacote de atualização inválido (server/index.js não encontrado no ZIP).');
    }

    const hashExtAntes = calcularHashPasta(path.join(rootDir, 'extensao-chrome'));
    const hashPkgAntes = calcularHashArquivo(path.join(rootDir, 'package.json'));

    // 1) Atualiza pastas de código (NUNCA toca em .env, dados/novelas/ ou Meus_Projetos_Flow/)
    for (const pastaCodigo of ['server', 'web', 'extensao-chrome']) {
      const origPasta = path.join(origemRaiz, pastaCodigo);
      if (fs.existsSync(origPasta)) {
        copiarRecursivoPreservandoDados(origPasta, path.join(rootDir, pastaCodigo));
      }
    }
    // Caso o ZIP tenha pasta 'extension', espelha também em 'extensao-chrome'
    if (fs.existsSync(path.join(origemRaiz, 'extension')) && !fs.existsSync(path.join(origemRaiz, 'extensao-chrome'))) {
      copiarRecursivoPreservandoDados(path.join(origemRaiz, 'extension'), path.join(rootDir, 'extensao-chrome'));
    }

    // 2) Atualiza arquivos de código e scripts de boot na raiz (preservando .env)
    const arquivosBoot = [
      'package.json',
      'package-lock.json',
      'version.json',
      'launcher.mjs',
      'gerar_pacote.mjs',
      'publicar_update.mjs',
      'INICIAR_APP.vbs',
      'INICIAR_STUDIO.bat',
      'Iniciar_Flow_Studio.bat',
      'Iniciar_Invisivel.vbs',
      'Subir_Servidor_Oculto.bat',
      'Parar_Flow_Studio.bat',
      'INSTALAR_TUDO.bat',
      'INSTALAR.bat',
      '1_INSTALAR_PRIMEIRA_VEZ.bat',
      'GERAR_PACOTE_AMIGO.bat',
      'PUBLICAR_ATUALIZACAO.bat',
      'LEIA-ME_COMO_USAR.txt',
      'flow-studio.ico',
    ];
    for (const arq of arquivosBoot) {
      const origArq = path.join(origemRaiz, arq);
      if (fs.existsSync(origArq)) {
        fs.copyFileSync(origArq, path.join(rootDir, arq));
      }
    }

    // Seletores calibrados do Flow (se presentes no pacote)
    const origSel = path.join(origemRaiz, 'dados', 'flow-selectors.json');
    if (fs.existsSync(origSel)) {
      fs.mkdirSync(path.join(rootDir, 'dados'), { recursive: true });
      fs.copyFileSync(origSel, path.join(rootDir, 'dados', 'flow-selectors.json'));
    }

    const hashExtDepois = calcularHashPasta(path.join(rootDir, 'extensao-chrome'));
    const hashPkgDepois = calcularHashArquivo(path.join(rootDir, 'package.json'));
    const extensaoMudou = Boolean(hashExtAntes && hashExtDepois && hashExtAntes !== hashExtDepois);
    const packageMudou = Boolean(hashPkgAntes !== hashPkgDepois);

    // 3) Se package.json mudou ou faltar node_modules, roda npm install silenciosamente
    const temExpress = fs.existsSync(path.join(rootDir, 'node_modules', 'express', 'package.json'));
    if (packageMudou || !temExpress) {
      log('📦 package.json alterado — atualizando dependências (npm install)...');
      const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
      spawnSync(npmCmd, ['install', '--no-audit', '--no-fund'], {
        cwd: rootDir,
        windowsHide: true,
        stdio: 'ignore',
      });
    }

    // Salva o hash atual do package.json para o launcher.mjs
    try {
      fs.mkdirSync(path.join(rootDir, 'dados'), { recursive: true });
      fs.writeFileSync(path.join(rootDir, 'dados', '.package_hash'), hashPkgDepois, 'utf8');
    } catch {}

    const novaInfo = lerVersionInfo(rootDir);
    log(`✅ Atualização concluída com sucesso (${local.version} → ${novaInfo.version})! Dados e .env preservados.`);

    return {
      ok: true,
      versaoAnterior: local.version,
      versaoNova: novaInfo.version,
      extensaoMudou,
      packageMudou,
    };
  } finally {
    try { fs.rmSync(tmpZip, { force: true }); } catch {}
    try { fs.rmSync(tmpExtract, { recursive: true, force: true }); } catch {}
  }
}
