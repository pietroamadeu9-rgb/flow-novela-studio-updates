// =============================================================
//  Exportador para o CapCut PC: cria/atualiza um rascunho com todos os
//  videos da novela em ordem, na trilha principal, canvas 9:16 (1080x1920).
//  Usa como MODELO um projeto real do CapCut instalado (mesmo schema/versao).
// =============================================================
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { lerMp4 } from './mp4.js';

const MARCADOR = 'flow_novela_studio.json';
const REFS_CLONAVEIS = new Set(['speeds', 'placeholder_infos', 'canvases', 'sound_channel_mappings', 'material_colors', 'vocal_separations', 'material_animations', 'beats']);

const uuidMaiusculo = () => crypto.randomUUID().toUpperCase();
const agoraUs = () => Date.now() * 1000;
const barras = (p) => String(p).replace(/\\/g, '/');
const clonar = (o) => JSON.parse(JSON.stringify(o));
const lerJson = (f) => JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, ''));

function escreverAtomico(arquivo, dados) {
  const tmp = arquivo + '.tmp-fns';
  fs.writeFileSync(tmp, typeof dados === 'string' ? dados : JSON.stringify(dados), 'utf8');
  try { fs.renameSync(tmp, arquivo); } catch { fs.copyFileSync(tmp, arquivo); try { fs.unlinkSync(tmp); } catch {} }
}

// ---------------- Deteccao da pasta de rascunhos ----------------
export function detectarPastaCapcut(caminhoConfigurado) {
  const home = os.homedir() || process.env.USERPROFILE || '';
  const local = process.env.LOCALAPPDATA || (home ? path.join(home, 'AppData', 'Local') : '');
  const candidatos = [];
  if (caminhoConfigurado) candidatos.push({ pasta: caminhoConfigurado, origem: 'configurado em ⚙ Padrões' });
  // caminho customizado definido no proprio CapCut (Configuracoes > Rascunhos)
  for (const gs of [path.join(local, 'CapCut', 'User Data', 'Config', 'globalSetting')]) {
    try {
      const m = fs.readFileSync(gs, 'utf8').match(/currentCustomDraftPath=(.+)/);
      if (m) candidatos.push({ pasta: m[1].trim().replace(/\\\\/g, '\\'), origem: 'globalSetting do CapCut' });
    } catch {}
  }
  candidatos.push({ pasta: path.join(local, 'CapCut', 'User Data', 'Projects', 'com.lveditor.draft'), origem: 'padrão do CapCut PC' });
  candidatos.push({ pasta: path.join(local, 'CapCut Drafts'), origem: 'CapCut Drafts' });
  try {
    for (const pkg of fs.readdirSync(path.join(local, 'Packages')).filter((n) => /capcut/i.test(n))) {
      candidatos.push({ pasta: path.join(local, 'Packages', pkg, 'LocalCache', 'Local', 'CapCut', 'User Data', 'Projects', 'com.lveditor.draft'), origem: 'Microsoft Store' });
    }
  } catch {}
  for (const c of candidatos) {
    if (!c.pasta || !fs.existsSync(c.pasta)) continue;
    const root = path.join(c.pasta, 'root_meta_info.json');
    let projetos = 0;
    try { projetos = fs.readdirSync(c.pasta, { withFileTypes: true }).filter((d) => d.isDirectory()).length; } catch {}
    let rootPath = null;
    try { rootPath = lerJson(root).root_path || null; } catch {}
    return { encontrada: true, pasta: c.pasta, origem: c.origem, projetos, temRootMeta: fs.existsSync(root), rootPath, candidatos: candidatos.map((x) => x.pasta) };
  }
  return { encontrada: false, pasta: null, candidatos: candidatos.map((x) => x.pasta) };
}

// ---------------- Limpeza 100% crua (ZERO aprimoramento automatico no CapCut) ----------------
const CHAVES_APRIMORAMENTO_EXTRAS = [
  'enable_video_ostr',
  'video_quality_enhance',
  'hd_enhance',
  'sharpness',
  'color_match',
  'beauty',
  'super_resolution',
  'noise_reduction',
  'deflicker',
];

/**
 * Remove 100% de qualquer configuracao de "Aprimorar qualidade" / QualityEnhance / HD / Super Resolution /
 * Nitidez / Reducao de ruido / Ajuste de cor / Beleza do material de video do CapCut.
 * Garante que o clipe entre na timeline 100% cru/original exatamente como saiu do Google Flow.
 */
export function limparMaterialVideoCru(mat) {
  if (!mat || typeof mat !== 'object') return mat;
  mat.unique_id = '';
  mat.reverse_path = '';
  mat.intensifies_path = '';
  mat.reverse_intensifies_path = '';
  mat.intensifies_audio_path = '';
  mat.cartoon_path = '';
  mat.formula_id = '';
  mat.extra_type_option = 0;
  mat.is_unified_beauty_mode = false;
  mat.is_set_beauty_mode = false;
  mat.beauty_face_preset_infos = [];
  mat.beauty_body_preset_id = '';
  mat.beauty_face_auto_preset = { preset_id: '', name: '', rate_map: '', scene: '' };
  mat.beauty_face_auto_preset_infos = [];
  mat.beauty_body_auto_preset = null;
  mat.smart_motion = null;
  mat.smart_match_info = null;
  mat.object_locked = null;
  mat.freeze = null;
  mat.pre_applied_vip_materials = [];
  if (mat.stable && typeof mat.stable === 'object') {
    mat.stable = { stable_level: 0, matrix_path: '', time_range: { start: 0, duration: 0 } };
  }
  if (mat.matting && typeof mat.matting === 'object') {
    Object.assign(mat.matting, {
      flag: 0,
      path: '',
      interactiveTime: [],
      has_use_quick_brush: false,
      strokes: [],
      has_use_quick_eraser: false,
      expansion: 0,
      feather: 0,
      reverse: false,
      custom_matting_id: '',
      enable_matting_stroke: false,
      is_clould: false,
      mask_video_path: '',
      cloud_product_fps: 0,
      usage: '',
    });
  }
  if ('video_algorithm' in mat || mat.video_algorithm) {
    mat.video_algorithm = {
      ...(mat.video_algorithm && typeof mat.video_algorithm === 'object' ? mat.video_algorithm : {}),
      algorithms: [],
      time_range: null,
      path: '',
      gameplay_configs: [],
      ai_in_painting_config: [],
      complement_frame_config: null,
      motion_blur_config: null,
      deflicker: null,
      noise_reduction: null,
      quality_enhance: null,
      super_resolution: null,
      ai_background_configs: [],
      smart_complement_frame: null,
      aigc_generate: null,
      aigc_generate_list: [],
      mouth_shape_driver: null,
      ai_expression_driven: null,
      ai_motion_driven: null,
      image_interpretation: null,
      story_video_modify_video_config: {
        task_id: '',
        is_overwrite_last_video: false,
        tracker_task_id: '',
        generate_id: '',
        generate_card_id: '',
      },
      skip_algorithm_index: [],
    };
    for (const k of CHAVES_APRIMORAMENTO_EXTRAS) {
      if (k in mat.video_algorithm) mat.video_algorithm[k] = null;
    }
  }
  for (const k of CHAVES_APRIMORAMENTO_EXTRAS) {
    if (k in mat) {
      mat[k] = typeof mat[k] === 'boolean' ? false : typeof mat[k] === 'number' ? 0 : null;
    }
  }
  return mat;
}

/**
 * Remove qualquer flag de ajuste de cor automatico, beleza, HDR vivid, ostr ou nitidez do segmento da timeline.
 */
export function limparSegmentoVideoCru(seg) {
  if (!seg || typeof seg !== 'object') return seg;
  Object.assign(seg, {
    speed: 1,
    volume: 1,
    last_nonzero_volume: 1,
    reverse: false,
    is_loop: false,
    is_tone_modify: false,
    intensifies_audio: false,
    cartoon: false,
    visible: true,
    enable_hsl: false,
    enable_smart_color_adjust: false,
    enable_color_match_adjust: false,
    enable_color_correct_adjust: false,
    enable_color_adjust_pro: false,
    enable_adjust_mask: false,
    enable_mask_stroke: false,
    enable_mask_shadow: false,
    color_correct_alg_result: '',
    hdr_vivid_settings: null,
    clip: {
      scale: { x: 1, y: 1 },
      rotation: 0,
      rotation3d: [],
      transform: { x: 0, y: 0 },
      flip: { vertical: false, horizontal: false },
      alpha: 1,
    },
    uniform_scale: { on: true, value: 1 },
  });
  for (const k of CHAVES_APRIMORAMENTO_EXTRAS) {
    if (k in seg) {
      seg[k] = typeof seg[k] === 'boolean' ? false : typeof seg[k] === 'number' ? 0 : null;
    }
  }
  return seg;
}

/**
 * Limpa existing Flow Studio drafts no CapCut que tenham herdado `quality_enhance` / `QualityEnhance` de projetos-modelo.
 */
export function limparAprimoramentoDraftsFlow(pastaDrafts) {
  if (!pastaDrafts || !fs.existsSync(pastaDrafts)) return { limpos: 0 };
  let limpos = 0;
  try {
    const dirs = fs.readdirSync(pastaDrafts, { withFileTypes: true }).filter((d) => d.isDirectory());
    for (const d of dirs) {
      const dirAbs = path.join(pastaDrafts, d.name);
      if (!fs.existsSync(path.join(dirAbs, MARCADOR))) continue;
      let alterouDraft = false;
      for (const arq of arquivosConteudo(dirAbs)) {
        try {
          const c = lerJson(arq);
          let mudouArq = false;
          for (const v of c.materials?.videos || []) {
            const va = v.video_algorithm;
            if (va && (va.quality_enhance !== null || (Array.isArray(va.algorithms) && va.algorithms.length > 0) || va.path || va.time_range || va.super_resolution || va.noise_reduction || va.deflicker)) {
              mudouArq = true;
            }
            limparMaterialVideoCru(v);
          }
          for (const t of c.tracks || []) {
            if (t.type !== 'video') continue;
            for (const s of t.segments || []) {
              if (s.enable_smart_color_adjust || s.enable_color_match_adjust || s.enable_color_correct_adjust || s.enable_color_adjust_pro || s.enable_video_ostr) {
                mudouArq = true;
              }
              s.enable_smart_color_adjust = false;
              s.enable_color_match_adjust = false;
              s.enable_color_correct_adjust = false;
              s.enable_color_adjust_pro = false;
              if ('enable_video_ostr' in s) s.enable_video_ostr = false;
            }
          }
          if (mudouArq) {
            escreverAtomico(arq, JSON.stringify(c));
            alterouDraft = true;
          }
        } catch {}
      }
      const pastaVideoAlg = path.join(dirAbs, 'Resources', 'videoAlg');
      if (fs.existsSync(pastaVideoAlg)) {
        try { fs.rmSync(pastaVideoAlg, { recursive: true, force: true }); alterouDraft = true; } catch {}
      }
      if (alterouDraft) limpos++;
    }
  } catch {}
  return { limpos };
}

// ---------------- Projeto modelo (schema do CapCut instalado) ----------------
function acharModelo(pastaDrafts) {
  const dirs = fs.readdirSync(pastaDrafts, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => ({ nome: d.name, abs: path.join(pastaDrafts, d.name) }))
    .filter((d) => !fs.existsSync(path.join(d.abs, MARCADOR)))
    .map((d) => ({ ...d, t: fs.statSync(d.abs).mtimeMs }))
    .sort((a, b) => b.t - a.t);
  let fallbackComAlg = null;
  for (const d of dirs.slice(0, 80)) {
    try {
      const c = lerJson(path.join(d.abs, 'draft_content.json'));
      const vid = c.materials?.videos?.find((v) => v.type === 'video' && v.path);
      const trilha = c.tracks?.find((t) => t.type === 'video' && t.segments?.some((s) => s.material_id === vid?.id));
      if (!vid || !trilha) continue;
      const seg = trilha.segments.find((s) => s.material_id === vid.id);
      let meta = null, project = null;
      try { meta = lerJson(path.join(d.abs, 'draft_meta_info.json')); } catch {}
      try { project = lerJson(path.join(d.abs, 'Timelines', 'project.json')); } catch {}
      const temAprimoramento = Boolean(
        vid.video_algorithm?.quality_enhance ||
        (Array.isArray(vid.video_algorithm?.algorithms) && vid.video_algorithm.algorithms.length > 0) ||
        vid.video_algorithm?.super_resolution ||
        vid.video_algorithm?.noise_reduction
      );
      const candidato = {
        nome: d.nome,
        abs: d.abs,
        conteudo: c,
        video: limparMaterialVideoCru(clonar(vid)),
        trilha,
        segmento: limparSegmentoVideoCru(clonar(seg)),
        meta,
        project,
      };
      if (!temAprimoramento) return candidato;
      if (!fallbackComAlg) fallbackComAlg = candidato;
    } catch {}
  }
  return fallbackComAlg;
}

/** Modelo base portatil (usado caso o CapCut tenha acabado de ser instalado e ainda nao tenha projetos com video). */
function modeloPadrao() {
  const listasMateriais = [
    'flowers', 'videos', 'tail_leaders', 'audios', 'images', 'texts', 'effects', 'stickers', 'canvases',
    'transitions', 'audio_effects', 'audio_fades', 'beats', 'material_animations', 'placeholders',
    'placeholder_infos', 'speeds', 'common_mask', 'chromas', 'text_templates', 'realtime_denoises',
    'audio_pannings', 'audio_pitch_shifts', 'video_trackings', 'hsl', 'drafts', 'color_curves',
    'hsl_curves', 'primary_color_wheels', 'log_color_wheels', 'video_effects', 'ai_text_effects',
    'audio_balances', 'handwrites', 'manual_deformations', 'manual_beautys', 'plugin_effects',
    'sound_channel_mappings', 'green_screens', 'shapes', 'material_colors', 'digital_humans',
    'digital_human_model_dressing', 'smart_crops', 'ai_translates', 'audio_track_indexes', 'loudnesses',
    'vocal_beautifys', 'vocal_separations', 'smart_relights', 'time_marks', 'multi_language_refs',
    'video_shadows', 'video_strokes', 'video_radius',
  ];
  const materials = Object.fromEntries(listasMateriais.map((k) => [k, []]));
  const speedId = 'SPEED_PADRAO';
  materials.speeds.push({ id: speedId, type: 'speed', mode: 0, speed: 1, curve_speed: null });
  const video = {
    id: '', unique_id: '', type: 'video', duration: 0, path: '', media_path: '', local_id: '',
    has_audio: true, width: 1080, height: 1920, category_id: '', category_name: 'local', material_id: '',
    material_name: '', material_url: '', extra_type_option: 0, source: 0, source_platform: 0, check_flag: 63487,
    crop: { upper_left_x: 0, upper_left_y: 0, upper_right_x: 1, upper_right_y: 0, lower_left_x: 0, lower_left_y: 1, lower_right_x: 1, lower_right_y: 1 },
    crop_ratio: 'free', crop_scale: 1, audio_fade: null, local_material_id: '',
  };
  const segmento = {
    id: '', material_id: '', source_timerange: { start: 0, duration: 0 }, target_timerange: { start: 0, duration: 0 },
    render_timerange: { start: 0, duration: 0 }, desc: '', state: 0, speed: 1, is_loop: false, is_tone_modify: false,
    reverse: false, intensifies_audio: false, cartoon: false, volume: 1, last_nonzero_volume: 1,
    clip: { scale: { x: 1, y: 1 }, rotation: 0, transform: { x: 0, y: 0 }, flip: { vertical: false, horizontal: false }, alpha: 1 },
    uniform_scale: { on: true, value: 1 }, extra_material_refs: [speedId], render_index: 0, keyframe_refs: [],
    enable_lut: true, enable_adjust: true, enable_hsl: false, visible: true, group_id: '',
    enable_color_curves: true, enable_hsl_curves: true, track_render_index: 0,
    hdr_settings: { mode: 1, intensity: 1, nits: 1000 }, enable_color_wheels: true, track_attribute: 0,
    is_placeholder: false, template_id: '', enable_smart_color_adjust: false, template_scene: 'default',
    common_keyframes: [], source: 'segmentsourcenormal', enable_video_mask: true,
  };
  const trilha = { id: '', type: 'video', segments: [], flag: 0, attribute: 0, name: '', is_default_name: true };
  const conteudo = {
    id: '', version: 360000, new_version: '110.0.0', name: '', duration: 0, create_time: 0, update_time: 0,
    fps: 30, is_drop_frame_timecode: false, color_space: 0,
    config: { adjust_max_index: 1, attachment_info: [], combination_max_index: 1, export_range: null, extract_audio_last_index: 1, lyrics_recognition_id: '', lyrics_sync: true, lyrics_taskinfo: [], maintrack_adsorb: true, material_save_mode: 0, multi_language_current: 'none', multi_language_list: [], multi_language_main: 'none', multi_language_mode: 'none', original_sound_last_index: 1, record_audio_last_index: 1, sticker_max_index: 1, subtitle_keywords_config: null, subtitle_recognition_id: '', subtitle_sync: true, subtitle_taskinfo: [], system_font_list: [], video_mute: false, zoom_info_params: null },
    canvas_config: { ratio: '9:16', width: 1080, height: 1920, background: null },
    tracks: [trilha], group_container: null, materials,
    keyframes: { adjusts: [], audios: [], effects: [], filters: [], handwrites: [], stickers: [], texts: [], videos: [] },
    keyframe_graph_list: [],
    platform: { os: 'windows', app_id: 359289, app_source: 'cc', device_id: '', hard_disk_id: '', mac_address: '' },
    last_modified_platform: { os: 'windows', app_id: 359289, app_source: 'cc', device_id: '', hard_disk_id: '', mac_address: '' },
    mutable_config: null, cover: null, retouch_cover: null, extra_info: null, relationships: [],
    mixed_track_mode_on: false, render_index_track_mode_on: false, free_render_index_mode_on: false,
    static_cover_image_path: '', source: 'default', time_marks: null, path: '', lyrics_effects: [],
  };
  return { nome: 'schema-padrao-integrado', abs: '', conteudo, video, trilha, segmento, meta: null, project: null };
}

/** Acha o material referenciado e o nome do array em materials. */
function acharRef(materials, id) {
  for (const [k, v] of Object.entries(materials)) {
    if (Array.isArray(v)) { const f = v.find((x) => x?.id === id); if (f) return { chave: k, obj: f }; }
  }
  return null;
}

// ---------------- Atualizacao cirurgica de UMA cena ----------------
const normCaminho = (p) => barras(path.resolve(String(p || ''))).toLowerCase();

/** Arquivos draft_content.json do rascunho (raiz + timelines). */
function arquivosConteudo(pastaDraft) {
  const lista = [path.join(pastaDraft, 'draft_content.json')];
  const tl = path.join(pastaDraft, 'Timelines');
  try {
    for (const d of fs.readdirSync(tl, { withFileTypes: true })) {
      if (d.isDirectory()) lista.push(path.join(tl, d.name, 'draft_content.json'));
    }
  } catch {}
  return lista.filter((f) => fs.existsSync(f));
}

/** Localiza a pasta de rascunho do CapCut correspondente a uma novela (pelo capcutDraftPath, flow_novela_studio.json ou nome da pasta). */
export function localizarDraftNovela({ novela, pastaDrafts = null, caminhoConfigurado = null } = {}) {
  if (novela?.capcutDraftPath && fs.existsSync(novela.capcutDraftPath)) return novela.capcutDraftPath;
  if (novela?.capcut?.pasta && fs.existsSync(novela.capcut.pasta)) return novela.capcut.pasta;
  const raiz = pastaDrafts || detectarPastaCapcut(caminhoConfigurado)?.pasta || null;
  if (!raiz || !fs.existsSync(raiz) || !novela) return null;

  const nomeSeguro = String(novela.nome || '').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').trim();
  if (nomeSeguro) {
    for (const cand of [path.join(raiz, nomeSeguro), path.join(raiz, `${nomeSeguro} (Flow Studio)`)]) {
      if (fs.existsSync(path.join(cand, 'draft_content.json'))) return cand;
    }
  }
  try {
    for (const d of fs.readdirSync(raiz, { withFileTypes: true })) {
      if (!d.isDirectory()) continue;
      const arqMarcador = path.join(raiz, d.name, MARCADOR);
      if (!fs.existsSync(arqMarcador)) continue;
      const m = lerJson(arqMarcador);
      if (m?.novelaId && m.novelaId === novela.id) return path.join(raiz, d.name);
    }
  } catch {}
  return null;
}

function casarMaterialVideo(mat, { alvosNorm, nomeArquivoLower }) {
  if (!mat) return false;
  if (mat.path && alvosNorm.has(normCaminho(mat.path))) return true;
  const basePath = mat.path ? path.basename(String(mat.path)).toLowerCase() : '';
  const baseMat = String(mat.material_name || '').toLowerCase();
  return Boolean(nomeArquivoLower && (basePath === nomeArquivoLower || baseMat === nomeArquivoLower));
}

function ajustarConteudo(c, criterios, info, aviso) {
  const mats = (c.materials?.videos || []).filter((m) => casarMaterialVideo(m, criterios));
  if (!mats.length) return { achou: false, caminhosMateriais: [] };
  const res = { achou: true, segmentos: 0, delta: 0, cortados: 0, caminhosMateriais: [] };
  const TOL = 40000; // ~1 frame
  for (const mat of mats) {
    if (mat.path) res.caminhosMateriais.push(mat.path);
    if (criterios.novoCaminhoPadrao) mat.path = barras(criterios.novoCaminhoPadrao);
    const antigo = Number(mat.duration) || 0;
    const novo = info.duracaoUs;
    mat.duration = novo;
    if (info.largura) mat.width = info.largura;
    if (info.altura) mat.height = info.altura;
    if (typeof info.temAudio === 'boolean') mat.has_audio = info.temAudio;
    limparMaterialVideoCru(mat);
    for (const trilha of c.tracks || []) {
      for (const seg of [...(trilha.segments || [])].sort((a, b) => a.target_timerange.start - b.target_timerange.start)) {
        if (seg.material_id !== mat.id) continue;
        res.segmentos++;
        const src = seg.source_timerange, tgt = seg.target_timerange;
        const velocidade = Number(seg.speed) || 1;
        const intacto = src.start === 0 && Math.abs(src.duration - antigo) <= TOL && Math.abs(velocidade - 1) < 1e-6 && Math.abs(tgt.duration - src.duration) <= TOL;
        let delta = 0;
        const fimAntigo = tgt.start + tgt.duration;
        if (intacto) {
          delta = novo - tgt.duration;
          src.duration = novo;
          tgt.duration = novo;
        } else if (src.start + src.duration > novo) {
          // segmento cortado manualmente que passou do fim do novo video: encurta sem criar buraco
          res.cortados++;
          const novaSrc = Math.max(0, novo - src.start);
          const novaTgt = Math.round(novaSrc / velocidade);
          delta = novaTgt - tgt.duration;
          src.duration = novaSrc;
          tgt.duration = novaTgt;
        } else {
          res.cortados++;
          aviso?.('Cena com corte manual mantida como está (só o arquivo foi trocado).');
        }
        if (delta) {
          // desloca tudo que vinha DEPOIS desta cena (todas as trilhas: legendas/efeitos acompanham)
          for (const t of c.tracks || []) {
            for (const s of t.segments || []) {
              if (s !== seg && s.target_timerange.start >= fimAntigo - TOL / 4) s.target_timerange.start += delta;
            }
          }
          res.delta += delta;
        }
      }
    }
  }
  // duracao total = fim do ultimo segmento
  let fim = 0;
  for (const t of c.tracks || []) for (const s of t.segments || []) fim = Math.max(fim, s.target_timerange.start + s.target_timerange.duration);
  c.duration = fim;
  return res;
}

function copiarVideoParaDraft(origemAbs, destinoAbs) {
  if (!origemAbs || !destinoAbs || normCaminho(origemAbs) === normCaminho(destinoAbs)) return destinoAbs;
  fs.mkdirSync(path.dirname(destinoAbs), { recursive: true });
  const tmp = `${destinoAbs}.tmp-fns`;
  fs.copyFileSync(origemAbs, tmp);
  try {
    fs.renameSync(tmp, destinoAbs);
  } catch {
    try {
      fs.copyFileSync(tmp, destinoAbs);
    } finally {
      try { fs.unlinkSync(tmp); } catch {}
    }
  }
  return destinoAbs;
}

/**
 * Atualiza SO a cena do arquivo regenerado dentro de um rascunho ja existente,
 * preservando cortes/legendas/efeitos das outras cenas. Faz backup .bak antes de salvar.
 */
export function atualizarCenaCapcut({ pastaDraft, arquivoAbs, itemId = null }) {
  if (!pastaDraft || !fs.existsSync(pastaDraft)) return { ok: false, motivo: 'rascunho não existe mais no CapCut' };
  if (!arquivoAbs || !fs.existsSync(arquivoAbs)) return { ok: false, motivo: 'arquivo de vídeo regenerado não encontrado' };
  const info = lerMp4(arquivoAbs);
  const nomeArquivo = path.basename(arquivoAbs);
  const nomeArquivoLower = nomeArquivo.toLowerCase();
  const caminhoMidiaDraft = path.join(pastaDraft, 'Resources', 'flow_media', nomeArquivo);
  const alvosNorm = new Set([
    normCaminho(arquivoAbs),
    normCaminho(caminhoMidiaDraft),
  ]);

  // Se o marcador flow_novela_studio.json tiver o mapeamento da cena, inclui seus caminhos conhecidos
  const arqMarcador = path.join(pastaDraft, MARCADOR);
  let dadosMarcador = null;
  if (fs.existsSync(arqMarcador)) {
    try {
      dadosMarcador = lerJson(arqMarcador);
      for (const cena of dadosMarcador?.cenas || []) {
        if ((itemId && cena.id === itemId) || (cena.arquivo && path.basename(cena.arquivo).toLowerCase() === nomeArquivoLower)) {
          if (cena.arquivo) alvosNorm.add(normCaminho(cena.arquivo));
          if (cena.arquivoOriginal) alvosNorm.add(normCaminho(cena.arquivoOriginal));
          if (cena.arquivoDraft) alvosNorm.add(normCaminho(cena.arquivoDraft));
        }
      }
    } catch {}
  }

  // Se o rascunho usa pasta de midia propria (Resources/flow_media), atualiza a copia fisica dentro do projeto do CapCut
  let novoCaminhoPadrao = null;
  if (fs.existsSync(path.join(pastaDraft, 'Resources', 'flow_media')) || fs.existsSync(caminhoMidiaDraft)) {
    try {
      copiarVideoParaDraft(arquivoAbs, caminhoMidiaDraft);
      novoCaminhoPadrao = caminhoMidiaDraft;
      alvosNorm.add(normCaminho(caminhoMidiaDraft));
    } catch {
      // Se o CapCut estiver com lock no arquivo do draft, aponta para o arquivo atualizado da pasta da novela
      novoCaminhoPadrao = arquivoAbs;
    }
  }

  const criterios = { alvosNorm, nomeArquivoLower, novoCaminhoPadrao };
  const avisos = new Set();
  let resumo = null;
  let duracaoFinal = null;
  for (const arq of arquivosConteudo(pastaDraft)) {
    let c;
    try { c = lerJson(arq); } catch { continue; }
    const r = ajustarConteudo(c, criterios, info, (m) => avisos.add(m));
    if (!r.achou) continue;
    // Se o material apontava para outro arquivo dentro da pasta do draft, garante que esse arquivo fisico tambem foi sobrescrito
    for (const pMat of r.caminhosMateriais || []) {
      const absMat = path.resolve(String(pMat));
      if (normCaminho(absMat).startsWith(normCaminho(pastaDraft)) && normCaminho(absMat) !== normCaminho(arquivoAbs)) {
        try { copiarVideoParaDraft(arquivoAbs, absMat); } catch {}
      }
    }
    fs.copyFileSync(arq, arq + '.bak');
    escreverAtomico(arq, JSON.stringify(c));
    if (!resumo || arq.endsWith(path.join(pastaDraft, 'draft_content.json'))) { resumo = r; duracaoFinal = c.duration; }
  }
  if (!resumo) return { ok: false, motivo: 'esta cena não está na timeline desse projeto do CapCut' };

  // draft_meta_info.json: duracao/dimensoes do material e duracao total
  const metaArq = path.join(pastaDraft, 'draft_meta_info.json');
  const agora = agoraUs();
  try {
    const meta = lerJson(metaArq);
    fs.copyFileSync(metaArq, metaArq + '.bak');
    for (const g of meta.draft_materials || []) {
      for (const v of g.value || []) {
        const baseMeta = v.file_Path ? path.basename(String(v.file_Path)).toLowerCase() : String(v.extra_info || '').toLowerCase();
        if ((v.file_Path && alvosNorm.has(normCaminho(v.file_Path))) || (nomeArquivoLower && baseMeta === nomeArquivoLower)) {
          if (novoCaminhoPadrao) v.file_Path = barras(novoCaminhoPadrao);
          v.duration = info.duracaoUs;
          if (info.largura) v.width = info.largura;
          if (info.altura) v.height = info.altura;
          v.roughcut_time_range = { duration: info.duracaoUs, start: 0 };
        }
      }
    }
    if (duracaoFinal != null) meta.tm_duration = duracaoFinal;
    meta.tm_draft_modified = agora;
    escreverAtomico(metaArq, meta);
  } catch {}

  if (dadosMarcador && Array.isArray(dadosMarcador.cenas)) {
    try {
      for (const cena of dadosMarcador.cenas) {
        if ((itemId && cena.id === itemId) || (cena.arquivo && path.basename(cena.arquivo).toLowerCase() === nomeArquivoLower)) {
          cena.duracaoUs = info.duracaoUs;
          cena.arquivoOriginal = barras(arquivoAbs);
          if (novoCaminhoPadrao) {
            cena.arquivo = barras(novoCaminhoPadrao);
            cena.arquivoDraft = barras(novoCaminhoPadrao);
          }
        }
      }
      dadosMarcador.atualizadoEm = new Date().toISOString();
      escreverAtomico(arqMarcador, dadosMarcador);
    } catch {}
  }

  // indice do CapCut (duracao exibida na tela inicial)
  try {
    const pastaDrafts = path.dirname(pastaDraft);
    const rootArq = path.join(pastaDrafts, 'root_meta_info.json');
    const root = lerJson(rootArq);
    const e = (root.all_draft_store || []).find((x) => normCaminho(x.draft_fold_path) === normCaminho(pastaDraft));
    if (e) {
      fs.copyFileSync(rootArq, rootArq + '.bak');
      if (duracaoFinal != null) e.tm_duration = duracaoFinal;
      e.tm_draft_modified = agora;
      escreverAtomico(rootArq, root);
    }
  } catch {}

  return {
    ok: true, duracaoUs: info.duracaoUs, deltaUs: resumo.delta, segmentos: resumo.segmentos, cortados: resumo.cortados,
    duracaoTotalUs: duracaoFinal, avisos: [...avisos], aberto: fs.existsSync(path.join(pastaDraft, '.locked')),
  };
}

// ---------------- Exportacao ----------------
/**
 * @param {{novela:object, pastaNovela:string, videos:Array<{id:string, arquivoAbs:string}>, pastaDrafts:string}} p
 */
export function exportarParaCapcut({ novela, videos, pastaDrafts }) {
  if (!pastaDrafts || !fs.existsSync(pastaDrafts)) throw new Error('Pasta de rascunhos do CapCut não encontrada. Configure em ⚙ Padrões.');
  if (!videos.length) throw new Error('Nenhum vídeo concluído em 03_Videos para enviar.');
  try { limparAprimoramentoDraftsFlow(pastaDrafts); } catch {}
  const modelo = acharModelo(pastaDrafts) || modeloPadrao();

  // leitura real dos MP4 (duracao exata em microssegundos + dimensoes)
  const clipes = videos.map((v) => {
    const info = lerMp4(v.arquivoAbs);
    return { ...v, ...info, bytes: fs.statSync(v.arquivoAbs).size, nomeArquivo: path.basename(v.arquivoAbs) };
  });

  // pasta do projeto: cria ou ATUALIZA (se ja foi criada pelo estudio)
  const nomeSeguro = String(novela.nome).replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').trim() || 'Novela';
  let nomeProjeto = nomeSeguro;
  let dir = path.join(pastaDrafts, nomeProjeto);
  if (fs.existsSync(dir) && !fs.existsSync(path.join(dir, MARCADOR))) {
    nomeProjeto = `${nomeSeguro} (Flow Studio)`;
    dir = path.join(pastaDrafts, nomeProjeto);
  }
  const atualizando = fs.existsSync(path.join(dir, MARCADOR));
  let anterior = {};
  if (atualizando) { try { anterior = lerJson(path.join(dir, MARCADOR)); } catch {} }
  const draftId = anterior.draftId || uuidMaiusculo();
  const timelineId = uuidMaiusculo();
  const t0 = anterior.criadoEmUs || agoraUs();
  const tAgora = agoraUs();

  // Copia física dos vídeos para a pasta de mídia isolada do projeto no CapCut
  // (assim "🔄 Regenerar" normal na pasta do Estúdio não afeta o rascunho do CapCut, e só "🔄✂️ Regenerar + CapCut" substitui no projeto!)
  const pastaMidiaDraft = path.join(dir, 'Resources', 'flow_media');
  fs.mkdirSync(pastaMidiaDraft, { recursive: true });
  for (const cl of clipes) {
    const destinoDraft = path.join(pastaMidiaDraft, cl.nomeArquivo);
    try {
      copiarVideoParaDraft(cl.arquivoAbs, destinoDraft);
      cl.arquivoDraft = destinoDraft;
    } catch {
      cl.arquivoDraft = cl.arquivoAbs;
    }
  }

  // ----- draft_content.json a partir do modelo -----
  const m = modelo.conteudo;
  const c = clonar(m);
  c.id = timelineId;
  c.name = '';
  c.create_time = 0;
  c.update_time = 0;
  c.canvas_config = { ...(c.canvas_config || {}), ratio: '9:16', width: 1080, height: 1920, background: null };
  for (const k of Object.keys(c.materials)) if (Array.isArray(c.materials[k])) c.materials[k] = [];
  if (c.keyframes && typeof c.keyframes === 'object') for (const k of Object.keys(c.keyframes)) if (Array.isArray(c.keyframes[k])) c.keyframes[k] = [];
  c.relationships = [];
  c.group_container = null;
  c.cover = null;
  c.static_cover_image_path = '';
  if ('time_marks' in c) c.time_marks = null;

  const segmentos = [];
  let cursor = 0;
  for (const cl of clipes) {
    const mat = limparMaterialVideoCru(clonar(modelo.video));
    Object.assign(mat, {
      id: uuidMaiusculo(),
      unique_id: '',
      path: barras(cl.arquivoDraft || cl.arquivoAbs),
      media_path: '',
      duration: cl.duracaoUs,
      width: cl.largura || 1080,
      height: cl.altura || 1920,
      material_name: cl.nomeArquivo,
      has_audio: cl.temAudio,
      local_material_id: crypto.randomUUID(),
      crop: { upper_left_x: 0, upper_left_y: 0, upper_right_x: 1, upper_right_y: 0, lower_left_x: 0, lower_left_y: 1, lower_right_x: 1, lower_right_y: 1 },
      crop_ratio: 'free',
      crop_scale: 1,
    });
    limparMaterialVideoCru(mat);
    c.materials.videos.push(mat);

    // materiais auxiliares (velocidade, canvas, canal de som...) clonados do modelo de forma 100% crua
    const refs = [];
    for (const r of modelo.segmento.extra_material_refs || []) {
      const achado = acharRef(m.materials, r);
      if (!achado || !REFS_CLONAVEIS.has(achado.chave)) continue;
      const novo = clonar(achado.obj);
      novo.id = uuidMaiusculo();
      if (achado.chave === 'speeds') { novo.speed = 1; novo.mode = 0; novo.curve_speed = null; }
      if (achado.chave === 'material_animations') novo.animations = [];
      if (achado.chave === 'canvases') { novo.color = ''; novo.blur = 0; novo.image = ''; novo.album_image = ''; novo.image_id = ''; novo.image_name = ''; }
      if (achado.chave === 'sound_channel_mappings') { novo.audio_channel_mapping = 0; novo.is_config_open = false; }
      if (achado.chave === 'material_colors') { novo.is_color_clip = false; novo.is_gradient = false; novo.solid_color = ''; novo.gradient_colors = []; novo.gradient_percents = []; }
      if (achado.chave === 'vocal_separations') { novo.choice = 0; novo.removed_sounds = []; novo.time_range = null; novo.production_path = ''; novo.final_algorithm = ''; novo.enter_from = ''; }
      c.materials[achado.chave].push(novo);
      refs.push(novo.id);
    }

    const seg = limparSegmentoVideoCru(clonar(modelo.segmento));
    Object.assign(seg, {
      id: uuidMaiusculo(),
      material_id: mat.id,
      source_timerange: { start: 0, duration: cl.duracaoUs },
      target_timerange: { start: cursor, duration: cl.duracaoUs },
      render_timerange: { start: 0, duration: 0 },
      speed: 1,
      volume: 1,
      last_nonzero_volume: 1,
      reverse: false,
      is_loop: false,
      visible: true,
      extra_material_refs: refs,
      keyframe_refs: [],
      common_keyframes: [],
      render_index: 0,
      track_render_index: 0,
      group_id: '',
      clip: { scale: { x: 1, y: 1 }, rotation: 0, rotation3d: [], transform: { x: 0, y: 0 }, flip: { vertical: false, horizontal: false }, alpha: 1 },
      uniform_scale: { on: true, value: 1 },
    });
    limparSegmentoVideoCru(seg);
    segmentos.push(seg);
    cursor += cl.duracaoUs;
  }
  const trilha = clonar(modelo.trilha);
  Object.assign(trilha, { id: uuidMaiusculo(), segments: segmentos, flag: 0, attribute: 0 });
  c.tracks = [trilha];
  c.duration = cursor;

  // Remove eventual cache de algoritmos de aprimoramento (videoAlg) do rascunho
  const pastaVideoAlg = path.join(dir, 'Resources', 'videoAlg');
  if (fs.existsSync(pastaVideoAlg)) {
    try { fs.rmSync(pastaVideoAlg, { recursive: true, force: true }); } catch {}
  }

  // ----- arquivos do projeto -----
  fs.mkdirSync(path.join(dir, 'Timelines', timelineId), { recursive: true });
  // limpa timelines antigas geradas pelo estudio (recria limpo)
  if (atualizando) {
    for (const d of fs.readdirSync(path.join(dir, 'Timelines'), { withFileTypes: true })) {
      if (d.isDirectory() && d.name !== timelineId) { try { fs.rmSync(path.join(dir, 'Timelines', d.name), { recursive: true, force: true }); } catch {} }
    }
    for (const f of ['draft_content.json.bak', 'template.tmp', 'template-2.tmp']) { try { fs.unlinkSync(path.join(dir, f)); } catch {} }
  }
  const conteudoStr = JSON.stringify(c);
  escreverAtomico(path.join(dir, 'draft_content.json'), conteudoStr);
  escreverAtomico(path.join(dir, 'Timelines', timelineId, 'draft_content.json'), conteudoStr);

  const project = modelo.project ? clonar(modelo.project) : { config: { color_space: -1, hdr_vivid: false, mixed_track_mode_on: false, render_index_track_mode_on: false, use_float_render: false }, version: 0 };
  Object.assign(project, {
    create_time: t0, update_time: tAgora, id: uuidMaiusculo(), main_timeline_id: timelineId,
    timelines: [{ create_time: t0, id: timelineId, is_marked_delete: false, name: 'Linha do tempo 01', update_time: tAgora }],
  });
  escreverAtomico(path.join(dir, 'Timelines', 'project.json'), project);

  const dirBarras = barras(dir);
  const rootBarras = barras(pastaDrafts);
  const meta = modelo.meta ? clonar(modelo.meta) : {};
  const entradaModelo = modelo.meta?.draft_materials?.find((x) => x.type === 0)?.value?.find((v) => v.metetype === 'video') || {};
  const seg = Math.floor(tAgora / 1e6);
  Object.assign(meta, {
    draft_cover: '',
    draft_fold_path: dirBarras,
    draft_id: draftId,
    draft_name: nomeProjeto,
    draft_root_path: rootBarras,
    draft_new_version: meta.draft_new_version ?? '',
    draft_materials: (modelo.meta?.draft_materials || [{ type: 0 }, { type: 1 }, { type: 2 }, { type: 3 }, { type: 6 }, { type: 7 }, { type: 8 }]).map((grupo) => ({
      type: grupo.type,
      value: grupo.type !== 0 ? [] : clipes.map((cl, i) => ({
        ...clonar(entradaModelo),
        ai_group_type: '', create_time: seg, duration: cl.duracaoUs, enter_from: 0, extra_info: cl.nomeArquivo,
        file_Path: barras(cl.arquivoDraft || cl.arquivoAbs), height: cl.altura, width: cl.largura, id: crypto.randomUUID(),
        import_time: seg, import_time_ms: tAgora + i, item_source: 1, md5: '', metetype: 'video',
        roughcut_time_range: { duration: cl.duracaoUs, start: 0 }, sub_time_range: { duration: -1, start: -1 }, type: 0,
      })),
    })),
    tm_draft_create: t0,
    tm_draft_modified: tAgora,
    tm_draft_removed: 0,
    tm_duration: cursor,
  });
  const tamTotal = clipes.reduce((s, cl) => s + cl.bytes, 0);
  if ('draft_timeline_materials_size_' in meta) meta.draft_timeline_materials_size_ = tamTotal;
  else meta.draft_timeline_materials_size = tamTotal;
  escreverAtomico(path.join(dir, 'draft_meta_info.json'), meta);
  if (!fs.existsSync(path.join(dir, 'draft_settings'))) {
    escreverAtomico(path.join(dir, 'draft_settings'), `[General]\r\ndraft_create_time=${Math.floor(t0 / 1e6)}\r\ndraft_last_edit_time=${seg}\r\nreal_edit_seconds=0\r\nreal_edit_keys=0\r\n`);
  }
  escreverAtomico(path.join(dir, MARCADOR), {
    app: 'Flow Novela Studio', novelaId: novela.id, draftId, criadoEmUs: t0, atualizadoEm: new Date().toISOString(),
    cenas: clipes.map((cl) => ({
      id: cl.id,
      arquivo: cl.arquivoDraft || cl.arquivoAbs,
      arquivoOriginal: cl.arquivoAbs,
      arquivoDraft: cl.arquivoDraft || cl.arquivoAbs,
      duracaoUs: cl.duracaoUs,
    })),
    modelo: modelo.nome,
  });

  // ----- indice root_meta_info.json (com backup) -----
  const rootArq = path.join(pastaDrafts, 'root_meta_info.json');
  let registrouIndice = false;
  if (fs.existsSync(rootArq)) {
    const original = path.join(pastaDrafts, 'root_meta_info.json.flowstudio-original.bak');
    if (!fs.existsSync(original)) fs.copyFileSync(rootArq, original);
    fs.copyFileSync(rootArq, rootArq + '.bak');
    const root = lerJson(rootArq);
    const lista = Array.isArray(root.all_draft_store) ? root.all_draft_store : [];
    const modeloEntrada = lista.find((e) => barras(e.draft_fold_path) === barras(modelo.abs)) || lista[0] || {};
    const entrada = {
      ...clonar(modeloEntrada),
      draft_cover: `${dirBarras}\\draft_cover.jpg`,
      draft_fold_path: dirBarras,
      draft_id: draftId,
      draft_is_invisible: false,
      draft_json_file: `${dirBarras}\\draft_content.json`,
      draft_name: nomeProjeto,
      draft_root_path: rootBarras,
      draft_timeline_materials_size: tamTotal,
      tm_draft_create: t0,
      tm_draft_modified: tAgora,
      tm_draft_removed: 0,
      tm_duration: cursor,
    };
    const semEste = lista.filter((e) => barras(e.draft_fold_path) !== dirBarras && e.draft_id !== draftId);
    root.all_draft_store = [entrada, ...semEste];
    if ('draft_ids' in root) root.draft_ids = root.all_draft_store.length;
    escreverAtomico(rootArq, root);
    registrouIndice = true;
  }

  return {
    ok: true, atualizado: atualizando, pasta: dir, nomeProjeto, draftId, modelo: modelo.nome, versaoCapcut: m.new_version,
    duracaoTotalUs: cursor, registrouIndice,
    cenas: clipes.map((cl) => ({ id: cl.id, arquivo: cl.nomeArquivo, duracaoSeg: +(cl.duracaoUs / 1e6).toFixed(3), largura: cl.largura, altura: cl.altura })),
  };
}
