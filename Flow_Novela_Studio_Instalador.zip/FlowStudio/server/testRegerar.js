// Testa "🔄 Gerar Novamente" (regerarParte) SEM gastar tokens: o Claude e substituido por um "dublê".
// Garante que o roteiro antigo NUNCA fica preso na pasta enquanto o Claude trabalha, que "Ler Só Diálogos"/Importar ficam
// bloqueados durante a reescrita, e que a versão anterior só volta se o Claude falhar/for cancelado.
//   node server/testRegerar.js
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'regerar-'));
const fabrica = path.join(tmp, 'Fabrica');
process.env.FABRICA_DIR = fabrica; // ANTES de importar os modulos
fs.mkdirSync(path.join(fabrica, "prompts"), { recursive: true });
for (const f of ["prompt_mestre_roteirista.md", "prompt_extrator_ficha.md"]) fs.copyFileSync(path.join("C:/FabricaClaude/prompts", f), path.join(fabrica, "prompts", f));
const pasta = path.join(fabrica, 'prontos_para_flow', 'teste', 'parte_01');
const BLOCO1 = '{ref_ana} -> (i) vertical 9:16 close-up of Ana.\n{ref_cenario_sala} -> (i) vertical 9:16 empty room with no people.';
const reset = () => {
  fs.rmSync(path.join(fabrica, 'prontos_para_flow'), { recursive: true, force: true });
  fs.mkdirSync(pasta, { recursive: true });
  fs.writeFileSync(path.join(pasta, 'roteiro_humano.md'), '# Teste — Parte 1 de 1\n## CENA 01 (15s) — Gancho\nANA [brava]: "ROTEIRO ANTIGO: papel velho não prova nada."\n');
  fs.writeFileSync(path.join(pasta, 'prompts_flow.txt'), `BLOCO 1 — REFERÊNCIAS\n${BLOCO1}\n\nBLOCO 2 — IMAGENS-BASE\n{imagem_01} -> (i) [ref_ana] x\n\nBLOCO 3 — PROMPTS DE VÍDEO\n{Cena 01} -> (v) [imagem_01] Exactly 15 seconds y\n`);
  fs.writeFileSync(path.join(pasta, 'metadata_flow.json'), JSON.stringify({ titulo: 'Teste', referenciasNovas: ['ref_ana'] }));
  fs.writeFileSync(path.join(pasta, 'legenda_facebook.txt'), 'a\nb 💔\n\n#filme #novela\n');
  fs.writeFileSync(path.join(pasta, 'continuidade_cenas.md'), '| Cena | Onde | Quem | Transição |\n|---|---|---|---|\n| 01 | ref_cenario_sala (INTERIOR) | ANA | x |\n');
};
reset();

const { Store } = await import('./store.js');
const { FabricaService } = await import('./fabricaService.js');
const { matarArvore } = await import('./claudeBridge.js');

let ok = 0;
const teste = async (nome, fn) => { try { await fn(); ok++; console.log(`  ✓ ${nome}`); } catch (e) { console.log(`  ✗ ${nome}\n    ${e.message}`); process.exitCode = 1; } };
const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
const logs = [];
const dados = path.join(tmp, 'dados');
fs.mkdirSync(dados, { recursive: true });
const store = new Store(dados, path.join(dados, 'proj'));
const novoSvc = () => new FabricaService({ store, log: (m, n) => logs.push({ m, n }), emitirNovela: () => {}, broadcastUI: () => {}, obterPadroes: () => ({}) });
const esperarFim = async (svc, id) => { for (let i = 0; i < 200; i++) { const j = svc.jobs.get(id); if (j.estado !== 'rodando') return j; await dormir(25); } throw new Error('job não terminou'); };
const ROTEIRO_NOVO = '# Teste — Parte 1 de 1\nRelação exata: x\n## CENA 01 (15s) — Gancho\nANA [brava]: "ROTEIRO NOVO: você pegou o dinheiro do meu remédio?"\n';
const pedido = { slug: 'teste', parte: 1, tipoFinal: 'fechado', reaproveitarRefs: true, importar: false };

console.log('\n[1] Sucesso: o roteiro antigo SAI da pasta antes do Claude e o novo aparece só no fim');
await teste('versão antiga é MOVIDA (não copiada) para _versoes/v_*, Bloco 1 vai para bloco1_refs_backup.txt, Ler Diálogos/Importar/Gerar Novamente ficam bloqueados e o texto novo aparece no fim', async () => {
  reset();
  const svc = novoSvc();
  let durante = null;
  svc.rodarClaude = async (job, prompt) => {
    if (durante) { durante.promptB = prompt; return 'RESULTADO_JSON: {"slug":"teste","parte":1}'; } // 2a chamada (Etapa 2/2): só a 1a observa o estado da pasta
    durante = {
      roteiroNaPasta: fs.existsSync(path.join(pasta, 'roteiro_humano.md')),
      promptsNaPasta: fs.existsSync(path.join(pasta, 'prompts_flow.txt')),
      backup: fs.readFileSync(path.join(pasta, 'bloco1_refs_backup.txt'), 'utf8'),
      versoes: fs.readdirSync(path.join(pasta, '_versoes')),
      prompt,
      regerando: svc.listarProntos().find((x) => x.slug === 'teste' && x.parte === 1)?.regerando,
    };
    assert.throws(() => svc.dialogos('teste', 1), /reescrevendo esta parte agora/);
    assert.throws(() => svc.importar({ slug: 'teste', parte: 1 }), /sendo reescrita/);
    assert.throws(() => svc.regerarParte(pedido), /JÁ está sendo reescrita/);
    await dormir(30);
    fs.writeFileSync(path.join(pasta, 'roteiro_humano.md'), ROTEIRO_NOVO);
    fs.writeFileSync(path.join(pasta, 'prompts_flow.txt'), 'BLOCO 1 — REFERÊNCIAS\n');
    return 'RESULTADO_JSON: {"slug":"teste","parte":1}';
  };
  const j = svc.regerarParte(pedido);
  const fim = await esperarFim(svc, j.id);
  assert.equal(fim.estado, 'ok', fim.erro);
  assert.equal(durante.roteiroNaPasta, false, 'o roteiro antigo continuou na pasta enquanto o Claude trabalhava!');
  assert.equal(durante.promptsNaPasta, false);
  assert.ok(durante.backup.includes('{ref_ana}') && durante.backup.includes('{ref_cenario_sala}'), 'Bloco 1 literal não foi guardado');
  assert.ok(/^v_/.test(durante.versoes[0]), `pasta de versão deve ser v_TIMESTAMP (achei ${durante.versoes})`);
  assert.ok(durante.regerando?.jobId, 'listarProntos deve marcar a parte como regerando');
  assert.ok(/BLOCO 1 DE REFERÊNCIAS FIXAS/.test(durante.promptB || '') && /\{ref_ana\} -> \(i\)/.test(durante.promptB || '') && /PROIBIDO varrer/.test(durante.promptB || ''), 'a Chamada B deve receber o Bloco 1 literal (do backup) e a proibição de ler pastas antigas');
  assert.ok(!/ROTEIRO ANTIGO: papel velho/.test(durante.prompt + (durante.promptB || '')), 'o texto antigo não pode vazar para os prompts');
  const ambos = `${durante.prompt}\n${durante.promptB || ''}`;
  assert.ok(/causa e efeito/i.test(durante.prompt) && /Dona Maria/i.test(durante.prompt), 'Chamada A deve carregar as 5 leis');
  assert.ok(/Novidade:/.test(ambos) && /Teste da Dona Maria: APROVADO/.test(ambos) && /Relação exata/.test(ambos), 'prompts devem exigir as 5 leis e o formato');
  const antigo = fs.readFileSync(path.join(pasta, '_versoes', durante.versoes[0], 'roteiro_humano.md'), 'utf8');
  assert.ok(antigo.includes('ROTEIRO ANTIGO'), 'a versão antiga precisa estar guardada em _versoes');
  const d = svc.dialogos('teste', 1);
  assert.ok(JSON.stringify(d).includes('ROTEIRO NOVO') && !JSON.stringify(d).includes('ROTEIRO ANTIGO'), 'Ler Só Diálogos deve mostrar o NOVO');
  assert.equal(svc.listarProntos().find((x) => x.slug === 'teste')?.regerando, null, 'depois de terminar, não pode ficar "regerando"');
  assert.equal(fs.existsSync(path.join(pasta, 'bloco1_refs_backup.txt')), false, 'backup temporário do Bloco 1 deve sumir no fim');
});

console.log('\n[2] Falhas: a versão anterior só volta se o Claude abortar / não escrever / for cancelado');
await teste('Claude aborta com erro fatal → versão anterior RESTAURADA, alerta vermelho (job + log + listarProntos)', async () => {
  reset(); logs.length = 0;
  const svc = novoSvc();
  svc.rodarClaude = async () => { assert.equal(fs.existsSync(path.join(pasta, 'roteiro_humano.md')), false); throw new Error('claude saiu com código 1 (sem login)'); };
  const fim = await esperarFim(svc, svc.regerarParte(pedido).id);
  assert.equal(fim.estado, 'erro');
  assert.ok(/sem login/.test(fim.erro) && /RESTAURADA/.test(fim.erro), fim.erro);
  assert.ok(fs.readFileSync(path.join(pasta, 'roteiro_humano.md'), 'utf8').includes('ROTEIRO ANTIGO'), 'roteiro antigo deveria ter voltado');
  assert.ok(fs.existsSync(path.join(pasta, 'prompts_flow.txt')) && fs.existsSync(path.join(pasta, 'legenda_facebook.txt')) && fs.existsSync(path.join(pasta, 'continuidade_cenas.md')));
  assert.equal(fim.restaurado, true);
  assert.ok(logs.some((l) => l.n === 'erro' && /FALHOU.*restaurada/i.test(l.m)), 'deve registrar erro vermelho no log de Atividade');
  const f = svc.listarProntos().find((x) => x.slug === 'teste')?.falhaRegerar;
  assert.ok(f && /sem login/.test(f.erro) && f.restaurado, 'card precisa receber falhaRegerar');
});
await teste('Claude termina "com sucesso" mas NÃO escreveu o roteiro novo → conta como falha e restaura (nunca fica pasta vazia nem texto velho passando por novo)', async () => {
  reset();
  const svc = novoSvc();
  svc.rodarClaude = async () => 'ok, feito!';
  const fim = await esperarFim(svc, svc.regerarParte(pedido).id);
  assert.equal(fim.estado, 'erro');
  assert.ok(/SEM escrever o novo roteiro/.test(fim.erro), fim.erro);
  assert.ok(fs.readFileSync(path.join(pasta, 'roteiro_humano.md'), 'utf8').includes('ROTEIRO ANTIGO'));
});
await teste('cancelar a tarefa durante a reescrita também restaura a versão anterior', async () => {
  reset();
  const svc = novoSvc();
  let solta; const preso = new Promise((r) => { solta = r; });
  svc.rodarClaude = async () => { await preso; return ''; };
  const j = svc.regerarParte(pedido);
  await dormir(60);
  assert.equal(fs.existsSync(path.join(pasta, 'roteiro_humano.md')), false, 'durante a reescrita a pasta não pode ter o roteiro antigo');
  svc.cancelarJob(j.id); solta();
  await dormir(60);
  assert.equal(svc.jobs.get(j.id).estado, 'cancelado');
  assert.ok(fs.readFileSync(path.join(pasta, 'roteiro_humano.md'), 'utf8').includes('ROTEIRO ANTIGO'));
});

console.log('\n[3] Encerrar de verdade o processo do Claude');
await teste('matarArvore encerra o processo (no Windows usa taskkill /T para derrubar cmd.exe + claude.exe)', async () => {
  const filho = process.platform === 'win32'
    ? spawn('cmd.exe', ['/d', '/s', '/c', `""${process.execPath}" -e "setInterval(function(){},1000)""`], { stdio: 'ignore', windowsHide: true, windowsVerbatimArguments: true })
    : spawn('sh', ['-c', 'sleep 30'], { stdio: 'ignore' });
  await dormir(500);
  let vivo = (() => { try { process.kill(filho.pid, 0); return true; } catch { return false; } })();
  assert.equal(vivo, true, 'processo de teste deveria estar vivo');
  matarArvore(filho);
  await dormir(700);
  vivo = (() => { try { process.kill(filho.pid, 0); return true; } catch { return false; } })();
  assert.equal(vivo, false, 'processo continuou vivo depois de matarArvore');
});

fs.rmSync(tmp, { recursive: true, force: true });
console.log(`\n${process.exitCode ? '❌ FALHOU' : `✅ ${ok} testes passaram`}`);
