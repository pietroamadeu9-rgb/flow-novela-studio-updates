// Seletores calibrados do Google Flow (flow.google.com) — Etapa 3
// Gerados a partir de dados/flow-dom-map.json (2 capturas + 91 cliques gravados).
// Cada "localizador": string CSS | array de alternativas | { css, role, nome, texto, ariaLabel, placeholder, icone, exato, regex, dentroDe, indice }
// Strings com {nome} sao substituidas em tempo de execucao.
export const SELETORES_MODELO = {
  _info: 'Seletores calibrados do Google Flow (Etapa 3). Edite com cuidado: a extensão recarrega este arquivo automaticamente.',
  _versao: 2,
  calibrado: true,
  calibradoEm: '2026-11-16',
  // Home do Flow. O prefixo /u/<n>/ da aba do usuario e preservado automaticamente pela extensao.
  flowUrlInicial: 'https://flow.google.com/',
  flowUrlLabs: 'https://labs.google/fx/pt/tools/flow',

  projeto: {
    // Nao capturado no mapa (fica na pagina inicial): deteccao por texto/aria-label
    botaoNovoProjeto: [
      { css: 'button, a, [role="button"]', ariaLabel: 'novo projeto|new project|criar projeto', regex: true },
      { css: 'button, a, [role="button"]', texto: 'novo projeto|new project|criar projeto', regex: true },
    ],
    inputNomeProjeto: 'header input[aria-label="Texto editável"]',
    padraoUrlProjeto: '/project/',
  },

  configuracoes: {
    gatilho: 'button[aria-label="Gatilho de configurações"]',
    painel: 'flow-prompt-box-settings',
    grupo: 'flow-toggles[aria-label="{nome}"]',
    grupos: {
      modo: 'Modo',
      tipoVideo: 'Tipo de vídeo',
      proporcao: 'Proporção',
      resolucao: 'Resolução do vídeo',
      duracao: 'Duração do vídeo',
      quantidade: 'Quantidade de resultados',
    },
    opcoes: {
      imagem: [{ icone: 'image' }, { nome: 'Imagem', exato: true }],
      video: [{ icone: 'videocam' }, { nome: 'Vídeo', exato: true }],
      frames: [
        { icone: 'crop_free' },
        { nome: 'Frames', exato: true },
        { texto: '^(frames|quadros|frame inicial)$', regex: true },
      ],
      elementos: [
        { icone: 'chrome_extension' },
        { icone: 'extension' },
        { nome: 'Elementos', exato: true },
        { nome: 'Ingredientes', exato: true },
        { texto: '^(elementos|ingredientes|elements|ingredients)$', regex: true },
      ],
      proporcao_9_16: [{ icone: 'crop_9_16' }, { nome: '9:16', exato: true }],
      quantidade_1: [{ nome: 'x1', exato: true }, { texto: '^(x?1|1x)$', regex: true }],
      quantidade_4: [{ nome: 'x4', exato: true }, { texto: '^(x?4|4x)$', regex: true }],
    },
    botaoModelo: 'button[aria-label="Selecionar família de modelos"]',
    itemMenu: '[role="menuitem"]',
    sliderDuracao: 'input[type="range"][aria-label="Duração"]',
  },

  ingredientes: {
    barra: 'flow-ingredient-bar',
    chip: 'flow-image-ingredient-chip',
    botaoAdicionar: 'button[aria-label="Adicionar elementos à caixa de comando"]',
    slotInicio: { css: 'flow-ingredient-bar button', nome: 'Início', exato: true },
    popover: 'flow-add-menu-popover-content',
    abaImagens: { css: 'flow-add-menu-popover-content [role="tab"]', nome: 'Imagens', exato: true },
    busca: 'input[aria-label="Pesquisar recursos"]',
    opcaoAtivo: '[role="listbox"][aria-label="Lista de recursos"] [role="option"]',
    incluir: { css: 'flow-add-menu-popover-content button', nome: 'Incluir no comando' },
  },

  prompt: {
    campo: 'div[role="textbox"][aria-label="O que você quer criar?"]',
    // barra inferior do compositor: [+ Adicionar] [Agente] ... [Gatilho de configurações] [→ envio]
    compositor: 'flow-base-prompt-box',
    gerar: [
      'flow-base-prompt-box flow-generate-icon-button button',
      'flow-generate-icon-button button',
      'flow-base-prompt-box button[type="submit"]',
      { css: 'button', ariaLabel: 'iniciar|gerar|criar|enviar|generate|create|send|submit', regex: true },
      { css: 'button', icone: 'arrow_forward' },
      { css: 'button', icone: 'send' },
    ],
    // botoes da mesma barra que NUNCA sao o envio
    naoEnviar: [
      { ariaLabel: 'Gatilho de configurações' },
      { ariaLabel: 'Adicionar elementos' },
      { ariaLabel: 'Apagar comando' },
      { nome: 'Agente', exato: true },
    ],
  },

  resultado: {
    tile: 'flow-grid-tile-container',
    // texto que indica falha na geracao ou bloqueio de politica/filtro (tile, alerta ou snackbar)
    regexErro: 'falh|não foi possível|nao foi possivel|couldn.?t\\s+(?:generate|create)|unable\\s+to\\s+(?:generate|create)|can.?t\\s+(?:generate|create)|erro ao gerar|something went wrong|failed|viola(?:tes?|r|ç[aã]o)?|política|politica|policy|guidelines|diretrizes|bloquead|blocked|unsafe|inappropriate|imprópri|impropri|tente outro comando|try a different prompt|conteúdo não permitido',
  },

  ativo: {
    botaoMais: [{ ariaLabel: 'Mais opções', exato: true }, { icone: 'more_vert' }],
    itemRenomear: [{ css: '[role="menuitem"]', icone: 'edit' }, { css: '[role="menuitem"]', nome: 'Renomear' }],
    // Captura #3 (renomear ao vivo): overlay flow-editable-text "Renomear bloco" com
    // input[aria-label="Texto editável"] + botoes "Concluir" (done) e "Cancelar" (close).
    // Atencao: o titulo do projeto no cabecalho usa o MESMO aria-label do input -> sempre filtrar pelo editor.
    editorNome: ['flow-editable-text[aria-label="Renomear bloco"]', 'flow-editable-text'],
    inputNome: 'input[aria-label="Texto editável"], input, textarea',
    confirmarNome: [{ ariaLabel: 'Concluir', exato: true }, { icone: 'done' }],
    cancelarNome: [{ ariaLabel: 'Cancelar', exato: true }, { icone: 'close' }],
    itemDownload: [
      { css: '[role="menuitem"]', icone: 'download' },
      { css: '[role="menuitem"]', texto: 'download|baixar', regex: true },
    ],
    // "maxima" = escolhe a maior resolucao do submenu (ex.: 1080p Aprimorada / 4K)
    resolucaoDownload: 'maxima',
  },
};
