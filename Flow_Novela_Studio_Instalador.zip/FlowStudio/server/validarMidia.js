// Validacao do conteudo REAL dos arquivos (magic bytes) antes de dar um item como concluido.
import fs from 'node:fs';

const MIN_VIDEO = 50 * 1024;
const MIN_IMAGEM = 10 * 1024;

/** Le os primeiros bytes de um Buffer ou arquivo. */
function cabecalho(origem, n = 64) {
  if (Buffer.isBuffer(origem)) return origem.subarray(0, n);
  const fd = fs.openSync(origem, 'r');
  try {
    const b = Buffer.alloc(n);
    const lidos = fs.readSync(fd, b, 0, n, 0);
    return b.subarray(0, lidos);
  } finally { fs.closeSync(fd); }
}

/**
 * Identifica o tipo real do arquivo.
 * @returns {{tipo:'mp4'|'webm'|'jpg'|'png'|'webp'|'gif'|'html'|'json'|'desconhecido', ext:string|null}}
 */
export function detectarTipo(origem) {
  const b = cabecalho(origem);
  const s = b.toString('latin1');
  if (s.slice(4, 8) === 'ftyp') return { tipo: 'mp4', ext: 'mp4' };
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return { tipo: 'webm', ext: 'webm' };
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { tipo: 'jpg', ext: 'jpg' };
  if (s.startsWith('\x89PNG\r\n\x1a\n')) return { tipo: 'png', ext: 'png' };
  if (s.startsWith('RIFF') && s.slice(8, 12) === 'WEBP') return { tipo: 'webp', ext: 'webp' };
  if (s.startsWith('GIF8')) return { tipo: 'gif', ext: 'gif' };
  if (/^\s*<(!doctype|html|head|\?xml)/i.test(s)) return { tipo: 'html', ext: null };
  if (/^\s*[{[]/.test(s)) return { tipo: 'json', ext: null };
  return { tipo: 'desconhecido', ext: null };
}

/**
 * Valida o arquivo para o tipo de item. Lanca erro com o diagnostico se for invalido.
 * @param {Buffer|string} origem buffer ou caminho
 * @param {'video'|'referencia_imagem'|'imagem_base'} tipoItem
 */
export function validarMidia(origem, tipoItem) {
  const tamanho = Buffer.isBuffer(origem) ? origem.length : fs.statSync(origem).size;
  const { tipo, ext } = detectarTipo(origem);
  const ehVideo = tipoItem === 'video';
  if (tipo === 'html') {
    const txt = cabecalho(origem, 4096).toString('latin1');
    const login = /accounts\.google\.com|signin|ServiceLogin/i.test(txt);
    throw new Error(`Arquivo inválido: é uma página HTML${login ? ' de LOGIN do Google' : ''} (${tamanho} bytes), não a mídia.`);
  }
  if (tipo === 'json') throw new Error(`Arquivo inválido: é uma resposta JSON de erro (${tamanho} bytes).`);
  if (ehVideo) {
    if (tipo !== 'mp4') throw new Error(`Vídeo inválido: cabeçalho "${tipo}" (esperado MP4 com "ftyp").`);
    if (tamanho < MIN_VIDEO) throw new Error(`Vídeo inválido: só ${tamanho} bytes.`);
    return { tipo, ext: 'mp4', tamanho };
  }
  if (!['jpg', 'png', 'webp'].includes(tipo)) throw new Error(`Imagem inválida: cabeçalho "${tipo}".`);
  if (tamanho < MIN_IMAGEM) throw new Error(`Imagem inválida: só ${tamanho} bytes.`);
  return { tipo, ext, tamanho };
}
