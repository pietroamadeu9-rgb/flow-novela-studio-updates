// =============================================================
//  Ponte para o Claude Code CLI (claude -p "..." --output-format text)
//  + Fallback local inteligente que suaviza gatilhos visuais sensiveis
//    em ingles preservando 100% das falas em portugues entre aspas.
// =============================================================
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync, spawn } from 'node:child_process';

let cacheCli = { verificadoEm: 0, info: null };

function candidatosClaudeWindows() {
  const cands = [];
  try {
    const out = execFileSync('where.exe', ['claude'], { encoding: 'utf8', timeout: 3000, windowsHide: true });
    for (const ln of out.split(/\r?\n/).map((s) => s.trim()).filter(Boolean)) {
      if (/\.(exe|cmd|bat)$/i.test(ln)) cands.unshift(ln);
      else cands.push(ln);
    }
  } catch {}
  const appData = process.env.APPDATA || '';
  const localAppData = process.env.LOCALAPPDATA || '';
  const home = process.env.USERPROFILE || '';
  for (const extra of [
    path.join(appData, 'npm', 'claude.cmd'),
    path.join(localAppData, 'Programs', 'claude', 'claude.exe'),
    path.join(home, '.local', 'bin', 'claude.exe'),
    path.join(home, '.claude', 'local', 'claude.exe'),
    path.join(localAppData, 'AnthropicClaude', 'claude.exe'),
  ]) {
    if (extra && fs.existsSync(extra) && !cands.includes(extra)) cands.push(extra);
  }
  return cands;
}

/** Detecta se o comando `claude` (Claude Code CLI) existe e responde no Windows. */
export function detectarClaudeCli({ forcar = false } = {}) {
  const agora = Date.now();
  if (!forcar && cacheCli.info && agora - cacheCli.verificadoEm < 30000) return cacheCli.info;

  let info = { disponivel: false, comando: null, versao: null };
  for (const cmd of candidatosClaudeWindows()) {
    try {
      const ehScript = /\.(cmd|bat)$/i.test(cmd);
      const versao = ehScript
        ? execFileSync('cmd.exe', ['/d', '/s', '/c', `""${cmd}" --version"`], { encoding: 'utf8', timeout: 5000, windowsHide: true, windowsVerbatimArguments: true }).trim()
        : execFileSync(cmd, ['--version'], { encoding: 'utf8', timeout: 5000, windowsHide: true }).trim();
      if (versao) {
        info = { disponivel: true, comando: cmd, versao: versao.split(/\r?\n/)[0].trim() };
        break;
      }
    } catch {}
  }
  cacheCli = { verificadoEm: agora, info };
  return info;
}

// ---------------- Protecao de dialogos entre aspas e tags [...] ----------------
const RE_PROTEGIDO = /("[^"]*"|“[^”]*”|\[[^\]]+\])/g;
const RE_ASPAS = /("[^"]*"|“[^”]*”)/g;

export function extrairFalasEntreAspas(texto) {
  return String(texto || '').match(RE_ASPAS) || [];
}

/** Preserva capitalizacao inicial (Poisonous -> Cold, POISONOUS -> COLD, poisonous -> cold). */
function ajustarCaixa(original, substituto) {
  if (!original || !substituto) return substituto;
  if (original === original.toUpperCase() && original.length > 1) return substituto.toUpperCase();
  if (original[0] === original[0].toUpperCase() && original[0] !== original[0].toLowerCase()) {
    return substituto[0].toUpperCase() + substituto.slice(1);
  }
  return substituto;
}

// Mapa nivel 1 (Tentativa 2) — gatilhos visuais sensiveis em ingles -> atuacao dramatica segura
const MAPA_NIVEL_1 = [
  [/\ban\s+aggressive\s+provocative\b/gi, 'a composed and earnest'],
  [/\baggressive\s+provocative\b/gi, 'composed and earnest'],
  [/\bconfrontational\s+aggressive\b/gi, 'direct composed'],
  [/\bexpressive\s+complaining\b/gi, 'expressive earnest'],
  [/\bvisibly\s+venting\b/gi, 'speaking earnestly'],
  [/\bultrarealistic\s+contemporary\s+cinema\b/gi, 'cinematic contemporary drama'],
  [/\bultrarealistic\b/gi, 'cinematic'],
  [/\bphotorealistic\b/gi, 'naturalistic'],
  [/\bnon-violent\b/gi, 'composed'],
  [/\bdead\s+bod(?:y|ies)\b/gi, 'still figure'],
  [/\bpool\s+of\s+blood\b/gi, 'dark dramatic shadow'],
  [/\bpoisonous\b/gi, 'cold'],
  [/\bvenomous\b/gi, 'icy'],
  [/\bpoison(?:ed|ing)?\b/gi, 'tense'],
  [/\bhostile\b/gi, 'tense'],
  [/\bhostility\b/gi, 'tension'],
  [/\bcruelly\b/gi, 'calmly'],
  [/\bcruelest\b/gi, 'most direct'],
  [/\bcruel\b/gi, 'stern'],
  [/\bviolently\b/gi, 'abruptly'],
  [/\bviolent\b/gi, 'intense'],
  [/\bviolence\b/gi, 'confrontation'],
  [/\bbrutally\b/gi, 'sharply'],
  [/\bbrutal\b/gi, 'harsh'],
  [/\bsavagely\b/gi, 'sharply'],
  [/\bsavage\b/gi, 'fierce'],
  [/\baggressively\b/gi, 'firmly'],
  [/\baggressive\b/gi, 'composed'],
  [/\bconfrontational\b/gi, 'direct'],
  [/\bconfronting\b/gi, 'facing'],
  [/\bconfronts\b/gi, 'addresses'],
  [/\bconfront\b/gi, 'address'],
  [/\bferocious(?:ly)?\b/gi, 'intense'],
  [/\bbloody\b/gi, 'shadowed'],
  [/\bbleeding\b/gi, 'trembling'],
  [/\bblood\b/gi, 'dramatic shadow'],
  [/\bwounded\b/gi, 'visibly shaken'],
  [/\bwounds?\b/gi, 'marks'],
  [/\bbruised\b/gi, 'weary'],
  [/\bbruises?\b/gi, 'shadows'],
  [/\bcorpses?\b/gi, 'still figure'],
  [/\bchoking\b/gi, 'standing closely'],
  [/\bchokes\b/gi, 'steps close to'],
  [/\bchoked\b/gi, 'visibly breathless'],
  [/\bchoke\b/gi, 'step close to'],
  [/\bstrangling\b/gi, 'holding back'],
  [/\bstrangles?\b/gi, 'holds back'],
  [/\bweapons?\b/gi, 'dramatic prop'],
  [/\b(?:gun|pistol|revolver|rifle|firearm)s?\b/gi, 'sealed folder'],
  [/\b(?:knife|knives|blade|blades|dagger|daggers)\b/gi, 'silver letter opener'],
  [/\bdisgusted\b/gi, 'unsettled'],
  [/\bdisgusting\b/gi, 'unsettling'],
  [/\bdisgust\b/gi, 'disapproval'],
  [/\brepulsed\b/gi, 'taken aback'],
  [/\bslapping\b/gi, 'gesturing toward'],
  [/\bslaps\b/gi, 'gestures toward'],
  [/\bslapped\b/gi, 'startled'],
  [/\bslap\b/gi, 'sharp gesture'],
  [/\bpunching\b/gi, 'facing'],
  [/\bpunches\b/gi, 'addresses'],
  [/\bpunch\b/gi, 'firm gesture'],
  [/\bshoving\b/gi, 'stepping past'],
  [/\bshoves\b/gi, 'steps past'],
  [/\bshove\b/gi, 'step past'],
  [/\bmurder(?:ed|ing|ous)?\b/gi, 'betrayal'],
  [/\bkilling\b/gi, 'facing'],
  [/\bkills?\b/gi, 'addresses'],
  [/\bsuicid(?:e|al)\b/gi, 'despair'],
  [/\btortur(?:e|ed|ing)\b/gi, 'emotional ordeal'],
  [/\babusive\b/gi, 'overbearing'],
  [/\babuse[ds]?\b/gi, 'mistreatment'],
  [/\b(?:naked|nude|topless)\b/gi, 'in formal evening attire'],
  [/\blingerie\b/gi, 'elegant silk gown'],
  [/\bcleavage\b/gi, 'tailored neckline'],
  [/\b(?:sexy|seductive|provocative|sensual)\b/gi, 'composed and earnest'],
  [/\bhumiliated\b/gi, 'visibly shaken'],
  [/\bhumiliating\b/gi, 'tense'],
  [/\bhumiliation\b/gi, 'disappointment'],
  [/\bdivorce\b/gi, 'separation'],
  [/\bex-boyfriend\b/gi, 'former partner'],
  [/\bangrily\b/gi, 'firmly'],
  [/\bangry\b/gi, 'earnest'],
  [/\bshouting\b/gi, 'speaking clearly'],
  [/\bscreaming\b/gi, 'speaking with emotion'],
  [/\bscreams\b/gi, 'exclaims'],
  [/\bcrying\b/gi, 'visibly moved'],
  [/\bsobbing\b/gi, 'tearful'],
  [/\bgrabbing\b/gi, 'reaching toward'],
  [/\bgrabs\b/gi, 'reaches toward'],
  [/\bgrabbed\b/gi, 'reached toward'],
  [/\bgrab\b/gi, 'reach toward'],
  [/\bcomplaining\b/gi, 'speaking earnestly'],
  [/\bventing\b/gi, 'speaking earnestly'],
  [/\bfrustrated\b/gi, 'thoughtful'],
  [/\bdevastated\b/gi, 'deeply affected'],
  [/\bdestroyed\b/gi, 'somber'],
  [/\bdesperate\b/gi, 'earnest'],
  [/\bdesperation\b/gi, 'concern'],
];

// Mapa nivel 2 (Rodada 2) — suavizacao adicional de conflito fisico, objetos quebrando e angustia extrema
const MAPA_NIVEL_2 = [
  ...MAPA_NIVEL_1,
  [/\bdrops?\s+the\s+glass\s+in\s+(?:his|her|their)\s+hand\b/gi, 'holds the glass still in hand'],
  [/\bdropping\s+the\s+glass\b/gi, 'holding the glass still'],
  [/\bdrops?\s+the\s+(?:cup|plate|tray|bottle|glass)\b/gi, 'places the item on the table'],
  [/\b(?:broken|shattered|smashed)\s+(?:glass|mirror|plate|bottle|cup)s?\b/gi, 'crystal glassware on the table'],
  [/\bfuriously\b/gi, 'firmly'],
  [/\bfurious\b/gi, 'indignant'],
  [/\benraged\b/gi, 'deeply upset'],
  [/\brage\b/gi, 'emotional tension'],
  [/\bhatred\b/gi, 'resentment'],
  [/\bhateful\b/gi, 'distant'],
  [/\bterrified\b/gi, 'startled'],
  [/\bterror\b/gi, 'surprise'],
  [/\bpanicked\b/gi, 'attentive'],
  [/\bpushing\b/gi, 'stepping away from'],
  [/\bpushes\b/gi, 'steps away from'],
  [/\bthrowing\b/gi, 'setting down'],
  [/\bthrows\b/gi, 'sets down firmly'],
  [/\bsmashing\b/gi, 'placing down'],
  [/\bsmashes\b/gi, 'places down'],
  [/\bshattering\b/gi, 'dramatic'],
  [/\bthreatening(?:ly)?\b/gi, 'unyielding'],
  [/\bthreatens?\b/gi, 'addresses'],
  [/\battacking\b/gi, 'facing'],
  [/\battacks?\b/gi, 'addresses'],
  [/\bhysterical(?:ly)?\b/gi, 'emotional'],
  [/\bmanipulative\b/gi, 'persuasive'],
  [/\bsly\b/gi, 'knowing'],
  [/\bsmug\b/gi, 'confident'],
  [/\bfaint(?:s|ed|ing)?\b/gi, 'sits down slowly'],
  [/\bcollaps(?:e|es|ed|ing)\b/gi, 'leans on a chair'],
  [/\bkneeling\b/gi, 'standing respectfully'],
  [/\bbegging\b/gi, 'speaking earnestly'],
  [/\bweeping\b/gi, 'visibly moved'],
  [/\bdrunk(?:en)?\b/gi, 'tired'],
  [/\bhandcuffs?\b/gi, 'official documents'],
  [/\barrest(?:s|ed|ing)?\b/gi, 'escorts'],
];

// Mapa nivel 3 e 4 (Rodadas 3 e 4) — neutralizacao fotográfica/editorial maxima para destravar filtros rigorosos
const MAPA_NIVEL_3 = [
  ...MAPA_NIVEL_2,
  [/\bshocked\s+guests\b/gi, 'attentive guests'],
  [/\bshocked\b/gi, 'surprised and attentive'],
  [/\bstartled\b/gi, 'attentive'],
  [/\bvisibly\s+shaken\b/gi, 'thoughtful and composed'],
  [/\bvisibly\s+breathless\b/gi, 'composed and earnest'],
  [/\btearful\b/gi, 'solemn'],
  [/\btears?\b/gi, 'calm expression'],
  [/\btrembling\b/gi, 'standing still'],
  [/\bdeeply\s+upset\b/gi, 'serious'],
  [/\bindignant\b/gi, 'firm and composed'],
  [/\bresentment\b/gi, 'quiet seriousness'],
  [/\bconfrontation\b/gi, 'conversation'],
  [/\btense\b/gi, 'focused'],
  [/\btension\b/gi, 'focus'],
  [/\bstern\b/gi, 'calm'],
  [/\bharsh\b/gi, 'clear'],
  [/\bfierce\b/gi, 'determined'],
  [/\bordeal\b/gi, 'moment'],
  [/\bmistreatment\b/gi, 'disagreement'],
  [/\bbetrayal\b/gi, 'revelation'],
  [/\bdespair\b/gi, 'reflection'],
];

/**
 * Fallback local inteligente: suaviza gatilhos visuais sensiveis em ingles
 * FORA das aspas ("..." e “...”) e FORA de colchetes [...], mantendo 100% das falas intactas.
 */
export function suavizarPromptLocal(promptOriginal, attempt = 2) {
  const texto = limparVazamentoExplicacaoPrompt(String(promptOriginal || ''));
  const regras = attempt >= 3 ? MAPA_NIVEL_3 : attempt === 2 ? MAPA_NIVEL_2 : MAPA_NIVEL_1;
  const partes = texto.split(RE_PROTEGIDO);
  let trocas = 0;

  const reconstruido = partes.map((parte) => {
    if (!parte) return parte;
    // Segmento protegido: fala em portugues entre aspas ou referencia [ref_xxx]
    if ((parte.startsWith('"') && parte.endsWith('"')) ||
        (parte.startsWith('“') && parte.endsWith('”')) ||
        (parte.startsWith('[') && parte.endsWith(']'))) {
      return parte;
    }
    let s = parte;
    for (const [regex, substituto] of regras) {
      s = s.replace(regex, (m) => {
        trocas++;
        return ajustarCaixa(m, substituto);
      });
    }
    return s;
  }).join('');

  let resultado = reconstruido.replace(/\s{2,}/g, ' ').trim();
  // Garante que cada rodada progressiva (1, 2, 3, 4) gere uma formulacao segura e distinta
  const sufixosPorRodada = {
    1: 'Safe dramatic television acting, composed posture, subtle emotional expression.',
    2: 'Composed theatrical soap-opera staging, safe dramatic reaction, restrained posture, clean broadcast television aesthetic.',
    3: 'Clean family television studio portrait staging, calm conversational body language, balanced natural lighting, PG-rated broadcast safe.',
    4: 'Serene editorial television framing, relaxed and respectful posture, peaceful indoor atmosphere, natural facial expression, family-friendly broadcast aesthetic.',
  };
  const notaSegura = sufixosPorRodada[Math.min(4, Math.max(1, Number(attempt) || 1))];
  if (resultado === texto.trim() || Number(attempt) >= 3) {
    if (!resultado.includes(notaSegura)) {
      resultado = `${resultado} ${notaSegura}`.trim();
    }
  }
  return restaurarFalasOriginais(texto, resultado) || resultado;
}

/** Garante 100% que todas as falas entre aspas do original continuem identicas palavra por palavra. */
function restaurarFalasOriginais(original, candidato) {
  const falasOrig = extrairFalasEntreAspas(original);
  if (!falasOrig.length) return candidato;
  const todasIntactas = falasOrig.every((f) => candidato.includes(f));
  if (todasIntactas) return candidato;

  const falasCand = extrairFalasEntreAspas(candidato);
  if (falasCand.length === falasOrig.length) {
    let idx = 0;
    return candidato.replace(RE_ASPAS, () => falasOrig[idx++]);
  }
  return null; // sinaliza que o candidato violou a quantidade de blocos de fala
}

/**
 * Remove qualquer comentario/explicacao que tenha vazado após `Nobody looks into the lens.`, ` ``` `, ou ` --- **O que foi trocado`.
 */
export function limparVazamentoExplicacaoPrompt(raw) {
  let t = String(raw || '').trim();
  if (!t) return '';
  // Se comeca com cerca markdown ```...```, extrai apenas o interior do primeiro bloco
  const mFenceIni = t.match(/^```[a-z]*\s*([\s\S]*?)```/i);
  if (mFenceIni) {
    t = mFenceIni[1].trim();
  } else if (t.includes('```')) {
    t = t.split('```')[0].trim();
  }
  // Corta qualquer bloco "--- **O que foi trocado" ou explicacao meta em portugues apos o prompt em ingles
  t = t.split(/\s+---+\s+|\n---+\n|\s+\*\*(?:O que foi trocado|Ajustes aplicados|Explicação)/i)[0].trim();
  const idxFimPadrao = t.search(/Nobody looks into the lens\./i);
  if (idxFimPadrao !== -1) {
    const fim = idxFimPadrao + 'Nobody looks into the lens.'.length;
    const resto = t.slice(fim).trim();
    // Se o que vem depois de "Nobody looks into the lens." contem explicacao em portugues ou markdown, descarta
    if (resto && (/[`*#]|ajustes?\s+aplicados?|o\s+que\s+foi\s+trocado|removido\s+o\s+bloco|fala,\s*dura[cç][aã]o/i.test(resto))) {
      t = t.slice(0, fim).trim();
    }
  }
  return t;
}

function limparSaidaClaude(raw, item) {
  let t = limparVazamentoExplicacaoPrompt(raw);
  // Remove eventual linha {id} ou prefixo (v) [refs] / (i) [refs] caso o modelo tenha incluido
  const linhas = t.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (linhas.length > 1 && /^\{[^}]+\}$/.test(linhas[0])) linhas.shift();
  t = linhas.join(' ').trim();
  t = limparVazamentoExplicacaoPrompt(t);
  if (!/^\([iv]\)/i.test(item?.prompt || '')) {
    t = t.replace(/^\([iv]\)\s*(?:\[[^\]]+\]\s*)*/i, '').trim();
  }
  return t;
}

/**
 * Salva `promptOriginalBackup` e `anexosOriginaisBackup` no item (se ainda nao salvos),
 * preservando sempre o prompt original limpo (sem vazamento de explicacao do Claude).
 */
export function salvarBackupsOriginaisItem(item, novela = null) {
  if (!item) return;
  const baseOriginal = limparVazamentoExplicacaoPrompt(item.promptOriginalBackup || item.originalPrompt || item.prompt || '');
  if (!item.promptOriginalBackup && baseOriginal) item.promptOriginalBackup = baseOriginal;
  if (!item.originalPrompt && baseOriginal) item.originalPrompt = baseOriginal;
  if (!Array.isArray(item.anexosOriginaisBackup) || !item.anexosOriginaisBackup.length) {
    if (Array.isArray(item.refs) && item.refs.length) {
      item.anexosOriginaisBackup = [...item.refs];
    } else if (novela) {
      const inf = inferirRefsOriginaisDaCena(novela, item);
      if (inf.length) item.anexosOriginaisBackup = inf;
    }
  }
}

/** Infere `[imagem_XX, ref_*]` de uma `{Cena XX}` a partir do `novela.roteiro` ou `imagem_XX` quando `item.refs` ja foi zerado. */
export function inferirRefsOriginaisDaCena(novela, item) {
  if (!novela || !item) return [];
  if (Array.isArray(item.anexosOriginaisBackup) && item.anexosOriginaisBackup.length) return [...item.anexosOriginaisBackup];
  if (Array.isArray(item.refs) && item.refs.length) return [...item.refs];
  const mCena = String(item.id || '').match(/(\d+)\s*$/);
  if (!mCena) return [];
  const num = mCena[1].padStart(2, '0');
  const idImg = `imagem_${num}`;
  const itemImg = (novela.itens || []).find((i) => i.id === idImg);
  if (itemImg) {
    const refsPers = (itemImg.refs || []).filter((r) => /^ref_(?!cenario_)/i.test(r));
    return [idImg, ...refsPers];
  }
  return [];
}

/** Restaura um item para seu prompt e anexos originais intactos. */
export function restaurarItemOriginal(item, novela = null) {
  if (!item) return item;
  const origPrompt = limparVazamentoExplicacaoPrompt(item.promptOriginalBackup || item.originalPrompt || item.prompt || '');
  const origRefs = (Array.isArray(item.anexosOriginaisBackup) && item.anexosOriginaisBackup.length)
    ? [...item.anexosOriginaisBackup]
    : inferirRefsOriginaisDaCena(novela, item);
  if (origPrompt) item.prompt = origPrompt;
  if (origRefs.length) item.refs = origRefs;
  item.originalPrompt = null;
  item.promptOriginalBackup = null;
  item.anexosOriginaisBackup = null;
  item.promptAutoAjustado = null;
  item.semAnexos = false;
  item.modoDescritivoSemImagem = false;
  item.geradoPorDescricaoSemImagem = false;
  return item;
}

/**
 * Tentativa 2 / Botao `🛡️ Suavizar (com imagem)`:
 * - Salva `promptOriginalBackup` e `anexosOriginaisBackup`
 * - Remove `ref_*` extras mantendo APENAS `imagem_XX` anexada
 * - Suaviza termos gatilho do Veo no prompt.
 */
export function aplicarSuavizacaoComImagem(novela, item, promptSuavizado = null) {
  if (!item) return item;
  salvarBackupsOriginaisItem(item, novela);
  const refsOrig = item.anexosOriginaisBackup || item.refs || [];
  if (item.tipo === 'video') {
    const apenasImg = refsOrig.filter((r) => /^imagem_/i.test(r));
    if (apenasImg.length) item.refs = apenasImg;
  }
  const base = limparVazamentoExplicacaoPrompt(promptSuavizado || item.promptOriginalBackup || item.originalPrompt || item.prompt || '');
  item.prompt = suavizarPromptLocal(base, 2);
  item.promptAutoAjustado = item.promptAutoAjustado || 'suavizado-com-imagem';
  item.semAnexos = false;
  item.modoDescritivoSemImagem = false;
  item.geradoPorDescricaoSemImagem = false;
  return item;
}

/**
 * Extrai a descricao visual enxuta de um item `ref_*` (Bloco 1) ou `imagem_XX` (Bloco 2).
 */
function limparDescricaoVisualBloco(promptBloco) {
  return String(promptBloco || '')
    .replace(/^\([iv]\)\s*/i, '')
    .replace(/\[[^\]]+\]\s*/g, '')
    .replace(/\bvertical\s+9:16\s*,?\s*/gi, '')
    .replace(/\bindividual\s+close-up\s+from\s+upper\s+chest\s+up\s+on\s+a\s+uniform\s+plain\s+white\s+background\s*,?\s*/gi, '')
    .replace(/\b85mm\s+(?:lens|vertical\s+framing)\s*,?\s*/gi, '')
    .replace(/\bneutral\s+expression\s*,?\s*/gi, '')
    .replace(/\blarge\s+(?:centered|sharp)\s+faces?\s*,?\s*/gi, '')
    .replace(/\bnobody\s+looking\s+at\s+the\s+lens\.?\s*/gi, '')
    .replace(/\bNo\s+other\s+people,\s+hand-held\s+objects\s+or\s+text\.?\s*/gi, '')
    .replace(/\bno\s+signs\s+or\s+text\.?\s*/gi, '')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[,\s]+|[.\s,]+$/g, '')
    .trim();
}

/**
 * Monta via Node.js puro (CUSTO ZERO DE CLAUDE!) o Prompt 100% Descritivo sem nenhuma imagem anexada (Text-to-Video):
 * 1) Remove todas as tags `[imagem_XX]` e `[ref_*]` e zera os anexos (`refs: []`, `semAnexos: true`).
 * 2) Extrai automaticamente dos prompts existentes na novela (`Bloco 1 - ref_*` + `Bloco 2 - imagem_XX`)
 *    a descricao fisica completa de cada personagem (idade, tom de pele, cabelo, rosto, roupa exata e cor)
 *    e a descricao exata do cenario/iluminacao de `imagem_XX`, injetando-as de forma enxuta e fluida antes da acao e do dialogo.
 * 3) Limpa todos os termos gatilho do Veo (`ultrarealistic`, `aggressive`, `complaining`, `humiliated`, etc.) mantendo 100% das falas em portugues.
 */
export function montarPrompt100DescritivoSemImagem(novela, item) {
  if (!item) throw new Error('Item ausente para montar prompt descritivo.');
  const itensNovela = Array.isArray(novela?.itens) ? novela.itens : [];
  const refsOrig = inferirRefsOriginaisDaCena(novela, item);
  const mCena = String(item.id || '').match(/(\d+)\s*$/);
  const numCena = mCena ? mCena[1].padStart(2, '0') : null;
  const idImagem = refsOrig.find((r) => /^imagem_/i.test(r)) || (numCena ? `imagem_${numCena}` : null);
  const itemImagem = idImagem ? itensNovela.find((i) => i.id === idImagem) : null;

  // Coleta refs de personagens e cenario da cena (do video + da imagem_XX correspondente)
  const todosIdsRef = [...new Set([
    ...refsOrig.filter((r) => /^ref_/i.test(r)),
    ...((itemImagem?.refs || []).filter((r) => /^ref_/i.test(r))),
  ])];

  const descCenarios = [];
  const descPersonagens = [];
  for (const rId of todosIdsRef) {
    const refItem = itensNovela.find((i) => i.id === rId);
    if (!refItem?.prompt) continue;
    const limpa = limparDescricaoVisualBloco(refItem.prompt);
    if (!limpa) continue;
    if (/^ref_cenario_/i.test(rId)) {
      descCenarios.push(limpa.replace(/\bempty\s+/i, '').replace(/\bwith\s+no\s+people\s*,?\s*/i, '').trim());
    } else {
      const nomePers = rId.replace(/^ref_/i, '').toUpperCase();
      descPersonagens.push(`${nomePers} (${limpa})`);
    }
  }

  const descImagemBase = itemImagem?.prompt
    ? limparDescricaoVisualBloco(suavizarPromptLocal(itemImagem.prompt, 3))
    : '';

  const baseOriginal = limparVazamentoExplicacaoPrompt(item.promptOriginalBackup || item.originalPrompt || item.prompt || '')
    .replace(/^\([iv]\)\s*/i, '')
    .replace(/\[(?:imagem|ref)_[^\]]+\]\s*/gi, '')
    .trim();

  const baseSuavizada = suavizarPromptLocal(baseOriginal, 3);

  // Monta ancora de consistencia visual a partir do Bloco 1 (ref_*) e Bloco 2 (imagem_XX)
  const partesConsistencia = [];
  if (descCenarios.length) partesConsistencia.push(`environment lighting and architecture: ${descCenarios.join('; ')}`);
  if (descImagemBase) partesConsistencia.push(`exact scene framing and wardrobe: ${descImagemBase}`);
  if (descPersonagens.length) partesConsistencia.push(`character physical traits and exact clothing: ${descPersonagens.join('; ')}`);
  const blocoConsistencia = partesConsistencia.length
    ? `Visual consistency anchor (${partesConsistencia.join(' | ')}).`
    : '';

  let promptFinal = baseSuavizada;
  if (blocoConsistencia && !promptFinal.includes('Visual consistency anchor (')) {
    const idxFixed = promptFinal.search(/Fixed cameras and hard cuts only/i);
    if (idxFixed !== -1) {
      promptFinal = `${promptFinal.slice(0, idxFixed).trim()} ${blocoConsistencia} ${promptFinal.slice(idxFixed).trim()}`;
    } else {
      promptFinal = `${blocoConsistencia} ${promptFinal}`;
    }
  }

  promptFinal = promptFinal.replace(/\s{2,}/g, ' ').trim();
  const validado = restaurarFalasOriginais(baseOriginal, promptFinal) || promptFinal;

  return {
    prompt: validado,
    refs: [],
    semAnexos: true,
    modoDescritivoSemImagem: true,
    origem: 'descritivo-sem-imagem',
    idImagemUsada: idImagem,
    refsExtraidas: todosIdsRef,
  };
}

/**
 * Converte um item de video para o Modo 100% Descritivo Sem Imagem (Text-to-Video puro, 0 anexos),
 * preservando `promptOriginalBackup` e `anexosOriginaisBackup` para restauracao a qualquer momento.
 */
export function aplicarModoDescritivoSemImagem(novela, item) {
  if (!item) return item;
  salvarBackupsOriginaisItem(item, novela);
  const montado = montarPrompt100DescritivoSemImagem(novela, item);
  item.prompt = montado.prompt;
  item.refs = [];
  item.semAnexos = true;
  item.modoDescritivoSemImagem = true;
  item.promptAutoAjustado = 'descritivo-sem-imagem';
  return item;
}

// ---------------- Fabrica Claude: pasta de trabalho e modelo economico ----------------
/** Pasta da Fabrica de Novelas (arquivos prontos_para_flow, series e scripts locais). */
export const FABRICA_DIR = process.env.FABRICA_DIR || 'C:\\FabricaClaude';
/** Pasta temporaria 100% VAZIA e isolada para o processo `claude` — impede leitura automatica de CLAUDE.md, .claude/skills e git status. */
export const PASTA_CLAUDE_VAZIA = path.join(os.tmpdir(), 'flowstudio_claude_empty');
/** Modelo forcado nas chamadas de fundo. Alias aceito pelo Claude CLI 2.1.87: --model sonnet (valide com: claude --help). */
export const MODELO_BACKGROUND = 'sonnet';
/** Modelos aceitos por chamada. Opus consome bem mais cota que Sonnet: o peso (proporcional) entra no painel de cota do topo. */
export const MODELOS_CLAUDE = ['opus', 'sonnet'];
export const PESO_MODELO_CLAUDE = { sonnet: 1, opus: 5 };
export const ROTULO_MODELO_CLAUDE = { sonnet: 'Sonnet', opus: 'Opus' };
export function normalizarModeloClaude(m, padrao = MODELO_BACKGROUND) {
  const v = String(m || '').trim().toLowerCase();
  return MODELOS_CLAUDE.includes(v) ? v : padrao;
}

/** Garante e devolve a pasta temporaria vazia onde o `claude` roda sem contexto de projeto. */
export function obterPastaClaudeVazia() {
  fs.mkdirSync(PASTA_CLAUDE_VAZIA, { recursive: true });
  try {
    for (const item of fs.readdirSync(PASTA_CLAUDE_VAZIA)) {
      fs.rmSync(path.join(PASTA_CLAUDE_VAZIA, item), { recursive: true, force: true });
    }
  } catch {}
  return PASTA_CLAUDE_VAZIA;
}

/** Encerra o processo E os filhos (no Windows o claude roda dentro de cmd.exe; child.kill() sozinho deixaria o claude.exe vivo). */
export function matarArvore(child) {
  if (!child) return;
  try {
    if (process.platform === 'win32' && child.pid) execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore', timeout: 8000 });
    else child.kill();
  } catch { try { child.kill(); } catch {} }
}

const aspas = (a) =>'"' + String(a).replace(/"/g, '\\"') + '"';

export const ARQUIVO_CLAUDE_USAGE_PADRAO = path.join(FABRICA_DIR, 'logs', 'claude_usage.jsonl');
export const ARQUIVO_CLAUDE_CALIBRACAO_PADRAO = path.join(FABRICA_DIR, 'logs', 'claude_cota_config.json');

/**
 * Extrai metricas reais de uso/custo e texto limpo quando o Claude CLI retorna JSON
 * (`--output-format json` ou linhas JSONL / envelope `{ type: "result", result, total_cost_usd, usage }`).
 * Mantem compatibilidade 100% com saida de texto puro (fallback seguro).
 */
export function extrairEnvelopeJsonClaude(bruto) {
  const s = String(bruto ?? '');
  const trim = s.trim();
  if (!trim) return { eraJson: false, texto: '', metricas: null };

  const extrairDeObjeto = (obj) => {
    if (!obj || typeof obj !== 'object') return null;
    const temCamposCli = (
      typeof obj.result === 'string' ||
      obj.type === 'result' ||
      obj.total_cost_usd !== undefined ||
      obj.cost_usd !== undefined ||
      (obj.usage && typeof obj.usage === 'object')
    );
    if (!temCamposCli) return null;

    const u = obj.usage || {};
    const inputTokens = Math.max(0, Number(u.input_tokens) || 0);
    const outputTokens = Math.max(0, Number(u.output_tokens) || 0);
    const cacheCreationTokens = Math.max(0, Number(u.cache_creation_input_tokens) || 0);
    const cacheReadTokens = Math.max(0, Number(u.cache_read_input_tokens) || 0);
    const thinkingTokens = Math.max(0, Number(u.thinking_tokens ?? obj.thinking_tokens) || 0);
    const custoRaw = obj.total_cost_usd ?? obj.cost_usd;
    const custoUsd = (custoRaw !== undefined && custoRaw !== null && Number.isFinite(Number(custoRaw)))
      ? Number(Number(custoRaw).toFixed(6))
      : null;

    // Tokens equivalentes de cota reportados pelo CLI (inclui input, output, thinking e peso parcial de cache)
    const tokensReaisCli = Math.round(
      inputTokens +
      outputTokens +
      thinkingTokens +
      cacheCreationTokens * 0.25 +
      cacheReadTokens * 0.05
    );

    let texto = '';
    if (typeof obj.result === 'string') {
      texto = obj.result;
    } else if (typeof obj.text === 'string') {
      texto = obj.text;
    } else if (Array.isArray(obj.content)) {
      texto = obj.content.map((c) => (typeof c?.text === 'string' ? c.text : '')).join('');
    } else if (Array.isArray(obj.message?.content)) {
      texto = obj.message.content.map((c) => (typeof c?.text === 'string' ? c.text : '')).join('');
    }

    return {
      eraJson: true,
      isError: Boolean(obj.is_error),
      texto,
      metricas: {
        inputTokens,
        outputTokens,
        cacheCreationTokens,
        cacheReadTokens,
        thinkingTokens,
        tokensReaisCli,
        custoUsd,
      },
    };
  };

  // 1) JSON unico (objeto ou array de eventos do CLI)
  if ((trim.startsWith('{') && trim.endsWith('}')) || (trim.startsWith('[') && trim.endsWith(']'))) {
    try {
      const parsed = JSON.parse(trim);
      if (Array.isArray(parsed)) {
        for (let i = parsed.length - 1; i >= 0; i--) {
          const r = extrairDeObjeto(parsed[i]);
          if (r) return r;
        }
      } else {
        const r = extrairDeObjeto(parsed);
        if (r) return r;
      }
    } catch {}
  }

  // 2) JSONL / stream-json (multiplas linhas JSON)
  if (trim.includes('{') && trim.includes('"type"')) {
    const linhas = trim.split(/\r?\n/);
    let textoAcumulado = '';
    let ultimoResultado = null;
    for (const l of linhas) {
      const lt = l.trim();
      if (!lt.startsWith('{') || !lt.endsWith('}')) continue;
      try {
        const obj = JSON.parse(lt);
        const r = extrairDeObjeto(obj);
        if (r) {
          if (r.texto) textoAcumulado = r.texto;
          ultimoResultado = r;
        }
      } catch {}
    }
    if (ultimoResultado) {
      if (!ultimoResultado.texto && textoAcumulado) ultimoResultado.texto = textoAcumulado;
      return ultimoResultado;
    }
  }

  return { eraJson: false, texto: s, metricas: null };
}

/**
 * Registra uma chamada do Claude CLI em `C:\FabricaClaude\logs\claude_usage.jsonl`.
 */
export function registrarUsoClaude(entrada = {}, { arquivoLog = ARQUIVO_CLAUDE_USAGE_PADRAO } = {}) {
  try {
    const charsPrompt = Math.max(0, Number(entrada.charsPrompt) || 0);
    const charsSaida = Math.max(0, Number(entrada.charsSaida) || 0);
    const tokensPorChars = Math.ceil((charsPrompt + charsSaida) / 4);
    const tokensReaisCli = Math.max(0, Number(entrada.tokensReaisCli) || 0);
    const tokensEstimados = Math.max(
      0,
      Number(entrada.tokensEstimados) || (tokensReaisCli > 0 ? Math.max(tokensReaisCli, tokensPorChars) : tokensPorChars)
    );
    const custoRaw = entrada.custoUsd ?? entrada.total_cost_usd;
    const custoUsd = (custoRaw !== undefined && custoRaw !== null && Number.isFinite(Number(custoRaw)))
      ? Number(Number(custoRaw).toFixed(6))
      : null;

    const registro = {
      timestamp: entrada.timestamp || new Date().toISOString(),
      tipo: String(entrada.tipo || 'geral'),
      novelaSlug: entrada.novelaSlug ? String(entrada.novelaSlug) : null,
      novelaTitulo: entrada.novelaTitulo ? String(entrada.novelaTitulo) : null,
      charsPrompt,
      charsSaida,
      tokensEstimados,
      ...(tokensReaisCli > 0 ? { tokensReaisCli } : {}),
      ...(Number(entrada.tokensInput) > 0 ? { tokensInput: Number(entrada.tokensInput) } : {}),
      ...(Number(entrada.tokensOutput) > 0 ? { tokensOutput: Number(entrada.tokensOutput) } : {}),
      ...(Number(entrada.tokensCacheCreation) > 0 ? { tokensCacheCreation: Number(entrada.tokensCacheCreation) } : {}),
      ...(Number(entrada.tokensCacheRead) > 0 ? { tokensCacheRead: Number(entrada.tokensCacheRead) } : {}),
      ...(Number(entrada.tokensThinking) > 0 ? { tokensThinking: Number(entrada.tokensThinking) } : {}),
      ...(custoUsd !== null ? { custoUsd } : {}),
      duracaoMs: Math.max(0, Math.round(Number(entrada.duracaoMs) || 0)),
      ok: Boolean(entrada.ok),
      modelo: normalizarModeloClaude(entrada.modelo),
    };
    registro.pesoModelo = PESO_MODELO_CLAUDE[registro.modelo] || 1;
    registro.tokensPonderados = Math.round(registro.tokensEstimados * registro.pesoModelo);
    fs.mkdirSync(path.dirname(arquivoLog), { recursive: true });
    fs.appendFileSync(arquivoLog, JSON.stringify(registro) + '\n', 'utf8');
    return registro;
  } catch {
    return null;
  }
}

/**
 * Enriquece o ultimo registro de uso com `novelaSlug` e `novelaTitulo` quando descobertos pos-chamada (ex.: etapa Roteiro).
 */
export function atualizarUltimoRegistroUsoClaude({ novelaSlug, novelaTitulo } = {}, { arquivoLog = ARQUIVO_CLAUDE_USAGE_PADRAO } = {}) {
  try {
    if (!fs.existsSync(arquivoLog) || (!novelaSlug && !novelaTitulo)) return false;
    const linhas = fs.readFileSync(arquivoLog, 'utf8').split(/\r?\n/).filter((l) => l.trim());
    if (!linhas.length) return false;
    const ult = JSON.parse(linhas[linhas.length - 1]);
    if (novelaSlug && !ult.novelaSlug) ult.novelaSlug = String(novelaSlug);
    if (novelaTitulo && (!ult.novelaTitulo || /^(Gerar|Roteiro|Prompts|Sementes|Criar)/i.test(ult.novelaTitulo))) {
      ult.novelaTitulo = String(novelaTitulo);
    }
    linhas[linhas.length - 1] = JSON.stringify(ult);
    fs.writeFileSync(arquivoLog, linhas.join('\n') + '\n', 'utf8');
    return true;
  } catch {
    return false;
  }
}

/** Le todos os registros validos de `claude_usage.jsonl`. */
export function lerRegistrosUsoClaude({ arquivoLog = ARQUIVO_CLAUDE_USAGE_PADRAO } = {}) {
  try {
    if (!fs.existsSync(arquivoLog)) return [];
    const txt = fs.readFileSync(arquivoLog, 'utf8');
    const out = [];
    for (const linha of txt.split(/\r?\n/)) {
      const l = linha.trim();
      if (!l) continue;
      try {
        const j = JSON.parse(l);
        if (j && j.timestamp) out.push(j);
      } catch {}
    }
    return out;
  } catch {
    return [];
  }
}

/** Salva ou atualiza a calibracao/reset do painel de cota do Claude. */
export function salvarCalibracaoCotaClaude(
  patch = {},
  {
    arquivoCalibracao = ARQUIVO_CLAUDE_CALIBRACAO_PADRAO,
    arquivoLog = ARQUIVO_CLAUDE_USAGE_PADRAO,
    padroes = {},
  } = {}
) {
  let atual = {};
  try {
    if (fs.existsSync(arquivoCalibracao)) atual = JSON.parse(fs.readFileSync(arquivoCalibracao, 'utf8'));
  } catch {}
  const novo = {
    pctPorHistoriaPadrao: 2.7,
    tokensPorHistoriaRef: 8500,
    fatorSemanaSobre5h: 12,
    metaSemanaPct: 60,
    reset5hEm: null,
    resetSemanaEm: null,
    offset5hPct: 0,
    ...atual,
    ...patch,
  };
  if (patch.zerarJanela5h) {
    novo.reset5hEm = new Date().toISOString();
    novo.offset5hPct = 0;
  }
  if (patch.zerarSemana) {
    novo.resetSemanaEm = new Date().toISOString();
  }
  if (patch.percentual5hAtualReal !== undefined && patch.percentual5hAtualReal !== null && patch.percentual5hAtualReal !== '') {
    const alvoPct = Math.max(0, Math.min(100, Number(patch.percentual5hAtualReal) || 0));
    try {
      fs.mkdirSync(path.dirname(arquivoCalibracao), { recursive: true });
      fs.writeFileSync(arquivoCalibracao, JSON.stringify({ ...novo, offset5hPct: 0 }, null, 2), 'utf8');
      const semOffset = calcularResumoCotaClaude({ arquivoLog, arquivoCalibracao, padroes });
      const basePct = Number(semOffset?.janela5h?.percentual) || 0;
      novo.offset5hPct = Number((alvoPct - basePct).toFixed(2));
    } catch {
      novo.offset5hPct = Number(alvoPct.toFixed(2));
    }
  }
  delete novo.zerarJanela5h;
  delete novo.zerarSemana;
  delete novo.percentual5hAtualReal;
  try {
    fs.mkdirSync(path.dirname(arquivoCalibracao), { recursive: true });
    fs.writeFileSync(arquivoCalibracao, JSON.stringify(novo, null, 2), 'utf8');
  } catch {}
  return novo;
}

/**
 * Calcula o consumo agregado do Claude CLI:
 *  - Janela Movel de 5 horas (300 min)
 *  - Hoje (24h)
 *  - Semana (7 dias)
 *  - Historico das ultimas 8 chamadas
 * Calibrado por padrao para ~2.7% (faixa 2.5%-3%) por historia completa de 18 cenas em modo Resumo (~8.500 tokens em 2 chamadas stateless).
 */
export function calcularResumoCotaClaude({
  arquivoLog = ARQUIVO_CLAUDE_USAGE_PADRAO,
  arquivoCalibracao = ARQUIVO_CLAUDE_CALIBRACAO_PADRAO,
  agora = Date.now(),
  padroes = {},
} = {}) {
  let calSalva = {};
  try {
    if (arquivoCalibracao && fs.existsSync(arquivoCalibracao)) {
      calSalva = JSON.parse(fs.readFileSync(arquivoCalibracao, 'utf8'));
    }
  } catch {}
  const pctPorHistoria = Math.max(0.5, Math.min(50, Number(padroes?.cotaPctPorHistoria || calSalva.pctPorHistoriaPadrao) || 2.7));
  const tokensPorHistoriaRef = Math.max(1000, Number(calSalva.tokensPorHistoriaRef) || 8500);
  const tokensLimite5h = Math.round((tokensPorHistoriaRef / pctPorHistoria) * 100);
  const fatorSemana = Math.max(2, Number(calSalva.fatorSemanaSobre5h) || 12);
  const tokensLimiteSemana = tokensLimite5h * fatorSemana;
  const metaSemanaPct = Math.max(10, Math.min(100, Number(calSalva.metaSemanaPct) || 60));

  const ms5h = 5 * 3600 * 1000;
  const ms24h = 24 * 3600 * 1000;
  const ms7d = 7 * 24 * 3600 * 1000;

  const corte5h = Math.max(agora - ms5h, calSalva.reset5hEm ? new Date(calSalva.reset5hEm).getTime() || 0 : 0);
  const corte24h = agora - ms24h;
  const corte7d = Math.max(agora - ms7d, calSalva.resetSemanaEm ? new Date(calSalva.resetSemanaEm).getTime() || 0 : 0);

  const registros = lerRegistrosUsoClaude({ arquivoLog });
  const pctDeTokens5h = (tok) => Number(((Math.max(0, Number(tok) || 0) / tokensLimite5h) * 100).toFixed(2));
  const pctDeTokensSem = (tok) => Number(((Math.max(0, Number(tok) || 0) / tokensLimiteSemana) * 100).toFixed(2));

  const rec5h = [];
  const rec24h = [];
  const rec7d = [];

  for (const r of registros) {
    const t = new Date(r.timestamp).getTime();
    if (!Number.isFinite(t)) continue;
    if (t >= corte5h && t <= agora + 60000) rec5h.push({ ...r, _t: t });
    if (t >= corte24h && t <= agora + 60000) rec24h.push({ ...r, _t: t });
    if (t >= corte7d && t <= agora + 60000) rec7d.push({ ...r, _t: t });
  }

  const tokensBase = (x) => {
    const porChars = Math.ceil(((x.charsPrompt || 0) + (x.charsSaida || 0)) / 4);
    const cli = Number(x.tokensReaisCli) || 0;
    const est = Number(x.tokensEstimados) || 0;
    return cli > 0 ? Math.max(cli, est, porChars) : (est || porChars);
  };
  const custoDe = (x) => (Number.isFinite(Number(x.custoUsd)) && Number(x.custoUsd) > 0 ? Number(x.custoUsd) : 0);
  const somarCusto = (arr) => Number(arr.reduce((acc, x) => acc + custoDe(x), 0).toFixed(4));
  const modeloDe = (x) => normalizarModeloClaude(x.modelo); // registros antigos (sem campo) = Sonnet
  const pesoDe = (x) => Number(x.pesoModelo) || PESO_MODELO_CLAUDE[modeloDe(x)] || 1;
  const tokPond = (x) => Number(x.tokensPonderados) || Math.round(tokensBase(x) * pesoDe(x));
  const somarTokens = (arr) => arr.reduce((acc, x) => acc + tokPond(x), 0);
  const porModelo = (arr) => {
    const out = {};
    for (const x of arr) {
      const m = modeloDe(x);
      out[m] = out[m] || { chamadas: 0, tokensReais: 0, tokensPonderados: 0, custoUsd: 0 };
      out[m].chamadas++;
      out[m].tokensReais += tokensBase(x);
      out[m].tokensPonderados += tokPond(x);
      out[m].custoUsd = Number((out[m].custoUsd + custoDe(x)).toFixed(4));
    }
    return out;
  };
  const contarHistorias = (arr) => {
    const slugs = new Set();
    let avulsas = 0;
    for (const x of arr) {
      if (!x.ok) continue;
      if (x.novelaSlug) slugs.add(x.novelaSlug);
      else if (['roteiro', 'automatico', 'parte'].includes(x.tipo)) avulsas++;
    }
    return slugs.size + avulsas;
  };

  const tokens5h = somarTokens(rec5h);
  const tokens24h = somarTokens(rec24h);
  const tokens7d = somarTokens(rec7d);
  const custo5h = somarCusto(rec5h);
  const custo24h = somarCusto(rec24h);
  const custo7d = somarCusto(rec7d);

  const offset5h = Number(calSalva.offset5hPct) || 0;
  const pct5hBruto = pctDeTokens5h(tokens5h) + offset5h;
  const pct5h = Math.max(0, Math.min(100, Number(pct5hBruto.toFixed(1))));
  const pct24h = Math.max(0, Number(pctDeTokens5h(tokens24h).toFixed(1)));
  const pctSemana = Math.max(0, Math.min(100, Number(pctDeTokensSem(tokens7d).toFixed(1))));

  // Horario estimado de liberacao da janela de 5h
  let liberaEm = null;
  let liberaTotalEm = null;
  let minutosParaLiberar = 0;
  if (rec5h.length > 0) {
    const maisAntiga = Math.min(...rec5h.map((x) => x._t));
    const maisRecente = Math.max(...rec5h.map((x) => x._t));
    liberaEm = new Date(maisAntiga + ms5h).toISOString();
    liberaTotalEm = new Date(maisRecente + ms5h).toISOString();
    minutosParaLiberar = Math.max(1, Math.ceil((maisRecente + ms5h - agora) / 60000));
  }

  const ultimasChamadas = registros
    .slice(-8)
    .reverse()
    .map((r) => {
      const tokReal = tokensBase(r);
      const tok = tokPond(r);
      return {
        timestamp: r.timestamp,
        tipo: r.tipo || 'geral',
        novelaSlug: r.novelaSlug || null,
        novelaTitulo: r.novelaTitulo || r.novelaSlug || 'História',
        charsPrompt: r.charsPrompt || 0,
        charsSaida: r.charsSaida || 0,
        tokensEstimados: tok,
        tokensReais: tokReal,
        tokensInput: Number(r.tokensInput) || null,
        tokensOutput: Number(r.tokensOutput) || null,
        custoUsd: custoDe(r) || null,
        modelo: modeloDe(r),
        modeloRotulo: ROTULO_MODELO_CLAUDE[modeloDe(r)],
        pesoModelo: pesoDe(r),
        duracaoMs: r.duracaoMs || 0,
        ok: Boolean(r.ok),
        percentual5h: Number(Math.max(0.1, pctDeTokens5h(tok)).toFixed(1)),
      };
    });

  return {
    janela5h: {
      chamadas: rec5h.length,
      tokensEstimados: tokens5h,
      custoUsd: custo5h,
      porModelo: porModelo(rec5h),
      percentual: pct5h,
      liberaEm,
      liberaTotalEm,
      minutosParaLiberar,
    },
    hoje24h: {
      chamadas: rec24h.length,
      tokensEstimados: tokens24h,
      custoUsd: custo24h,
      percentual5hEquiv: pct24h,
      historias: contarHistorias(rec24h),
    },
    semana7d: {
      chamadas: rec7d.length,
      tokensEstimados: tokens7d,
      custoUsd: custo7d,
      porModelo: porModelo(rec7d),
      percentual: pctSemana,
      metaPercentual: metaSemanaPct,
      historias: contarHistorias(rec7d),
    },
    pesosModelo: PESO_MODELO_CLAUDE,
    calibracao: {
      pctPorHistoriaPadrao: pctPorHistoria,
      tokensPorHistoriaRef,
      tokensLimite5h,
      tokensLimiteSemana,
      reset5hEm: calSalva.reset5hEm || null,
      offset5hPct: offset5h,
    },
    ultimasChamadas,
  };
}

/**
 * Executa `claude -p` SEMPRE em modo stateless de 1 unico turno (`--max-turns 1 --tools "" --no-session-persistence`)
 * e com `cwd` em uma pasta temporaria VAZIA (nunca em C:\FabricaClaude nem C:\FlowStudio).
 * Por padrao usa `--output-format json` para capturar metricas reais de uso/custo (`usage`, `total_cost_usd`)
 * e desempacota `result` de forma transparente para os parsers de texto.
 * Registra automaticamente a chamada em `C:\FabricaClaude\logs\claude_usage.jsonl`.
 */
export function executarClaude({
  prompt,
  comando,
  extraArgs = ['--max-turns', '1', '--tools', ''],
  timeoutMs = 75000,
  onData = null,
  cwd = null,
  processoRef = null,
  meta = {},
  arquivoUsageLog = ARQUIVO_CLAUDE_USAGE_PADRAO,
  modelo = null,
  outputFormat = 'json',
}) {
  return new Promise((resolve, reject) => {
    if (!comando) return reject(new Error('Claude Code CLI não encontrado.'));
    const modeloUsado = normalizarModeloClaude(modelo || meta?.modelo); // --model opus | --model sonnet (padrão: sonnet)
    const tInicio = Date.now();
    const charsPrompt = String(prompt || '').length;
    let jaRegistrou = false;
    const gravarLog = (ok, saidaTexto, metricas = null) => {
      if (jaRegistrou || arquivoUsageLog === false) return;
      jaRegistrou = true;
      const charsSaida = String(saidaTexto || '').length;
      const tokensPorChars = Math.ceil((charsPrompt + charsSaida) / 4);
      const tokensReaisCli = Number(metricas?.tokensReaisCli) || 0;
      registrarUsoClaude({
        timestamp: new Date().toISOString(),
        tipo: meta?.tipo || 'geral',
        novelaSlug: meta?.novelaSlug || null,
        novelaTitulo: meta?.novelaTitulo || null,
        charsPrompt,
        charsSaida,
        tokensEstimados: tokensReaisCli > 0 ? Math.max(tokensReaisCli, tokensPorChars) : tokensPorChars,
        tokensReaisCli: tokensReaisCli || undefined,
        tokensInput: metricas?.inputTokens || undefined,
        tokensOutput: metricas?.outputTokens || undefined,
        tokensCacheCreation: metricas?.cacheCreationTokens || undefined,
        tokensCacheRead: metricas?.cacheReadTokens || undefined,
        tokensThinking: metricas?.thinkingTokens || undefined,
        custoUsd: metricas?.custoUsd ?? undefined,
        duracaoMs: Date.now() - tInicio,
        ok,
        modelo: modeloUsado,
      }, { arquivoLog: arquivoUsageLog || ARQUIVO_CLAUDE_USAGE_PADRAO });
    };

    const cwdSeguro = obterPastaClaudeVazia();
    // Bloqueia qualquer tentativa de rodar dentro da Fabrica ou do FlowStudio
    const dirExec = (cwd && fs.existsSync(cwd) && !path.resolve(cwd).toLowerCase().startsWith(path.resolve(FABRICA_DIR).toLowerCase()) && !path.resolve(cwd).toLowerCase().startsWith(path.resolve(process.cwd()).toLowerCase()))
      ? cwd
      : cwdSeguro;
    const argsExtras = Array.isArray(extraArgs) ? [...extraArgs] : [];
    if (!argsExtras.includes('--max-turns')) argsExtras.unshift('--max-turns', '1');
    if (!argsExtras.includes('--tools')) argsExtras.push('--tools', '');
    const formatoSaida = outputFormat === 'text' ? 'text' : 'json';
    const ehScript = /\.(cmd|bat)$/i.test(comando);
    const baseArgs = ['-p', '--output-format', formatoSaida, '--model', modeloUsado, '--no-session-persistence', ...argsExtras];
    const child = ehScript
      ? spawn('cmd.exe', ['/d', '/s', '/c', `"${aspas(comando)} ${baseArgs.map(aspas).join(' ')}"`], {
          cwd: dirExec, windowsHide: true, windowsVerbatimArguments: true, stdio: ['pipe', 'pipe', 'pipe'],
        })
      : spawn(comando, baseArgs, { cwd: dirExec, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    if (processoRef) {
      processoRef.child = child;
      processoRef.cwd = dirExec;
      processoRef.args = baseArgs;
      processoRef.modelo = modeloUsado;
    }

    let stdout = '';
    let stderr = '';
    let streamouTextoPuro = false;
    const timer = setTimeout(() => {
      matarArvore(child);
      const env = extrairEnvelopeJsonClaude(stdout);
      if (env.eraJson && env.texto && !streamouTextoPuro) onData?.(env.texto);
      gravarLog(false, env.texto || stdout, env.metricas);
      reject(new Error(`Claude Code CLI excedeu ${Math.round(timeoutMs / 1000)}s.`));
    }, timeoutMs);

    child.stdout.on('data', (d) => {
      const t = d.toString('utf8');
      stdout += t;
      if (formatoSaida === 'text') {
        streamouTextoPuro = true;
        onData?.(t);
      }
    });
    child.stderr.on('data', (d) => { stderr += d.toString('utf8'); });
    child.on('error', (err) => {
      clearTimeout(timer);
      const env = extrairEnvelopeJsonClaude(stdout);
      gravarLog(false, env.texto || stdout, env.metricas);
      reject(err);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      const env = extrairEnvelopeJsonClaude(stdout);
      const textoFinal = env.eraJson ? env.texto : stdout;
      if (!streamouTextoPuro && textoFinal) {
        onData?.(textoFinal);
      }
      const okFinal = code === 0 && !env.isError;
      gravarLog(okFinal, textoFinal, env.metricas);
      if (!okFinal) {
        return reject(new Error(stderr.trim() || String(textoFinal || stdout).trim() || `claude saiu com código ${code}`));
      }
      resolve(String(textoFinal || '').trim());
    });
    child.stdin.write(prompt, 'utf8');
    child.stdin.end();
  });
}

function executarClaudePrint(comando, instrucaoCompleta, timeoutMs = 75000, meta = {}) {
  return executarClaude({ prompt: instrucaoCompleta, comando, extraArgs: ['--max-turns', '1', '--tools', ''], timeoutMs, meta });
}

/** Status completo do Claude CLI: instalado, versao, logado e modelo forcado. */
export function statusClaudeCompleto({ forcar = false } = {}) {
  const cli = detectarClaudeCli({ forcar });
  const out = { ...cli, modeloBackground: MODELO_BACKGROUND, pastaFabrica: FABRICA_DIR, fabricaExiste: fs.existsSync(FABRICA_DIR), logado: null, metodoLogin: null };
  if (!cli.disponivel) return out;
  try {
    const ehScript = /\.(cmd|bat)$/i.test(cli.comando);
    const txt = ehScript
      ? execFileSync('cmd.exe', ['/d', '/s', '/c', `"${aspas(cli.comando)} auth status"`], { encoding: 'utf8', timeout: 8000, windowsHide: true, windowsVerbatimArguments: true })
      : execFileSync(cli.comando, ['auth', 'status'], { encoding: 'utf8', timeout: 8000, windowsHide: true });
    const j = JSON.parse(txt);
    out.logado = !!j.loggedIn;
    out.metodoLogin = j.authMethod || null;
  } catch (e) {
    // `claude auth status` sai com codigo 1 quando NAO esta logado, mas ainda imprime o JSON
    try {
      const j = JSON.parse(String(e.stdout || ''));
      out.logado = !!j.loggedIn;
      out.metodoLogin = j.authMethod || null;
    } catch {}
  }
  return out;
}

/** Abre um terminal VISIVEL com o claude para o usuario fazer login (/login) na pasta da Fabrica. */
export function abrirLoginClaude() {
  const cli = detectarClaudeCli({ forcar: true });
  if (!cli.disponivel) throw new Error('Claude Code CLI não encontrado neste PC.');
  const cwd = fs.existsSync(FABRICA_DIR) ? FABRICA_DIR : process.env.USERPROFILE || process.cwd();
  spawn('cmd.exe', ['/c', 'start', '"Login do Claude"', 'cmd.exe', '/k', aspas(cli.comando)], {
    cwd, detached: true, stdio: 'ignore', windowsHide: false, windowsVerbatimArguments: true,
  }).unref();
  return { ok: true, mensagem: 'Terminal aberto. Se pedir login, digite /login e siga os passos no navegador.' };
}

/** Corpo (sem frontmatter) de uma skill da Fabrica, para embutir no prompt. */
export function lerSkillFabrica(nome) {
  try {
    const t = fs.readFileSync(path.join(FABRICA_DIR, '.claude', 'skills', nome, 'SKILL.md'), 'utf8').replace(/^﻿/, '');
    return t.replace(/^---[\s\S]*?---\s*/, '').trim();
  } catch { return ''; }
}

/**
 * Reescreve cirurgicamente via Claude Code CLI (`claude -p`) um prompt de imagem ou vídeo que falhou/bloqueou no Google Flow:
 *  - Suporta múltiplas rodadas progressivamente mais seguras (`attempt = 1, 2, 3, 4`);
 *  - Envia o prompt que falhou + motivo do erro + contexto dos personagens/cena + tentativas anteriores que já falharam;
 *  - Preserva 100% da aparência física, roupa exata, cenário, continuidade e fala em português entre aspas;
 *  - Se o Claude CLI falhar/expirar, aplica o fallback determinístico local (`suavizarPromptLocal`) correspondente ao nível da rodada.
 */
export async function repairBlockedPrompt({
  item,
  errorReason = '',
  novelSummary = '',
  neighborItems = [],
  attempt = 1,
  previousAttempts = [],
  log,
  contextoHistoria = '',
  permitirClaude = true,
} = {}) {
  const promptOriginal = limparVazamentoExplicacaoPrompt(String(item?.promptOriginalBackup || item?.originalPrompt || item?.prompt || '').trim());
  const promptAtualFalho = limparVazamentoExplicacaoPrompt(String(item?.prompt || promptOriginal).trim());
  if (!promptOriginal) throw new Error('Prompt vazio para reparo.');

  const rodada = Math.max(1, Math.min(4, Number(attempt) || 1));
  const ehImagem = item?.tipo !== 'video';

  const cli = permitirClaude ? detectarClaudeCli() : { disponivel: false };
  if (permitirClaude && cli.disponivel && cli.comando) {
    try {
      const nivelInstrucao = {
        1: 'RODADA 1 (REESCRITA CIRÚRGICA): Substitua apenas os termos sensíveis que acionam o filtro do Google Flow (violência física, queda/quebra de objetos como copos/vidros, ferimentos, choro/engasgo extremo como "choked"/"sobbing", palavras de conflito pesado, idade vulnerável em sofrimento ou descrições ambíguas) por equivalentes visuais cinematográficos seguros.',
        2: 'RODADA 2 (SUAVIZAÇÃO DRAMÁTICA CONTIDA): A tentativa anterior ainda foi rejeitada pelo filtro. Reformule a ação corporal e expressões faciais para uma postura de novela televisiva serena e contida ("composed", "earnest", "attentive", "standing naturally"), removendo qualquer gesto brusco, choque, susto, tensão física ou objeto sensível.',
        3: 'RODADA 3 (REFORMULAÇÃO NEUTRA DE TV ABERTA): O filtro do Google Flow bloqueou as formulações anteriores. Reescreva a cena de forma 100% neutra, pacífica e segura (estilo fotografia editorial de novela familiar de TV aberta), descrevendo os personagens com suas roupas e traços físicos exatos conversando calmamente no cenário iluminado, sem nenhuma palavra de tristeza, conflito, susto ou drama.',
        4: 'RODADA 4 (ENQUADRAMENTO FOTOGRÁFICO ULTRA-SEGURO): Última rodada de segurança máxima! Descreva apenas um retrato/plano cinematográfico vertical 9:16 limpo e elegante mostrando os personagens (com 100% da aparência física e roupas exatas) posicionados de forma tranquila e respeitosa no cenário, com iluminação natural suave e expressão calma/conversacional.',
      }[rodada];

      const vizinhosTxt = Array.isArray(neighborItems) && neighborItems.length
        ? neighborItems.map((v) => `{${v.id}}: ${String(v.promptOriginalBackup || v.prompt || '').slice(0, 180)}`).join('\n')
        : '';
      const anterioresTxt = Array.isArray(previousAttempts) && previousAttempts.length
        ? previousAttempts.slice(-3).map((p, i) => `Tentativa anterior #${i + 1} (rejeitada): ${p}`).join('\n')
        : '';

      const instrucao = [
        `REPARO CIRÚRGICO DE PROMPT (${ehImagem ? 'IMAGEM NANO BANANA / GOOGLE FLOW' : 'VÍDEO VEO / GOOGLE FLOW'}) — 1 ÚNICO TURNO STATELESS, ZERO EXPLICAÇÕES:`,
        nivelInstrucao,
        '',
        'REGRAS OBRIGATÓRIAS:',
        '1) PRESERVE 100% da aparência física de cada personagem (idade, tom de pele, cabelo, barba, traços do rosto), 100% das roupas/cores exatas, 100% do cenário/iluminação e 100% da continuidade com a cena.',
        '2) Se houver fala em português entre aspas ("..."), preserve a fala e a quantidade exata de blocos entre aspas.',
        '3) Remova termos gatilho em inglês fora das aspas (`ultrarealistic` -> `cinematic`, `photorealistic` -> `naturalistic`, `choked` -> `composed and earnest`, `drops the glass` -> `holds the glass calmly`, `shocked` -> `attentive`, `humiliated` -> `thoughtful`, `angry`/`aggressive`/`confrontational`/`furious` -> `composed`/`direct`, `shouting`/`screaming` -> `speaking clearly`, `crying`/`sobbing`/`weeping` -> `visibly moved`, `grabbing`/`pushing`/`slapping` -> `standing beside`).',
        '4) Devolva SOMENTE o texto final do prompt em 1 única linha limpa. PROIBIDO adicionar cercas ```, traços ---, cabeçalhos {id} ou qualquer comentário antes ou depois.',
        '',
        ...(errorReason ? [`MOTIVO DO ERRO NO GOOGLE FLOW: ${String(errorReason).slice(0, 260)}`] : []),
        ...(novelSummary ? [`CONTEXTO DOS PERSONAGENS/NOVELA: ${String(novelSummary).slice(0, 500)}`] : []),
        ...(contextoHistoria ? [`CONTEXTO ADICIONAL: ${String(contextoHistoria).slice(0, 350)}`] : []),
        ...(vizinhosTxt ? [`CENAS VIZINHAS (CONTINUIDADE):\n${vizinhosTxt}`] : []),
        ...(anterioresTxt ? [`FORMULAÇÕES JÁ REJEITADAS (NÃO REPITA ESTAS FRASES EXATAS):\n${anterioresTxt}`] : []),
        '',
        'PROMPT ORIGINAL:',
        promptOriginal,
        ...(promptAtualFalho !== promptOriginal ? ['\nÚLTIMA VERSÃO QUE FALHOU:', promptAtualFalho] : []),
      ].join('\n');

      const resposta = await executarClaudePrint(cli.comando, instrucao, 45000, {
        tipo: 'reparo_bloqueio',
        novelaSlug: item?.id || null,
        novelaTitulo: (novelSummary || '').split('\n')[0]?.slice(0, 60) || `Reparo R${rodada} ${item?.id || ''}`.trim(),
      });
      const limpo = limparSaidaClaude(resposta, item);
      const falasOrig = extrairFalasEntreAspas(promptOriginal);
      const falasCand = extrairFalasEntreAspas(limpo);
      const candidatoValido = limpo && limpo.length >= 25 && (falasCand.length === falasOrig.length || !falasOrig.length)
        ? suavizarPromptLocal(limpo, rodada)
        : null;

      if (candidatoValido) {
        log?.(`✨ Prompt de {${item?.id}} reescrito cirurgicamente pelo Claude (Rodada ${rodada}/4 · ${cli.versao}).`, 'ok');
        return { prompt: candidatoValido, origem: 'claude-cli', versao: cli.versao, rodada };
      }
      log?.(`Claude retornou saída fora do padrão na Rodada ${rodada} — aplicando suavização progressiva local.`, 'aviso');
    } catch (e) {
      log?.(`Claude indisponível na Rodada ${rodada} (${e.message}) — aplicando suavização progressiva local.`, 'aviso');
    }
  }

  const suavizado = suavizarPromptLocal(promptOriginal, rodada);
  log?.(`Prompt de {${item?.id}} suavizado pelo fallback local progressivo (Rodada ${rodada}/4, 100% de roupas/cenário/falas preservados).`, 'info');
  return { prompt: suavizado, origem: 'fallback-local', versao: null, rodada };
}
