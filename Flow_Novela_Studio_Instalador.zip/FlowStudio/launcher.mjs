// =========================================================================
//  Flow Novela Studio — Launcher Blindado + Supervisor Auto-Restart + Updater
//  Acionado de forma 100% oculta por INICIAR_APP.vbs (zero janela preta CMD)
// =========================================================================
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { spawn, spawnSync, execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  calcularHashArquivo,
  verificarAtualizacao,
  aplicarAtualizacao,
} from './server/updaterService.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname);
const DADOS = path.join(ROOT, 'dados');
const LOG_FILE = path.join(DADOS, 'startup.log');
const HASH_FILE = path.join(DADOS, '.package_hash');
const PID_DAEMON_FILE = path.join(DADOS, '.daemon.pid');
const PORT = Number(process.env.PORT) || 3456;
const HEALTH_URL = `http://127.0.0.1:${PORT}/api/health`;
const APP_URL = `http://localhost:${PORT}`;

fs.mkdirSync(DADOS, { recursive: true });

function registrarLog(msg) {
  const linha = `[${new Date().toISOString()}] [LAUNCHER] ${msg}\n`;
  try {
    fs.appendFileSync(LOG_FILE, linha, 'utf8');
  } catch {}
}

function dormir(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function consultarHealth(timeoutMs = 1500) {
  return new Promise((resolve) => {
    let concluido = false;
    const finalizar = (res) => {
      if (concluido) return;
      concluido = true;
      clearTimeout(timer);
      resolve(res);
    };
    const timer = setTimeout(() => {
      try { req?.destroy(); } catch {}
      finalizar(null);
    }, timeoutMs);

    const req = http.get(HEALTH_URL, (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        return finalizar(null);
      }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        try {
          const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          finalizar(data?.ok ? data : null);
        } catch {
          finalizar(null);
        }
      });
    });
    req.on('error', () => finalizar(null));
  });
}

function dispararUpdateEmServidorAtivo() {
  return new Promise((resolve) => {
    const req = http.request(
      `http://127.0.0.1:${PORT}/api/update/verificar?auto=1`,
      { method: 'POST', timeout: 3500 },
      (res) => {
        res.resume();
        resolve(true);
      }
    );
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      try { req.destroy(); } catch {}
      resolve(false);
    });
    req.end();
  });
}

/**
 * Localiza apenas os PIDs que estão em estado LISTEN na porta 3456 e finaliza somente eles.
 */
function finalizarPidPresoNaPorta(porta = PORT) {
  try {
    const out = execFileSync('netstat.exe', ['-ano', '-p', 'tcp'], {
      encoding: 'utf8',
      windowsHide: true,
    });
    const pids = new Set();
    for (const raw of out.split(/\r?\n/)) {
      const l = raw.trim();
      if (!l.startsWith('TCP')) continue;
      const partes = l.split(/\s+/);
      if (partes.length < 5) continue;
      const localAddr = partes[1];
      const estado = partes[3];
      const pid = Number(partes[4]);
      if (
        (localAddr.endsWith(`:${porta}`) || localAddr.endsWith(`]:${porta}`)) &&
        /LISTENING/i.test(estado) &&
        pid > 0 &&
        pid !== process.pid
      ) {
        pids.add(pid);
      }
    }
    for (const pid of pids) {
      registrarLog(`Porta ${porta} presa por processo que não responde a /api/health — finalizando apenas o PID ${pid}.`);
      try {
        process.kill(pid, 'SIGKILL');
      } catch {
        try {
          spawnSync('taskkill.exe', ['/F', '/PID', String(pid)], { windowsHide: true, stdio: 'ignore' });
        } catch {}
      }
    }
    return [...pids];
  } catch (e) {
    registrarLog(`Aviso ao inspecionar porta ${porta}: ${e.message}`);
    return [];
  }
}

/**
 * Verifica se falta node_modules ou se package.json mudou; se necessário, roda npm install oculto.
 */
function garantirDependenciasInstaladas() {
  const arqPkg = path.join(ROOT, 'package.json');
  const hashAtual = calcularHashArquivo(arqPkg);
  let hashSalvo = '';
  try {
    if (fs.existsSync(HASH_FILE)) hashSalvo = fs.readFileSync(HASH_FILE, 'utf8').trim();
  } catch {}

  const temExpress = fs.existsSync(path.join(ROOT, 'node_modules', 'express', 'package.json'));
  const temWs = fs.existsSync(path.join(ROOT, 'node_modules', 'ws', 'package.json'));
  const precisaInstalar = !temExpress || !temWs || (hashAtual && hashSalvo && hashAtual !== hashSalvo);

  if (precisaInstalar) {
    registrarLog(
      !temExpress || !temWs
        ? 'node_modules ausente ou incompleto — rodando npm install automaticamente...'
        : 'package.json mudou — rodando npm install automaticamente...'
    );
    const npmCandidates = [
      path.join(process.env.ProgramFiles || 'C:\\Program Files', 'nodejs', 'npm.cmd'),
      path.join(process.env.LOCALAPPDATA || '', 'Programs', 'nodejs', 'npm.cmd'),
      'npm.cmd',
    ];
    const npmExe = npmCandidates.find((c) => c === 'npm.cmd' || fs.existsSync(c)) || 'npm.cmd';
    const r = spawnSync(npmExe, ['install', '--no-audit', '--no-fund'], {
      cwd: ROOT,
      windowsHide: true,
      encoding: 'utf8',
    });
    if (r.status !== 0) {
      registrarLog(`Aviso npm install (code=${r.status}): ${(r.stderr || r.stdout || '').slice(0, 400)}`);
    } else {
      registrarLog('npm install concluído com sucesso.');
    }
  }

  if (hashAtual && fs.existsSync(path.join(ROOT, 'node_modules', 'express', 'package.json'))) {
    try {
      fs.writeFileSync(HASH_FILE, hashAtual, 'utf8');
    } catch {}
  }
}

/**
 * Verifica se há atualização no GitHub (com timeout máximo estrito de 3s para nunca travar offline).
 */
async function verificarEAplicarAutoUpdateBoot() {
  try {
    const check = await verificarAtualizacao({ rootDir: ROOT, timeoutMs: 3000 });
    if (!check.configurado) return;
    if (check.erro) {
      registrarLog(`Auto-update (offline/timeout 3s ignorado): ${check.erro}`);
      return;
    }
    if (check.atualizacaoDisponivel && check.zipUrl) {
      registrarLog(`Nova versão disponível no GitHub (${check.versaoLocal} → ${check.versaoRemota}). Aplicando atualização...`);
      await aplicarAtualizacao({
        rootDir: ROOT,
        zipUrl: check.zipUrl,
        versaoAlvo: check.versaoRemota,
        log: registrarLog,
      });
    }
  } catch (e) {
    registrarLog(`Auto-update ignorado no boot: ${e.message}`);
  }
}

/**
 * Localiza o Google Chrome (Program Files, Program Files x86 ou LocalAppData) com fallback para Microsoft Edge
 * e abre obrigatoriamente em janela standalone `--app=http://localhost:3456`.
 */
export function abrirJanelaApp(url = APP_URL) {
  const pf = process.env.ProgramFiles || 'C:\\Program Files';
  const pfx86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const localApp = process.env.LOCALAPPDATA || '';

  const candidatos = [
    path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(pfx86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    localApp ? path.join(localApp, 'Google', 'Chrome', 'Application', 'chrome.exe') : '',
    path.join(pfx86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    localApp ? path.join(localApp, 'Microsoft', 'Edge', 'Application', 'msedge.exe') : '',
  ].filter(Boolean);

  const navExe = candidatos.find((c) => fs.existsSync(c));
  if (navExe) {
    registrarLog(`Abrindo janela standalone de aplicativo: "${navExe}" --app=${url}`);
    const child = spawn(navExe, [`--app=${url}`, '--window-size=1500,920'], {
      cwd: ROOT,
      detached: true,
      stdio: 'ignore',
      windowsHide: false,
    });
    child.unref();
    return { ok: true, navegador: navExe };
  }

  // Fallback via cmd start caso nenhum caminho padrão seja encontrado
  registrarLog(`Navegador padrão acionado para ${url}`);
  const child = spawn('cmd.exe', ['/c', 'start', '', url], {
    cwd: ROOT,
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.unref();
  return { ok: true, navegador: 'default' };
}

/**
 * Modo supervisor em background (--daemon): mantém server/index.js rodando com auto-restart.
 */
async function rodarSupervisorDaemon() {
  try {
    fs.writeFileSync(PID_DAEMON_FILE, String(process.pid), 'utf8');
  } catch {}
  registrarLog(`Supervisor background iniciado (PID ${process.pid}).`);

  let falhasSeguidas = 0;
  while (true) {
    // Se já houver outro servidor saudável respondendo em /api/health, aguarda ou encerra duplicata
    const jaAtivo = await consultarHealth(1200);
    if (jaAtivo) {
      await dormir(4000);
      continue;
    }

    // Se a porta estiver presa por processo zumbi que não responde ao /api/health, limpa apenas o PID preso
    finalizarPidPresoNaPorta(PORT);

    const tInicio = Date.now();
    const outFd = fs.openSync(LOG_FILE, 'a');
    const child = spawn(process.execPath, [path.join(ROOT, 'server', 'index.js')], {
      cwd: ROOT,
      stdio: ['ignore', outFd, outFd],
      windowsHide: true,
      env: { ...process.env, PORT: String(PORT) },
    });

    const exitCode = await new Promise((resolve) => {
      child.on('close', (code) => resolve(code ?? 1));
      child.on('error', (err) => {
        registrarLog(`Erro ao iniciar server/index.js: ${err.message}`);
        resolve(1);
      });
    });
    try { fs.closeSync(outFd); } catch {}

    // Código 0 = encerrado intencionalmente (ex.: Parar_Flow_Studio.bat); Código 2 = EADDRINUSE (outro servidor assumiu)
    if (exitCode === 0 || exitCode === 2) {
      registrarLog(`Servidor encerrou normalmente (code=${exitCode}). Supervisor finalizando.`);
      break;
    }

    // Código 42 = restart imediato solicitado pelo Auto-Updater após atualizar arquivos
    if (exitCode === 42) {
      registrarLog('Reiniciando servidor após atualização automática...');
      falhasSeguidas = 0;
      await dormir(400);
      continue;
    }

    const duracaoMs = Date.now() - tInicio;
    falhasSeguidas = duracaoMs > 15000 ? 1 : falhasSeguidas + 1;
    const esperaMs = Math.min(1500 * falhasSeguidas, 10000);
    registrarLog(`server/index.js caiu com código ${exitCode}. Auto-restart em ${esperaMs}ms...`);
    await dormir(esperaMs);
  }
}

/**
 * Fluxo principal do launcher (acionado por INICIAR_APP.vbs):
 */
async function main() {
  const args = process.argv.slice(2);
  const modoDaemon = args.includes('--daemon');
  const semJanela = args.includes('--no-window');
  const forcarRestart = args.includes('--restart');

  if (modoDaemon) {
    await rodarSupervisorDaemon();
    return;
  }

  if (forcarRestart) {
    finalizarPidPresoNaPorta(PORT);
    await dormir(500);
  }

  // 1) Se http://127.0.0.1:3456/api/health já responder, abre a janela do app imediatamente!
  const healthInicial = await consultarHealth(1500);
  if (healthInicial) {
    registrarLog(`Servidor já ativo (v${healthInicial.version || '?'}). Abrindo janela standalone imediatamente.`);
    if (!semJanela) abrirJanelaApp(APP_URL);
    // Dispara checagem silenciosa de update em background (timeout 3s)
    dispararUpdateEmServidorAtivo().catch(() => {});
    return;
  }

  // 2) Se a porta 3456 estiver presa por processo travado que não responde ao /api/health, finaliza apenas o PID preso
  finalizarPidPresoNaPorta(PORT);

  // 3) Se faltar node_modules ou o package.json tiver mudado, roda npm install automaticamente
  garantirDependenciasInstaladas();

  // 4) Auto-Updater no boot com timeout máximo de 3s para nunca travar offline
  await verificarEAplicarAutoUpdateBoot();

  // 5) Sobe o supervisor do server/index.js em background oculto com auto-restart
  const daemon = spawn(process.execPath, [path.join(ROOT, 'launcher.mjs'), '--daemon'], {
    cwd: ROOT,
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  daemon.unref();

  // 6) Aguarda /api/health responder (até 20s) e abre o Chrome (ou Edge como fallback) em --app=http://localhost:3456
  for (let i = 0; i < 65; i++) {
    const h = await consultarHealth(800);
    if (h) {
      registrarLog(`Servidor pronto em /api/health (v${h.version}).`);
      break;
    }
    await dormir(300);
  }

  if (!semJanela) {
    abrirJanelaApp(APP_URL);
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main().catch((e) => {
    registrarLog(`Erro fatal no launcher: ${e.stack || e.message}`);
    process.exit(1);
  });
}
