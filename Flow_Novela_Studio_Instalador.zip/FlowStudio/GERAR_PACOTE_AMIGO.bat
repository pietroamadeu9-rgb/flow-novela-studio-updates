@echo off
setlocal
title Flow Novela Studio - Gerar Pacote para Amigo
cd /d "%~dp0"
set "PATH=%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;%PATH%"
echo.
echo Compilando interface e gerando Flow_Novela_Studio_Instalador.zip...
if exist "node_modules\vite\bin\vite.js" (
  call npm.cmd run build
)
node gerar_pacote.mjs
echo.
echo Pacote limpo gerado com sucesso na sua Area de Trabalho!
pause
endlocal
exit /b 0
