@echo off
setlocal
cd /d "C:\FlowStudio" 2>nul || cd /d "%~dp0"
if not exist "dados" mkdir "dados"
if not exist "dados\novelas" mkdir "dados\novelas"
if not exist "Meus_Projetos_Flow" mkdir "Meus_Projetos_Flow"

set "NODE_EXE="
if exist "C:\Program Files\nodejs\node.exe" set "NODE_EXE=C:\Program Files\nodejs\node.exe"
if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined NODE_EXE if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles(x86)%\nodejs\node.exe"
if not defined NODE_EXE (
  for /f "delims=" %%I in ('where.exe node 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%I"
)

if not defined NODE_EXE (
  echo [%DATE% %TIME%] [ERRO] node.exe nao encontrado no sistema.>> "dados\startup.log"
  exit /b 1
)

rem --- Limpa processo antigo preso na porta 3456 caso nao esteja respondendo ---
powershell -NoProfile -WindowStyle Hidden -Command "$conns = Get-NetTCPConnection -LocalPort 3456 -State Listen -ErrorAction SilentlyContinue; if ($conns) { $conns | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { if ($_ -gt 0) { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue } }; Start-Sleep -Milliseconds 400 }"

echo ==================================================>> "dados\startup.log"
echo [%DATE% %TIME%] Subindo Flow Novela Studio com "%NODE_EXE%"...>> "dados\startup.log"
"%NODE_EXE%" "server\index.js" >> "dados\startup.log" 2>&1
endlocal
