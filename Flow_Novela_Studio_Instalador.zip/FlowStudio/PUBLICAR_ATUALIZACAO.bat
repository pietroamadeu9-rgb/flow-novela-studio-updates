@echo off
setlocal
title Flow Novela Studio - Publicar Atualizacao no GitHub
color 0B
cd /d "C:\FlowStudio" 2>nul || cd /d "%~dp0"
set "PATH=%ProgramFiles%\GitHub CLI;%LOCALAPPDATA%\Programs\GitHub CLI;%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;%ProgramFiles%\Git\cmd;%PATH%"

echo.
echo  ==============================================================
echo     FLOW NOVELA STUDIO - PUBLICAR ATUALIZACAO PARA O AMIGO
echo  ==============================================================
echo.

node publicar_update.mjs %*
if errorlevel 1 (
  echo.
  echo  [AVISO] A publicacao parou ou precisa do seu login unico no GitHub.
  pause
  exit /b 1
)

echo.
pause
endlocal
exit /b 0
