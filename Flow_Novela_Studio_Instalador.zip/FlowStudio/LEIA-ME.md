# Flow Novela Studio

Estúdio local para produzir novelas verticais (9:16) no Google Flow, em duas partes conectadas:

| Parte | Onde | O que faz |
|---|---|---|
| App Desktop Local | `server/` (Node.js + Express + ws) e `web/` (React + Vite + Tailwind) | Roteiros, fila, galerias e arquivos — http://localhost:3456 |
| Extensão do Chrome (MV3) | `extensao-chrome/` | Conecta em `ws://localhost:3456`, mapeia o Google Flow e executa a automação |

Não usa nenhuma dependência nativa (sem node-gyp / Build Tools).

## Como instalar (PC novo) e abrir no dia a dia
- **Primeira vez em um PC novo:** dê dois cliques em **`1_INSTALAR_PRIMEIRA_VEZ.bat`** (verifica/instala o Node.js LTS, instala as dependências do servidor, cria as pastas e coloca o atalho **Flow Novela Studio** na Área de Trabalho).
- **Uso diário (1 clique):** use o atalho **`Flow Novela Studio`** na Área de Trabalho ou dê dois cliques em **`Iniciar_Flow_Studio.bat`** (sobe o servidor discreto na porta 3456 se ainda não estiver rodando e abre `http://localhost:3456` no navegador padrão). Também há o **`Abrir_Estudio.bat`** para abrir em modo janela de aplicativo do Edge.
- **Para encerrar tudo:** dê dois cliques em **`Parar_Flow_Studio.bat`**.

## Carregar a extensão (Edge ou Chrome)
1. Abra `edge://extensions` (ou `chrome://extensions`) e ative o **Modo do desenvolvedor**.
2. Clique em **Carregar sem compactação** (*Load unpacked*) e escolha `C:\FlowStudio\extensao-chrome`.
3. O topo do estúdio mostra **Extensão Conectada ✅**.

Endereços do Flow aceitos: `https://flow.google.com/*` e `https://labs.google/*` (ex.: `/fx/pt/tools/flow`).
O prefixo de conta `/u/<X>/` da aba aberta pelo usuário é detectado e preservado dinamicamente em toda navegação
(home, novo projeto, abrir projeto).

## Mapear o Google Flow (preparação da Etapa 3)
1. Abra o Google Flow (https://flow.google.com/u/SEU_NUMERO/) e entre em um projeto.
2. Clique no ícone da extensão → **🔍 Mapear Botões do Google Flow** (cria um mapa novo).
3. Para submenus: digite um rótulo (ex.: “menu de modelos aberto”), clique em **⏱ Capturar em 5s** e abra o menu no Flow. A captura é **adicionada** ao mapa.
4. **⏺ Gravar meus cliques** registra o caminho que você clica nos menus (vai junto na próxima captura).

Tudo é salvo em `dados/flow-dom-map.json`. O mapa anterior fica em `flow-dom-map.anterior.json`.

## Automação real (Etapa 3)
Calibrada em `dados/flow-selectors.json` (a extensão recarrega sozinha quando o arquivo muda). Para cada item:
1. Painel **Gatilho de configurações** → Modo Imagem/Vídeo → modelo → Tipo (Frames = frame inicial / Elementos) →
   maior resolução → duração 10/15 s → proporção **9:16** → quantidade **x1**.
2. Remove referências antigas e anexa cada `[ref]` pelo **nome exato** (Pesquisar recursos → Incluir no comando).
3. Cola o prompt com eventos reais de input e clica em **Iniciar geração**.
4. Espera a mídia nova aparecer de verdade, **renomeia** o ativo com o `{id}` e baixa pela opção de **maior resolução**.
   O navegador salva em `Downloads\FlowNovelaStudio_tmp\` e o servidor move para a pasta da novela.

> No Edge/Chrome, desative “Perguntar onde salvar cada arquivo” para os downloads não pararem numa janela.

## Estrutura de dados
```
dados/
  novelas/<id>.json        uma novela por arquivo (roteiro, itens, status, flowProjectUrl)
  config.json              listas de modelos de imagem/vídeo
  flow-selectors.json      seletores do Flow (preenchidos na Etapa 3; null = não calibrado)
  flow-dom-map.json        relatório do mapeamento
Meus_Projetos_Flow/<Novela>/
  01_Referencias/<id>.png
  02_Imagens_Base/<id>.png
  03_Videos/<id>.mp4
```

## Regras do roteiro
- `{id}` sozinho na linha define o nome do arquivo do item seguinte.
- `(i) texto` → referência (texto puro, 9:16) → `01_Referencias/<id>.png`
- `(i) [ref_a] [ref_b] texto` → imagem-base (ingredientes, na ordem) → `02_Imagens_Base/<id>.png`
- `(v) [imagem_01] texto` → vídeo; duração lida de “10 seconds”/“15 seconds” (padrão 10). 1 ref = frame inicial; 2+ refs ou “Forçar Modo Elementos” = elementos → `03_Videos/<id>.mp4`
- Títulos (`BLOCO…`, `Imagem-base:…`, `Parte…`) são ignorados.
- O validador bloqueia a fila se alguma `[ref]` não tiver sido declarada antes num `{id}`.

Teste do parser: `npm run test:parser`

## Comandos
- `npm start` – inicia o servidor
- `npm run build` – recompila a interface
- `npm run dev` – interface em modo desenvolvimento (http://localhost:5173, usa o servidor na 3456)
